(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))r(o);new MutationObserver(o=>{for(const l of o)if(l.type==="childList")for(const u of l.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&r(u)}).observe(document,{childList:!0,subtree:!0});function t(o){const l={};return o.integrity&&(l.integrity=o.integrity),o.referrerPolicy&&(l.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?l.credentials="include":o.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function r(o){if(o.ep)return;o.ep=!0;const l=t(o);fetch(o.href,l)}})();function W0(s){return s&&s.__esModule&&Object.prototype.hasOwnProperty.call(s,"default")?s.default:s}var Rd={exports:{}},Sa={},Pd={exports:{}},Lt={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ug;function Ny(){if(ug)return Lt;ug=1;var s=Symbol.for("react.element"),e=Symbol.for("react.portal"),t=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),l=Symbol.for("react.provider"),u=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),f=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),y=Symbol.for("react.lazy"),S=Symbol.iterator;function v(O){return O===null||typeof O!="object"?null:(O=S&&O[S]||O["@@iterator"],typeof O=="function"?O:null)}var _={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},M=Object.assign,A={};function m(O,de,Ce){this.props=O,this.context=de,this.refs=A,this.updater=Ce||_}m.prototype.isReactComponent={},m.prototype.setState=function(O,de){if(typeof O!="object"&&typeof O!="function"&&O!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,O,de,"setState")},m.prototype.forceUpdate=function(O){this.updater.enqueueForceUpdate(this,O,"forceUpdate")};function x(){}x.prototype=m.prototype;function P(O,de,Ce){this.props=O,this.context=de,this.refs=A,this.updater=Ce||_}var U=P.prototype=new x;U.constructor=P,M(U,m.prototype),U.isPureReactComponent=!0;var b=Array.isArray,R=Object.prototype.hasOwnProperty,N={current:null},F={key:!0,ref:!0,__self:!0,__source:!0};function E(O,de,Ce){var Te,De={},Ye=null,le=null;if(de!=null)for(Te in de.ref!==void 0&&(le=de.ref),de.key!==void 0&&(Ye=""+de.key),de)R.call(de,Te)&&!F.hasOwnProperty(Te)&&(De[Te]=de[Te]);var ge=arguments.length-2;if(ge===1)De.children=Ce;else if(1<ge){for(var Ne=Array(ge),tt=0;tt<ge;tt++)Ne[tt]=arguments[tt+2];De.children=Ne}if(O&&O.defaultProps)for(Te in ge=O.defaultProps,ge)De[Te]===void 0&&(De[Te]=ge[Te]);return{$$typeof:s,type:O,key:Ye,ref:le,props:De,_owner:N.current}}function L(O,de){return{$$typeof:s,type:O.type,key:de,ref:O.ref,props:O.props,_owner:O._owner}}function B(O){return typeof O=="object"&&O!==null&&O.$$typeof===s}function X(O){var de={"=":"=0",":":"=2"};return"$"+O.replace(/[=:]/g,function(Ce){return de[Ce]})}var j=/\/+/g;function ne(O,de){return typeof O=="object"&&O!==null&&O.key!=null?X(""+O.key):de.toString(36)}function H(O,de,Ce,Te,De){var Ye=typeof O;(Ye==="undefined"||Ye==="boolean")&&(O=null);var le=!1;if(O===null)le=!0;else switch(Ye){case"string":case"number":le=!0;break;case"object":switch(O.$$typeof){case s:case e:le=!0}}if(le)return le=O,De=De(le),O=Te===""?"."+ne(le,0):Te,b(De)?(Ce="",O!=null&&(Ce=O.replace(j,"$&/")+"/"),H(De,de,Ce,"",function(tt){return tt})):De!=null&&(B(De)&&(De=L(De,Ce+(!De.key||le&&le.key===De.key?"":(""+De.key).replace(j,"$&/")+"/")+O)),de.push(De)),1;if(le=0,Te=Te===""?".":Te+":",b(O))for(var ge=0;ge<O.length;ge++){Ye=O[ge];var Ne=Te+ne(Ye,ge);le+=H(Ye,de,Ce,Ne,De)}else if(Ne=v(O),typeof Ne=="function")for(O=Ne.call(O),ge=0;!(Ye=O.next()).done;)Ye=Ye.value,Ne=Te+ne(Ye,ge++),le+=H(Ye,de,Ce,Ne,De);else if(Ye==="object")throw de=String(O),Error("Objects are not valid as a React child (found: "+(de==="[object Object]"?"object with keys {"+Object.keys(O).join(", ")+"}":de)+"). If you meant to render a collection of children, use an array instead.");return le}function W(O,de,Ce){if(O==null)return O;var Te=[],De=0;return H(O,Te,"","",function(Ye){return de.call(Ce,Ye,De++)}),Te}function ue(O){if(O._status===-1){var de=O._result;de=de(),de.then(function(Ce){(O._status===0||O._status===-1)&&(O._status=1,O._result=Ce)},function(Ce){(O._status===0||O._status===-1)&&(O._status=2,O._result=Ce)}),O._status===-1&&(O._status=0,O._result=de)}if(O._status===1)return O._result.default;throw O._result}var Q={current:null},te={transition:null},G={ReactCurrentDispatcher:Q,ReactCurrentBatchConfig:te,ReactCurrentOwner:N};function ee(){throw Error("act(...) is not supported in production builds of React.")}return Lt.Children={map:W,forEach:function(O,de,Ce){W(O,function(){de.apply(this,arguments)},Ce)},count:function(O){var de=0;return W(O,function(){de++}),de},toArray:function(O){return W(O,function(de){return de})||[]},only:function(O){if(!B(O))throw Error("React.Children.only expected to receive a single React element child.");return O}},Lt.Component=m,Lt.Fragment=t,Lt.Profiler=o,Lt.PureComponent=P,Lt.StrictMode=r,Lt.Suspense=f,Lt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=G,Lt.act=ee,Lt.cloneElement=function(O,de,Ce){if(O==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+O+".");var Te=M({},O.props),De=O.key,Ye=O.ref,le=O._owner;if(de!=null){if(de.ref!==void 0&&(Ye=de.ref,le=N.current),de.key!==void 0&&(De=""+de.key),O.type&&O.type.defaultProps)var ge=O.type.defaultProps;for(Ne in de)R.call(de,Ne)&&!F.hasOwnProperty(Ne)&&(Te[Ne]=de[Ne]===void 0&&ge!==void 0?ge[Ne]:de[Ne])}var Ne=arguments.length-2;if(Ne===1)Te.children=Ce;else if(1<Ne){ge=Array(Ne);for(var tt=0;tt<Ne;tt++)ge[tt]=arguments[tt+2];Te.children=ge}return{$$typeof:s,type:O.type,key:De,ref:Ye,props:Te,_owner:le}},Lt.createContext=function(O){return O={$$typeof:u,_currentValue:O,_currentValue2:O,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},O.Provider={$$typeof:l,_context:O},O.Consumer=O},Lt.createElement=E,Lt.createFactory=function(O){var de=E.bind(null,O);return de.type=O,de},Lt.createRef=function(){return{current:null}},Lt.forwardRef=function(O){return{$$typeof:d,render:O}},Lt.isValidElement=B,Lt.lazy=function(O){return{$$typeof:y,_payload:{_status:-1,_result:O},_init:ue}},Lt.memo=function(O,de){return{$$typeof:p,type:O,compare:de===void 0?null:de}},Lt.startTransition=function(O){var de=te.transition;te.transition={};try{O()}finally{te.transition=de}},Lt.unstable_act=ee,Lt.useCallback=function(O,de){return Q.current.useCallback(O,de)},Lt.useContext=function(O){return Q.current.useContext(O)},Lt.useDebugValue=function(){},Lt.useDeferredValue=function(O){return Q.current.useDeferredValue(O)},Lt.useEffect=function(O,de){return Q.current.useEffect(O,de)},Lt.useId=function(){return Q.current.useId()},Lt.useImperativeHandle=function(O,de,Ce){return Q.current.useImperativeHandle(O,de,Ce)},Lt.useInsertionEffect=function(O,de){return Q.current.useInsertionEffect(O,de)},Lt.useLayoutEffect=function(O,de){return Q.current.useLayoutEffect(O,de)},Lt.useMemo=function(O,de){return Q.current.useMemo(O,de)},Lt.useReducer=function(O,de,Ce){return Q.current.useReducer(O,de,Ce)},Lt.useRef=function(O){return Q.current.useRef(O)},Lt.useState=function(O){return Q.current.useState(O)},Lt.useSyncExternalStore=function(O,de,Ce){return Q.current.useSyncExternalStore(O,de,Ce)},Lt.useTransition=function(){return Q.current.useTransition()},Lt.version="18.3.1",Lt}var dg;function vh(){return dg||(dg=1,Pd.exports=Ny()),Pd.exports}/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var fg;function Dy(){if(fg)return Sa;fg=1;var s=vh(),e=Symbol.for("react.element"),t=Symbol.for("react.fragment"),r=Object.prototype.hasOwnProperty,o=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function u(d,f,p){var y,S={},v=null,_=null;p!==void 0&&(v=""+p),f.key!==void 0&&(v=""+f.key),f.ref!==void 0&&(_=f.ref);for(y in f)r.call(f,y)&&!l.hasOwnProperty(y)&&(S[y]=f[y]);if(d&&d.defaultProps)for(y in f=d.defaultProps,f)S[y]===void 0&&(S[y]=f[y]);return{$$typeof:e,type:d,key:v,ref:_,props:S,_owner:o.current}}return Sa.Fragment=t,Sa.jsx=u,Sa.jsxs=u,Sa}var hg;function Uy(){return hg||(hg=1,Rd.exports=Dy()),Rd.exports}var T=Uy(),Be=vh();const j0=W0(Be);var $l={},Id={exports:{}},ai={},Ld={exports:{}},Nd={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var pg;function Fy(){return pg||(pg=1,(function(s){function e(te,G){var ee=te.length;te.push(G);e:for(;0<ee;){var O=ee-1>>>1,de=te[O];if(0<o(de,G))te[O]=G,te[ee]=de,ee=O;else break e}}function t(te){return te.length===0?null:te[0]}function r(te){if(te.length===0)return null;var G=te[0],ee=te.pop();if(ee!==G){te[0]=ee;e:for(var O=0,de=te.length,Ce=de>>>1;O<Ce;){var Te=2*(O+1)-1,De=te[Te],Ye=Te+1,le=te[Ye];if(0>o(De,ee))Ye<de&&0>o(le,De)?(te[O]=le,te[Ye]=ee,O=Ye):(te[O]=De,te[Te]=ee,O=Te);else if(Ye<de&&0>o(le,ee))te[O]=le,te[Ye]=ee,O=Ye;else break e}}return G}function o(te,G){var ee=te.sortIndex-G.sortIndex;return ee!==0?ee:te.id-G.id}if(typeof performance=="object"&&typeof performance.now=="function"){var l=performance;s.unstable_now=function(){return l.now()}}else{var u=Date,d=u.now();s.unstable_now=function(){return u.now()-d}}var f=[],p=[],y=1,S=null,v=3,_=!1,M=!1,A=!1,m=typeof setTimeout=="function"?setTimeout:null,x=typeof clearTimeout=="function"?clearTimeout:null,P=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function U(te){for(var G=t(p);G!==null;){if(G.callback===null)r(p);else if(G.startTime<=te)r(p),G.sortIndex=G.expirationTime,e(f,G);else break;G=t(p)}}function b(te){if(A=!1,U(te),!M)if(t(f)!==null)M=!0,ue(R);else{var G=t(p);G!==null&&Q(b,G.startTime-te)}}function R(te,G){M=!1,A&&(A=!1,x(E),E=-1),_=!0;var ee=v;try{for(U(G),S=t(f);S!==null&&(!(S.expirationTime>G)||te&&!X());){var O=S.callback;if(typeof O=="function"){S.callback=null,v=S.priorityLevel;var de=O(S.expirationTime<=G);G=s.unstable_now(),typeof de=="function"?S.callback=de:S===t(f)&&r(f),U(G)}else r(f);S=t(f)}if(S!==null)var Ce=!0;else{var Te=t(p);Te!==null&&Q(b,Te.startTime-G),Ce=!1}return Ce}finally{S=null,v=ee,_=!1}}var N=!1,F=null,E=-1,L=5,B=-1;function X(){return!(s.unstable_now()-B<L)}function j(){if(F!==null){var te=s.unstable_now();B=te;var G=!0;try{G=F(!0,te)}finally{G?ne():(N=!1,F=null)}}else N=!1}var ne;if(typeof P=="function")ne=function(){P(j)};else if(typeof MessageChannel<"u"){var H=new MessageChannel,W=H.port2;H.port1.onmessage=j,ne=function(){W.postMessage(null)}}else ne=function(){m(j,0)};function ue(te){F=te,N||(N=!0,ne())}function Q(te,G){E=m(function(){te(s.unstable_now())},G)}s.unstable_IdlePriority=5,s.unstable_ImmediatePriority=1,s.unstable_LowPriority=4,s.unstable_NormalPriority=3,s.unstable_Profiling=null,s.unstable_UserBlockingPriority=2,s.unstable_cancelCallback=function(te){te.callback=null},s.unstable_continueExecution=function(){M||_||(M=!0,ue(R))},s.unstable_forceFrameRate=function(te){0>te||125<te?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):L=0<te?Math.floor(1e3/te):5},s.unstable_getCurrentPriorityLevel=function(){return v},s.unstable_getFirstCallbackNode=function(){return t(f)},s.unstable_next=function(te){switch(v){case 1:case 2:case 3:var G=3;break;default:G=v}var ee=v;v=G;try{return te()}finally{v=ee}},s.unstable_pauseExecution=function(){},s.unstable_requestPaint=function(){},s.unstable_runWithPriority=function(te,G){switch(te){case 1:case 2:case 3:case 4:case 5:break;default:te=3}var ee=v;v=te;try{return G()}finally{v=ee}},s.unstable_scheduleCallback=function(te,G,ee){var O=s.unstable_now();switch(typeof ee=="object"&&ee!==null?(ee=ee.delay,ee=typeof ee=="number"&&0<ee?O+ee:O):ee=O,te){case 1:var de=-1;break;case 2:de=250;break;case 5:de=1073741823;break;case 4:de=1e4;break;default:de=5e3}return de=ee+de,te={id:y++,callback:G,priorityLevel:te,startTime:ee,expirationTime:de,sortIndex:-1},ee>O?(te.sortIndex=ee,e(p,te),t(f)===null&&te===t(p)&&(A?(x(E),E=-1):A=!0,Q(b,ee-O))):(te.sortIndex=de,e(f,te),M||_||(M=!0,ue(R))),te},s.unstable_shouldYield=X,s.unstable_wrapCallback=function(te){var G=v;return function(){var ee=v;v=G;try{return te.apply(this,arguments)}finally{v=ee}}}})(Nd)),Nd}var mg;function Oy(){return mg||(mg=1,Ld.exports=Fy()),Ld.exports}/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var gg;function ky(){if(gg)return ai;gg=1;var s=vh(),e=Oy();function t(n){for(var i="https://reactjs.org/docs/error-decoder.html?invariant="+n,a=1;a<arguments.length;a++)i+="&args[]="+encodeURIComponent(arguments[a]);return"Minified React error #"+n+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var r=new Set,o={};function l(n,i){u(n,i),u(n+"Capture",i)}function u(n,i){for(o[n]=i,n=0;n<i.length;n++)r.add(i[n])}var d=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),f=Object.prototype.hasOwnProperty,p=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,y={},S={};function v(n){return f.call(S,n)?!0:f.call(y,n)?!1:p.test(n)?S[n]=!0:(y[n]=!0,!1)}function _(n,i,a,c){if(a!==null&&a.type===0)return!1;switch(typeof i){case"function":case"symbol":return!0;case"boolean":return c?!1:a!==null?!a.acceptsBooleans:(n=n.toLowerCase().slice(0,5),n!=="data-"&&n!=="aria-");default:return!1}}function M(n,i,a,c){if(i===null||typeof i>"u"||_(n,i,a,c))return!0;if(c)return!1;if(a!==null)switch(a.type){case 3:return!i;case 4:return i===!1;case 5:return isNaN(i);case 6:return isNaN(i)||1>i}return!1}function A(n,i,a,c,h,g,C){this.acceptsBooleans=i===2||i===3||i===4,this.attributeName=c,this.attributeNamespace=h,this.mustUseProperty=a,this.propertyName=n,this.type=i,this.sanitizeURL=g,this.removeEmptyString=C}var m={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n){m[n]=new A(n,0,!1,n,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(n){var i=n[0];m[i]=new A(i,1,!1,n[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(n){m[n]=new A(n,2,!1,n.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(n){m[n]=new A(n,2,!1,n,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n){m[n]=new A(n,3,!1,n.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(n){m[n]=new A(n,3,!0,n,null,!1,!1)}),["capture","download"].forEach(function(n){m[n]=new A(n,4,!1,n,null,!1,!1)}),["cols","rows","size","span"].forEach(function(n){m[n]=new A(n,6,!1,n,null,!1,!1)}),["rowSpan","start"].forEach(function(n){m[n]=new A(n,5,!1,n.toLowerCase(),null,!1,!1)});var x=/[\-:]([a-z])/g;function P(n){return n[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n){var i=n.replace(x,P);m[i]=new A(i,1,!1,n,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n){var i=n.replace(x,P);m[i]=new A(i,1,!1,n,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(n){var i=n.replace(x,P);m[i]=new A(i,1,!1,n,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(n){m[n]=new A(n,1,!1,n.toLowerCase(),null,!1,!1)}),m.xlinkHref=new A("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(n){m[n]=new A(n,1,!1,n.toLowerCase(),null,!0,!0)});function U(n,i,a,c){var h=m.hasOwnProperty(i)?m[i]:null;(h!==null?h.type!==0:c||!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")&&(M(i,a,h,c)&&(a=null),c||h===null?v(i)&&(a===null?n.removeAttribute(i):n.setAttribute(i,""+a)):h.mustUseProperty?n[h.propertyName]=a===null?h.type===3?!1:"":a:(i=h.attributeName,c=h.attributeNamespace,a===null?n.removeAttribute(i):(h=h.type,a=h===3||h===4&&a===!0?"":""+a,c?n.setAttributeNS(c,i,a):n.setAttribute(i,a))))}var b=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,R=Symbol.for("react.element"),N=Symbol.for("react.portal"),F=Symbol.for("react.fragment"),E=Symbol.for("react.strict_mode"),L=Symbol.for("react.profiler"),B=Symbol.for("react.provider"),X=Symbol.for("react.context"),j=Symbol.for("react.forward_ref"),ne=Symbol.for("react.suspense"),H=Symbol.for("react.suspense_list"),W=Symbol.for("react.memo"),ue=Symbol.for("react.lazy"),Q=Symbol.for("react.offscreen"),te=Symbol.iterator;function G(n){return n===null||typeof n!="object"?null:(n=te&&n[te]||n["@@iterator"],typeof n=="function"?n:null)}var ee=Object.assign,O;function de(n){if(O===void 0)try{throw Error()}catch(a){var i=a.stack.trim().match(/\n( *(at )?)/);O=i&&i[1]||""}return`
`+O+n}var Ce=!1;function Te(n,i){if(!n||Ce)return"";Ce=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(i)if(i=function(){throw Error()},Object.defineProperty(i.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(i,[])}catch(xe){var c=xe}Reflect.construct(n,[],i)}else{try{i.call()}catch(xe){c=xe}n.call(i.prototype)}else{try{throw Error()}catch(xe){c=xe}n()}}catch(xe){if(xe&&c&&typeof xe.stack=="string"){for(var h=xe.stack.split(`
`),g=c.stack.split(`
`),C=h.length-1,z=g.length-1;1<=C&&0<=z&&h[C]!==g[z];)z--;for(;1<=C&&0<=z;C--,z--)if(h[C]!==g[z]){if(C!==1||z!==1)do if(C--,z--,0>z||h[C]!==g[z]){var Y=`
`+h[C].replace(" at new "," at ");return n.displayName&&Y.includes("<anonymous>")&&(Y=Y.replace("<anonymous>",n.displayName)),Y}while(1<=C&&0<=z);break}}}finally{Ce=!1,Error.prepareStackTrace=a}return(n=n?n.displayName||n.name:"")?de(n):""}function De(n){switch(n.tag){case 5:return de(n.type);case 16:return de("Lazy");case 13:return de("Suspense");case 19:return de("SuspenseList");case 0:case 2:case 15:return n=Te(n.type,!1),n;case 11:return n=Te(n.type.render,!1),n;case 1:return n=Te(n.type,!0),n;default:return""}}function Ye(n){if(n==null)return null;if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case F:return"Fragment";case N:return"Portal";case L:return"Profiler";case E:return"StrictMode";case ne:return"Suspense";case H:return"SuspenseList"}if(typeof n=="object")switch(n.$$typeof){case X:return(n.displayName||"Context")+".Consumer";case B:return(n._context.displayName||"Context")+".Provider";case j:var i=n.render;return n=n.displayName,n||(n=i.displayName||i.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case W:return i=n.displayName||null,i!==null?i:Ye(n.type)||"Memo";case ue:i=n._payload,n=n._init;try{return Ye(n(i))}catch{}}return null}function le(n){var i=n.type;switch(n.tag){case 24:return"Cache";case 9:return(i.displayName||"Context")+".Consumer";case 10:return(i._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return n=i.render,n=n.displayName||n.name||"",i.displayName||(n!==""?"ForwardRef("+n+")":"ForwardRef");case 7:return"Fragment";case 5:return i;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Ye(i);case 8:return i===E?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof i=="function")return i.displayName||i.name||null;if(typeof i=="string")return i}return null}function ge(n){switch(typeof n){case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function Ne(n){var i=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function tt(n){var i=Ne(n)?"checked":"value",a=Object.getOwnPropertyDescriptor(n.constructor.prototype,i),c=""+n[i];if(!n.hasOwnProperty(i)&&typeof a<"u"&&typeof a.get=="function"&&typeof a.set=="function"){var h=a.get,g=a.set;return Object.defineProperty(n,i,{configurable:!0,get:function(){return h.call(this)},set:function(C){c=""+C,g.call(this,C)}}),Object.defineProperty(n,i,{enumerable:a.enumerable}),{getValue:function(){return c},setValue:function(C){c=""+C},stopTracking:function(){n._valueTracker=null,delete n[i]}}}}function Xe(n){n._valueTracker||(n._valueTracker=tt(n))}function mt(n){if(!n)return!1;var i=n._valueTracker;if(!i)return!0;var a=i.getValue(),c="";return n&&(c=Ne(n)?n.checked?"true":"false":n.value),n=c,n!==a?(i.setValue(n),!0):!1}function Gt(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}function lt(n,i){var a=i.checked;return ee({},i,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:a??n._wrapperState.initialChecked})}function Et(n,i){var a=i.defaultValue==null?"":i.defaultValue,c=i.checked!=null?i.checked:i.defaultChecked;a=ge(i.value!=null?i.value:a),n._wrapperState={initialChecked:c,initialValue:a,controlled:i.type==="checkbox"||i.type==="radio"?i.checked!=null:i.value!=null}}function Ot(n,i){i=i.checked,i!=null&&U(n,"checked",i,!1)}function xt(n,i){Ot(n,i);var a=ge(i.value),c=i.type;if(a!=null)c==="number"?(a===0&&n.value===""||n.value!=a)&&(n.value=""+a):n.value!==""+a&&(n.value=""+a);else if(c==="submit"||c==="reset"){n.removeAttribute("value");return}i.hasOwnProperty("value")?Xt(n,i.type,a):i.hasOwnProperty("defaultValue")&&Xt(n,i.type,ge(i.defaultValue)),i.checked==null&&i.defaultChecked!=null&&(n.defaultChecked=!!i.defaultChecked)}function At(n,i,a){if(i.hasOwnProperty("value")||i.hasOwnProperty("defaultValue")){var c=i.type;if(!(c!=="submit"&&c!=="reset"||i.value!==void 0&&i.value!==null))return;i=""+n._wrapperState.initialValue,a||i===n.value||(n.value=i),n.defaultValue=i}a=n.name,a!==""&&(n.name=""),n.defaultChecked=!!n._wrapperState.initialChecked,a!==""&&(n.name=a)}function Xt(n,i,a){(i!=="number"||Gt(n.ownerDocument)!==n)&&(a==null?n.defaultValue=""+n._wrapperState.initialValue:n.defaultValue!==""+a&&(n.defaultValue=""+a))}var Wt=Array.isArray;function _t(n,i,a,c){if(n=n.options,i){i={};for(var h=0;h<a.length;h++)i["$"+a[h]]=!0;for(a=0;a<n.length;a++)h=i.hasOwnProperty("$"+n[a].value),n[a].selected!==h&&(n[a].selected=h),h&&c&&(n[a].defaultSelected=!0)}else{for(a=""+ge(a),i=null,h=0;h<n.length;h++){if(n[h].value===a){n[h].selected=!0,c&&(n[h].defaultSelected=!0);return}i!==null||n[h].disabled||(i=n[h])}i!==null&&(i.selected=!0)}}function Nt(n,i){if(i.dangerouslySetInnerHTML!=null)throw Error(t(91));return ee({},i,{value:void 0,defaultValue:void 0,children:""+n._wrapperState.initialValue})}function $(n,i){var a=i.value;if(a==null){if(a=i.children,i=i.defaultValue,a!=null){if(i!=null)throw Error(t(92));if(Wt(a)){if(1<a.length)throw Error(t(93));a=a[0]}i=a}i==null&&(i=""),a=i}n._wrapperState={initialValue:ge(a)}}function It(n,i){var a=ge(i.value),c=ge(i.defaultValue);a!=null&&(a=""+a,a!==n.value&&(n.value=a),i.defaultValue==null&&n.defaultValue!==a&&(n.defaultValue=a)),c!=null&&(n.defaultValue=""+c)}function wt(n){var i=n.textContent;i===n._wrapperState.initialValue&&i!==""&&i!==null&&(n.value=i)}function k(n){switch(n){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function w(n,i){return n==null||n==="http://www.w3.org/1999/xhtml"?k(i):n==="http://www.w3.org/2000/svg"&&i==="foreignObject"?"http://www.w3.org/1999/xhtml":n}var re,he=(function(n){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(i,a,c,h){MSApp.execUnsafeLocalFunction(function(){return n(i,a,c,h)})}:n})(function(n,i){if(n.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in n)n.innerHTML=i;else{for(re=re||document.createElement("div"),re.innerHTML="<svg>"+i.valueOf().toString()+"</svg>",i=re.firstChild;n.firstChild;)n.removeChild(n.firstChild);for(;i.firstChild;)n.appendChild(i.firstChild)}});function ye(n,i){if(i){var a=n.firstChild;if(a&&a===n.lastChild&&a.nodeType===3){a.nodeValue=i;return}}n.textContent=i}var Pe={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},fe=["Webkit","ms","Moz","O"];Object.keys(Pe).forEach(function(n){fe.forEach(function(i){i=i+n.charAt(0).toUpperCase()+n.substring(1),Pe[i]=Pe[n]})});function ie(n,i,a){return i==null||typeof i=="boolean"||i===""?"":a||typeof i!="number"||i===0||Pe.hasOwnProperty(n)&&Pe[n]?(""+i).trim():i+"px"}function se(n,i){n=n.style;for(var a in i)if(i.hasOwnProperty(a)){var c=a.indexOf("--")===0,h=ie(a,i[a],c);a==="float"&&(a="cssFloat"),c?n.setProperty(a,h):n[a]=h}}var be=ee({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Fe(n,i){if(i){if(be[n]&&(i.children!=null||i.dangerouslySetInnerHTML!=null))throw Error(t(137,n));if(i.dangerouslySetInnerHTML!=null){if(i.children!=null)throw Error(t(60));if(typeof i.dangerouslySetInnerHTML!="object"||!("__html"in i.dangerouslySetInnerHTML))throw Error(t(61))}if(i.style!=null&&typeof i.style!="object")throw Error(t(62))}}function ve(n,i){if(n.indexOf("-")===-1)return typeof i.is=="string";switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Ee=null;function K(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var Ue=null,_e=null,V=null;function Oe(n){if(n=oa(n)){if(typeof Ue!="function")throw Error(t(280));var i=n.stateNode;i&&(i=dl(i),Ue(n.stateNode,n.type,i))}}function Se(n){_e?V?V.push(n):V=[n]:_e=n}function Ve(){if(_e){var n=_e,i=V;if(V=_e=null,Oe(n),i)for(n=0;n<i.length;n++)Oe(i[n])}}function Ge(n,i){return n(i)}function we(){}var rt=!1;function $e(n,i,a){if(rt)return n(i,a);rt=!0;try{return Ge(n,i,a)}finally{rt=!1,(_e!==null||V!==null)&&(we(),Ve())}}function Ut(n,i){var a=n.stateNode;if(a===null)return null;var c=dl(a);if(c===null)return null;a=c[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(c=!c.disabled)||(n=n.type,c=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!c;break e;default:n=!1}if(n)return null;if(a&&typeof a!="function")throw Error(t(231,i,typeof a));return a}var bt=!1;if(d)try{var fn={};Object.defineProperty(fn,"passive",{get:function(){bt=!0}}),window.addEventListener("test",fn,fn),window.removeEventListener("test",fn,fn)}catch{bt=!1}function ei(n,i,a,c,h,g,C,z,Y){var xe=Array.prototype.slice.call(arguments,3);try{i.apply(a,xe)}catch(Ie){this.onError(Ie)}}var xi=!1,ji=null,Xi=!1,bi=null,lr={onError:function(n){xi=!0,ji=n}};function Yi(n,i,a,c,h,g,C,z,Y){xi=!1,ji=null,ei.apply(lr,arguments)}function Vs(n,i,a,c,h,g,C,z,Y){if(Yi.apply(this,arguments),xi){if(xi){var xe=ji;xi=!1,ji=null}else throw Error(t(198));Xi||(Xi=!0,bi=xe)}}function wn(n){var i=n,a=n;if(n.alternate)for(;i.return;)i=i.return;else{n=i;do i=n,(i.flags&4098)!==0&&(a=i.return),n=i.return;while(n)}return i.tag===3?a:null}function cr(n){if(n.tag===13){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function Lr(n){if(wn(n)!==n)throw Error(t(188))}function Hs(n){var i=n.alternate;if(!i){if(i=wn(n),i===null)throw Error(t(188));return i!==n?null:n}for(var a=n,c=i;;){var h=a.return;if(h===null)break;var g=h.alternate;if(g===null){if(c=h.return,c!==null){a=c;continue}break}if(h.child===g.child){for(g=h.child;g;){if(g===a)return Lr(h),n;if(g===c)return Lr(h),i;g=g.sibling}throw Error(t(188))}if(a.return!==c.return)a=h,c=g;else{for(var C=!1,z=h.child;z;){if(z===a){C=!0,a=h,c=g;break}if(z===c){C=!0,c=h,a=g;break}z=z.sibling}if(!C){for(z=g.child;z;){if(z===a){C=!0,a=g,c=h;break}if(z===c){C=!0,c=g,a=h;break}z=z.sibling}if(!C)throw Error(t(189))}}if(a.alternate!==c)throw Error(t(190))}if(a.tag!==3)throw Error(t(188));return a.stateNode.current===a?n:i}function qi(n){return n=Hs(n),n!==null?Nr(n):null}function Nr(n){if(n.tag===5||n.tag===6)return n;for(n=n.child;n!==null;){var i=Nr(n);if(i!==null)return i;n=n.sibling}return null}var Fn=e.unstable_scheduleCallback,ur=e.unstable_cancelCallback,ti=e.unstable_shouldYield,Go=e.unstable_requestPaint,$t=e.unstable_now,Gs=e.unstable_getCurrentPriorityLevel,Dr=e.unstable_ImmediatePriority,Ur=e.unstable_UserBlockingPriority,I=e.unstable_NormalPriority,q=e.unstable_LowPriority,me=e.unstable_IdlePriority,ae=null,oe=null;function We(n){if(oe&&typeof oe.onCommitFiberRoot=="function")try{oe.onCommitFiberRoot(ae,n,void 0,(n.current.flags&128)===128)}catch{}}var ze=Math.clz32?Math.clz32:nt,je=Math.log,Je=Math.LN2;function nt(n){return n>>>=0,n===0?32:31-(je(n)/Je|0)|0}var pt=64,Me=4194304;function Ae(n){switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return n&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return n}}function He(n,i){var a=n.pendingLanes;if(a===0)return 0;var c=0,h=n.suspendedLanes,g=n.pingedLanes,C=a&268435455;if(C!==0){var z=C&~h;z!==0?c=Ae(z):(g&=C,g!==0&&(c=Ae(g)))}else C=a&~h,C!==0?c=Ae(C):g!==0&&(c=Ae(g));if(c===0)return 0;if(i!==0&&i!==c&&(i&h)===0&&(h=c&-c,g=i&-i,h>=g||h===16&&(g&4194240)!==0))return i;if((c&4)!==0&&(c|=a&16),i=n.entangledLanes,i!==0)for(n=n.entanglements,i&=c;0<i;)a=31-ze(i),h=1<<a,c|=n[a],i&=~h;return c}function at(n,i){switch(n){case 1:case 2:case 4:return i+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function ft(n,i){for(var a=n.suspendedLanes,c=n.pingedLanes,h=n.expirationTimes,g=n.pendingLanes;0<g;){var C=31-ze(g),z=1<<C,Y=h[C];Y===-1?((z&a)===0||(z&c)!==0)&&(h[C]=at(z,i)):Y<=i&&(n.expiredLanes|=z),g&=~z}}function et(n){return n=n.pendingLanes&-1073741825,n!==0?n:n&1073741824?1073741824:0}function St(){var n=pt;return pt<<=1,(pt&4194240)===0&&(pt=64),n}function qe(n){for(var i=[],a=0;31>a;a++)i.push(n);return i}function Qt(n,i,a){n.pendingLanes|=i,i!==536870912&&(n.suspendedLanes=0,n.pingedLanes=0),n=n.eventTimes,i=31-ze(i),n[i]=a}function Tt(n,i){var a=n.pendingLanes&~i;n.pendingLanes=i,n.suspendedLanes=0,n.pingedLanes=0,n.expiredLanes&=i,n.mutableReadLanes&=i,n.entangledLanes&=i,i=n.entanglements;var c=n.eventTimes;for(n=n.expirationTimes;0<a;){var h=31-ze(a),g=1<<h;i[h]=0,c[h]=-1,n[h]=-1,a&=~g}}function ln(n,i){var a=n.entangledLanes|=i;for(n=n.entanglements;a;){var c=31-ze(a),h=1<<c;h&i|n[c]&i&&(n[c]|=i),a&=~h}}var Mt=0;function en(n){return n&=-n,1<n?4<n?(n&268435455)!==0?16:536870912:4:1}var Tn,Rt,Vt,vn,Ft,cn=!1,On=[],qn=null,Fr=null,Or=null,Wo=new Map,jo=new Map,kr=[],tx="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Yh(n,i){switch(n){case"focusin":case"focusout":qn=null;break;case"dragenter":case"dragleave":Fr=null;break;case"mouseover":case"mouseout":Or=null;break;case"pointerover":case"pointerout":Wo.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":jo.delete(i.pointerId)}}function Xo(n,i,a,c,h,g){return n===null||n.nativeEvent!==g?(n={blockedOn:i,domEventName:a,eventSystemFlags:c,nativeEvent:g,targetContainers:[h]},i!==null&&(i=oa(i),i!==null&&Rt(i)),n):(n.eventSystemFlags|=c,i=n.targetContainers,h!==null&&i.indexOf(h)===-1&&i.push(h),n)}function nx(n,i,a,c,h){switch(i){case"focusin":return qn=Xo(qn,n,i,a,c,h),!0;case"dragenter":return Fr=Xo(Fr,n,i,a,c,h),!0;case"mouseover":return Or=Xo(Or,n,i,a,c,h),!0;case"pointerover":var g=h.pointerId;return Wo.set(g,Xo(Wo.get(g)||null,n,i,a,c,h)),!0;case"gotpointercapture":return g=h.pointerId,jo.set(g,Xo(jo.get(g)||null,n,i,a,c,h)),!0}return!1}function qh(n){var i=fs(n.target);if(i!==null){var a=wn(i);if(a!==null){if(i=a.tag,i===13){if(i=cr(a),i!==null){n.blockedOn=i,Ft(n.priority,function(){Vt(a)});return}}else if(i===3&&a.stateNode.current.memoizedState.isDehydrated){n.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}n.blockedOn=null}function Za(n){if(n.blockedOn!==null)return!1;for(var i=n.targetContainers;0<i.length;){var a=nu(n.domEventName,n.eventSystemFlags,i[0],n.nativeEvent);if(a===null){a=n.nativeEvent;var c=new a.constructor(a.type,a);Ee=c,a.target.dispatchEvent(c),Ee=null}else return i=oa(a),i!==null&&Rt(i),n.blockedOn=a,!1;i.shift()}return!0}function Kh(n,i,a){Za(n)&&a.delete(i)}function ix(){cn=!1,qn!==null&&Za(qn)&&(qn=null),Fr!==null&&Za(Fr)&&(Fr=null),Or!==null&&Za(Or)&&(Or=null),Wo.forEach(Kh),jo.forEach(Kh)}function Yo(n,i){n.blockedOn===i&&(n.blockedOn=null,cn||(cn=!0,e.unstable_scheduleCallback(e.unstable_NormalPriority,ix)))}function qo(n){function i(h){return Yo(h,n)}if(0<On.length){Yo(On[0],n);for(var a=1;a<On.length;a++){var c=On[a];c.blockedOn===n&&(c.blockedOn=null)}}for(qn!==null&&Yo(qn,n),Fr!==null&&Yo(Fr,n),Or!==null&&Yo(Or,n),Wo.forEach(i),jo.forEach(i),a=0;a<kr.length;a++)c=kr[a],c.blockedOn===n&&(c.blockedOn=null);for(;0<kr.length&&(a=kr[0],a.blockedOn===null);)qh(a),a.blockedOn===null&&kr.shift()}var Ws=b.ReactCurrentBatchConfig,Ja=!0;function rx(n,i,a,c){var h=Mt,g=Ws.transition;Ws.transition=null;try{Mt=1,tu(n,i,a,c)}finally{Mt=h,Ws.transition=g}}function sx(n,i,a,c){var h=Mt,g=Ws.transition;Ws.transition=null;try{Mt=4,tu(n,i,a,c)}finally{Mt=h,Ws.transition=g}}function tu(n,i,a,c){if(Ja){var h=nu(n,i,a,c);if(h===null)yu(n,i,c,Qa,a),Yh(n,c);else if(nx(h,n,i,a,c))c.stopPropagation();else if(Yh(n,c),i&4&&-1<tx.indexOf(n)){for(;h!==null;){var g=oa(h);if(g!==null&&Tn(g),g=nu(n,i,a,c),g===null&&yu(n,i,c,Qa,a),g===h)break;h=g}h!==null&&c.stopPropagation()}else yu(n,i,c,null,a)}}var Qa=null;function nu(n,i,a,c){if(Qa=null,n=K(c),n=fs(n),n!==null)if(i=wn(n),i===null)n=null;else if(a=i.tag,a===13){if(n=cr(i),n!==null)return n;n=null}else if(a===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;n=null}else i!==n&&(n=null);return Qa=n,null}function $h(n){switch(n){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Gs()){case Dr:return 1;case Ur:return 4;case I:case q:return 16;case me:return 536870912;default:return 16}default:return 16}}var Br=null,iu=null,el=null;function Zh(){if(el)return el;var n,i=iu,a=i.length,c,h="value"in Br?Br.value:Br.textContent,g=h.length;for(n=0;n<a&&i[n]===h[n];n++);var C=a-n;for(c=1;c<=C&&i[a-c]===h[g-c];c++);return el=h.slice(n,1<c?1-c:void 0)}function tl(n){var i=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&i===13&&(n=13)):n=i,n===10&&(n=13),32<=n||n===13?n:0}function nl(){return!0}function Jh(){return!1}function ui(n){function i(a,c,h,g,C){this._reactName=a,this._targetInst=h,this.type=c,this.nativeEvent=g,this.target=C,this.currentTarget=null;for(var z in n)n.hasOwnProperty(z)&&(a=n[z],this[z]=a?a(g):g[z]);return this.isDefaultPrevented=(g.defaultPrevented!=null?g.defaultPrevented:g.returnValue===!1)?nl:Jh,this.isPropagationStopped=Jh,this}return ee(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=nl)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=nl)},persist:function(){},isPersistent:nl}),i}var js={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},ru=ui(js),Ko=ee({},js,{view:0,detail:0}),ox=ui(Ko),su,ou,$o,il=ee({},Ko,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:lu,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==$o&&($o&&n.type==="mousemove"?(su=n.screenX-$o.screenX,ou=n.screenY-$o.screenY):ou=su=0,$o=n),su)},movementY:function(n){return"movementY"in n?n.movementY:ou}}),Qh=ui(il),ax=ee({},il,{dataTransfer:0}),lx=ui(ax),cx=ee({},Ko,{relatedTarget:0}),au=ui(cx),ux=ee({},js,{animationName:0,elapsedTime:0,pseudoElement:0}),dx=ui(ux),fx=ee({},js,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),hx=ui(fx),px=ee({},js,{data:0}),ep=ui(px),mx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},gx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},vx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function xx(n){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(n):(n=vx[n])?!!i[n]:!1}function lu(){return xx}var yx=ee({},Ko,{key:function(n){if(n.key){var i=mx[n.key]||n.key;if(i!=="Unidentified")return i}return n.type==="keypress"?(n=tl(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?gx[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:lu,charCode:function(n){return n.type==="keypress"?tl(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?tl(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),_x=ui(yx),Sx=ee({},il,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),tp=ui(Sx),Mx=ee({},Ko,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:lu}),Ex=ui(Mx),wx=ee({},js,{propertyName:0,elapsedTime:0,pseudoElement:0}),Tx=ui(wx),Ax=ee({},il,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),bx=ui(Ax),Cx=[9,13,27,32],cu=d&&"CompositionEvent"in window,Zo=null;d&&"documentMode"in document&&(Zo=document.documentMode);var Rx=d&&"TextEvent"in window&&!Zo,np=d&&(!cu||Zo&&8<Zo&&11>=Zo),ip=" ",rp=!1;function sp(n,i){switch(n){case"keyup":return Cx.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function op(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Xs=!1;function Px(n,i){switch(n){case"compositionend":return op(i);case"keypress":return i.which!==32?null:(rp=!0,ip);case"textInput":return n=i.data,n===ip&&rp?null:n;default:return null}}function Ix(n,i){if(Xs)return n==="compositionend"||!cu&&sp(n,i)?(n=Zh(),el=iu=Br=null,Xs=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return np&&i.locale!=="ko"?null:i.data;default:return null}}var Lx={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function ap(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i==="input"?!!Lx[n.type]:i==="textarea"}function lp(n,i,a,c){Se(c),i=ll(i,"onChange"),0<i.length&&(a=new ru("onChange","change",null,a,c),n.push({event:a,listeners:i}))}var Jo=null,Qo=null;function Nx(n){Ap(n,0)}function rl(n){var i=Zs(n);if(mt(i))return n}function Dx(n,i){if(n==="change")return i}var cp=!1;if(d){var uu;if(d){var du="oninput"in document;if(!du){var up=document.createElement("div");up.setAttribute("oninput","return;"),du=typeof up.oninput=="function"}uu=du}else uu=!1;cp=uu&&(!document.documentMode||9<document.documentMode)}function dp(){Jo&&(Jo.detachEvent("onpropertychange",fp),Qo=Jo=null)}function fp(n){if(n.propertyName==="value"&&rl(Qo)){var i=[];lp(i,Qo,n,K(n)),$e(Nx,i)}}function Ux(n,i,a){n==="focusin"?(dp(),Jo=i,Qo=a,Jo.attachEvent("onpropertychange",fp)):n==="focusout"&&dp()}function Fx(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return rl(Qo)}function Ox(n,i){if(n==="click")return rl(i)}function kx(n,i){if(n==="input"||n==="change")return rl(i)}function Bx(n,i){return n===i&&(n!==0||1/n===1/i)||n!==n&&i!==i}var Ci=typeof Object.is=="function"?Object.is:Bx;function ea(n,i){if(Ci(n,i))return!0;if(typeof n!="object"||n===null||typeof i!="object"||i===null)return!1;var a=Object.keys(n),c=Object.keys(i);if(a.length!==c.length)return!1;for(c=0;c<a.length;c++){var h=a[c];if(!f.call(i,h)||!Ci(n[h],i[h]))return!1}return!0}function hp(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function pp(n,i){var a=hp(n);n=0;for(var c;a;){if(a.nodeType===3){if(c=n+a.textContent.length,n<=i&&c>=i)return{node:a,offset:i-n};n=c}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=hp(a)}}function mp(n,i){return n&&i?n===i?!0:n&&n.nodeType===3?!1:i&&i.nodeType===3?mp(n,i.parentNode):"contains"in n?n.contains(i):n.compareDocumentPosition?!!(n.compareDocumentPosition(i)&16):!1:!1}function gp(){for(var n=window,i=Gt();i instanceof n.HTMLIFrameElement;){try{var a=typeof i.contentWindow.location.href=="string"}catch{a=!1}if(a)n=i.contentWindow;else break;i=Gt(n.document)}return i}function fu(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i&&(i==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||i==="textarea"||n.contentEditable==="true")}function zx(n){var i=gp(),a=n.focusedElem,c=n.selectionRange;if(i!==a&&a&&a.ownerDocument&&mp(a.ownerDocument.documentElement,a)){if(c!==null&&fu(a)){if(i=c.start,n=c.end,n===void 0&&(n=i),"selectionStart"in a)a.selectionStart=i,a.selectionEnd=Math.min(n,a.value.length);else if(n=(i=a.ownerDocument||document)&&i.defaultView||window,n.getSelection){n=n.getSelection();var h=a.textContent.length,g=Math.min(c.start,h);c=c.end===void 0?g:Math.min(c.end,h),!n.extend&&g>c&&(h=c,c=g,g=h),h=pp(a,g);var C=pp(a,c);h&&C&&(n.rangeCount!==1||n.anchorNode!==h.node||n.anchorOffset!==h.offset||n.focusNode!==C.node||n.focusOffset!==C.offset)&&(i=i.createRange(),i.setStart(h.node,h.offset),n.removeAllRanges(),g>c?(n.addRange(i),n.extend(C.node,C.offset)):(i.setEnd(C.node,C.offset),n.addRange(i)))}}for(i=[],n=a;n=n.parentNode;)n.nodeType===1&&i.push({element:n,left:n.scrollLeft,top:n.scrollTop});for(typeof a.focus=="function"&&a.focus(),a=0;a<i.length;a++)n=i[a],n.element.scrollLeft=n.left,n.element.scrollTop=n.top}}var Vx=d&&"documentMode"in document&&11>=document.documentMode,Ys=null,hu=null,ta=null,pu=!1;function vp(n,i,a){var c=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;pu||Ys==null||Ys!==Gt(c)||(c=Ys,"selectionStart"in c&&fu(c)?c={start:c.selectionStart,end:c.selectionEnd}:(c=(c.ownerDocument&&c.ownerDocument.defaultView||window).getSelection(),c={anchorNode:c.anchorNode,anchorOffset:c.anchorOffset,focusNode:c.focusNode,focusOffset:c.focusOffset}),ta&&ea(ta,c)||(ta=c,c=ll(hu,"onSelect"),0<c.length&&(i=new ru("onSelect","select",null,i,a),n.push({event:i,listeners:c}),i.target=Ys)))}function sl(n,i){var a={};return a[n.toLowerCase()]=i.toLowerCase(),a["Webkit"+n]="webkit"+i,a["Moz"+n]="moz"+i,a}var qs={animationend:sl("Animation","AnimationEnd"),animationiteration:sl("Animation","AnimationIteration"),animationstart:sl("Animation","AnimationStart"),transitionend:sl("Transition","TransitionEnd")},mu={},xp={};d&&(xp=document.createElement("div").style,"AnimationEvent"in window||(delete qs.animationend.animation,delete qs.animationiteration.animation,delete qs.animationstart.animation),"TransitionEvent"in window||delete qs.transitionend.transition);function ol(n){if(mu[n])return mu[n];if(!qs[n])return n;var i=qs[n],a;for(a in i)if(i.hasOwnProperty(a)&&a in xp)return mu[n]=i[a];return n}var yp=ol("animationend"),_p=ol("animationiteration"),Sp=ol("animationstart"),Mp=ol("transitionend"),Ep=new Map,wp="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function zr(n,i){Ep.set(n,i),l(i,[n])}for(var gu=0;gu<wp.length;gu++){var vu=wp[gu],Hx=vu.toLowerCase(),Gx=vu[0].toUpperCase()+vu.slice(1);zr(Hx,"on"+Gx)}zr(yp,"onAnimationEnd"),zr(_p,"onAnimationIteration"),zr(Sp,"onAnimationStart"),zr("dblclick","onDoubleClick"),zr("focusin","onFocus"),zr("focusout","onBlur"),zr(Mp,"onTransitionEnd"),u("onMouseEnter",["mouseout","mouseover"]),u("onMouseLeave",["mouseout","mouseover"]),u("onPointerEnter",["pointerout","pointerover"]),u("onPointerLeave",["pointerout","pointerover"]),l("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),l("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),l("onBeforeInput",["compositionend","keypress","textInput","paste"]),l("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var na="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Wx=new Set("cancel close invalid load scroll toggle".split(" ").concat(na));function Tp(n,i,a){var c=n.type||"unknown-event";n.currentTarget=a,Vs(c,i,void 0,n),n.currentTarget=null}function Ap(n,i){i=(i&4)!==0;for(var a=0;a<n.length;a++){var c=n[a],h=c.event;c=c.listeners;e:{var g=void 0;if(i)for(var C=c.length-1;0<=C;C--){var z=c[C],Y=z.instance,xe=z.currentTarget;if(z=z.listener,Y!==g&&h.isPropagationStopped())break e;Tp(h,z,xe),g=Y}else for(C=0;C<c.length;C++){if(z=c[C],Y=z.instance,xe=z.currentTarget,z=z.listener,Y!==g&&h.isPropagationStopped())break e;Tp(h,z,xe),g=Y}}}if(Xi)throw n=bi,Xi=!1,bi=null,n}function tn(n,i){var a=i[Tu];a===void 0&&(a=i[Tu]=new Set);var c=n+"__bubble";a.has(c)||(bp(i,n,2,!1),a.add(c))}function xu(n,i,a){var c=0;i&&(c|=4),bp(a,n,c,i)}var al="_reactListening"+Math.random().toString(36).slice(2);function ia(n){if(!n[al]){n[al]=!0,r.forEach(function(a){a!=="selectionchange"&&(Wx.has(a)||xu(a,!1,n),xu(a,!0,n))});var i=n.nodeType===9?n:n.ownerDocument;i===null||i[al]||(i[al]=!0,xu("selectionchange",!1,i))}}function bp(n,i,a,c){switch($h(i)){case 1:var h=rx;break;case 4:h=sx;break;default:h=tu}a=h.bind(null,i,a,n),h=void 0,!bt||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(h=!0),c?h!==void 0?n.addEventListener(i,a,{capture:!0,passive:h}):n.addEventListener(i,a,!0):h!==void 0?n.addEventListener(i,a,{passive:h}):n.addEventListener(i,a,!1)}function yu(n,i,a,c,h){var g=c;if((i&1)===0&&(i&2)===0&&c!==null)e:for(;;){if(c===null)return;var C=c.tag;if(C===3||C===4){var z=c.stateNode.containerInfo;if(z===h||z.nodeType===8&&z.parentNode===h)break;if(C===4)for(C=c.return;C!==null;){var Y=C.tag;if((Y===3||Y===4)&&(Y=C.stateNode.containerInfo,Y===h||Y.nodeType===8&&Y.parentNode===h))return;C=C.return}for(;z!==null;){if(C=fs(z),C===null)return;if(Y=C.tag,Y===5||Y===6){c=g=C;continue e}z=z.parentNode}}c=c.return}$e(function(){var xe=g,Ie=K(a),Le=[];e:{var Re=Ep.get(n);if(Re!==void 0){var Ze=ru,it=n;switch(n){case"keypress":if(tl(a)===0)break e;case"keydown":case"keyup":Ze=_x;break;case"focusin":it="focus",Ze=au;break;case"focusout":it="blur",Ze=au;break;case"beforeblur":case"afterblur":Ze=au;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":Ze=Qh;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":Ze=lx;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":Ze=Ex;break;case yp:case _p:case Sp:Ze=dx;break;case Mp:Ze=Tx;break;case"scroll":Ze=ox;break;case"wheel":Ze=bx;break;case"copy":case"cut":case"paste":Ze=hx;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":Ze=tp}var st=(i&4)!==0,hn=!st&&n==="scroll",ce=st?Re!==null?Re+"Capture":null:Re;st=[];for(var J=xe,pe;J!==null;){pe=J;var ke=pe.stateNode;if(pe.tag===5&&ke!==null&&(pe=ke,ce!==null&&(ke=Ut(J,ce),ke!=null&&st.push(ra(J,ke,pe)))),hn)break;J=J.return}0<st.length&&(Re=new Ze(Re,it,null,a,Ie),Le.push({event:Re,listeners:st}))}}if((i&7)===0){e:{if(Re=n==="mouseover"||n==="pointerover",Ze=n==="mouseout"||n==="pointerout",Re&&a!==Ee&&(it=a.relatedTarget||a.fromElement)&&(fs(it)||it[dr]))break e;if((Ze||Re)&&(Re=Ie.window===Ie?Ie:(Re=Ie.ownerDocument)?Re.defaultView||Re.parentWindow:window,Ze?(it=a.relatedTarget||a.toElement,Ze=xe,it=it?fs(it):null,it!==null&&(hn=wn(it),it!==hn||it.tag!==5&&it.tag!==6)&&(it=null)):(Ze=null,it=xe),Ze!==it)){if(st=Qh,ke="onMouseLeave",ce="onMouseEnter",J="mouse",(n==="pointerout"||n==="pointerover")&&(st=tp,ke="onPointerLeave",ce="onPointerEnter",J="pointer"),hn=Ze==null?Re:Zs(Ze),pe=it==null?Re:Zs(it),Re=new st(ke,J+"leave",Ze,a,Ie),Re.target=hn,Re.relatedTarget=pe,ke=null,fs(Ie)===xe&&(st=new st(ce,J+"enter",it,a,Ie),st.target=pe,st.relatedTarget=hn,ke=st),hn=ke,Ze&&it)t:{for(st=Ze,ce=it,J=0,pe=st;pe;pe=Ks(pe))J++;for(pe=0,ke=ce;ke;ke=Ks(ke))pe++;for(;0<J-pe;)st=Ks(st),J--;for(;0<pe-J;)ce=Ks(ce),pe--;for(;J--;){if(st===ce||ce!==null&&st===ce.alternate)break t;st=Ks(st),ce=Ks(ce)}st=null}else st=null;Ze!==null&&Cp(Le,Re,Ze,st,!1),it!==null&&hn!==null&&Cp(Le,hn,it,st,!0)}}e:{if(Re=xe?Zs(xe):window,Ze=Re.nodeName&&Re.nodeName.toLowerCase(),Ze==="select"||Ze==="input"&&Re.type==="file")var ot=Dx;else if(ap(Re))if(cp)ot=kx;else{ot=Fx;var ct=Ux}else(Ze=Re.nodeName)&&Ze.toLowerCase()==="input"&&(Re.type==="checkbox"||Re.type==="radio")&&(ot=Ox);if(ot&&(ot=ot(n,xe))){lp(Le,ot,a,Ie);break e}ct&&ct(n,Re,xe),n==="focusout"&&(ct=Re._wrapperState)&&ct.controlled&&Re.type==="number"&&Xt(Re,"number",Re.value)}switch(ct=xe?Zs(xe):window,n){case"focusin":(ap(ct)||ct.contentEditable==="true")&&(Ys=ct,hu=xe,ta=null);break;case"focusout":ta=hu=Ys=null;break;case"mousedown":pu=!0;break;case"contextmenu":case"mouseup":case"dragend":pu=!1,vp(Le,a,Ie);break;case"selectionchange":if(Vx)break;case"keydown":case"keyup":vp(Le,a,Ie)}var ut;if(cu)e:{switch(n){case"compositionstart":var gt="onCompositionStart";break e;case"compositionend":gt="onCompositionEnd";break e;case"compositionupdate":gt="onCompositionUpdate";break e}gt=void 0}else Xs?sp(n,a)&&(gt="onCompositionEnd"):n==="keydown"&&a.keyCode===229&&(gt="onCompositionStart");gt&&(np&&a.locale!=="ko"&&(Xs||gt!=="onCompositionStart"?gt==="onCompositionEnd"&&Xs&&(ut=Zh()):(Br=Ie,iu="value"in Br?Br.value:Br.textContent,Xs=!0)),ct=ll(xe,gt),0<ct.length&&(gt=new ep(gt,n,null,a,Ie),Le.push({event:gt,listeners:ct}),ut?gt.data=ut:(ut=op(a),ut!==null&&(gt.data=ut)))),(ut=Rx?Px(n,a):Ix(n,a))&&(xe=ll(xe,"onBeforeInput"),0<xe.length&&(Ie=new ep("onBeforeInput","beforeinput",null,a,Ie),Le.push({event:Ie,listeners:xe}),Ie.data=ut))}Ap(Le,i)})}function ra(n,i,a){return{instance:n,listener:i,currentTarget:a}}function ll(n,i){for(var a=i+"Capture",c=[];n!==null;){var h=n,g=h.stateNode;h.tag===5&&g!==null&&(h=g,g=Ut(n,a),g!=null&&c.unshift(ra(n,g,h)),g=Ut(n,i),g!=null&&c.push(ra(n,g,h))),n=n.return}return c}function Ks(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5);return n||null}function Cp(n,i,a,c,h){for(var g=i._reactName,C=[];a!==null&&a!==c;){var z=a,Y=z.alternate,xe=z.stateNode;if(Y!==null&&Y===c)break;z.tag===5&&xe!==null&&(z=xe,h?(Y=Ut(a,g),Y!=null&&C.unshift(ra(a,Y,z))):h||(Y=Ut(a,g),Y!=null&&C.push(ra(a,Y,z)))),a=a.return}C.length!==0&&n.push({event:i,listeners:C})}var jx=/\r\n?/g,Xx=/\u0000|\uFFFD/g;function Rp(n){return(typeof n=="string"?n:""+n).replace(jx,`
`).replace(Xx,"")}function cl(n,i,a){if(i=Rp(i),Rp(n)!==i&&a)throw Error(t(425))}function ul(){}var _u=null,Su=null;function Mu(n,i){return n==="textarea"||n==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Eu=typeof setTimeout=="function"?setTimeout:void 0,Yx=typeof clearTimeout=="function"?clearTimeout:void 0,Pp=typeof Promise=="function"?Promise:void 0,qx=typeof queueMicrotask=="function"?queueMicrotask:typeof Pp<"u"?function(n){return Pp.resolve(null).then(n).catch(Kx)}:Eu;function Kx(n){setTimeout(function(){throw n})}function wu(n,i){var a=i,c=0;do{var h=a.nextSibling;if(n.removeChild(a),h&&h.nodeType===8)if(a=h.data,a==="/$"){if(c===0){n.removeChild(h),qo(i);return}c--}else a!=="$"&&a!=="$?"&&a!=="$!"||c++;a=h}while(a);qo(i)}function Vr(n){for(;n!=null;n=n.nextSibling){var i=n.nodeType;if(i===1||i===3)break;if(i===8){if(i=n.data,i==="$"||i==="$!"||i==="$?")break;if(i==="/$")return null}}return n}function Ip(n){n=n.previousSibling;for(var i=0;n;){if(n.nodeType===8){var a=n.data;if(a==="$"||a==="$!"||a==="$?"){if(i===0)return n;i--}else a==="/$"&&i++}n=n.previousSibling}return null}var $s=Math.random().toString(36).slice(2),Ki="__reactFiber$"+$s,sa="__reactProps$"+$s,dr="__reactContainer$"+$s,Tu="__reactEvents$"+$s,$x="__reactListeners$"+$s,Zx="__reactHandles$"+$s;function fs(n){var i=n[Ki];if(i)return i;for(var a=n.parentNode;a;){if(i=a[dr]||a[Ki]){if(a=i.alternate,i.child!==null||a!==null&&a.child!==null)for(n=Ip(n);n!==null;){if(a=n[Ki])return a;n=Ip(n)}return i}n=a,a=n.parentNode}return null}function oa(n){return n=n[Ki]||n[dr],!n||n.tag!==5&&n.tag!==6&&n.tag!==13&&n.tag!==3?null:n}function Zs(n){if(n.tag===5||n.tag===6)return n.stateNode;throw Error(t(33))}function dl(n){return n[sa]||null}var Au=[],Js=-1;function Hr(n){return{current:n}}function nn(n){0>Js||(n.current=Au[Js],Au[Js]=null,Js--)}function Zt(n,i){Js++,Au[Js]=n.current,n.current=i}var Gr={},kn=Hr(Gr),ni=Hr(!1),hs=Gr;function Qs(n,i){var a=n.type.contextTypes;if(!a)return Gr;var c=n.stateNode;if(c&&c.__reactInternalMemoizedUnmaskedChildContext===i)return c.__reactInternalMemoizedMaskedChildContext;var h={},g;for(g in a)h[g]=i[g];return c&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=i,n.__reactInternalMemoizedMaskedChildContext=h),h}function ii(n){return n=n.childContextTypes,n!=null}function fl(){nn(ni),nn(kn)}function Lp(n,i,a){if(kn.current!==Gr)throw Error(t(168));Zt(kn,i),Zt(ni,a)}function Np(n,i,a){var c=n.stateNode;if(i=i.childContextTypes,typeof c.getChildContext!="function")return a;c=c.getChildContext();for(var h in c)if(!(h in i))throw Error(t(108,le(n)||"Unknown",h));return ee({},a,c)}function hl(n){return n=(n=n.stateNode)&&n.__reactInternalMemoizedMergedChildContext||Gr,hs=kn.current,Zt(kn,n),Zt(ni,ni.current),!0}function Dp(n,i,a){var c=n.stateNode;if(!c)throw Error(t(169));a?(n=Np(n,i,hs),c.__reactInternalMemoizedMergedChildContext=n,nn(ni),nn(kn),Zt(kn,n)):nn(ni),Zt(ni,a)}var fr=null,pl=!1,bu=!1;function Up(n){fr===null?fr=[n]:fr.push(n)}function Jx(n){pl=!0,Up(n)}function Wr(){if(!bu&&fr!==null){bu=!0;var n=0,i=Mt;try{var a=fr;for(Mt=1;n<a.length;n++){var c=a[n];do c=c(!0);while(c!==null)}fr=null,pl=!1}catch(h){throw fr!==null&&(fr=fr.slice(n+1)),Fn(Dr,Wr),h}finally{Mt=i,bu=!1}}return null}var eo=[],to=0,ml=null,gl=0,yi=[],_i=0,ps=null,hr=1,pr="";function ms(n,i){eo[to++]=gl,eo[to++]=ml,ml=n,gl=i}function Fp(n,i,a){yi[_i++]=hr,yi[_i++]=pr,yi[_i++]=ps,ps=n;var c=hr;n=pr;var h=32-ze(c)-1;c&=~(1<<h),a+=1;var g=32-ze(i)+h;if(30<g){var C=h-h%5;g=(c&(1<<C)-1).toString(32),c>>=C,h-=C,hr=1<<32-ze(i)+h|a<<h|c,pr=g+n}else hr=1<<g|a<<h|c,pr=n}function Cu(n){n.return!==null&&(ms(n,1),Fp(n,1,0))}function Ru(n){for(;n===ml;)ml=eo[--to],eo[to]=null,gl=eo[--to],eo[to]=null;for(;n===ps;)ps=yi[--_i],yi[_i]=null,pr=yi[--_i],yi[_i]=null,hr=yi[--_i],yi[_i]=null}var di=null,fi=null,rn=!1,Ri=null;function Op(n,i){var a=wi(5,null,null,0);a.elementType="DELETED",a.stateNode=i,a.return=n,i=n.deletions,i===null?(n.deletions=[a],n.flags|=16):i.push(a)}function kp(n,i){switch(n.tag){case 5:var a=n.type;return i=i.nodeType!==1||a.toLowerCase()!==i.nodeName.toLowerCase()?null:i,i!==null?(n.stateNode=i,di=n,fi=Vr(i.firstChild),!0):!1;case 6:return i=n.pendingProps===""||i.nodeType!==3?null:i,i!==null?(n.stateNode=i,di=n,fi=null,!0):!1;case 13:return i=i.nodeType!==8?null:i,i!==null?(a=ps!==null?{id:hr,overflow:pr}:null,n.memoizedState={dehydrated:i,treeContext:a,retryLane:1073741824},a=wi(18,null,null,0),a.stateNode=i,a.return=n,n.child=a,di=n,fi=null,!0):!1;default:return!1}}function Pu(n){return(n.mode&1)!==0&&(n.flags&128)===0}function Iu(n){if(rn){var i=fi;if(i){var a=i;if(!kp(n,i)){if(Pu(n))throw Error(t(418));i=Vr(a.nextSibling);var c=di;i&&kp(n,i)?Op(c,a):(n.flags=n.flags&-4097|2,rn=!1,di=n)}}else{if(Pu(n))throw Error(t(418));n.flags=n.flags&-4097|2,rn=!1,di=n}}}function Bp(n){for(n=n.return;n!==null&&n.tag!==5&&n.tag!==3&&n.tag!==13;)n=n.return;di=n}function vl(n){if(n!==di)return!1;if(!rn)return Bp(n),rn=!0,!1;var i;if((i=n.tag!==3)&&!(i=n.tag!==5)&&(i=n.type,i=i!=="head"&&i!=="body"&&!Mu(n.type,n.memoizedProps)),i&&(i=fi)){if(Pu(n))throw zp(),Error(t(418));for(;i;)Op(n,i),i=Vr(i.nextSibling)}if(Bp(n),n.tag===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(t(317));e:{for(n=n.nextSibling,i=0;n;){if(n.nodeType===8){var a=n.data;if(a==="/$"){if(i===0){fi=Vr(n.nextSibling);break e}i--}else a!=="$"&&a!=="$!"&&a!=="$?"||i++}n=n.nextSibling}fi=null}}else fi=di?Vr(n.stateNode.nextSibling):null;return!0}function zp(){for(var n=fi;n;)n=Vr(n.nextSibling)}function no(){fi=di=null,rn=!1}function Lu(n){Ri===null?Ri=[n]:Ri.push(n)}var Qx=b.ReactCurrentBatchConfig;function aa(n,i,a){if(n=a.ref,n!==null&&typeof n!="function"&&typeof n!="object"){if(a._owner){if(a=a._owner,a){if(a.tag!==1)throw Error(t(309));var c=a.stateNode}if(!c)throw Error(t(147,n));var h=c,g=""+n;return i!==null&&i.ref!==null&&typeof i.ref=="function"&&i.ref._stringRef===g?i.ref:(i=function(C){var z=h.refs;C===null?delete z[g]:z[g]=C},i._stringRef=g,i)}if(typeof n!="string")throw Error(t(284));if(!a._owner)throw Error(t(290,n))}return n}function xl(n,i){throw n=Object.prototype.toString.call(i),Error(t(31,n==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":n))}function Vp(n){var i=n._init;return i(n._payload)}function Hp(n){function i(ce,J){if(n){var pe=ce.deletions;pe===null?(ce.deletions=[J],ce.flags|=16):pe.push(J)}}function a(ce,J){if(!n)return null;for(;J!==null;)i(ce,J),J=J.sibling;return null}function c(ce,J){for(ce=new Map;J!==null;)J.key!==null?ce.set(J.key,J):ce.set(J.index,J),J=J.sibling;return ce}function h(ce,J){return ce=Jr(ce,J),ce.index=0,ce.sibling=null,ce}function g(ce,J,pe){return ce.index=pe,n?(pe=ce.alternate,pe!==null?(pe=pe.index,pe<J?(ce.flags|=2,J):pe):(ce.flags|=2,J)):(ce.flags|=1048576,J)}function C(ce){return n&&ce.alternate===null&&(ce.flags|=2),ce}function z(ce,J,pe,ke){return J===null||J.tag!==6?(J=Ed(pe,ce.mode,ke),J.return=ce,J):(J=h(J,pe),J.return=ce,J)}function Y(ce,J,pe,ke){var ot=pe.type;return ot===F?Ie(ce,J,pe.props.children,ke,pe.key):J!==null&&(J.elementType===ot||typeof ot=="object"&&ot!==null&&ot.$$typeof===ue&&Vp(ot)===J.type)?(ke=h(J,pe.props),ke.ref=aa(ce,J,pe),ke.return=ce,ke):(ke=Hl(pe.type,pe.key,pe.props,null,ce.mode,ke),ke.ref=aa(ce,J,pe),ke.return=ce,ke)}function xe(ce,J,pe,ke){return J===null||J.tag!==4||J.stateNode.containerInfo!==pe.containerInfo||J.stateNode.implementation!==pe.implementation?(J=wd(pe,ce.mode,ke),J.return=ce,J):(J=h(J,pe.children||[]),J.return=ce,J)}function Ie(ce,J,pe,ke,ot){return J===null||J.tag!==7?(J=Es(pe,ce.mode,ke,ot),J.return=ce,J):(J=h(J,pe),J.return=ce,J)}function Le(ce,J,pe){if(typeof J=="string"&&J!==""||typeof J=="number")return J=Ed(""+J,ce.mode,pe),J.return=ce,J;if(typeof J=="object"&&J!==null){switch(J.$$typeof){case R:return pe=Hl(J.type,J.key,J.props,null,ce.mode,pe),pe.ref=aa(ce,null,J),pe.return=ce,pe;case N:return J=wd(J,ce.mode,pe),J.return=ce,J;case ue:var ke=J._init;return Le(ce,ke(J._payload),pe)}if(Wt(J)||G(J))return J=Es(J,ce.mode,pe,null),J.return=ce,J;xl(ce,J)}return null}function Re(ce,J,pe,ke){var ot=J!==null?J.key:null;if(typeof pe=="string"&&pe!==""||typeof pe=="number")return ot!==null?null:z(ce,J,""+pe,ke);if(typeof pe=="object"&&pe!==null){switch(pe.$$typeof){case R:return pe.key===ot?Y(ce,J,pe,ke):null;case N:return pe.key===ot?xe(ce,J,pe,ke):null;case ue:return ot=pe._init,Re(ce,J,ot(pe._payload),ke)}if(Wt(pe)||G(pe))return ot!==null?null:Ie(ce,J,pe,ke,null);xl(ce,pe)}return null}function Ze(ce,J,pe,ke,ot){if(typeof ke=="string"&&ke!==""||typeof ke=="number")return ce=ce.get(pe)||null,z(J,ce,""+ke,ot);if(typeof ke=="object"&&ke!==null){switch(ke.$$typeof){case R:return ce=ce.get(ke.key===null?pe:ke.key)||null,Y(J,ce,ke,ot);case N:return ce=ce.get(ke.key===null?pe:ke.key)||null,xe(J,ce,ke,ot);case ue:var ct=ke._init;return Ze(ce,J,pe,ct(ke._payload),ot)}if(Wt(ke)||G(ke))return ce=ce.get(pe)||null,Ie(J,ce,ke,ot,null);xl(J,ke)}return null}function it(ce,J,pe,ke){for(var ot=null,ct=null,ut=J,gt=J=0,Cn=null;ut!==null&&gt<pe.length;gt++){ut.index>gt?(Cn=ut,ut=null):Cn=ut.sibling;var Ht=Re(ce,ut,pe[gt],ke);if(Ht===null){ut===null&&(ut=Cn);break}n&&ut&&Ht.alternate===null&&i(ce,ut),J=g(Ht,J,gt),ct===null?ot=Ht:ct.sibling=Ht,ct=Ht,ut=Cn}if(gt===pe.length)return a(ce,ut),rn&&ms(ce,gt),ot;if(ut===null){for(;gt<pe.length;gt++)ut=Le(ce,pe[gt],ke),ut!==null&&(J=g(ut,J,gt),ct===null?ot=ut:ct.sibling=ut,ct=ut);return rn&&ms(ce,gt),ot}for(ut=c(ce,ut);gt<pe.length;gt++)Cn=Ze(ut,ce,gt,pe[gt],ke),Cn!==null&&(n&&Cn.alternate!==null&&ut.delete(Cn.key===null?gt:Cn.key),J=g(Cn,J,gt),ct===null?ot=Cn:ct.sibling=Cn,ct=Cn);return n&&ut.forEach(function(Qr){return i(ce,Qr)}),rn&&ms(ce,gt),ot}function st(ce,J,pe,ke){var ot=G(pe);if(typeof ot!="function")throw Error(t(150));if(pe=ot.call(pe),pe==null)throw Error(t(151));for(var ct=ot=null,ut=J,gt=J=0,Cn=null,Ht=pe.next();ut!==null&&!Ht.done;gt++,Ht=pe.next()){ut.index>gt?(Cn=ut,ut=null):Cn=ut.sibling;var Qr=Re(ce,ut,Ht.value,ke);if(Qr===null){ut===null&&(ut=Cn);break}n&&ut&&Qr.alternate===null&&i(ce,ut),J=g(Qr,J,gt),ct===null?ot=Qr:ct.sibling=Qr,ct=Qr,ut=Cn}if(Ht.done)return a(ce,ut),rn&&ms(ce,gt),ot;if(ut===null){for(;!Ht.done;gt++,Ht=pe.next())Ht=Le(ce,Ht.value,ke),Ht!==null&&(J=g(Ht,J,gt),ct===null?ot=Ht:ct.sibling=Ht,ct=Ht);return rn&&ms(ce,gt),ot}for(ut=c(ce,ut);!Ht.done;gt++,Ht=pe.next())Ht=Ze(ut,ce,gt,Ht.value,ke),Ht!==null&&(n&&Ht.alternate!==null&&ut.delete(Ht.key===null?gt:Ht.key),J=g(Ht,J,gt),ct===null?ot=Ht:ct.sibling=Ht,ct=Ht);return n&&ut.forEach(function(Ly){return i(ce,Ly)}),rn&&ms(ce,gt),ot}function hn(ce,J,pe,ke){if(typeof pe=="object"&&pe!==null&&pe.type===F&&pe.key===null&&(pe=pe.props.children),typeof pe=="object"&&pe!==null){switch(pe.$$typeof){case R:e:{for(var ot=pe.key,ct=J;ct!==null;){if(ct.key===ot){if(ot=pe.type,ot===F){if(ct.tag===7){a(ce,ct.sibling),J=h(ct,pe.props.children),J.return=ce,ce=J;break e}}else if(ct.elementType===ot||typeof ot=="object"&&ot!==null&&ot.$$typeof===ue&&Vp(ot)===ct.type){a(ce,ct.sibling),J=h(ct,pe.props),J.ref=aa(ce,ct,pe),J.return=ce,ce=J;break e}a(ce,ct);break}else i(ce,ct);ct=ct.sibling}pe.type===F?(J=Es(pe.props.children,ce.mode,ke,pe.key),J.return=ce,ce=J):(ke=Hl(pe.type,pe.key,pe.props,null,ce.mode,ke),ke.ref=aa(ce,J,pe),ke.return=ce,ce=ke)}return C(ce);case N:e:{for(ct=pe.key;J!==null;){if(J.key===ct)if(J.tag===4&&J.stateNode.containerInfo===pe.containerInfo&&J.stateNode.implementation===pe.implementation){a(ce,J.sibling),J=h(J,pe.children||[]),J.return=ce,ce=J;break e}else{a(ce,J);break}else i(ce,J);J=J.sibling}J=wd(pe,ce.mode,ke),J.return=ce,ce=J}return C(ce);case ue:return ct=pe._init,hn(ce,J,ct(pe._payload),ke)}if(Wt(pe))return it(ce,J,pe,ke);if(G(pe))return st(ce,J,pe,ke);xl(ce,pe)}return typeof pe=="string"&&pe!==""||typeof pe=="number"?(pe=""+pe,J!==null&&J.tag===6?(a(ce,J.sibling),J=h(J,pe),J.return=ce,ce=J):(a(ce,J),J=Ed(pe,ce.mode,ke),J.return=ce,ce=J),C(ce)):a(ce,J)}return hn}var io=Hp(!0),Gp=Hp(!1),yl=Hr(null),_l=null,ro=null,Nu=null;function Du(){Nu=ro=_l=null}function Uu(n){var i=yl.current;nn(yl),n._currentValue=i}function Fu(n,i,a){for(;n!==null;){var c=n.alternate;if((n.childLanes&i)!==i?(n.childLanes|=i,c!==null&&(c.childLanes|=i)):c!==null&&(c.childLanes&i)!==i&&(c.childLanes|=i),n===a)break;n=n.return}}function so(n,i){_l=n,Nu=ro=null,n=n.dependencies,n!==null&&n.firstContext!==null&&((n.lanes&i)!==0&&(ri=!0),n.firstContext=null)}function Si(n){var i=n._currentValue;if(Nu!==n)if(n={context:n,memoizedValue:i,next:null},ro===null){if(_l===null)throw Error(t(308));ro=n,_l.dependencies={lanes:0,firstContext:n}}else ro=ro.next=n;return i}var gs=null;function Ou(n){gs===null?gs=[n]:gs.push(n)}function Wp(n,i,a,c){var h=i.interleaved;return h===null?(a.next=a,Ou(i)):(a.next=h.next,h.next=a),i.interleaved=a,mr(n,c)}function mr(n,i){n.lanes|=i;var a=n.alternate;for(a!==null&&(a.lanes|=i),a=n,n=n.return;n!==null;)n.childLanes|=i,a=n.alternate,a!==null&&(a.childLanes|=i),a=n,n=n.return;return a.tag===3?a.stateNode:null}var jr=!1;function ku(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function jp(n,i){n=n.updateQueue,i.updateQueue===n&&(i.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,effects:n.effects})}function gr(n,i){return{eventTime:n,lane:i,tag:0,payload:null,callback:null,next:null}}function Xr(n,i,a){var c=n.updateQueue;if(c===null)return null;if(c=c.shared,(kt&2)!==0){var h=c.pending;return h===null?i.next=i:(i.next=h.next,h.next=i),c.pending=i,mr(n,a)}return h=c.interleaved,h===null?(i.next=i,Ou(c)):(i.next=h.next,h.next=i),c.interleaved=i,mr(n,a)}function Sl(n,i,a){if(i=i.updateQueue,i!==null&&(i=i.shared,(a&4194240)!==0)){var c=i.lanes;c&=n.pendingLanes,a|=c,i.lanes=a,ln(n,a)}}function Xp(n,i){var a=n.updateQueue,c=n.alternate;if(c!==null&&(c=c.updateQueue,a===c)){var h=null,g=null;if(a=a.firstBaseUpdate,a!==null){do{var C={eventTime:a.eventTime,lane:a.lane,tag:a.tag,payload:a.payload,callback:a.callback,next:null};g===null?h=g=C:g=g.next=C,a=a.next}while(a!==null);g===null?h=g=i:g=g.next=i}else h=g=i;a={baseState:c.baseState,firstBaseUpdate:h,lastBaseUpdate:g,shared:c.shared,effects:c.effects},n.updateQueue=a;return}n=a.lastBaseUpdate,n===null?a.firstBaseUpdate=i:n.next=i,a.lastBaseUpdate=i}function Ml(n,i,a,c){var h=n.updateQueue;jr=!1;var g=h.firstBaseUpdate,C=h.lastBaseUpdate,z=h.shared.pending;if(z!==null){h.shared.pending=null;var Y=z,xe=Y.next;Y.next=null,C===null?g=xe:C.next=xe,C=Y;var Ie=n.alternate;Ie!==null&&(Ie=Ie.updateQueue,z=Ie.lastBaseUpdate,z!==C&&(z===null?Ie.firstBaseUpdate=xe:z.next=xe,Ie.lastBaseUpdate=Y))}if(g!==null){var Le=h.baseState;C=0,Ie=xe=Y=null,z=g;do{var Re=z.lane,Ze=z.eventTime;if((c&Re)===Re){Ie!==null&&(Ie=Ie.next={eventTime:Ze,lane:0,tag:z.tag,payload:z.payload,callback:z.callback,next:null});e:{var it=n,st=z;switch(Re=i,Ze=a,st.tag){case 1:if(it=st.payload,typeof it=="function"){Le=it.call(Ze,Le,Re);break e}Le=it;break e;case 3:it.flags=it.flags&-65537|128;case 0:if(it=st.payload,Re=typeof it=="function"?it.call(Ze,Le,Re):it,Re==null)break e;Le=ee({},Le,Re);break e;case 2:jr=!0}}z.callback!==null&&z.lane!==0&&(n.flags|=64,Re=h.effects,Re===null?h.effects=[z]:Re.push(z))}else Ze={eventTime:Ze,lane:Re,tag:z.tag,payload:z.payload,callback:z.callback,next:null},Ie===null?(xe=Ie=Ze,Y=Le):Ie=Ie.next=Ze,C|=Re;if(z=z.next,z===null){if(z=h.shared.pending,z===null)break;Re=z,z=Re.next,Re.next=null,h.lastBaseUpdate=Re,h.shared.pending=null}}while(!0);if(Ie===null&&(Y=Le),h.baseState=Y,h.firstBaseUpdate=xe,h.lastBaseUpdate=Ie,i=h.shared.interleaved,i!==null){h=i;do C|=h.lane,h=h.next;while(h!==i)}else g===null&&(h.shared.lanes=0);ys|=C,n.lanes=C,n.memoizedState=Le}}function Yp(n,i,a){if(n=i.effects,i.effects=null,n!==null)for(i=0;i<n.length;i++){var c=n[i],h=c.callback;if(h!==null){if(c.callback=null,c=a,typeof h!="function")throw Error(t(191,h));h.call(c)}}}var la={},$i=Hr(la),ca=Hr(la),ua=Hr(la);function vs(n){if(n===la)throw Error(t(174));return n}function Bu(n,i){switch(Zt(ua,i),Zt(ca,n),Zt($i,la),n=i.nodeType,n){case 9:case 11:i=(i=i.documentElement)?i.namespaceURI:w(null,"");break;default:n=n===8?i.parentNode:i,i=n.namespaceURI||null,n=n.tagName,i=w(i,n)}nn($i),Zt($i,i)}function oo(){nn($i),nn(ca),nn(ua)}function qp(n){vs(ua.current);var i=vs($i.current),a=w(i,n.type);i!==a&&(Zt(ca,n),Zt($i,a))}function zu(n){ca.current===n&&(nn($i),nn(ca))}var sn=Hr(0);function El(n){for(var i=n;i!==null;){if(i.tag===13){var a=i.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||a.data==="$?"||a.data==="$!"))return i}else if(i.tag===19&&i.memoizedProps.revealOrder!==void 0){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Vu=[];function Hu(){for(var n=0;n<Vu.length;n++)Vu[n]._workInProgressVersionPrimary=null;Vu.length=0}var wl=b.ReactCurrentDispatcher,Gu=b.ReactCurrentBatchConfig,xs=0,on=null,xn=null,An=null,Tl=!1,da=!1,fa=0,ey=0;function Bn(){throw Error(t(321))}function Wu(n,i){if(i===null)return!1;for(var a=0;a<i.length&&a<n.length;a++)if(!Ci(n[a],i[a]))return!1;return!0}function ju(n,i,a,c,h,g){if(xs=g,on=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,wl.current=n===null||n.memoizedState===null?ry:sy,n=a(c,h),da){g=0;do{if(da=!1,fa=0,25<=g)throw Error(t(301));g+=1,An=xn=null,i.updateQueue=null,wl.current=oy,n=a(c,h)}while(da)}if(wl.current=Cl,i=xn!==null&&xn.next!==null,xs=0,An=xn=on=null,Tl=!1,i)throw Error(t(300));return n}function Xu(){var n=fa!==0;return fa=0,n}function Zi(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return An===null?on.memoizedState=An=n:An=An.next=n,An}function Mi(){if(xn===null){var n=on.alternate;n=n!==null?n.memoizedState:null}else n=xn.next;var i=An===null?on.memoizedState:An.next;if(i!==null)An=i,xn=n;else{if(n===null)throw Error(t(310));xn=n,n={memoizedState:xn.memoizedState,baseState:xn.baseState,baseQueue:xn.baseQueue,queue:xn.queue,next:null},An===null?on.memoizedState=An=n:An=An.next=n}return An}function ha(n,i){return typeof i=="function"?i(n):i}function Yu(n){var i=Mi(),a=i.queue;if(a===null)throw Error(t(311));a.lastRenderedReducer=n;var c=xn,h=c.baseQueue,g=a.pending;if(g!==null){if(h!==null){var C=h.next;h.next=g.next,g.next=C}c.baseQueue=h=g,a.pending=null}if(h!==null){g=h.next,c=c.baseState;var z=C=null,Y=null,xe=g;do{var Ie=xe.lane;if((xs&Ie)===Ie)Y!==null&&(Y=Y.next={lane:0,action:xe.action,hasEagerState:xe.hasEagerState,eagerState:xe.eagerState,next:null}),c=xe.hasEagerState?xe.eagerState:n(c,xe.action);else{var Le={lane:Ie,action:xe.action,hasEagerState:xe.hasEagerState,eagerState:xe.eagerState,next:null};Y===null?(z=Y=Le,C=c):Y=Y.next=Le,on.lanes|=Ie,ys|=Ie}xe=xe.next}while(xe!==null&&xe!==g);Y===null?C=c:Y.next=z,Ci(c,i.memoizedState)||(ri=!0),i.memoizedState=c,i.baseState=C,i.baseQueue=Y,a.lastRenderedState=c}if(n=a.interleaved,n!==null){h=n;do g=h.lane,on.lanes|=g,ys|=g,h=h.next;while(h!==n)}else h===null&&(a.lanes=0);return[i.memoizedState,a.dispatch]}function qu(n){var i=Mi(),a=i.queue;if(a===null)throw Error(t(311));a.lastRenderedReducer=n;var c=a.dispatch,h=a.pending,g=i.memoizedState;if(h!==null){a.pending=null;var C=h=h.next;do g=n(g,C.action),C=C.next;while(C!==h);Ci(g,i.memoizedState)||(ri=!0),i.memoizedState=g,i.baseQueue===null&&(i.baseState=g),a.lastRenderedState=g}return[g,c]}function Kp(){}function $p(n,i){var a=on,c=Mi(),h=i(),g=!Ci(c.memoizedState,h);if(g&&(c.memoizedState=h,ri=!0),c=c.queue,Ku(Qp.bind(null,a,c,n),[n]),c.getSnapshot!==i||g||An!==null&&An.memoizedState.tag&1){if(a.flags|=2048,pa(9,Jp.bind(null,a,c,h,i),void 0,null),bn===null)throw Error(t(349));(xs&30)!==0||Zp(a,i,h)}return h}function Zp(n,i,a){n.flags|=16384,n={getSnapshot:i,value:a},i=on.updateQueue,i===null?(i={lastEffect:null,stores:null},on.updateQueue=i,i.stores=[n]):(a=i.stores,a===null?i.stores=[n]:a.push(n))}function Jp(n,i,a,c){i.value=a,i.getSnapshot=c,em(i)&&tm(n)}function Qp(n,i,a){return a(function(){em(i)&&tm(n)})}function em(n){var i=n.getSnapshot;n=n.value;try{var a=i();return!Ci(n,a)}catch{return!0}}function tm(n){var i=mr(n,1);i!==null&&Ni(i,n,1,-1)}function nm(n){var i=Zi();return typeof n=="function"&&(n=n()),i.memoizedState=i.baseState=n,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:ha,lastRenderedState:n},i.queue=n,n=n.dispatch=iy.bind(null,on,n),[i.memoizedState,n]}function pa(n,i,a,c){return n={tag:n,create:i,destroy:a,deps:c,next:null},i=on.updateQueue,i===null?(i={lastEffect:null,stores:null},on.updateQueue=i,i.lastEffect=n.next=n):(a=i.lastEffect,a===null?i.lastEffect=n.next=n:(c=a.next,a.next=n,n.next=c,i.lastEffect=n)),n}function im(){return Mi().memoizedState}function Al(n,i,a,c){var h=Zi();on.flags|=n,h.memoizedState=pa(1|i,a,void 0,c===void 0?null:c)}function bl(n,i,a,c){var h=Mi();c=c===void 0?null:c;var g=void 0;if(xn!==null){var C=xn.memoizedState;if(g=C.destroy,c!==null&&Wu(c,C.deps)){h.memoizedState=pa(i,a,g,c);return}}on.flags|=n,h.memoizedState=pa(1|i,a,g,c)}function rm(n,i){return Al(8390656,8,n,i)}function Ku(n,i){return bl(2048,8,n,i)}function sm(n,i){return bl(4,2,n,i)}function om(n,i){return bl(4,4,n,i)}function am(n,i){if(typeof i=="function")return n=n(),i(n),function(){i(null)};if(i!=null)return n=n(),i.current=n,function(){i.current=null}}function lm(n,i,a){return a=a!=null?a.concat([n]):null,bl(4,4,am.bind(null,i,n),a)}function $u(){}function cm(n,i){var a=Mi();i=i===void 0?null:i;var c=a.memoizedState;return c!==null&&i!==null&&Wu(i,c[1])?c[0]:(a.memoizedState=[n,i],n)}function um(n,i){var a=Mi();i=i===void 0?null:i;var c=a.memoizedState;return c!==null&&i!==null&&Wu(i,c[1])?c[0]:(n=n(),a.memoizedState=[n,i],n)}function dm(n,i,a){return(xs&21)===0?(n.baseState&&(n.baseState=!1,ri=!0),n.memoizedState=a):(Ci(a,i)||(a=St(),on.lanes|=a,ys|=a,n.baseState=!0),i)}function ty(n,i){var a=Mt;Mt=a!==0&&4>a?a:4,n(!0);var c=Gu.transition;Gu.transition={};try{n(!1),i()}finally{Mt=a,Gu.transition=c}}function fm(){return Mi().memoizedState}function ny(n,i,a){var c=$r(n);if(a={lane:c,action:a,hasEagerState:!1,eagerState:null,next:null},hm(n))pm(i,a);else if(a=Wp(n,i,a,c),a!==null){var h=$n();Ni(a,n,c,h),mm(a,i,c)}}function iy(n,i,a){var c=$r(n),h={lane:c,action:a,hasEagerState:!1,eagerState:null,next:null};if(hm(n))pm(i,h);else{var g=n.alternate;if(n.lanes===0&&(g===null||g.lanes===0)&&(g=i.lastRenderedReducer,g!==null))try{var C=i.lastRenderedState,z=g(C,a);if(h.hasEagerState=!0,h.eagerState=z,Ci(z,C)){var Y=i.interleaved;Y===null?(h.next=h,Ou(i)):(h.next=Y.next,Y.next=h),i.interleaved=h;return}}catch{}finally{}a=Wp(n,i,h,c),a!==null&&(h=$n(),Ni(a,n,c,h),mm(a,i,c))}}function hm(n){var i=n.alternate;return n===on||i!==null&&i===on}function pm(n,i){da=Tl=!0;var a=n.pending;a===null?i.next=i:(i.next=a.next,a.next=i),n.pending=i}function mm(n,i,a){if((a&4194240)!==0){var c=i.lanes;c&=n.pendingLanes,a|=c,i.lanes=a,ln(n,a)}}var Cl={readContext:Si,useCallback:Bn,useContext:Bn,useEffect:Bn,useImperativeHandle:Bn,useInsertionEffect:Bn,useLayoutEffect:Bn,useMemo:Bn,useReducer:Bn,useRef:Bn,useState:Bn,useDebugValue:Bn,useDeferredValue:Bn,useTransition:Bn,useMutableSource:Bn,useSyncExternalStore:Bn,useId:Bn,unstable_isNewReconciler:!1},ry={readContext:Si,useCallback:function(n,i){return Zi().memoizedState=[n,i===void 0?null:i],n},useContext:Si,useEffect:rm,useImperativeHandle:function(n,i,a){return a=a!=null?a.concat([n]):null,Al(4194308,4,am.bind(null,i,n),a)},useLayoutEffect:function(n,i){return Al(4194308,4,n,i)},useInsertionEffect:function(n,i){return Al(4,2,n,i)},useMemo:function(n,i){var a=Zi();return i=i===void 0?null:i,n=n(),a.memoizedState=[n,i],n},useReducer:function(n,i,a){var c=Zi();return i=a!==void 0?a(i):i,c.memoizedState=c.baseState=i,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:i},c.queue=n,n=n.dispatch=ny.bind(null,on,n),[c.memoizedState,n]},useRef:function(n){var i=Zi();return n={current:n},i.memoizedState=n},useState:nm,useDebugValue:$u,useDeferredValue:function(n){return Zi().memoizedState=n},useTransition:function(){var n=nm(!1),i=n[0];return n=ty.bind(null,n[1]),Zi().memoizedState=n,[i,n]},useMutableSource:function(){},useSyncExternalStore:function(n,i,a){var c=on,h=Zi();if(rn){if(a===void 0)throw Error(t(407));a=a()}else{if(a=i(),bn===null)throw Error(t(349));(xs&30)!==0||Zp(c,i,a)}h.memoizedState=a;var g={value:a,getSnapshot:i};return h.queue=g,rm(Qp.bind(null,c,g,n),[n]),c.flags|=2048,pa(9,Jp.bind(null,c,g,a,i),void 0,null),a},useId:function(){var n=Zi(),i=bn.identifierPrefix;if(rn){var a=pr,c=hr;a=(c&~(1<<32-ze(c)-1)).toString(32)+a,i=":"+i+"R"+a,a=fa++,0<a&&(i+="H"+a.toString(32)),i+=":"}else a=ey++,i=":"+i+"r"+a.toString(32)+":";return n.memoizedState=i},unstable_isNewReconciler:!1},sy={readContext:Si,useCallback:cm,useContext:Si,useEffect:Ku,useImperativeHandle:lm,useInsertionEffect:sm,useLayoutEffect:om,useMemo:um,useReducer:Yu,useRef:im,useState:function(){return Yu(ha)},useDebugValue:$u,useDeferredValue:function(n){var i=Mi();return dm(i,xn.memoizedState,n)},useTransition:function(){var n=Yu(ha)[0],i=Mi().memoizedState;return[n,i]},useMutableSource:Kp,useSyncExternalStore:$p,useId:fm,unstable_isNewReconciler:!1},oy={readContext:Si,useCallback:cm,useContext:Si,useEffect:Ku,useImperativeHandle:lm,useInsertionEffect:sm,useLayoutEffect:om,useMemo:um,useReducer:qu,useRef:im,useState:function(){return qu(ha)},useDebugValue:$u,useDeferredValue:function(n){var i=Mi();return xn===null?i.memoizedState=n:dm(i,xn.memoizedState,n)},useTransition:function(){var n=qu(ha)[0],i=Mi().memoizedState;return[n,i]},useMutableSource:Kp,useSyncExternalStore:$p,useId:fm,unstable_isNewReconciler:!1};function Pi(n,i){if(n&&n.defaultProps){i=ee({},i),n=n.defaultProps;for(var a in n)i[a]===void 0&&(i[a]=n[a]);return i}return i}function Zu(n,i,a,c){i=n.memoizedState,a=a(c,i),a=a==null?i:ee({},i,a),n.memoizedState=a,n.lanes===0&&(n.updateQueue.baseState=a)}var Rl={isMounted:function(n){return(n=n._reactInternals)?wn(n)===n:!1},enqueueSetState:function(n,i,a){n=n._reactInternals;var c=$n(),h=$r(n),g=gr(c,h);g.payload=i,a!=null&&(g.callback=a),i=Xr(n,g,h),i!==null&&(Ni(i,n,h,c),Sl(i,n,h))},enqueueReplaceState:function(n,i,a){n=n._reactInternals;var c=$n(),h=$r(n),g=gr(c,h);g.tag=1,g.payload=i,a!=null&&(g.callback=a),i=Xr(n,g,h),i!==null&&(Ni(i,n,h,c),Sl(i,n,h))},enqueueForceUpdate:function(n,i){n=n._reactInternals;var a=$n(),c=$r(n),h=gr(a,c);h.tag=2,i!=null&&(h.callback=i),i=Xr(n,h,c),i!==null&&(Ni(i,n,c,a),Sl(i,n,c))}};function gm(n,i,a,c,h,g,C){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(c,g,C):i.prototype&&i.prototype.isPureReactComponent?!ea(a,c)||!ea(h,g):!0}function vm(n,i,a){var c=!1,h=Gr,g=i.contextType;return typeof g=="object"&&g!==null?g=Si(g):(h=ii(i)?hs:kn.current,c=i.contextTypes,g=(c=c!=null)?Qs(n,h):Gr),i=new i(a,g),n.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=Rl,n.stateNode=i,i._reactInternals=n,c&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=h,n.__reactInternalMemoizedMaskedChildContext=g),i}function xm(n,i,a,c){n=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(a,c),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(a,c),i.state!==n&&Rl.enqueueReplaceState(i,i.state,null)}function Ju(n,i,a,c){var h=n.stateNode;h.props=a,h.state=n.memoizedState,h.refs={},ku(n);var g=i.contextType;typeof g=="object"&&g!==null?h.context=Si(g):(g=ii(i)?hs:kn.current,h.context=Qs(n,g)),h.state=n.memoizedState,g=i.getDerivedStateFromProps,typeof g=="function"&&(Zu(n,i,g,a),h.state=n.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof h.getSnapshotBeforeUpdate=="function"||typeof h.UNSAFE_componentWillMount!="function"&&typeof h.componentWillMount!="function"||(i=h.state,typeof h.componentWillMount=="function"&&h.componentWillMount(),typeof h.UNSAFE_componentWillMount=="function"&&h.UNSAFE_componentWillMount(),i!==h.state&&Rl.enqueueReplaceState(h,h.state,null),Ml(n,a,h,c),h.state=n.memoizedState),typeof h.componentDidMount=="function"&&(n.flags|=4194308)}function ao(n,i){try{var a="",c=i;do a+=De(c),c=c.return;while(c);var h=a}catch(g){h=`
Error generating stack: `+g.message+`
`+g.stack}return{value:n,source:i,stack:h,digest:null}}function Qu(n,i,a){return{value:n,source:null,stack:a??null,digest:i??null}}function ed(n,i){try{console.error(i.value)}catch(a){setTimeout(function(){throw a})}}var ay=typeof WeakMap=="function"?WeakMap:Map;function ym(n,i,a){a=gr(-1,a),a.tag=3,a.payload={element:null};var c=i.value;return a.callback=function(){Fl||(Fl=!0,md=c),ed(n,i)},a}function _m(n,i,a){a=gr(-1,a),a.tag=3;var c=n.type.getDerivedStateFromError;if(typeof c=="function"){var h=i.value;a.payload=function(){return c(h)},a.callback=function(){ed(n,i)}}var g=n.stateNode;return g!==null&&typeof g.componentDidCatch=="function"&&(a.callback=function(){ed(n,i),typeof c!="function"&&(qr===null?qr=new Set([this]):qr.add(this));var C=i.stack;this.componentDidCatch(i.value,{componentStack:C!==null?C:""})}),a}function Sm(n,i,a){var c=n.pingCache;if(c===null){c=n.pingCache=new ay;var h=new Set;c.set(i,h)}else h=c.get(i),h===void 0&&(h=new Set,c.set(i,h));h.has(a)||(h.add(a),n=Sy.bind(null,n,i,a),i.then(n,n))}function Mm(n){do{var i;if((i=n.tag===13)&&(i=n.memoizedState,i=i!==null?i.dehydrated!==null:!0),i)return n;n=n.return}while(n!==null);return null}function Em(n,i,a,c,h){return(n.mode&1)===0?(n===i?n.flags|=65536:(n.flags|=128,a.flags|=131072,a.flags&=-52805,a.tag===1&&(a.alternate===null?a.tag=17:(i=gr(-1,1),i.tag=2,Xr(a,i,1))),a.lanes|=1),n):(n.flags|=65536,n.lanes=h,n)}var ly=b.ReactCurrentOwner,ri=!1;function Kn(n,i,a,c){i.child=n===null?Gp(i,null,a,c):io(i,n.child,a,c)}function wm(n,i,a,c,h){a=a.render;var g=i.ref;return so(i,h),c=ju(n,i,a,c,g,h),a=Xu(),n!==null&&!ri?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~h,vr(n,i,h)):(rn&&a&&Cu(i),i.flags|=1,Kn(n,i,c,h),i.child)}function Tm(n,i,a,c,h){if(n===null){var g=a.type;return typeof g=="function"&&!Md(g)&&g.defaultProps===void 0&&a.compare===null&&a.defaultProps===void 0?(i.tag=15,i.type=g,Am(n,i,g,c,h)):(n=Hl(a.type,null,c,i,i.mode,h),n.ref=i.ref,n.return=i,i.child=n)}if(g=n.child,(n.lanes&h)===0){var C=g.memoizedProps;if(a=a.compare,a=a!==null?a:ea,a(C,c)&&n.ref===i.ref)return vr(n,i,h)}return i.flags|=1,n=Jr(g,c),n.ref=i.ref,n.return=i,i.child=n}function Am(n,i,a,c,h){if(n!==null){var g=n.memoizedProps;if(ea(g,c)&&n.ref===i.ref)if(ri=!1,i.pendingProps=c=g,(n.lanes&h)!==0)(n.flags&131072)!==0&&(ri=!0);else return i.lanes=n.lanes,vr(n,i,h)}return td(n,i,a,c,h)}function bm(n,i,a){var c=i.pendingProps,h=c.children,g=n!==null?n.memoizedState:null;if(c.mode==="hidden")if((i.mode&1)===0)i.memoizedState={baseLanes:0,cachePool:null,transitions:null},Zt(co,hi),hi|=a;else{if((a&1073741824)===0)return n=g!==null?g.baseLanes|a:a,i.lanes=i.childLanes=1073741824,i.memoizedState={baseLanes:n,cachePool:null,transitions:null},i.updateQueue=null,Zt(co,hi),hi|=n,null;i.memoizedState={baseLanes:0,cachePool:null,transitions:null},c=g!==null?g.baseLanes:a,Zt(co,hi),hi|=c}else g!==null?(c=g.baseLanes|a,i.memoizedState=null):c=a,Zt(co,hi),hi|=c;return Kn(n,i,h,a),i.child}function Cm(n,i){var a=i.ref;(n===null&&a!==null||n!==null&&n.ref!==a)&&(i.flags|=512,i.flags|=2097152)}function td(n,i,a,c,h){var g=ii(a)?hs:kn.current;return g=Qs(i,g),so(i,h),a=ju(n,i,a,c,g,h),c=Xu(),n!==null&&!ri?(i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~h,vr(n,i,h)):(rn&&c&&Cu(i),i.flags|=1,Kn(n,i,a,h),i.child)}function Rm(n,i,a,c,h){if(ii(a)){var g=!0;hl(i)}else g=!1;if(so(i,h),i.stateNode===null)Il(n,i),vm(i,a,c),Ju(i,a,c,h),c=!0;else if(n===null){var C=i.stateNode,z=i.memoizedProps;C.props=z;var Y=C.context,xe=a.contextType;typeof xe=="object"&&xe!==null?xe=Si(xe):(xe=ii(a)?hs:kn.current,xe=Qs(i,xe));var Ie=a.getDerivedStateFromProps,Le=typeof Ie=="function"||typeof C.getSnapshotBeforeUpdate=="function";Le||typeof C.UNSAFE_componentWillReceiveProps!="function"&&typeof C.componentWillReceiveProps!="function"||(z!==c||Y!==xe)&&xm(i,C,c,xe),jr=!1;var Re=i.memoizedState;C.state=Re,Ml(i,c,C,h),Y=i.memoizedState,z!==c||Re!==Y||ni.current||jr?(typeof Ie=="function"&&(Zu(i,a,Ie,c),Y=i.memoizedState),(z=jr||gm(i,a,z,c,Re,Y,xe))?(Le||typeof C.UNSAFE_componentWillMount!="function"&&typeof C.componentWillMount!="function"||(typeof C.componentWillMount=="function"&&C.componentWillMount(),typeof C.UNSAFE_componentWillMount=="function"&&C.UNSAFE_componentWillMount()),typeof C.componentDidMount=="function"&&(i.flags|=4194308)):(typeof C.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=c,i.memoizedState=Y),C.props=c,C.state=Y,C.context=xe,c=z):(typeof C.componentDidMount=="function"&&(i.flags|=4194308),c=!1)}else{C=i.stateNode,jp(n,i),z=i.memoizedProps,xe=i.type===i.elementType?z:Pi(i.type,z),C.props=xe,Le=i.pendingProps,Re=C.context,Y=a.contextType,typeof Y=="object"&&Y!==null?Y=Si(Y):(Y=ii(a)?hs:kn.current,Y=Qs(i,Y));var Ze=a.getDerivedStateFromProps;(Ie=typeof Ze=="function"||typeof C.getSnapshotBeforeUpdate=="function")||typeof C.UNSAFE_componentWillReceiveProps!="function"&&typeof C.componentWillReceiveProps!="function"||(z!==Le||Re!==Y)&&xm(i,C,c,Y),jr=!1,Re=i.memoizedState,C.state=Re,Ml(i,c,C,h);var it=i.memoizedState;z!==Le||Re!==it||ni.current||jr?(typeof Ze=="function"&&(Zu(i,a,Ze,c),it=i.memoizedState),(xe=jr||gm(i,a,xe,c,Re,it,Y)||!1)?(Ie||typeof C.UNSAFE_componentWillUpdate!="function"&&typeof C.componentWillUpdate!="function"||(typeof C.componentWillUpdate=="function"&&C.componentWillUpdate(c,it,Y),typeof C.UNSAFE_componentWillUpdate=="function"&&C.UNSAFE_componentWillUpdate(c,it,Y)),typeof C.componentDidUpdate=="function"&&(i.flags|=4),typeof C.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof C.componentDidUpdate!="function"||z===n.memoizedProps&&Re===n.memoizedState||(i.flags|=4),typeof C.getSnapshotBeforeUpdate!="function"||z===n.memoizedProps&&Re===n.memoizedState||(i.flags|=1024),i.memoizedProps=c,i.memoizedState=it),C.props=c,C.state=it,C.context=Y,c=xe):(typeof C.componentDidUpdate!="function"||z===n.memoizedProps&&Re===n.memoizedState||(i.flags|=4),typeof C.getSnapshotBeforeUpdate!="function"||z===n.memoizedProps&&Re===n.memoizedState||(i.flags|=1024),c=!1)}return nd(n,i,a,c,g,h)}function nd(n,i,a,c,h,g){Cm(n,i);var C=(i.flags&128)!==0;if(!c&&!C)return h&&Dp(i,a,!1),vr(n,i,g);c=i.stateNode,ly.current=i;var z=C&&typeof a.getDerivedStateFromError!="function"?null:c.render();return i.flags|=1,n!==null&&C?(i.child=io(i,n.child,null,g),i.child=io(i,null,z,g)):Kn(n,i,z,g),i.memoizedState=c.state,h&&Dp(i,a,!0),i.child}function Pm(n){var i=n.stateNode;i.pendingContext?Lp(n,i.pendingContext,i.pendingContext!==i.context):i.context&&Lp(n,i.context,!1),Bu(n,i.containerInfo)}function Im(n,i,a,c,h){return no(),Lu(h),i.flags|=256,Kn(n,i,a,c),i.child}var id={dehydrated:null,treeContext:null,retryLane:0};function rd(n){return{baseLanes:n,cachePool:null,transitions:null}}function Lm(n,i,a){var c=i.pendingProps,h=sn.current,g=!1,C=(i.flags&128)!==0,z;if((z=C)||(z=n!==null&&n.memoizedState===null?!1:(h&2)!==0),z?(g=!0,i.flags&=-129):(n===null||n.memoizedState!==null)&&(h|=1),Zt(sn,h&1),n===null)return Iu(i),n=i.memoizedState,n!==null&&(n=n.dehydrated,n!==null)?((i.mode&1)===0?i.lanes=1:n.data==="$!"?i.lanes=8:i.lanes=1073741824,null):(C=c.children,n=c.fallback,g?(c=i.mode,g=i.child,C={mode:"hidden",children:C},(c&1)===0&&g!==null?(g.childLanes=0,g.pendingProps=C):g=Gl(C,c,0,null),n=Es(n,c,a,null),g.return=i,n.return=i,g.sibling=n,i.child=g,i.child.memoizedState=rd(a),i.memoizedState=id,n):sd(i,C));if(h=n.memoizedState,h!==null&&(z=h.dehydrated,z!==null))return cy(n,i,C,c,z,h,a);if(g){g=c.fallback,C=i.mode,h=n.child,z=h.sibling;var Y={mode:"hidden",children:c.children};return(C&1)===0&&i.child!==h?(c=i.child,c.childLanes=0,c.pendingProps=Y,i.deletions=null):(c=Jr(h,Y),c.subtreeFlags=h.subtreeFlags&14680064),z!==null?g=Jr(z,g):(g=Es(g,C,a,null),g.flags|=2),g.return=i,c.return=i,c.sibling=g,i.child=c,c=g,g=i.child,C=n.child.memoizedState,C=C===null?rd(a):{baseLanes:C.baseLanes|a,cachePool:null,transitions:C.transitions},g.memoizedState=C,g.childLanes=n.childLanes&~a,i.memoizedState=id,c}return g=n.child,n=g.sibling,c=Jr(g,{mode:"visible",children:c.children}),(i.mode&1)===0&&(c.lanes=a),c.return=i,c.sibling=null,n!==null&&(a=i.deletions,a===null?(i.deletions=[n],i.flags|=16):a.push(n)),i.child=c,i.memoizedState=null,c}function sd(n,i){return i=Gl({mode:"visible",children:i},n.mode,0,null),i.return=n,n.child=i}function Pl(n,i,a,c){return c!==null&&Lu(c),io(i,n.child,null,a),n=sd(i,i.pendingProps.children),n.flags|=2,i.memoizedState=null,n}function cy(n,i,a,c,h,g,C){if(a)return i.flags&256?(i.flags&=-257,c=Qu(Error(t(422))),Pl(n,i,C,c)):i.memoizedState!==null?(i.child=n.child,i.flags|=128,null):(g=c.fallback,h=i.mode,c=Gl({mode:"visible",children:c.children},h,0,null),g=Es(g,h,C,null),g.flags|=2,c.return=i,g.return=i,c.sibling=g,i.child=c,(i.mode&1)!==0&&io(i,n.child,null,C),i.child.memoizedState=rd(C),i.memoizedState=id,g);if((i.mode&1)===0)return Pl(n,i,C,null);if(h.data==="$!"){if(c=h.nextSibling&&h.nextSibling.dataset,c)var z=c.dgst;return c=z,g=Error(t(419)),c=Qu(g,c,void 0),Pl(n,i,C,c)}if(z=(C&n.childLanes)!==0,ri||z){if(c=bn,c!==null){switch(C&-C){case 4:h=2;break;case 16:h=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:h=32;break;case 536870912:h=268435456;break;default:h=0}h=(h&(c.suspendedLanes|C))!==0?0:h,h!==0&&h!==g.retryLane&&(g.retryLane=h,mr(n,h),Ni(c,n,h,-1))}return Sd(),c=Qu(Error(t(421))),Pl(n,i,C,c)}return h.data==="$?"?(i.flags|=128,i.child=n.child,i=My.bind(null,n),h._reactRetry=i,null):(n=g.treeContext,fi=Vr(h.nextSibling),di=i,rn=!0,Ri=null,n!==null&&(yi[_i++]=hr,yi[_i++]=pr,yi[_i++]=ps,hr=n.id,pr=n.overflow,ps=i),i=sd(i,c.children),i.flags|=4096,i)}function Nm(n,i,a){n.lanes|=i;var c=n.alternate;c!==null&&(c.lanes|=i),Fu(n.return,i,a)}function od(n,i,a,c,h){var g=n.memoizedState;g===null?n.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:c,tail:a,tailMode:h}:(g.isBackwards=i,g.rendering=null,g.renderingStartTime=0,g.last=c,g.tail=a,g.tailMode=h)}function Dm(n,i,a){var c=i.pendingProps,h=c.revealOrder,g=c.tail;if(Kn(n,i,c.children,a),c=sn.current,(c&2)!==0)c=c&1|2,i.flags|=128;else{if(n!==null&&(n.flags&128)!==0)e:for(n=i.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&Nm(n,a,i);else if(n.tag===19)Nm(n,a,i);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===i)break e;for(;n.sibling===null;){if(n.return===null||n.return===i)break e;n=n.return}n.sibling.return=n.return,n=n.sibling}c&=1}if(Zt(sn,c),(i.mode&1)===0)i.memoizedState=null;else switch(h){case"forwards":for(a=i.child,h=null;a!==null;)n=a.alternate,n!==null&&El(n)===null&&(h=a),a=a.sibling;a=h,a===null?(h=i.child,i.child=null):(h=a.sibling,a.sibling=null),od(i,!1,h,a,g);break;case"backwards":for(a=null,h=i.child,i.child=null;h!==null;){if(n=h.alternate,n!==null&&El(n)===null){i.child=h;break}n=h.sibling,h.sibling=a,a=h,h=n}od(i,!0,a,null,g);break;case"together":od(i,!1,null,null,void 0);break;default:i.memoizedState=null}return i.child}function Il(n,i){(i.mode&1)===0&&n!==null&&(n.alternate=null,i.alternate=null,i.flags|=2)}function vr(n,i,a){if(n!==null&&(i.dependencies=n.dependencies),ys|=i.lanes,(a&i.childLanes)===0)return null;if(n!==null&&i.child!==n.child)throw Error(t(153));if(i.child!==null){for(n=i.child,a=Jr(n,n.pendingProps),i.child=a,a.return=i;n.sibling!==null;)n=n.sibling,a=a.sibling=Jr(n,n.pendingProps),a.return=i;a.sibling=null}return i.child}function uy(n,i,a){switch(i.tag){case 3:Pm(i),no();break;case 5:qp(i);break;case 1:ii(i.type)&&hl(i);break;case 4:Bu(i,i.stateNode.containerInfo);break;case 10:var c=i.type._context,h=i.memoizedProps.value;Zt(yl,c._currentValue),c._currentValue=h;break;case 13:if(c=i.memoizedState,c!==null)return c.dehydrated!==null?(Zt(sn,sn.current&1),i.flags|=128,null):(a&i.child.childLanes)!==0?Lm(n,i,a):(Zt(sn,sn.current&1),n=vr(n,i,a),n!==null?n.sibling:null);Zt(sn,sn.current&1);break;case 19:if(c=(a&i.childLanes)!==0,(n.flags&128)!==0){if(c)return Dm(n,i,a);i.flags|=128}if(h=i.memoizedState,h!==null&&(h.rendering=null,h.tail=null,h.lastEffect=null),Zt(sn,sn.current),c)break;return null;case 22:case 23:return i.lanes=0,bm(n,i,a)}return vr(n,i,a)}var Um,ad,Fm,Om;Um=function(n,i){for(var a=i.child;a!==null;){if(a.tag===5||a.tag===6)n.appendChild(a.stateNode);else if(a.tag!==4&&a.child!==null){a.child.return=a,a=a.child;continue}if(a===i)break;for(;a.sibling===null;){if(a.return===null||a.return===i)return;a=a.return}a.sibling.return=a.return,a=a.sibling}},ad=function(){},Fm=function(n,i,a,c){var h=n.memoizedProps;if(h!==c){n=i.stateNode,vs($i.current);var g=null;switch(a){case"input":h=lt(n,h),c=lt(n,c),g=[];break;case"select":h=ee({},h,{value:void 0}),c=ee({},c,{value:void 0}),g=[];break;case"textarea":h=Nt(n,h),c=Nt(n,c),g=[];break;default:typeof h.onClick!="function"&&typeof c.onClick=="function"&&(n.onclick=ul)}Fe(a,c);var C;a=null;for(xe in h)if(!c.hasOwnProperty(xe)&&h.hasOwnProperty(xe)&&h[xe]!=null)if(xe==="style"){var z=h[xe];for(C in z)z.hasOwnProperty(C)&&(a||(a={}),a[C]="")}else xe!=="dangerouslySetInnerHTML"&&xe!=="children"&&xe!=="suppressContentEditableWarning"&&xe!=="suppressHydrationWarning"&&xe!=="autoFocus"&&(o.hasOwnProperty(xe)?g||(g=[]):(g=g||[]).push(xe,null));for(xe in c){var Y=c[xe];if(z=h!=null?h[xe]:void 0,c.hasOwnProperty(xe)&&Y!==z&&(Y!=null||z!=null))if(xe==="style")if(z){for(C in z)!z.hasOwnProperty(C)||Y&&Y.hasOwnProperty(C)||(a||(a={}),a[C]="");for(C in Y)Y.hasOwnProperty(C)&&z[C]!==Y[C]&&(a||(a={}),a[C]=Y[C])}else a||(g||(g=[]),g.push(xe,a)),a=Y;else xe==="dangerouslySetInnerHTML"?(Y=Y?Y.__html:void 0,z=z?z.__html:void 0,Y!=null&&z!==Y&&(g=g||[]).push(xe,Y)):xe==="children"?typeof Y!="string"&&typeof Y!="number"||(g=g||[]).push(xe,""+Y):xe!=="suppressContentEditableWarning"&&xe!=="suppressHydrationWarning"&&(o.hasOwnProperty(xe)?(Y!=null&&xe==="onScroll"&&tn("scroll",n),g||z===Y||(g=[])):(g=g||[]).push(xe,Y))}a&&(g=g||[]).push("style",a);var xe=g;(i.updateQueue=xe)&&(i.flags|=4)}},Om=function(n,i,a,c){a!==c&&(i.flags|=4)};function ma(n,i){if(!rn)switch(n.tailMode){case"hidden":i=n.tail;for(var a=null;i!==null;)i.alternate!==null&&(a=i),i=i.sibling;a===null?n.tail=null:a.sibling=null;break;case"collapsed":a=n.tail;for(var c=null;a!==null;)a.alternate!==null&&(c=a),a=a.sibling;c===null?i||n.tail===null?n.tail=null:n.tail.sibling=null:c.sibling=null}}function zn(n){var i=n.alternate!==null&&n.alternate.child===n.child,a=0,c=0;if(i)for(var h=n.child;h!==null;)a|=h.lanes|h.childLanes,c|=h.subtreeFlags&14680064,c|=h.flags&14680064,h.return=n,h=h.sibling;else for(h=n.child;h!==null;)a|=h.lanes|h.childLanes,c|=h.subtreeFlags,c|=h.flags,h.return=n,h=h.sibling;return n.subtreeFlags|=c,n.childLanes=a,i}function dy(n,i,a){var c=i.pendingProps;switch(Ru(i),i.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return zn(i),null;case 1:return ii(i.type)&&fl(),zn(i),null;case 3:return c=i.stateNode,oo(),nn(ni),nn(kn),Hu(),c.pendingContext&&(c.context=c.pendingContext,c.pendingContext=null),(n===null||n.child===null)&&(vl(i)?i.flags|=4:n===null||n.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Ri!==null&&(xd(Ri),Ri=null))),ad(n,i),zn(i),null;case 5:zu(i);var h=vs(ua.current);if(a=i.type,n!==null&&i.stateNode!=null)Fm(n,i,a,c,h),n.ref!==i.ref&&(i.flags|=512,i.flags|=2097152);else{if(!c){if(i.stateNode===null)throw Error(t(166));return zn(i),null}if(n=vs($i.current),vl(i)){c=i.stateNode,a=i.type;var g=i.memoizedProps;switch(c[Ki]=i,c[sa]=g,n=(i.mode&1)!==0,a){case"dialog":tn("cancel",c),tn("close",c);break;case"iframe":case"object":case"embed":tn("load",c);break;case"video":case"audio":for(h=0;h<na.length;h++)tn(na[h],c);break;case"source":tn("error",c);break;case"img":case"image":case"link":tn("error",c),tn("load",c);break;case"details":tn("toggle",c);break;case"input":Et(c,g),tn("invalid",c);break;case"select":c._wrapperState={wasMultiple:!!g.multiple},tn("invalid",c);break;case"textarea":$(c,g),tn("invalid",c)}Fe(a,g),h=null;for(var C in g)if(g.hasOwnProperty(C)){var z=g[C];C==="children"?typeof z=="string"?c.textContent!==z&&(g.suppressHydrationWarning!==!0&&cl(c.textContent,z,n),h=["children",z]):typeof z=="number"&&c.textContent!==""+z&&(g.suppressHydrationWarning!==!0&&cl(c.textContent,z,n),h=["children",""+z]):o.hasOwnProperty(C)&&z!=null&&C==="onScroll"&&tn("scroll",c)}switch(a){case"input":Xe(c),At(c,g,!0);break;case"textarea":Xe(c),wt(c);break;case"select":case"option":break;default:typeof g.onClick=="function"&&(c.onclick=ul)}c=h,i.updateQueue=c,c!==null&&(i.flags|=4)}else{C=h.nodeType===9?h:h.ownerDocument,n==="http://www.w3.org/1999/xhtml"&&(n=k(a)),n==="http://www.w3.org/1999/xhtml"?a==="script"?(n=C.createElement("div"),n.innerHTML="<script><\/script>",n=n.removeChild(n.firstChild)):typeof c.is=="string"?n=C.createElement(a,{is:c.is}):(n=C.createElement(a),a==="select"&&(C=n,c.multiple?C.multiple=!0:c.size&&(C.size=c.size))):n=C.createElementNS(n,a),n[Ki]=i,n[sa]=c,Um(n,i,!1,!1),i.stateNode=n;e:{switch(C=ve(a,c),a){case"dialog":tn("cancel",n),tn("close",n),h=c;break;case"iframe":case"object":case"embed":tn("load",n),h=c;break;case"video":case"audio":for(h=0;h<na.length;h++)tn(na[h],n);h=c;break;case"source":tn("error",n),h=c;break;case"img":case"image":case"link":tn("error",n),tn("load",n),h=c;break;case"details":tn("toggle",n),h=c;break;case"input":Et(n,c),h=lt(n,c),tn("invalid",n);break;case"option":h=c;break;case"select":n._wrapperState={wasMultiple:!!c.multiple},h=ee({},c,{value:void 0}),tn("invalid",n);break;case"textarea":$(n,c),h=Nt(n,c),tn("invalid",n);break;default:h=c}Fe(a,h),z=h;for(g in z)if(z.hasOwnProperty(g)){var Y=z[g];g==="style"?se(n,Y):g==="dangerouslySetInnerHTML"?(Y=Y?Y.__html:void 0,Y!=null&&he(n,Y)):g==="children"?typeof Y=="string"?(a!=="textarea"||Y!=="")&&ye(n,Y):typeof Y=="number"&&ye(n,""+Y):g!=="suppressContentEditableWarning"&&g!=="suppressHydrationWarning"&&g!=="autoFocus"&&(o.hasOwnProperty(g)?Y!=null&&g==="onScroll"&&tn("scroll",n):Y!=null&&U(n,g,Y,C))}switch(a){case"input":Xe(n),At(n,c,!1);break;case"textarea":Xe(n),wt(n);break;case"option":c.value!=null&&n.setAttribute("value",""+ge(c.value));break;case"select":n.multiple=!!c.multiple,g=c.value,g!=null?_t(n,!!c.multiple,g,!1):c.defaultValue!=null&&_t(n,!!c.multiple,c.defaultValue,!0);break;default:typeof h.onClick=="function"&&(n.onclick=ul)}switch(a){case"button":case"input":case"select":case"textarea":c=!!c.autoFocus;break e;case"img":c=!0;break e;default:c=!1}}c&&(i.flags|=4)}i.ref!==null&&(i.flags|=512,i.flags|=2097152)}return zn(i),null;case 6:if(n&&i.stateNode!=null)Om(n,i,n.memoizedProps,c);else{if(typeof c!="string"&&i.stateNode===null)throw Error(t(166));if(a=vs(ua.current),vs($i.current),vl(i)){if(c=i.stateNode,a=i.memoizedProps,c[Ki]=i,(g=c.nodeValue!==a)&&(n=di,n!==null))switch(n.tag){case 3:cl(c.nodeValue,a,(n.mode&1)!==0);break;case 5:n.memoizedProps.suppressHydrationWarning!==!0&&cl(c.nodeValue,a,(n.mode&1)!==0)}g&&(i.flags|=4)}else c=(a.nodeType===9?a:a.ownerDocument).createTextNode(c),c[Ki]=i,i.stateNode=c}return zn(i),null;case 13:if(nn(sn),c=i.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(rn&&fi!==null&&(i.mode&1)!==0&&(i.flags&128)===0)zp(),no(),i.flags|=98560,g=!1;else if(g=vl(i),c!==null&&c.dehydrated!==null){if(n===null){if(!g)throw Error(t(318));if(g=i.memoizedState,g=g!==null?g.dehydrated:null,!g)throw Error(t(317));g[Ki]=i}else no(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;zn(i),g=!1}else Ri!==null&&(xd(Ri),Ri=null),g=!0;if(!g)return i.flags&65536?i:null}return(i.flags&128)!==0?(i.lanes=a,i):(c=c!==null,c!==(n!==null&&n.memoizedState!==null)&&c&&(i.child.flags|=8192,(i.mode&1)!==0&&(n===null||(sn.current&1)!==0?yn===0&&(yn=3):Sd())),i.updateQueue!==null&&(i.flags|=4),zn(i),null);case 4:return oo(),ad(n,i),n===null&&ia(i.stateNode.containerInfo),zn(i),null;case 10:return Uu(i.type._context),zn(i),null;case 17:return ii(i.type)&&fl(),zn(i),null;case 19:if(nn(sn),g=i.memoizedState,g===null)return zn(i),null;if(c=(i.flags&128)!==0,C=g.rendering,C===null)if(c)ma(g,!1);else{if(yn!==0||n!==null&&(n.flags&128)!==0)for(n=i.child;n!==null;){if(C=El(n),C!==null){for(i.flags|=128,ma(g,!1),c=C.updateQueue,c!==null&&(i.updateQueue=c,i.flags|=4),i.subtreeFlags=0,c=a,a=i.child;a!==null;)g=a,n=c,g.flags&=14680066,C=g.alternate,C===null?(g.childLanes=0,g.lanes=n,g.child=null,g.subtreeFlags=0,g.memoizedProps=null,g.memoizedState=null,g.updateQueue=null,g.dependencies=null,g.stateNode=null):(g.childLanes=C.childLanes,g.lanes=C.lanes,g.child=C.child,g.subtreeFlags=0,g.deletions=null,g.memoizedProps=C.memoizedProps,g.memoizedState=C.memoizedState,g.updateQueue=C.updateQueue,g.type=C.type,n=C.dependencies,g.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),a=a.sibling;return Zt(sn,sn.current&1|2),i.child}n=n.sibling}g.tail!==null&&$t()>uo&&(i.flags|=128,c=!0,ma(g,!1),i.lanes=4194304)}else{if(!c)if(n=El(C),n!==null){if(i.flags|=128,c=!0,a=n.updateQueue,a!==null&&(i.updateQueue=a,i.flags|=4),ma(g,!0),g.tail===null&&g.tailMode==="hidden"&&!C.alternate&&!rn)return zn(i),null}else 2*$t()-g.renderingStartTime>uo&&a!==1073741824&&(i.flags|=128,c=!0,ma(g,!1),i.lanes=4194304);g.isBackwards?(C.sibling=i.child,i.child=C):(a=g.last,a!==null?a.sibling=C:i.child=C,g.last=C)}return g.tail!==null?(i=g.tail,g.rendering=i,g.tail=i.sibling,g.renderingStartTime=$t(),i.sibling=null,a=sn.current,Zt(sn,c?a&1|2:a&1),i):(zn(i),null);case 22:case 23:return _d(),c=i.memoizedState!==null,n!==null&&n.memoizedState!==null!==c&&(i.flags|=8192),c&&(i.mode&1)!==0?(hi&1073741824)!==0&&(zn(i),i.subtreeFlags&6&&(i.flags|=8192)):zn(i),null;case 24:return null;case 25:return null}throw Error(t(156,i.tag))}function fy(n,i){switch(Ru(i),i.tag){case 1:return ii(i.type)&&fl(),n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 3:return oo(),nn(ni),nn(kn),Hu(),n=i.flags,(n&65536)!==0&&(n&128)===0?(i.flags=n&-65537|128,i):null;case 5:return zu(i),null;case 13:if(nn(sn),n=i.memoizedState,n!==null&&n.dehydrated!==null){if(i.alternate===null)throw Error(t(340));no()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 19:return nn(sn),null;case 4:return oo(),null;case 10:return Uu(i.type._context),null;case 22:case 23:return _d(),null;case 24:return null;default:return null}}var Ll=!1,Vn=!1,hy=typeof WeakSet=="function"?WeakSet:Set,Qe=null;function lo(n,i){var a=n.ref;if(a!==null)if(typeof a=="function")try{a(null)}catch(c){un(n,i,c)}else a.current=null}function ld(n,i,a){try{a()}catch(c){un(n,i,c)}}var km=!1;function py(n,i){if(_u=Ja,n=gp(),fu(n)){if("selectionStart"in n)var a={start:n.selectionStart,end:n.selectionEnd};else e:{a=(a=n.ownerDocument)&&a.defaultView||window;var c=a.getSelection&&a.getSelection();if(c&&c.rangeCount!==0){a=c.anchorNode;var h=c.anchorOffset,g=c.focusNode;c=c.focusOffset;try{a.nodeType,g.nodeType}catch{a=null;break e}var C=0,z=-1,Y=-1,xe=0,Ie=0,Le=n,Re=null;t:for(;;){for(var Ze;Le!==a||h!==0&&Le.nodeType!==3||(z=C+h),Le!==g||c!==0&&Le.nodeType!==3||(Y=C+c),Le.nodeType===3&&(C+=Le.nodeValue.length),(Ze=Le.firstChild)!==null;)Re=Le,Le=Ze;for(;;){if(Le===n)break t;if(Re===a&&++xe===h&&(z=C),Re===g&&++Ie===c&&(Y=C),(Ze=Le.nextSibling)!==null)break;Le=Re,Re=Le.parentNode}Le=Ze}a=z===-1||Y===-1?null:{start:z,end:Y}}else a=null}a=a||{start:0,end:0}}else a=null;for(Su={focusedElem:n,selectionRange:a},Ja=!1,Qe=i;Qe!==null;)if(i=Qe,n=i.child,(i.subtreeFlags&1028)!==0&&n!==null)n.return=i,Qe=n;else for(;Qe!==null;){i=Qe;try{var it=i.alternate;if((i.flags&1024)!==0)switch(i.tag){case 0:case 11:case 15:break;case 1:if(it!==null){var st=it.memoizedProps,hn=it.memoizedState,ce=i.stateNode,J=ce.getSnapshotBeforeUpdate(i.elementType===i.type?st:Pi(i.type,st),hn);ce.__reactInternalSnapshotBeforeUpdate=J}break;case 3:var pe=i.stateNode.containerInfo;pe.nodeType===1?pe.textContent="":pe.nodeType===9&&pe.documentElement&&pe.removeChild(pe.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(t(163))}}catch(ke){un(i,i.return,ke)}if(n=i.sibling,n!==null){n.return=i.return,Qe=n;break}Qe=i.return}return it=km,km=!1,it}function ga(n,i,a){var c=i.updateQueue;if(c=c!==null?c.lastEffect:null,c!==null){var h=c=c.next;do{if((h.tag&n)===n){var g=h.destroy;h.destroy=void 0,g!==void 0&&ld(i,a,g)}h=h.next}while(h!==c)}}function Nl(n,i){if(i=i.updateQueue,i=i!==null?i.lastEffect:null,i!==null){var a=i=i.next;do{if((a.tag&n)===n){var c=a.create;a.destroy=c()}a=a.next}while(a!==i)}}function cd(n){var i=n.ref;if(i!==null){var a=n.stateNode;switch(n.tag){case 5:n=a;break;default:n=a}typeof i=="function"?i(n):i.current=n}}function Bm(n){var i=n.alternate;i!==null&&(n.alternate=null,Bm(i)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(i=n.stateNode,i!==null&&(delete i[Ki],delete i[sa],delete i[Tu],delete i[$x],delete i[Zx])),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}function zm(n){return n.tag===5||n.tag===3||n.tag===4}function Vm(n){e:for(;;){for(;n.sibling===null;){if(n.return===null||zm(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.flags&2||n.child===null||n.tag===4)continue e;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function ud(n,i,a){var c=n.tag;if(c===5||c===6)n=n.stateNode,i?a.nodeType===8?a.parentNode.insertBefore(n,i):a.insertBefore(n,i):(a.nodeType===8?(i=a.parentNode,i.insertBefore(n,a)):(i=a,i.appendChild(n)),a=a._reactRootContainer,a!=null||i.onclick!==null||(i.onclick=ul));else if(c!==4&&(n=n.child,n!==null))for(ud(n,i,a),n=n.sibling;n!==null;)ud(n,i,a),n=n.sibling}function dd(n,i,a){var c=n.tag;if(c===5||c===6)n=n.stateNode,i?a.insertBefore(n,i):a.appendChild(n);else if(c!==4&&(n=n.child,n!==null))for(dd(n,i,a),n=n.sibling;n!==null;)dd(n,i,a),n=n.sibling}var In=null,Ii=!1;function Yr(n,i,a){for(a=a.child;a!==null;)Hm(n,i,a),a=a.sibling}function Hm(n,i,a){if(oe&&typeof oe.onCommitFiberUnmount=="function")try{oe.onCommitFiberUnmount(ae,a)}catch{}switch(a.tag){case 5:Vn||lo(a,i);case 6:var c=In,h=Ii;In=null,Yr(n,i,a),In=c,Ii=h,In!==null&&(Ii?(n=In,a=a.stateNode,n.nodeType===8?n.parentNode.removeChild(a):n.removeChild(a)):In.removeChild(a.stateNode));break;case 18:In!==null&&(Ii?(n=In,a=a.stateNode,n.nodeType===8?wu(n.parentNode,a):n.nodeType===1&&wu(n,a),qo(n)):wu(In,a.stateNode));break;case 4:c=In,h=Ii,In=a.stateNode.containerInfo,Ii=!0,Yr(n,i,a),In=c,Ii=h;break;case 0:case 11:case 14:case 15:if(!Vn&&(c=a.updateQueue,c!==null&&(c=c.lastEffect,c!==null))){h=c=c.next;do{var g=h,C=g.destroy;g=g.tag,C!==void 0&&((g&2)!==0||(g&4)!==0)&&ld(a,i,C),h=h.next}while(h!==c)}Yr(n,i,a);break;case 1:if(!Vn&&(lo(a,i),c=a.stateNode,typeof c.componentWillUnmount=="function"))try{c.props=a.memoizedProps,c.state=a.memoizedState,c.componentWillUnmount()}catch(z){un(a,i,z)}Yr(n,i,a);break;case 21:Yr(n,i,a);break;case 22:a.mode&1?(Vn=(c=Vn)||a.memoizedState!==null,Yr(n,i,a),Vn=c):Yr(n,i,a);break;default:Yr(n,i,a)}}function Gm(n){var i=n.updateQueue;if(i!==null){n.updateQueue=null;var a=n.stateNode;a===null&&(a=n.stateNode=new hy),i.forEach(function(c){var h=Ey.bind(null,n,c);a.has(c)||(a.add(c),c.then(h,h))})}}function Li(n,i){var a=i.deletions;if(a!==null)for(var c=0;c<a.length;c++){var h=a[c];try{var g=n,C=i,z=C;e:for(;z!==null;){switch(z.tag){case 5:In=z.stateNode,Ii=!1;break e;case 3:In=z.stateNode.containerInfo,Ii=!0;break e;case 4:In=z.stateNode.containerInfo,Ii=!0;break e}z=z.return}if(In===null)throw Error(t(160));Hm(g,C,h),In=null,Ii=!1;var Y=h.alternate;Y!==null&&(Y.return=null),h.return=null}catch(xe){un(h,i,xe)}}if(i.subtreeFlags&12854)for(i=i.child;i!==null;)Wm(i,n),i=i.sibling}function Wm(n,i){var a=n.alternate,c=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:if(Li(i,n),Ji(n),c&4){try{ga(3,n,n.return),Nl(3,n)}catch(st){un(n,n.return,st)}try{ga(5,n,n.return)}catch(st){un(n,n.return,st)}}break;case 1:Li(i,n),Ji(n),c&512&&a!==null&&lo(a,a.return);break;case 5:if(Li(i,n),Ji(n),c&512&&a!==null&&lo(a,a.return),n.flags&32){var h=n.stateNode;try{ye(h,"")}catch(st){un(n,n.return,st)}}if(c&4&&(h=n.stateNode,h!=null)){var g=n.memoizedProps,C=a!==null?a.memoizedProps:g,z=n.type,Y=n.updateQueue;if(n.updateQueue=null,Y!==null)try{z==="input"&&g.type==="radio"&&g.name!=null&&Ot(h,g),ve(z,C);var xe=ve(z,g);for(C=0;C<Y.length;C+=2){var Ie=Y[C],Le=Y[C+1];Ie==="style"?se(h,Le):Ie==="dangerouslySetInnerHTML"?he(h,Le):Ie==="children"?ye(h,Le):U(h,Ie,Le,xe)}switch(z){case"input":xt(h,g);break;case"textarea":It(h,g);break;case"select":var Re=h._wrapperState.wasMultiple;h._wrapperState.wasMultiple=!!g.multiple;var Ze=g.value;Ze!=null?_t(h,!!g.multiple,Ze,!1):Re!==!!g.multiple&&(g.defaultValue!=null?_t(h,!!g.multiple,g.defaultValue,!0):_t(h,!!g.multiple,g.multiple?[]:"",!1))}h[sa]=g}catch(st){un(n,n.return,st)}}break;case 6:if(Li(i,n),Ji(n),c&4){if(n.stateNode===null)throw Error(t(162));h=n.stateNode,g=n.memoizedProps;try{h.nodeValue=g}catch(st){un(n,n.return,st)}}break;case 3:if(Li(i,n),Ji(n),c&4&&a!==null&&a.memoizedState.isDehydrated)try{qo(i.containerInfo)}catch(st){un(n,n.return,st)}break;case 4:Li(i,n),Ji(n);break;case 13:Li(i,n),Ji(n),h=n.child,h.flags&8192&&(g=h.memoizedState!==null,h.stateNode.isHidden=g,!g||h.alternate!==null&&h.alternate.memoizedState!==null||(pd=$t())),c&4&&Gm(n);break;case 22:if(Ie=a!==null&&a.memoizedState!==null,n.mode&1?(Vn=(xe=Vn)||Ie,Li(i,n),Vn=xe):Li(i,n),Ji(n),c&8192){if(xe=n.memoizedState!==null,(n.stateNode.isHidden=xe)&&!Ie&&(n.mode&1)!==0)for(Qe=n,Ie=n.child;Ie!==null;){for(Le=Qe=Ie;Qe!==null;){switch(Re=Qe,Ze=Re.child,Re.tag){case 0:case 11:case 14:case 15:ga(4,Re,Re.return);break;case 1:lo(Re,Re.return);var it=Re.stateNode;if(typeof it.componentWillUnmount=="function"){c=Re,a=Re.return;try{i=c,it.props=i.memoizedProps,it.state=i.memoizedState,it.componentWillUnmount()}catch(st){un(c,a,st)}}break;case 5:lo(Re,Re.return);break;case 22:if(Re.memoizedState!==null){Ym(Le);continue}}Ze!==null?(Ze.return=Re,Qe=Ze):Ym(Le)}Ie=Ie.sibling}e:for(Ie=null,Le=n;;){if(Le.tag===5){if(Ie===null){Ie=Le;try{h=Le.stateNode,xe?(g=h.style,typeof g.setProperty=="function"?g.setProperty("display","none","important"):g.display="none"):(z=Le.stateNode,Y=Le.memoizedProps.style,C=Y!=null&&Y.hasOwnProperty("display")?Y.display:null,z.style.display=ie("display",C))}catch(st){un(n,n.return,st)}}}else if(Le.tag===6){if(Ie===null)try{Le.stateNode.nodeValue=xe?"":Le.memoizedProps}catch(st){un(n,n.return,st)}}else if((Le.tag!==22&&Le.tag!==23||Le.memoizedState===null||Le===n)&&Le.child!==null){Le.child.return=Le,Le=Le.child;continue}if(Le===n)break e;for(;Le.sibling===null;){if(Le.return===null||Le.return===n)break e;Ie===Le&&(Ie=null),Le=Le.return}Ie===Le&&(Ie=null),Le.sibling.return=Le.return,Le=Le.sibling}}break;case 19:Li(i,n),Ji(n),c&4&&Gm(n);break;case 21:break;default:Li(i,n),Ji(n)}}function Ji(n){var i=n.flags;if(i&2){try{e:{for(var a=n.return;a!==null;){if(zm(a)){var c=a;break e}a=a.return}throw Error(t(160))}switch(c.tag){case 5:var h=c.stateNode;c.flags&32&&(ye(h,""),c.flags&=-33);var g=Vm(n);dd(n,g,h);break;case 3:case 4:var C=c.stateNode.containerInfo,z=Vm(n);ud(n,z,C);break;default:throw Error(t(161))}}catch(Y){un(n,n.return,Y)}n.flags&=-3}i&4096&&(n.flags&=-4097)}function my(n,i,a){Qe=n,jm(n)}function jm(n,i,a){for(var c=(n.mode&1)!==0;Qe!==null;){var h=Qe,g=h.child;if(h.tag===22&&c){var C=h.memoizedState!==null||Ll;if(!C){var z=h.alternate,Y=z!==null&&z.memoizedState!==null||Vn;z=Ll;var xe=Vn;if(Ll=C,(Vn=Y)&&!xe)for(Qe=h;Qe!==null;)C=Qe,Y=C.child,C.tag===22&&C.memoizedState!==null?qm(h):Y!==null?(Y.return=C,Qe=Y):qm(h);for(;g!==null;)Qe=g,jm(g),g=g.sibling;Qe=h,Ll=z,Vn=xe}Xm(n)}else(h.subtreeFlags&8772)!==0&&g!==null?(g.return=h,Qe=g):Xm(n)}}function Xm(n){for(;Qe!==null;){var i=Qe;if((i.flags&8772)!==0){var a=i.alternate;try{if((i.flags&8772)!==0)switch(i.tag){case 0:case 11:case 15:Vn||Nl(5,i);break;case 1:var c=i.stateNode;if(i.flags&4&&!Vn)if(a===null)c.componentDidMount();else{var h=i.elementType===i.type?a.memoizedProps:Pi(i.type,a.memoizedProps);c.componentDidUpdate(h,a.memoizedState,c.__reactInternalSnapshotBeforeUpdate)}var g=i.updateQueue;g!==null&&Yp(i,g,c);break;case 3:var C=i.updateQueue;if(C!==null){if(a=null,i.child!==null)switch(i.child.tag){case 5:a=i.child.stateNode;break;case 1:a=i.child.stateNode}Yp(i,C,a)}break;case 5:var z=i.stateNode;if(a===null&&i.flags&4){a=z;var Y=i.memoizedProps;switch(i.type){case"button":case"input":case"select":case"textarea":Y.autoFocus&&a.focus();break;case"img":Y.src&&(a.src=Y.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(i.memoizedState===null){var xe=i.alternate;if(xe!==null){var Ie=xe.memoizedState;if(Ie!==null){var Le=Ie.dehydrated;Le!==null&&qo(Le)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(t(163))}Vn||i.flags&512&&cd(i)}catch(Re){un(i,i.return,Re)}}if(i===n){Qe=null;break}if(a=i.sibling,a!==null){a.return=i.return,Qe=a;break}Qe=i.return}}function Ym(n){for(;Qe!==null;){var i=Qe;if(i===n){Qe=null;break}var a=i.sibling;if(a!==null){a.return=i.return,Qe=a;break}Qe=i.return}}function qm(n){for(;Qe!==null;){var i=Qe;try{switch(i.tag){case 0:case 11:case 15:var a=i.return;try{Nl(4,i)}catch(Y){un(i,a,Y)}break;case 1:var c=i.stateNode;if(typeof c.componentDidMount=="function"){var h=i.return;try{c.componentDidMount()}catch(Y){un(i,h,Y)}}var g=i.return;try{cd(i)}catch(Y){un(i,g,Y)}break;case 5:var C=i.return;try{cd(i)}catch(Y){un(i,C,Y)}}}catch(Y){un(i,i.return,Y)}if(i===n){Qe=null;break}var z=i.sibling;if(z!==null){z.return=i.return,Qe=z;break}Qe=i.return}}var gy=Math.ceil,Dl=b.ReactCurrentDispatcher,fd=b.ReactCurrentOwner,Ei=b.ReactCurrentBatchConfig,kt=0,bn=null,mn=null,Ln=0,hi=0,co=Hr(0),yn=0,va=null,ys=0,Ul=0,hd=0,xa=null,si=null,pd=0,uo=1/0,xr=null,Fl=!1,md=null,qr=null,Ol=!1,Kr=null,kl=0,ya=0,gd=null,Bl=-1,zl=0;function $n(){return(kt&6)!==0?$t():Bl!==-1?Bl:Bl=$t()}function $r(n){return(n.mode&1)===0?1:(kt&2)!==0&&Ln!==0?Ln&-Ln:Qx.transition!==null?(zl===0&&(zl=St()),zl):(n=Mt,n!==0||(n=window.event,n=n===void 0?16:$h(n.type)),n)}function Ni(n,i,a,c){if(50<ya)throw ya=0,gd=null,Error(t(185));Qt(n,a,c),((kt&2)===0||n!==bn)&&(n===bn&&((kt&2)===0&&(Ul|=a),yn===4&&Zr(n,Ln)),oi(n,c),a===1&&kt===0&&(i.mode&1)===0&&(uo=$t()+500,pl&&Wr()))}function oi(n,i){var a=n.callbackNode;ft(n,i);var c=He(n,n===bn?Ln:0);if(c===0)a!==null&&ur(a),n.callbackNode=null,n.callbackPriority=0;else if(i=c&-c,n.callbackPriority!==i){if(a!=null&&ur(a),i===1)n.tag===0?Jx($m.bind(null,n)):Up($m.bind(null,n)),qx(function(){(kt&6)===0&&Wr()}),a=null;else{switch(en(c)){case 1:a=Dr;break;case 4:a=Ur;break;case 16:a=I;break;case 536870912:a=me;break;default:a=I}a=rg(a,Km.bind(null,n))}n.callbackPriority=i,n.callbackNode=a}}function Km(n,i){if(Bl=-1,zl=0,(kt&6)!==0)throw Error(t(327));var a=n.callbackNode;if(fo()&&n.callbackNode!==a)return null;var c=He(n,n===bn?Ln:0);if(c===0)return null;if((c&30)!==0||(c&n.expiredLanes)!==0||i)i=Vl(n,c);else{i=c;var h=kt;kt|=2;var g=Jm();(bn!==n||Ln!==i)&&(xr=null,uo=$t()+500,Ss(n,i));do try{yy();break}catch(z){Zm(n,z)}while(!0);Du(),Dl.current=g,kt=h,mn!==null?i=0:(bn=null,Ln=0,i=yn)}if(i!==0){if(i===2&&(h=et(n),h!==0&&(c=h,i=vd(n,h))),i===1)throw a=va,Ss(n,0),Zr(n,c),oi(n,$t()),a;if(i===6)Zr(n,c);else{if(h=n.current.alternate,(c&30)===0&&!vy(h)&&(i=Vl(n,c),i===2&&(g=et(n),g!==0&&(c=g,i=vd(n,g))),i===1))throw a=va,Ss(n,0),Zr(n,c),oi(n,$t()),a;switch(n.finishedWork=h,n.finishedLanes=c,i){case 0:case 1:throw Error(t(345));case 2:Ms(n,si,xr);break;case 3:if(Zr(n,c),(c&130023424)===c&&(i=pd+500-$t(),10<i)){if(He(n,0)!==0)break;if(h=n.suspendedLanes,(h&c)!==c){$n(),n.pingedLanes|=n.suspendedLanes&h;break}n.timeoutHandle=Eu(Ms.bind(null,n,si,xr),i);break}Ms(n,si,xr);break;case 4:if(Zr(n,c),(c&4194240)===c)break;for(i=n.eventTimes,h=-1;0<c;){var C=31-ze(c);g=1<<C,C=i[C],C>h&&(h=C),c&=~g}if(c=h,c=$t()-c,c=(120>c?120:480>c?480:1080>c?1080:1920>c?1920:3e3>c?3e3:4320>c?4320:1960*gy(c/1960))-c,10<c){n.timeoutHandle=Eu(Ms.bind(null,n,si,xr),c);break}Ms(n,si,xr);break;case 5:Ms(n,si,xr);break;default:throw Error(t(329))}}}return oi(n,$t()),n.callbackNode===a?Km.bind(null,n):null}function vd(n,i){var a=xa;return n.current.memoizedState.isDehydrated&&(Ss(n,i).flags|=256),n=Vl(n,i),n!==2&&(i=si,si=a,i!==null&&xd(i)),n}function xd(n){si===null?si=n:si.push.apply(si,n)}function vy(n){for(var i=n;;){if(i.flags&16384){var a=i.updateQueue;if(a!==null&&(a=a.stores,a!==null))for(var c=0;c<a.length;c++){var h=a[c],g=h.getSnapshot;h=h.value;try{if(!Ci(g(),h))return!1}catch{return!1}}}if(a=i.child,i.subtreeFlags&16384&&a!==null)a.return=i,i=a;else{if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function Zr(n,i){for(i&=~hd,i&=~Ul,n.suspendedLanes|=i,n.pingedLanes&=~i,n=n.expirationTimes;0<i;){var a=31-ze(i),c=1<<a;n[a]=-1,i&=~c}}function $m(n){if((kt&6)!==0)throw Error(t(327));fo();var i=He(n,0);if((i&1)===0)return oi(n,$t()),null;var a=Vl(n,i);if(n.tag!==0&&a===2){var c=et(n);c!==0&&(i=c,a=vd(n,c))}if(a===1)throw a=va,Ss(n,0),Zr(n,i),oi(n,$t()),a;if(a===6)throw Error(t(345));return n.finishedWork=n.current.alternate,n.finishedLanes=i,Ms(n,si,xr),oi(n,$t()),null}function yd(n,i){var a=kt;kt|=1;try{return n(i)}finally{kt=a,kt===0&&(uo=$t()+500,pl&&Wr())}}function _s(n){Kr!==null&&Kr.tag===0&&(kt&6)===0&&fo();var i=kt;kt|=1;var a=Ei.transition,c=Mt;try{if(Ei.transition=null,Mt=1,n)return n()}finally{Mt=c,Ei.transition=a,kt=i,(kt&6)===0&&Wr()}}function _d(){hi=co.current,nn(co)}function Ss(n,i){n.finishedWork=null,n.finishedLanes=0;var a=n.timeoutHandle;if(a!==-1&&(n.timeoutHandle=-1,Yx(a)),mn!==null)for(a=mn.return;a!==null;){var c=a;switch(Ru(c),c.tag){case 1:c=c.type.childContextTypes,c!=null&&fl();break;case 3:oo(),nn(ni),nn(kn),Hu();break;case 5:zu(c);break;case 4:oo();break;case 13:nn(sn);break;case 19:nn(sn);break;case 10:Uu(c.type._context);break;case 22:case 23:_d()}a=a.return}if(bn=n,mn=n=Jr(n.current,null),Ln=hi=i,yn=0,va=null,hd=Ul=ys=0,si=xa=null,gs!==null){for(i=0;i<gs.length;i++)if(a=gs[i],c=a.interleaved,c!==null){a.interleaved=null;var h=c.next,g=a.pending;if(g!==null){var C=g.next;g.next=h,c.next=C}a.pending=c}gs=null}return n}function Zm(n,i){do{var a=mn;try{if(Du(),wl.current=Cl,Tl){for(var c=on.memoizedState;c!==null;){var h=c.queue;h!==null&&(h.pending=null),c=c.next}Tl=!1}if(xs=0,An=xn=on=null,da=!1,fa=0,fd.current=null,a===null||a.return===null){yn=1,va=i,mn=null;break}e:{var g=n,C=a.return,z=a,Y=i;if(i=Ln,z.flags|=32768,Y!==null&&typeof Y=="object"&&typeof Y.then=="function"){var xe=Y,Ie=z,Le=Ie.tag;if((Ie.mode&1)===0&&(Le===0||Le===11||Le===15)){var Re=Ie.alternate;Re?(Ie.updateQueue=Re.updateQueue,Ie.memoizedState=Re.memoizedState,Ie.lanes=Re.lanes):(Ie.updateQueue=null,Ie.memoizedState=null)}var Ze=Mm(C);if(Ze!==null){Ze.flags&=-257,Em(Ze,C,z,g,i),Ze.mode&1&&Sm(g,xe,i),i=Ze,Y=xe;var it=i.updateQueue;if(it===null){var st=new Set;st.add(Y),i.updateQueue=st}else it.add(Y);break e}else{if((i&1)===0){Sm(g,xe,i),Sd();break e}Y=Error(t(426))}}else if(rn&&z.mode&1){var hn=Mm(C);if(hn!==null){(hn.flags&65536)===0&&(hn.flags|=256),Em(hn,C,z,g,i),Lu(ao(Y,z));break e}}g=Y=ao(Y,z),yn!==4&&(yn=2),xa===null?xa=[g]:xa.push(g),g=C;do{switch(g.tag){case 3:g.flags|=65536,i&=-i,g.lanes|=i;var ce=ym(g,Y,i);Xp(g,ce);break e;case 1:z=Y;var J=g.type,pe=g.stateNode;if((g.flags&128)===0&&(typeof J.getDerivedStateFromError=="function"||pe!==null&&typeof pe.componentDidCatch=="function"&&(qr===null||!qr.has(pe)))){g.flags|=65536,i&=-i,g.lanes|=i;var ke=_m(g,z,i);Xp(g,ke);break e}}g=g.return}while(g!==null)}eg(a)}catch(ot){i=ot,mn===a&&a!==null&&(mn=a=a.return);continue}break}while(!0)}function Jm(){var n=Dl.current;return Dl.current=Cl,n===null?Cl:n}function Sd(){(yn===0||yn===3||yn===2)&&(yn=4),bn===null||(ys&268435455)===0&&(Ul&268435455)===0||Zr(bn,Ln)}function Vl(n,i){var a=kt;kt|=2;var c=Jm();(bn!==n||Ln!==i)&&(xr=null,Ss(n,i));do try{xy();break}catch(h){Zm(n,h)}while(!0);if(Du(),kt=a,Dl.current=c,mn!==null)throw Error(t(261));return bn=null,Ln=0,yn}function xy(){for(;mn!==null;)Qm(mn)}function yy(){for(;mn!==null&&!ti();)Qm(mn)}function Qm(n){var i=ig(n.alternate,n,hi);n.memoizedProps=n.pendingProps,i===null?eg(n):mn=i,fd.current=null}function eg(n){var i=n;do{var a=i.alternate;if(n=i.return,(i.flags&32768)===0){if(a=dy(a,i,hi),a!==null){mn=a;return}}else{if(a=fy(a,i),a!==null){a.flags&=32767,mn=a;return}if(n!==null)n.flags|=32768,n.subtreeFlags=0,n.deletions=null;else{yn=6,mn=null;return}}if(i=i.sibling,i!==null){mn=i;return}mn=i=n}while(i!==null);yn===0&&(yn=5)}function Ms(n,i,a){var c=Mt,h=Ei.transition;try{Ei.transition=null,Mt=1,_y(n,i,a,c)}finally{Ei.transition=h,Mt=c}return null}function _y(n,i,a,c){do fo();while(Kr!==null);if((kt&6)!==0)throw Error(t(327));a=n.finishedWork;var h=n.finishedLanes;if(a===null)return null;if(n.finishedWork=null,n.finishedLanes=0,a===n.current)throw Error(t(177));n.callbackNode=null,n.callbackPriority=0;var g=a.lanes|a.childLanes;if(Tt(n,g),n===bn&&(mn=bn=null,Ln=0),(a.subtreeFlags&2064)===0&&(a.flags&2064)===0||Ol||(Ol=!0,rg(I,function(){return fo(),null})),g=(a.flags&15990)!==0,(a.subtreeFlags&15990)!==0||g){g=Ei.transition,Ei.transition=null;var C=Mt;Mt=1;var z=kt;kt|=4,fd.current=null,py(n,a),Wm(a,n),zx(Su),Ja=!!_u,Su=_u=null,n.current=a,my(a),Go(),kt=z,Mt=C,Ei.transition=g}else n.current=a;if(Ol&&(Ol=!1,Kr=n,kl=h),g=n.pendingLanes,g===0&&(qr=null),We(a.stateNode),oi(n,$t()),i!==null)for(c=n.onRecoverableError,a=0;a<i.length;a++)h=i[a],c(h.value,{componentStack:h.stack,digest:h.digest});if(Fl)throw Fl=!1,n=md,md=null,n;return(kl&1)!==0&&n.tag!==0&&fo(),g=n.pendingLanes,(g&1)!==0?n===gd?ya++:(ya=0,gd=n):ya=0,Wr(),null}function fo(){if(Kr!==null){var n=en(kl),i=Ei.transition,a=Mt;try{if(Ei.transition=null,Mt=16>n?16:n,Kr===null)var c=!1;else{if(n=Kr,Kr=null,kl=0,(kt&6)!==0)throw Error(t(331));var h=kt;for(kt|=4,Qe=n.current;Qe!==null;){var g=Qe,C=g.child;if((Qe.flags&16)!==0){var z=g.deletions;if(z!==null){for(var Y=0;Y<z.length;Y++){var xe=z[Y];for(Qe=xe;Qe!==null;){var Ie=Qe;switch(Ie.tag){case 0:case 11:case 15:ga(8,Ie,g)}var Le=Ie.child;if(Le!==null)Le.return=Ie,Qe=Le;else for(;Qe!==null;){Ie=Qe;var Re=Ie.sibling,Ze=Ie.return;if(Bm(Ie),Ie===xe){Qe=null;break}if(Re!==null){Re.return=Ze,Qe=Re;break}Qe=Ze}}}var it=g.alternate;if(it!==null){var st=it.child;if(st!==null){it.child=null;do{var hn=st.sibling;st.sibling=null,st=hn}while(st!==null)}}Qe=g}}if((g.subtreeFlags&2064)!==0&&C!==null)C.return=g,Qe=C;else e:for(;Qe!==null;){if(g=Qe,(g.flags&2048)!==0)switch(g.tag){case 0:case 11:case 15:ga(9,g,g.return)}var ce=g.sibling;if(ce!==null){ce.return=g.return,Qe=ce;break e}Qe=g.return}}var J=n.current;for(Qe=J;Qe!==null;){C=Qe;var pe=C.child;if((C.subtreeFlags&2064)!==0&&pe!==null)pe.return=C,Qe=pe;else e:for(C=J;Qe!==null;){if(z=Qe,(z.flags&2048)!==0)try{switch(z.tag){case 0:case 11:case 15:Nl(9,z)}}catch(ot){un(z,z.return,ot)}if(z===C){Qe=null;break e}var ke=z.sibling;if(ke!==null){ke.return=z.return,Qe=ke;break e}Qe=z.return}}if(kt=h,Wr(),oe&&typeof oe.onPostCommitFiberRoot=="function")try{oe.onPostCommitFiberRoot(ae,n)}catch{}c=!0}return c}finally{Mt=a,Ei.transition=i}}return!1}function tg(n,i,a){i=ao(a,i),i=ym(n,i,1),n=Xr(n,i,1),i=$n(),n!==null&&(Qt(n,1,i),oi(n,i))}function un(n,i,a){if(n.tag===3)tg(n,n,a);else for(;i!==null;){if(i.tag===3){tg(i,n,a);break}else if(i.tag===1){var c=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof c.componentDidCatch=="function"&&(qr===null||!qr.has(c))){n=ao(a,n),n=_m(i,n,1),i=Xr(i,n,1),n=$n(),i!==null&&(Qt(i,1,n),oi(i,n));break}}i=i.return}}function Sy(n,i,a){var c=n.pingCache;c!==null&&c.delete(i),i=$n(),n.pingedLanes|=n.suspendedLanes&a,bn===n&&(Ln&a)===a&&(yn===4||yn===3&&(Ln&130023424)===Ln&&500>$t()-pd?Ss(n,0):hd|=a),oi(n,i)}function ng(n,i){i===0&&((n.mode&1)===0?i=1:(i=Me,Me<<=1,(Me&130023424)===0&&(Me=4194304)));var a=$n();n=mr(n,i),n!==null&&(Qt(n,i,a),oi(n,a))}function My(n){var i=n.memoizedState,a=0;i!==null&&(a=i.retryLane),ng(n,a)}function Ey(n,i){var a=0;switch(n.tag){case 13:var c=n.stateNode,h=n.memoizedState;h!==null&&(a=h.retryLane);break;case 19:c=n.stateNode;break;default:throw Error(t(314))}c!==null&&c.delete(i),ng(n,a)}var ig;ig=function(n,i,a){if(n!==null)if(n.memoizedProps!==i.pendingProps||ni.current)ri=!0;else{if((n.lanes&a)===0&&(i.flags&128)===0)return ri=!1,uy(n,i,a);ri=(n.flags&131072)!==0}else ri=!1,rn&&(i.flags&1048576)!==0&&Fp(i,gl,i.index);switch(i.lanes=0,i.tag){case 2:var c=i.type;Il(n,i),n=i.pendingProps;var h=Qs(i,kn.current);so(i,a),h=ju(null,i,c,n,h,a);var g=Xu();return i.flags|=1,typeof h=="object"&&h!==null&&typeof h.render=="function"&&h.$$typeof===void 0?(i.tag=1,i.memoizedState=null,i.updateQueue=null,ii(c)?(g=!0,hl(i)):g=!1,i.memoizedState=h.state!==null&&h.state!==void 0?h.state:null,ku(i),h.updater=Rl,i.stateNode=h,h._reactInternals=i,Ju(i,c,n,a),i=nd(null,i,c,!0,g,a)):(i.tag=0,rn&&g&&Cu(i),Kn(null,i,h,a),i=i.child),i;case 16:c=i.elementType;e:{switch(Il(n,i),n=i.pendingProps,h=c._init,c=h(c._payload),i.type=c,h=i.tag=Ty(c),n=Pi(c,n),h){case 0:i=td(null,i,c,n,a);break e;case 1:i=Rm(null,i,c,n,a);break e;case 11:i=wm(null,i,c,n,a);break e;case 14:i=Tm(null,i,c,Pi(c.type,n),a);break e}throw Error(t(306,c,""))}return i;case 0:return c=i.type,h=i.pendingProps,h=i.elementType===c?h:Pi(c,h),td(n,i,c,h,a);case 1:return c=i.type,h=i.pendingProps,h=i.elementType===c?h:Pi(c,h),Rm(n,i,c,h,a);case 3:e:{if(Pm(i),n===null)throw Error(t(387));c=i.pendingProps,g=i.memoizedState,h=g.element,jp(n,i),Ml(i,c,null,a);var C=i.memoizedState;if(c=C.element,g.isDehydrated)if(g={element:c,isDehydrated:!1,cache:C.cache,pendingSuspenseBoundaries:C.pendingSuspenseBoundaries,transitions:C.transitions},i.updateQueue.baseState=g,i.memoizedState=g,i.flags&256){h=ao(Error(t(423)),i),i=Im(n,i,c,a,h);break e}else if(c!==h){h=ao(Error(t(424)),i),i=Im(n,i,c,a,h);break e}else for(fi=Vr(i.stateNode.containerInfo.firstChild),di=i,rn=!0,Ri=null,a=Gp(i,null,c,a),i.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling;else{if(no(),c===h){i=vr(n,i,a);break e}Kn(n,i,c,a)}i=i.child}return i;case 5:return qp(i),n===null&&Iu(i),c=i.type,h=i.pendingProps,g=n!==null?n.memoizedProps:null,C=h.children,Mu(c,h)?C=null:g!==null&&Mu(c,g)&&(i.flags|=32),Cm(n,i),Kn(n,i,C,a),i.child;case 6:return n===null&&Iu(i),null;case 13:return Lm(n,i,a);case 4:return Bu(i,i.stateNode.containerInfo),c=i.pendingProps,n===null?i.child=io(i,null,c,a):Kn(n,i,c,a),i.child;case 11:return c=i.type,h=i.pendingProps,h=i.elementType===c?h:Pi(c,h),wm(n,i,c,h,a);case 7:return Kn(n,i,i.pendingProps,a),i.child;case 8:return Kn(n,i,i.pendingProps.children,a),i.child;case 12:return Kn(n,i,i.pendingProps.children,a),i.child;case 10:e:{if(c=i.type._context,h=i.pendingProps,g=i.memoizedProps,C=h.value,Zt(yl,c._currentValue),c._currentValue=C,g!==null)if(Ci(g.value,C)){if(g.children===h.children&&!ni.current){i=vr(n,i,a);break e}}else for(g=i.child,g!==null&&(g.return=i);g!==null;){var z=g.dependencies;if(z!==null){C=g.child;for(var Y=z.firstContext;Y!==null;){if(Y.context===c){if(g.tag===1){Y=gr(-1,a&-a),Y.tag=2;var xe=g.updateQueue;if(xe!==null){xe=xe.shared;var Ie=xe.pending;Ie===null?Y.next=Y:(Y.next=Ie.next,Ie.next=Y),xe.pending=Y}}g.lanes|=a,Y=g.alternate,Y!==null&&(Y.lanes|=a),Fu(g.return,a,i),z.lanes|=a;break}Y=Y.next}}else if(g.tag===10)C=g.type===i.type?null:g.child;else if(g.tag===18){if(C=g.return,C===null)throw Error(t(341));C.lanes|=a,z=C.alternate,z!==null&&(z.lanes|=a),Fu(C,a,i),C=g.sibling}else C=g.child;if(C!==null)C.return=g;else for(C=g;C!==null;){if(C===i){C=null;break}if(g=C.sibling,g!==null){g.return=C.return,C=g;break}C=C.return}g=C}Kn(n,i,h.children,a),i=i.child}return i;case 9:return h=i.type,c=i.pendingProps.children,so(i,a),h=Si(h),c=c(h),i.flags|=1,Kn(n,i,c,a),i.child;case 14:return c=i.type,h=Pi(c,i.pendingProps),h=Pi(c.type,h),Tm(n,i,c,h,a);case 15:return Am(n,i,i.type,i.pendingProps,a);case 17:return c=i.type,h=i.pendingProps,h=i.elementType===c?h:Pi(c,h),Il(n,i),i.tag=1,ii(c)?(n=!0,hl(i)):n=!1,so(i,a),vm(i,c,h),Ju(i,c,h,a),nd(null,i,c,!0,n,a);case 19:return Dm(n,i,a);case 22:return bm(n,i,a)}throw Error(t(156,i.tag))};function rg(n,i){return Fn(n,i)}function wy(n,i,a,c){this.tag=n,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=c,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function wi(n,i,a,c){return new wy(n,i,a,c)}function Md(n){return n=n.prototype,!(!n||!n.isReactComponent)}function Ty(n){if(typeof n=="function")return Md(n)?1:0;if(n!=null){if(n=n.$$typeof,n===j)return 11;if(n===W)return 14}return 2}function Jr(n,i){var a=n.alternate;return a===null?(a=wi(n.tag,i,n.key,n.mode),a.elementType=n.elementType,a.type=n.type,a.stateNode=n.stateNode,a.alternate=n,n.alternate=a):(a.pendingProps=i,a.type=n.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=n.flags&14680064,a.childLanes=n.childLanes,a.lanes=n.lanes,a.child=n.child,a.memoizedProps=n.memoizedProps,a.memoizedState=n.memoizedState,a.updateQueue=n.updateQueue,i=n.dependencies,a.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},a.sibling=n.sibling,a.index=n.index,a.ref=n.ref,a}function Hl(n,i,a,c,h,g){var C=2;if(c=n,typeof n=="function")Md(n)&&(C=1);else if(typeof n=="string")C=5;else e:switch(n){case F:return Es(a.children,h,g,i);case E:C=8,h|=8;break;case L:return n=wi(12,a,i,h|2),n.elementType=L,n.lanes=g,n;case ne:return n=wi(13,a,i,h),n.elementType=ne,n.lanes=g,n;case H:return n=wi(19,a,i,h),n.elementType=H,n.lanes=g,n;case Q:return Gl(a,h,g,i);default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case B:C=10;break e;case X:C=9;break e;case j:C=11;break e;case W:C=14;break e;case ue:C=16,c=null;break e}throw Error(t(130,n==null?n:typeof n,""))}return i=wi(C,a,i,h),i.elementType=n,i.type=c,i.lanes=g,i}function Es(n,i,a,c){return n=wi(7,n,c,i),n.lanes=a,n}function Gl(n,i,a,c){return n=wi(22,n,c,i),n.elementType=Q,n.lanes=a,n.stateNode={isHidden:!1},n}function Ed(n,i,a){return n=wi(6,n,null,i),n.lanes=a,n}function wd(n,i,a){return i=wi(4,n.children!==null?n.children:[],n.key,i),i.lanes=a,i.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},i}function Ay(n,i,a,c,h){this.tag=i,this.containerInfo=n,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=qe(0),this.expirationTimes=qe(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=qe(0),this.identifierPrefix=c,this.onRecoverableError=h,this.mutableSourceEagerHydrationData=null}function Td(n,i,a,c,h,g,C,z,Y){return n=new Ay(n,i,a,z,Y),i===1?(i=1,g===!0&&(i|=8)):i=0,g=wi(3,null,null,i),n.current=g,g.stateNode=n,g.memoizedState={element:c,isDehydrated:a,cache:null,transitions:null,pendingSuspenseBoundaries:null},ku(g),n}function by(n,i,a){var c=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:N,key:c==null?null:""+c,children:n,containerInfo:i,implementation:a}}function sg(n){if(!n)return Gr;n=n._reactInternals;e:{if(wn(n)!==n||n.tag!==1)throw Error(t(170));var i=n;do{switch(i.tag){case 3:i=i.stateNode.context;break e;case 1:if(ii(i.type)){i=i.stateNode.__reactInternalMemoizedMergedChildContext;break e}}i=i.return}while(i!==null);throw Error(t(171))}if(n.tag===1){var a=n.type;if(ii(a))return Np(n,a,i)}return i}function og(n,i,a,c,h,g,C,z,Y){return n=Td(a,c,!0,n,h,g,C,z,Y),n.context=sg(null),a=n.current,c=$n(),h=$r(a),g=gr(c,h),g.callback=i??null,Xr(a,g,h),n.current.lanes=h,Qt(n,h,c),oi(n,c),n}function Wl(n,i,a,c){var h=i.current,g=$n(),C=$r(h);return a=sg(a),i.context===null?i.context=a:i.pendingContext=a,i=gr(g,C),i.payload={element:n},c=c===void 0?null:c,c!==null&&(i.callback=c),n=Xr(h,i,C),n!==null&&(Ni(n,h,C,g),Sl(n,h,C)),C}function jl(n){if(n=n.current,!n.child)return null;switch(n.child.tag){case 5:return n.child.stateNode;default:return n.child.stateNode}}function ag(n,i){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var a=n.retryLane;n.retryLane=a!==0&&a<i?a:i}}function Ad(n,i){ag(n,i),(n=n.alternate)&&ag(n,i)}function Cy(){return null}var lg=typeof reportError=="function"?reportError:function(n){console.error(n)};function bd(n){this._internalRoot=n}Xl.prototype.render=bd.prototype.render=function(n){var i=this._internalRoot;if(i===null)throw Error(t(409));Wl(n,i,null,null)},Xl.prototype.unmount=bd.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var i=n.containerInfo;_s(function(){Wl(null,n,null,null)}),i[dr]=null}};function Xl(n){this._internalRoot=n}Xl.prototype.unstable_scheduleHydration=function(n){if(n){var i=vn();n={blockedOn:null,target:n,priority:i};for(var a=0;a<kr.length&&i!==0&&i<kr[a].priority;a++);kr.splice(a,0,n),a===0&&qh(n)}};function Cd(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function Yl(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11&&(n.nodeType!==8||n.nodeValue!==" react-mount-point-unstable "))}function cg(){}function Ry(n,i,a,c,h){if(h){if(typeof c=="function"){var g=c;c=function(){var xe=jl(C);g.call(xe)}}var C=og(i,c,n,0,null,!1,!1,"",cg);return n._reactRootContainer=C,n[dr]=C.current,ia(n.nodeType===8?n.parentNode:n),_s(),C}for(;h=n.lastChild;)n.removeChild(h);if(typeof c=="function"){var z=c;c=function(){var xe=jl(Y);z.call(xe)}}var Y=Td(n,0,!1,null,null,!1,!1,"",cg);return n._reactRootContainer=Y,n[dr]=Y.current,ia(n.nodeType===8?n.parentNode:n),_s(function(){Wl(i,Y,a,c)}),Y}function ql(n,i,a,c,h){var g=a._reactRootContainer;if(g){var C=g;if(typeof h=="function"){var z=h;h=function(){var Y=jl(C);z.call(Y)}}Wl(i,C,n,h)}else C=Ry(a,i,n,h,c);return jl(C)}Tn=function(n){switch(n.tag){case 3:var i=n.stateNode;if(i.current.memoizedState.isDehydrated){var a=Ae(i.pendingLanes);a!==0&&(ln(i,a|1),oi(i,$t()),(kt&6)===0&&(uo=$t()+500,Wr()))}break;case 13:_s(function(){var c=mr(n,1);if(c!==null){var h=$n();Ni(c,n,1,h)}}),Ad(n,1)}},Rt=function(n){if(n.tag===13){var i=mr(n,134217728);if(i!==null){var a=$n();Ni(i,n,134217728,a)}Ad(n,134217728)}},Vt=function(n){if(n.tag===13){var i=$r(n),a=mr(n,i);if(a!==null){var c=$n();Ni(a,n,i,c)}Ad(n,i)}},vn=function(){return Mt},Ft=function(n,i){var a=Mt;try{return Mt=n,i()}finally{Mt=a}},Ue=function(n,i,a){switch(i){case"input":if(xt(n,a),i=a.name,a.type==="radio"&&i!=null){for(a=n;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll("input[name="+JSON.stringify(""+i)+'][type="radio"]'),i=0;i<a.length;i++){var c=a[i];if(c!==n&&c.form===n.form){var h=dl(c);if(!h)throw Error(t(90));mt(c),xt(c,h)}}}break;case"textarea":It(n,a);break;case"select":i=a.value,i!=null&&_t(n,!!a.multiple,i,!1)}},Ge=yd,we=_s;var Py={usingClientEntryPoint:!1,Events:[oa,Zs,dl,Se,Ve,yd]},_a={findFiberByHostInstance:fs,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Iy={bundleType:_a.bundleType,version:_a.version,rendererPackageName:_a.rendererPackageName,rendererConfig:_a.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:b.ReactCurrentDispatcher,findHostInstanceByFiber:function(n){return n=qi(n),n===null?null:n.stateNode},findFiberByHostInstance:_a.findFiberByHostInstance||Cy,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Kl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Kl.isDisabled&&Kl.supportsFiber)try{ae=Kl.inject(Iy),oe=Kl}catch{}}return ai.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Py,ai.createPortal=function(n,i){var a=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Cd(i))throw Error(t(200));return by(n,i,null,a)},ai.createRoot=function(n,i){if(!Cd(n))throw Error(t(299));var a=!1,c="",h=lg;return i!=null&&(i.unstable_strictMode===!0&&(a=!0),i.identifierPrefix!==void 0&&(c=i.identifierPrefix),i.onRecoverableError!==void 0&&(h=i.onRecoverableError)),i=Td(n,1,!1,null,null,a,!1,c,h),n[dr]=i.current,ia(n.nodeType===8?n.parentNode:n),new bd(i)},ai.findDOMNode=function(n){if(n==null)return null;if(n.nodeType===1)return n;var i=n._reactInternals;if(i===void 0)throw typeof n.render=="function"?Error(t(188)):(n=Object.keys(n).join(","),Error(t(268,n)));return n=qi(i),n=n===null?null:n.stateNode,n},ai.flushSync=function(n){return _s(n)},ai.hydrate=function(n,i,a){if(!Yl(i))throw Error(t(200));return ql(null,n,i,!0,a)},ai.hydrateRoot=function(n,i,a){if(!Cd(n))throw Error(t(405));var c=a!=null&&a.hydratedSources||null,h=!1,g="",C=lg;if(a!=null&&(a.unstable_strictMode===!0&&(h=!0),a.identifierPrefix!==void 0&&(g=a.identifierPrefix),a.onRecoverableError!==void 0&&(C=a.onRecoverableError)),i=og(i,null,n,1,a??null,h,!1,g,C),n[dr]=i.current,ia(n),c)for(n=0;n<c.length;n++)a=c[n],h=a._getVersion,h=h(a._source),i.mutableSourceEagerHydrationData==null?i.mutableSourceEagerHydrationData=[a,h]:i.mutableSourceEagerHydrationData.push(a,h);return new Xl(i)},ai.render=function(n,i,a){if(!Yl(i))throw Error(t(200));return ql(null,n,i,!1,a)},ai.unmountComponentAtNode=function(n){if(!Yl(n))throw Error(t(40));return n._reactRootContainer?(_s(function(){ql(null,null,n,!1,function(){n._reactRootContainer=null,n[dr]=null})}),!0):!1},ai.unstable_batchedUpdates=yd,ai.unstable_renderSubtreeIntoContainer=function(n,i,a,c){if(!Yl(a))throw Error(t(200));if(n==null||n._reactInternals===void 0)throw Error(t(38));return ql(n,i,a,!1,c)},ai.version="18.3.1-next-f1338f8080-20240426",ai}var vg;function By(){if(vg)return Id.exports;vg=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(e){console.error(e)}}return s(),Id.exports=ky(),Id.exports}var xg;function zy(){if(xg)return $l;xg=1;var s=By();return $l.createRoot=s.createRoot,$l.hydrateRoot=s.hydrateRoot,$l}var Vy=zy();const Hy=W0(Vy);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gy=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),X0=(...s)=>s.filter((e,t,r)=>!!e&&e.trim()!==""&&r.indexOf(e)===t).join(" ").trim();/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Wy={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jy=Be.forwardRef(({color:s="currentColor",size:e=24,strokeWidth:t=2,absoluteStrokeWidth:r,className:o="",children:l,iconNode:u,...d},f)=>Be.createElement("svg",{ref:f,...Wy,width:e,height:e,stroke:s,strokeWidth:r?Number(t)*24/Number(e):t,className:X0("lucide",o),...d},[...u.map(([p,y])=>Be.createElement(p,y)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jt=(s,e)=>{const t=Be.forwardRef(({className:r,...o},l)=>Be.createElement(jy,{ref:l,iconNode:e,className:X0(`lucide-${Gy(s)}`,r),...o}));return t.displayName=`${s}`,t};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y0=jt("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xy=jt("ArrowDownToLine",[["path",{d:"M12 17V3",key:"1cwfxf"}],["path",{d:"m6 11 6 6 6-6",key:"12ii2o"}],["path",{d:"M19 21H5",key:"150jfl"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yy=jt("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qy=jt("ArrowUpFromLine",[["path",{d:"m18 9-6-6-6 6",key:"kcunyi"}],["path",{d:"M12 3v14",key:"7cf3v8"}],["path",{d:"M5 21h14",key:"11awu3"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q0=jt("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yg=jt("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _g=jt("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ky=jt("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zl=jt("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $y=jt("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Sg=jt("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K0=jt("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vf=jt("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zy=jt("MapPin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $0=jt("Moon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jy=jt("Network",[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1",key:"4q2zg0"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1",key:"8cvhb9"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1",key:"1egb70"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",key:"1jsf9p"}],["path",{d:"M12 12V8",key:"2874zd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z0=jt("Puzzle",[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qy=jt("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mg=jt("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e_=jt("Server",[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2",key:"ngkwjq"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2",key:"iecqi9"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6",key:"16zg32"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18",key:"nzw8ys"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J0=jt("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t_=jt("ShieldAlert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xf=jt("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n_=jt("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i_=jt("Smartphone",[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q0=jt("Sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yf=jt("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r_=jt("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Eg=jt("Tv",[["rect",{width:"20",height:"15",x:"2",y:"7",rx:"2",ry:"2",key:"10ag99"}],["polyline",{points:"17 2 12 7 7 2",key:"11pgbg"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _f=jt("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ev=jt("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),tv=[{iso:"AR",name:"Argentina",region:"America",continent:"SA",city:"Buenos Aires",hasStreaming:!0,serverCount:8,gatewayIp:"190.211.255.181",basePingMs:148,coordinates:{lat:-34.6037,lng:-58.3816}},{iso:"BO",name:"Bolivia",region:"America",continent:"SA",city:"Santa Cruz",hasStreaming:!1,serverCount:3,gatewayIp:"200.105.192.9",basePingMs:162,coordinates:{lat:-17.7833,lng:-63.1821}},{iso:"BR",name:"Brazil",region:"America",continent:"SA",city:"São Paulo",hasStreaming:!0,serverCount:16,gatewayIp:"212.119.37.60",basePingMs:134,coordinates:{lat:-23.5505,lng:-46.6333}},{iso:"CA",name:"Canada",region:"America",continent:"NA",city:"Montreal",hasStreaming:!0,serverCount:28,gatewayIp:"45.87.213.210",basePingMs:58,coordinates:{lat:45.5017,lng:-73.5673}},{iso:"CL",name:"Chile",region:"America",continent:"SA",city:"Santiago",hasStreaming:!0,serverCount:6,gatewayIp:"45.239.210.181",basePingMs:152,coordinates:{lat:-33.4489,lng:-70.6693}},{iso:"CO",name:"Colombia",region:"America",continent:"SA",city:"Bogotá",hasStreaming:!1,serverCount:6,gatewayIp:"45.238.181.213",basePingMs:118,coordinates:{lat:4.711,lng:-74.0721}},{iso:"CR",name:"Costa Rica",region:"America",continent:"NA",city:"San José",hasStreaming:!1,serverCount:4,gatewayIp:"38.52.32.226",basePingMs:108,coordinates:{lat:9.9281,lng:-84.0907}},{iso:"EC",name:"Ecuador",region:"America",continent:"SA",city:"Guayaquil",hasStreaming:!1,serverCount:4,gatewayIp:"45.188.76.84",basePingMs:126,coordinates:{lat:-2.1894,lng:-79.8891}},{iso:"GT",name:"Guatemala",region:"America",continent:"NA",city:"Guatemala City",hasStreaming:!1,serverCount:3,gatewayIp:"209.14.80.171",basePingMs:104,coordinates:{lat:14.6349,lng:-90.5069}},{iso:"MX",name:"Mexico",region:"America",continent:"NA",city:"Mexico City",hasStreaming:!0,serverCount:12,gatewayIp:"45.188.78.234",basePingMs:82,coordinates:{lat:19.4326,lng:-99.1332}},{iso:"NI",name:"Nicaragua",region:"America",continent:"NA",city:"Managua",hasStreaming:!1,serverCount:3,gatewayIp:"200.62.66.66",basePingMs:114,coordinates:{lat:12.115,lng:-86.2362}},{iso:"PA",name:"Panama",region:"America",continent:"NA",city:"Panama City",hasStreaming:!1,serverCount:5,gatewayIp:"38.51.148.2",basePingMs:98,coordinates:{lat:8.9824,lng:-79.5199}},{iso:"PY",name:"Paraguay",region:"America",continent:"SA",city:"Asunción",hasStreaming:!1,serverCount:3,gatewayIp:"38.43.130.66",basePingMs:156,coordinates:{lat:-25.2637,lng:-57.5759}},{iso:"PE",name:"Peru",region:"America",continent:"SA",city:"Lima",hasStreaming:!1,serverCount:5,gatewayIp:"38.250.159.170",basePingMs:138,coordinates:{lat:-12.0464,lng:-77.0428}},{iso:"PR",name:"Puerto Rico",region:"America",continent:"NA",city:"San Juan",hasStreaming:!1,serverCount:4,gatewayIp:"146.70.207.2",basePingMs:86,coordinates:{lat:18.4655,lng:-66.1057}},{iso:"US",name:"United States",region:"America",continent:"NA",city:"New York, NY",hasStreaming:!0,serverCount:74,gatewayIp:"86.106.92.149",basePingMs:42,coordinates:{lat:40.7128,lng:-74.006}},{iso:"UY",name:"Uruguay",region:"America",continent:"SA",city:"Montevideo",hasStreaming:!1,serverCount:4,gatewayIp:"190.112.207.181",basePingMs:151,coordinates:{lat:-34.9011,lng:-56.1645}},{iso:"AU",name:"Australia",region:"Asia & Oceania",continent:"OC",city:"Melbourne",hasStreaming:!0,serverCount:22,gatewayIp:"103.108.229.219",basePingMs:112,coordinates:{lat:-37.8136,lng:144.9631}},{iso:"HK",name:"Hong Kong",region:"Asia & Oceania",continent:"AS",city:"Hong Kong SAR",hasStreaming:!0,serverCount:14,gatewayIp:"146.70.204.2",basePingMs:54,coordinates:{lat:22.3193,lng:114.1694}},{iso:"IN",name:"India",region:"Asia & Oceania",continent:"AS",city:"Mumbai",hasStreaming:!0,serverCount:18,gatewayIp:"103.142.161.242",basePingMs:38,coordinates:{lat:19.076,lng:72.8777}},{iso:"ID",name:"Indonesia",region:"Asia & Oceania",continent:"AS",city:"Jakarta",hasStreaming:!1,serverCount:8,gatewayIp:"103.126.116.58",basePingMs:52,coordinates:{lat:-6.2088,lng:106.8456}},{iso:"JP",name:"Japan",region:"Asia & Oceania",continent:"AS",city:"Tokyo",hasStreaming:!0,serverCount:26,gatewayIp:"85.131.255.20",basePingMs:68,coordinates:{lat:35.6762,lng:139.6503}},{iso:"KZ",name:"Kazakhstan",region:"Asia & Oceania",continent:"AS",city:"Almaty",hasStreaming:!1,serverCount:4,gatewayIp:"185.129.50.251",basePingMs:88,coordinates:{lat:43.222,lng:76.8512}},{iso:"KG",name:"Kyrgyzstan",region:"Asia & Oceania",continent:"AS",city:"Bishkek",hasStreaming:!1,serverCount:3,gatewayIp:"109.71.224.229",basePingMs:94,coordinates:{lat:42.8746,lng:74.5698}},{iso:"MY",name:"Malaysia",region:"Asia & Oceania",continent:"AS",city:"Kuala Lumpur",hasStreaming:!0,serverCount:9,gatewayIp:"111.90.141.10",basePingMs:44,coordinates:{lat:3.139,lng:101.6869}},{iso:"MN",name:"Mongolia",region:"Asia & Oceania",continent:"AS",city:"Ulaanbaatar",hasStreaming:!1,serverCount:3,gatewayIp:"202.5.205.51",basePingMs:99,coordinates:{lat:47.8864,lng:106.9057}},{iso:"NZ",name:"New Zealand",region:"Asia & Oceania",continent:"OC",city:"Auckland",hasStreaming:!0,serverCount:8,gatewayIp:"146.70.205.130",basePingMs:128,coordinates:{lat:-36.8485,lng:174.7633}},{iso:"PK",name:"Pakistan",region:"Asia & Oceania",continent:"AS",city:"Islamabad",hasStreaming:!1,serverCount:5,gatewayIp:"38.54.17.50",basePingMs:62,coordinates:{lat:33.6844,lng:73.0479}},{iso:"PH",name:"Philippines",region:"Asia & Oceania",continent:"AS",city:"Manila",hasStreaming:!1,serverCount:7,gatewayIp:"109.104.155.146",basePingMs:64,coordinates:{lat:14.5995,lng:120.9842}},{iso:"SG",name:"Singapore",region:"Asia & Oceania",continent:"AS",city:"Singapore",hasStreaming:!0,serverCount:24,gatewayIp:"146.70.198.130",basePingMs:34,coordinates:{lat:1.3521,lng:103.8198}},{iso:"KR",name:"South Korea",region:"Asia & Oceania",continent:"AS",city:"Seoul",hasStreaming:!0,serverCount:14,gatewayIp:"108.181.50.35",basePingMs:72,coordinates:{lat:37.5665,lng:126.978}},{iso:"LK",name:"Sri Lanka",region:"Asia & Oceania",continent:"AS",city:"Colombo",hasStreaming:!1,serverCount:4,gatewayIp:"146.70.229.138",basePingMs:42,coordinates:{lat:6.9271,lng:79.8612}},{iso:"TW",name:"Taiwan",region:"Asia & Oceania",continent:"AS",city:"Taipei",hasStreaming:!0,serverCount:10,gatewayIp:"103.124.72.14",basePingMs:61,coordinates:{lat:25.033,lng:121.5654}},{iso:"TH",name:"Thailand",region:"Asia & Oceania",continent:"AS",city:"Bangkok",hasStreaming:!1,serverCount:8,gatewayIp:"27.254.132.163",basePingMs:46,coordinates:{lat:13.7563,lng:100.5018}},{iso:"VN",name:"Vietnam",region:"Asia & Oceania",continent:"AS",city:"Hanoi",hasStreaming:!1,serverCount:7,gatewayIp:"103.186.64.250",basePingMs:56,coordinates:{lat:21.0278,lng:105.8342}},{iso:"DZ",name:"Algeria",region:"Europe, Middle East & Africa",continent:"AF",city:"Algiers",hasStreaming:!1,serverCount:3,gatewayIp:"102.216.178.10",basePingMs:112,coordinates:{lat:36.7538,lng:3.0588}},{iso:"AT",name:"Austria",region:"Europe, Middle East & Africa",continent:"EU",city:"Vienna",hasStreaming:!0,serverCount:10,gatewayIp:"185.202.222.244",basePingMs:79,coordinates:{lat:48.2082,lng:16.3738}},{iso:"BY",name:"Belarus",region:"Europe, Middle East & Africa",continent:"EU",city:"Minsk",hasStreaming:!1,serverCount:3,gatewayIp:"95.169.180.52",basePingMs:92,coordinates:{lat:53.9006,lng:27.559}},{iso:"BE",name:"Belgium",region:"Europe, Middle East & Africa",continent:"EU",city:"Brussels",hasStreaming:!0,serverCount:10,gatewayIp:"185.216.33.175",basePingMs:76,coordinates:{lat:50.8503,lng:4.3517}},{iso:"BG",name:"Bulgaria",region:"Europe, Middle East & Africa",continent:"EU",city:"Sofia",hasStreaming:!1,serverCount:8,gatewayIp:"185.216.34.81",basePingMs:84,coordinates:{lat:42.6977,lng:23.3219}},{iso:"HR",name:"Croatia",region:"Europe, Middle East & Africa",continent:"EU",city:"Zagreb",hasStreaming:!1,serverCount:5,gatewayIp:"193.37.68.18",basePingMs:82,coordinates:{lat:45.815,lng:15.9819}},{iso:"CY",name:"Cyprus",region:"Europe, Middle East & Africa",continent:"EU",city:"Nicosia",hasStreaming:!1,serverCount:4,gatewayIp:"213.209.159.170",basePingMs:91,coordinates:{lat:35.1856,lng:33.3823}},{iso:"CZ",name:"Czech Republic",region:"Europe, Middle East & Africa",continent:"EU",city:"Prague",hasStreaming:!0,serverCount:10,gatewayIp:"185.102.219.166",basePingMs:78,coordinates:{lat:50.0755,lng:14.4378}},{iso:"DK",name:"Denmark",region:"Europe, Middle East & Africa",continent:"EU",city:"Copenhagen",hasStreaming:!0,serverCount:10,gatewayIp:"185.204.1.228",basePingMs:81,coordinates:{lat:55.6761,lng:12.5683}},{iso:"EG",name:"Egypt",region:"Europe, Middle East & Africa",continent:"AF",city:"Cairo",hasStreaming:!1,serverCount:5,gatewayIp:"38.54.117.163",basePingMs:95,coordinates:{lat:30.0444,lng:31.2357}},{iso:"EE",name:"Estonia",region:"Europe, Middle East & Africa",continent:"EU",city:"Tallinn",hasStreaming:!1,serverCount:5,gatewayIp:"185.158.113.213",basePingMs:86,coordinates:{lat:59.437,lng:24.7536}},{iso:"FI",name:"Finland",region:"Europe, Middle East & Africa",continent:"EU",city:"Helsinki",hasStreaming:!0,serverCount:9,gatewayIp:"185.216.35.91",basePingMs:87,coordinates:{lat:60.1699,lng:24.9384}},{iso:"FR",name:"France",region:"Europe, Middle East & Africa",continent:"EU",city:"Paris",hasStreaming:!0,serverCount:28,gatewayIp:"185.246.211.124",basePingMs:74,coordinates:{lat:48.8566,lng:2.3522}},{iso:"GE",name:"Georgia",region:"Europe, Middle East & Africa",continent:"EU",city:"Tbilisi",hasStreaming:!1,serverCount:4,gatewayIp:"188.93.91.2",basePingMs:87,coordinates:{lat:41.7151,lng:44.8271}},{iso:"DE",name:"Germany",region:"Europe, Middle East & Africa",continent:"EU",city:"Frankfurt",hasStreaming:!0,serverCount:38,gatewayIp:"45.14.194.242",basePingMs:71,coordinates:{lat:50.1109,lng:8.6821}},{iso:"GR",name:"Greece",region:"Europe, Middle East & Africa",continent:"EU",city:"Athens",hasStreaming:!1,serverCount:6,gatewayIp:"185.209.228.59",basePingMs:88,coordinates:{lat:37.9838,lng:23.7275}},{iso:"HU",name:"Hungary",region:"Europe, Middle East & Africa",continent:"EU",city:"Budapest",hasStreaming:!1,serverCount:7,gatewayIp:"194.36.110.22",basePingMs:80,coordinates:{lat:47.4979,lng:19.0402}},{iso:"IS",name:"Iceland",region:"Europe, Middle East & Africa",continent:"EU",city:"Reykjavik",hasStreaming:!1,serverCount:4,gatewayIp:"37.235.49.36",basePingMs:96,coordinates:{lat:64.1466,lng:-21.9426}},{iso:"IE",name:"Ireland",region:"Europe, Middle East & Africa",continent:"EU",city:"Dublin",hasStreaming:!0,serverCount:12,gatewayIp:"193.118.52.238",basePingMs:79,coordinates:{lat:53.3498,lng:-6.2603}},{iso:"IL",name:"Israel",region:"Europe, Middle East & Africa",continent:"AS",city:"Tel Aviv",hasStreaming:!0,serverCount:9,gatewayIp:"45.80.93.249",basePingMs:89,coordinates:{lat:32.0853,lng:34.7818}},{iso:"IT",name:"Italy",region:"Europe, Middle East & Africa",continent:"EU",city:"Milan",hasStreaming:!0,serverCount:18,gatewayIp:"146.70.193.130",basePingMs:77,coordinates:{lat:45.4642,lng:9.19}},{iso:"JO",name:"Jordan",region:"Europe, Middle East & Africa",continent:"AS",city:"Amman",hasStreaming:!1,serverCount:3,gatewayIp:"188.247.92.186",basePingMs:94,coordinates:{lat:31.9454,lng:35.9284}},{iso:"KE",name:"Kenya",region:"Europe, Middle East & Africa",continent:"AF",city:"Nairobi",hasStreaming:!1,serverCount:4,gatewayIp:"102.68.86.97",basePingMs:116,coordinates:{lat:-1.2921,lng:36.8219}},{iso:"KW",name:"Kuwait",region:"Europe, Middle East & Africa",continent:"AS",city:"Kuwait City",hasStreaming:!1,serverCount:4,gatewayIp:"38.54.124.170",basePingMs:78,coordinates:{lat:29.3759,lng:47.9774}},{iso:"LV",name:"Latvia",region:"Europe, Middle East & Africa",continent:"EU",city:"Riga",hasStreaming:!1,serverCount:5,gatewayIp:"89.111.52.71",basePingMs:85,coordinates:{lat:56.9496,lng:24.1052}},{iso:"LT",name:"Lithuania",region:"Europe, Middle East & Africa",continent:"EU",city:"Vilnius",hasStreaming:!1,serverCount:5,gatewayIp:"185.203.119.225",basePingMs:84,coordinates:{lat:54.6872,lng:25.2797}},{iso:"LU",name:"Luxembourg",region:"Europe, Middle East & Africa",continent:"EU",city:"Luxembourg City",hasStreaming:!1,serverCount:6,gatewayIp:"146.70.119.98",basePingMs:75,coordinates:{lat:49.6116,lng:6.1319}},{iso:"MT",name:"Malta",region:"Europe, Middle East & Africa",continent:"EU",city:"Valletta",hasStreaming:!1,serverCount:4,gatewayIp:"146.70.141.66",basePingMs:86,coordinates:{lat:35.8989,lng:14.5146}},{iso:"MA",name:"Morocco",region:"Europe, Middle East & Africa",continent:"AF",city:"Rabat",hasStreaming:!1,serverCount:4,gatewayIp:"105.66.135.42",basePingMs:102,coordinates:{lat:34.0209,lng:-6.8416}},{iso:"NL",name:"Netherlands",region:"Europe, Middle East & Africa",continent:"EU",city:"Amsterdam",hasStreaming:!0,serverCount:34,gatewayIp:"185.107.56.140",basePingMs:72,coordinates:{lat:52.3676,lng:4.9041}},{iso:"NG",name:"Nigeria",region:"Europe, Middle East & Africa",continent:"AF",city:"Lagos",hasStreaming:!1,serverCount:4,gatewayIp:"169.255.57.58",basePingMs:124,coordinates:{lat:6.5244,lng:3.3792}},{iso:"NO",name:"Norway",region:"Europe, Middle East & Africa",continent:"EU",city:"Sandefjord",hasStreaming:!0,serverCount:10,gatewayIp:"185.181.61.141",basePingMs:83,coordinates:{lat:59.1312,lng:10.2167}},{iso:"PL",name:"Poland",region:"Europe, Middle East & Africa",continent:"EU",city:"Warsaw",hasStreaming:!0,serverCount:14,gatewayIp:"185.243.56.185",basePingMs:79,coordinates:{lat:52.2297,lng:21.0122}},{iso:"PT",name:"Portugal",region:"Europe, Middle East & Africa",continent:"EU",city:"Lisbon",hasStreaming:!1,serverCount:7,gatewayIp:"185.240.244.45",basePingMs:85,coordinates:{lat:38.7223,lng:-9.1393}},{iso:"RO",name:"Romania",region:"Europe, Middle East & Africa",continent:"EU",city:"Bucharest",hasStreaming:!0,serverCount:16,gatewayIp:"146.70.125.134",basePingMs:82,coordinates:{lat:44.4268,lng:26.1025}},{iso:"RU",name:"Russia",region:"Europe, Middle East & Africa",continent:"EU",city:"Moscow",hasStreaming:!1,serverCount:8,gatewayIp:"146.70.231.130",basePingMs:90,coordinates:{lat:55.7558,lng:37.6173}},{iso:"RS",name:"Serbia",region:"Europe, Middle East & Africa",continent:"EU",city:"Belgrade",hasStreaming:!1,serverCount:6,gatewayIp:"83.143.82.62",basePingMs:83,coordinates:{lat:44.7866,lng:20.4489}},{iso:"SK",name:"Slovakia",region:"Europe, Middle East & Africa",continent:"EU",city:"Bratislava",hasStreaming:!1,serverCount:5,gatewayIp:"185.205.245.55",basePingMs:80,coordinates:{lat:48.1486,lng:17.1077}},{iso:"SI",name:"Slovenia",region:"Europe, Middle East & Africa",continent:"EU",city:"Ljubljana",hasStreaming:!1,serverCount:4,gatewayIp:"188.214.126.134",basePingMs:81,coordinates:{lat:46.0569,lng:14.5058}},{iso:"ZA",name:"South Africa",region:"Europe, Middle East & Africa",continent:"AF",city:"Johannesburg",hasStreaming:!0,serverCount:8,gatewayIp:"102.130.113.105",basePingMs:142,coordinates:{lat:-26.2041,lng:28.0473}},{iso:"ES",name:"Spain",region:"Europe, Middle East & Africa",continent:"EU",city:"Madrid",hasStreaming:!0,serverCount:16,gatewayIp:"185.253.97.205",basePingMs:81,coordinates:{lat:40.4168,lng:-3.7038}},{iso:"SE",name:"Sweden",region:"Europe, Middle East & Africa",continent:"EU",city:"Stockholm",hasStreaming:!0,serverCount:14,gatewayIp:"185.213.154.170",basePingMs:83,coordinates:{lat:59.3293,lng:18.0686}},{iso:"CH",name:"Switzerland",region:"Europe, Middle East & Africa",continent:"EU",city:"Zurich",hasStreaming:!0,serverCount:16,gatewayIp:"185.246.208.73",basePingMs:75,coordinates:{lat:47.3769,lng:8.5417}},{iso:"TR",name:"Turkey",region:"Europe, Middle East & Africa",continent:"EU",city:"Istanbul",hasStreaming:!0,serverCount:10,gatewayIp:"185.126.178.79",basePingMs:86,coordinates:{lat:41.0082,lng:28.9784}},{iso:"UA",name:"Ukraine",region:"Europe, Middle East & Africa",continent:"EU",city:"Kyiv",hasStreaming:!1,serverCount:7,gatewayIp:"185.246.209.251",basePingMs:88,coordinates:{lat:50.4501,lng:30.5234}},{iso:"AE",name:"United Arab Emirates",region:"Europe, Middle East & Africa",continent:"AS",city:"Dubai",hasStreaming:!0,serverCount:12,gatewayIp:"146.70.189.2",basePingMs:68,coordinates:{lat:25.2048,lng:55.2708}},{iso:"GB",name:"United Kingdom",region:"Europe, Middle East & Africa",continent:"EU",city:"London",hasStreaming:!0,serverCount:42,gatewayIp:"149.102.244.142",basePingMs:73,coordinates:{lat:51.5074,lng:-.1278}}],Fc={AF:"Afghanistan",AL:"Albania",DZ:"Algeria",AS:"American Samoa",AD:"Andorra",AO:"Angola",AI:"Anguilla",AQ:"Antarctica",AG:"Antigua and Barbuda",AR:"Argentina",AM:"Armenia",AW:"Aruba",AU:"Australia",AT:"Austria",AX:"Aland Islands",AZ:"Azerbaijan",BS:"Bahamas",BH:"Bahrain",BD:"Bangladesh",BB:"Barbados",BY:"Belarus",BE:"Belgium",BZ:"Belize",BJ:"Benin",BM:"Bermuda",BT:"Bhutan",BO:"Bolivia",BA:"Bosnia and Herzegovina",BW:"Botswana",BV:"Bouvet Island",BR:"Brazil",IO:"British Indian Ocean Territory",VG:"British Virgin Islands",BN:"Brunei",BG:"Bulgaria",BF:"Burkina Faso",BI:"Burundi",KH:"Cambodia",CM:"Cameroon",CA:"Canada",CV:"Cape Verde",BQ:"Caribbean Netherlands",KY:"Cayman Islands",CF:"Central African Republic",TD:"Chad",CL:"Chile",CN:"China",CX:"Christmas Island",CC:"Cocos Islands",CO:"Colombia",KM:"Comoros",CG:"Congo",CK:"Cook Islands",CR:"Costa Rica",HR:"Croatia",CU:"Cuba",CW:"Curacao",CY:"Cyprus",CZ:"Czech Republic",CD:"Democratic Republic of the Congo",DK:"Denmark",DJ:"Djibouti",DM:"Dominica",DO:"Dominican Republic",EC:"Ecuador",EG:"Egypt",SV:"El Salvador",GQ:"Equatorial Guinea",ER:"Eritrea",EE:"Estonia",SZ:"Eswatini",ET:"Ethiopia",FK:"Falkland Islands",FO:"Faroe Islands",FJ:"Fiji",FI:"Finland",FR:"France",GF:"French Guiana",PF:"French Polynesia",TF:"French Southern Territories",GA:"Gabon",GM:"Gambia",GE:"Georgia",DE:"Germany",GH:"Ghana",GI:"Gibraltar",GR:"Greece",GL:"Greenland",GD:"Grenada",GP:"Guadeloupe",GU:"Guam",GT:"Guatemala",GG:"Guernsey",GN:"Guinea",GW:"Guinea-Bissau",GY:"Guyana",HT:"Haiti",HM:"Heard Island and McDonald Islands",HN:"Honduras",HK:"Hong Kong",HU:"Hungary",IS:"Iceland",IN:"India",ID:"Indonesia",IR:"Iran",IQ:"Iraq",IE:"Ireland",IM:"Isle of Man",IL:"Israel",IT:"Italy",CI:"Ivory Coast",JM:"Jamaica",JP:"Japan",JE:"Jersey",JO:"Jordan",KZ:"Kazakhstan",KE:"Kenya",KI:"Kiribati",XK:"Kosovo",KW:"Kuwait",KG:"Kyrgyzstan",LA:"Laos",LV:"Latvia",LB:"Lebanon",LS:"Lesotho",LR:"Liberia",LY:"Libya",LI:"Liechtenstein",LT:"Lithuania",LU:"Luxembourg",MO:"Macao",MG:"Madagascar",MW:"Malawi",MY:"Malaysia",MV:"Maldives",ML:"Mali",MT:"Malta",MH:"Marshall Islands",MQ:"Martinique",MR:"Mauritania",MU:"Mauritius",YT:"Mayotte",MX:"Mexico",FM:"Micronesia",MD:"Moldova",MC:"Monaco",MN:"Mongolia",ME:"Montenegro",MS:"Montserrat",MA:"Morocco",MZ:"Mozambique",MM:"Myanmar",NA:"Namibia",NR:"Nauru",NP:"Nepal",NL:"Netherlands",NC:"New Caledonia",NZ:"New Zealand",NI:"Nicaragua",NE:"Niger",NG:"Nigeria",NU:"Niue",NF:"Norfolk Island",KP:"North Korea",MK:"North Macedonia",MP:"Northern Mariana Islands",NO:"Norway",OM:"Oman",PK:"Pakistan",PW:"Palau",PS:"Palestinian Territory",PA:"Panama",PG:"Papua New Guinea",PY:"Paraguay",PE:"Peru",PH:"Philippines",PN:"Pitcairn",PL:"Poland",PT:"Portugal",PR:"Puerto Rico",QA:"Qatar",RE:"Reunion",RO:"Romania",RU:"Russia",RW:"Rwanda",BL:"Saint Barthelemy",SH:"Saint Helena",KN:"Saint Kitts and Nevis",LC:"Saint Lucia",MF:"Saint Martin",PM:"Saint Pierre and Miquelon",VC:"Saint Vincent and the Grenadines",WS:"Samoa",SM:"San Marino",ST:"Sao Tome and Principe",SA:"Saudi Arabia",SN:"Senegal",RS:"Serbia",SC:"Seychelles",SL:"Sierra Leone",SG:"Singapore",SX:"Sint Maarten",SK:"Slovakia",SI:"Slovenia",SB:"Solomon Islands",SO:"Somalia",ZA:"South Africa",GS:"South Georgia and the South Sandwich Islands",KR:"South Korea",SS:"South Sudan",ES:"Spain",LK:"Sri Lanka",SD:"Sudan",SR:"Suriname",SJ:"Svalbard and Jan Mayen",SE:"Sweden",CH:"Switzerland",SY:"Syria",TW:"Taiwan",TJ:"Tajikistan",TZ:"Tanzania",TH:"Thailand",TL:"Timor-Leste",TG:"Togo",TK:"Tokelau",TO:"Tonga",TT:"Trinidad and Tobago",TN:"Tunisia",TR:"Turkey",TM:"Turkmenistan",TC:"Turks and Caicos Islands",TV:"Tuvalu",VI:"U.S. Virgin Islands",UG:"Uganda",UA:"Ukraine",AE:"United Arab Emirates",GB:"United Kingdom",US:"United States",UM:"United States Minor Outlying Islands",UY:"Uruguay",UZ:"Uzbekistan",VU:"Vanuatu",VA:"Vatican",VE:"Venezuela",VN:"Vietnam",WF:"Wallis and Futuna",EH:"Western Sahara",YE:"Yemen",ZM:"Zambia",ZW:"Zimbabwe"};function nv(s){const e=s.charCodeAt(0)||85,t=s.charCodeAt(1)||83;return`LuciferLinkX_${s}_NodeKey2026_${(e*31+t*17).toString(16).padStart(4,"0")}==`.slice(0,44).padEnd(44,"=")}function s_(s){switch(s){case"NA":case"SA":return{isp:"Lucifer Tunnel / Datacamp Limited",asn:"AS60068 Datacamp Limited"};case"AS":case"OC":return{isp:"Lucifer Tunnel / M247 Asia-Pacific",asn:"AS9009 M247 Europe SRL"};default:return{isp:"Lucifer Tunnel / M247 Ltd",asn:"AS9009 M247 Europe SRL"}}}function iv(s,e=0){const t=(s||"US").toUpperCase(),r=tv.find(p=>p.iso===t);if(r){if(e===0)return r.gatewayIp;const p=r.gatewayIp.split(".").map(Number),y=(p[3]+e*7)%240+10;return`${p[0]}.${p[1]}.${p[2]}.${y}`}const o=t.charCodeAt(0)||65,l=t.charCodeAt(1)||66,u=(o*3+l)%200+20,d=(o*7+l*5)%220+15,f=(o*11+l*13+e*7)%230+12;return`185.${u}.${d}.${f}`}function rv(s,e=!1){const t=s.iso.toUpperCase(),r=t.toLowerCase(),o=s_(s.continent||"EU");return{iso:t,isoLower:r,name:s.name||Fc[t]||t,region:s.region||"Europe, Middle East & Africa",continent:s.continent||"EU",city:s.city||`${s.name||Fc[t]||t} Gateway`,hasStreaming:!!s.hasStreaming,serverCount:s.serverCount||2,gatewayIp:s.gatewayIp||iv(t,0),isp:s.isp||o.isp,asn:s.asn||o.asn,basePingMs:s.basePingMs||85,coordinates:s.coordinates||{lat:25,lng:18},wgPublicKey:nv(t),endpointHost:`${r}-wg01.lucifertunnel.net`,isExtendedLocation:e}}const Oc=tv.map(s=>rv(s,!1)).sort((s,e)=>s.name.localeCompare(e.name)),o_=new Set(Oc.map(s=>s.iso)),a_={BD:{city:"Dhaka",region:"Asia & Oceania",continent:"AS",gatewayIp:"103.145.72.94",basePingMs:24,serverCount:4,coordinates:{lat:23.8103,lng:90.4125}},GH:{city:"Accra",region:"Europe, Middle East & Africa",continent:"AF",gatewayIp:"169.255.56.147",basePingMs:118,serverCount:3,coordinates:{lat:5.6037,lng:-.187}},NP:{city:"Kathmandu",region:"Asia & Oceania",continent:"AS",gatewayIp:"103.139.64.38",basePingMs:36,serverCount:3,coordinates:{lat:27.7172,lng:85.324}},KH:{city:"Phnom Penh",region:"Asia & Oceania",continent:"AS",gatewayIp:"103.133.120.71",basePingMs:52,serverCount:3,coordinates:{lat:11.5564,lng:104.9282}}},l_=[...Oc,...Object.entries(Fc).filter(([s])=>!o_.has(s)).map(([s,e])=>{const t=a_[s]||{},r=s.charCodeAt(0)||65,o=s.charCodeAt(1)||66;return rv({iso:s,name:e,region:t.region||"Global Extended Network",continent:t.continent||"EU",city:t.city||`${e} Edge Relay`,hasStreaming:!1,serverCount:t.serverCount||2,gatewayIp:t.gatewayIp||iv(s,0),basePingMs:t.basePingMs||60+(r*5+o*3)%75,coordinates:t.coordinates||{lat:r*7%100-40,lng:o*13%280-140}},!0)})].sort((s,e)=>s.name.localeCompare(e.name));function c_(s){if(!s)return"Unknown";const e=s.toUpperCase();return Fc[e]||e}function No(s){return`/resources/icons/flags/ic_flag_${(s||"unknown").toLowerCase()}.webp`}function Xn(s){if(!s)return null;const e=s.toUpperCase();return l_.find(t=>t.iso===e)||null}const wg={AR:"America/Argentina/Buenos_Aires",BO:"America/La_Paz",BR:"America/Sao_Paulo",CA:"America/Toronto",CL:"America/Santiago",CO:"America/Bogota",CR:"America/Costa_Rica",EC:"America/Guayaquil",GT:"America/Guatemala",MX:"America/Mexico_City",NI:"America/Managua",PA:"America/Panama",PY:"America/Asuncion",PE:"America/Lima",PR:"America/Puerto_Rico",US:"America/New_York",UY:"America/Montevideo",AU:"Australia/Melbourne",BD:"Asia/Dhaka",CN:"Asia/Shanghai",HK:"Asia/Hong_Kong",IN:"Asia/Kolkata",ID:"Asia/Jakarta",JP:"Asia/Tokyo",KZ:"Asia/Almaty",KG:"Asia/Bishkek",KH:"Asia/Phnom_Penh",MY:"Asia/Kuala_Lumpur",MN:"Asia/Ulaanbaatar",NP:"Asia/Kathmandu",NZ:"Pacific/Auckland",PK:"Asia/Karachi",PH:"Asia/Manila",SG:"Asia/Singapore",KR:"Asia/Seoul",LK:"Asia/Colombo",TW:"Asia/Taipei",TH:"Asia/Bangkok",VN:"Asia/Ho_Chi_Minh",DZ:"Africa/Algiers",AT:"Europe/Vienna",BY:"Europe/Minsk",BE:"Europe/Brussels",BG:"Europe/Sofia",HR:"Europe/Zagreb",CY:"Asia/Nicosia",CZ:"Europe/Prague",DK:"Europe/Copenhagen",EG:"Africa/Cairo",EE:"Europe/Tallinn",FI:"Europe/Helsinki",FR:"Europe/Paris",GE:"Asia/Tbilisi",DE:"Europe/Berlin",GH:"Africa/Accra",GR:"Europe/Athens",HU:"Europe/Budapest",IS:"Atlantic/Reykjavik",IE:"Europe/Dublin",IL:"Asia/Jerusalem",IT:"Europe/Rome",JO:"Asia/Amman",KE:"Africa/Nairobi",KW:"Asia/Kuwait",LV:"Europe/Riga",LT:"Europe/Vilnius",LU:"Europe/Luxembourg",MT:"Europe/Malta",MA:"Africa/Casablanca",NL:"Europe/Amsterdam",NG:"Africa/Lagos",NO:"Europe/Oslo",PL:"Europe/Warsaw",PT:"Europe/Lisbon",RO:"Europe/Bucharest",RU:"Europe/Moscow",RS:"Europe/Belgrade",SA:"Asia/Riyadh",SK:"Europe/Bratislava",SI:"Europe/Ljubljana",ZA:"Africa/Johannesburg",ES:"Europe/Madrid",SE:"Europe/Stockholm",CH:"Europe/Zurich",TR:"Europe/Istanbul",UA:"Europe/Kyiv",AE:"Asia/Dubai",GB:"Europe/London"};function u_(s){const e=String(s).toUpperCase().trim();if(e&&wg[e])return wg[e];try{return Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC"}catch{return"UTC"}}function Da(s,e=new Date,t={}){var f;const{showCountryTag:r=!0,hour12:o=!0}=t,l=String(s||"BD").toUpperCase().trim()||"BD",u=u_(l);let d=e instanceof Date?e:new Date(e);Number.isNaN(d.getTime())&&(d=new Date);try{const p=new Intl.DateTimeFormat("en-US",{timeZone:u,hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:o}).format(d);return r?`${p} (${l} Time)`:p}catch{const p=Xn(l),y=(f=p==null?void 0:p.coordinates)!=null&&f.lng?Math.round(p.coordinates.lng/15):6,S=new Date(d.getTime()+y*3600*1e3),v=String(S.getUTCHours()).padStart(2,"0"),_=String(S.getUTCMinutes()).padStart(2,"0"),M=String(S.getUTCSeconds()).padStart(2,"0");return r?`${v}:${_}:${M} (${l} Time)`:`${v}:${_}:${M}`}}function d_(s,e){const t=String(s||"").trim(),r=String(e).toUpperCase().trim()||"BD";if(!t)return Da(r,new Date,{showCountryTag:!0,hour12:!0});if(/AM|PM|Time/i.test(t))return t;if(t.includes("T")&&t.includes("Z"))return Da(r,new Date(t),{showCountryTag:!0,hour12:!0});const o=t.match(/^(\d{2}):(\d{2}):(\d{2})$/);if(o){const l=new Date,u=new Date(Date.UTC(l.getUTCFullYear(),l.getUTCMonth(),l.getUTCDate(),parseInt(o[1],10),parseInt(o[2],10),parseInt(o[3],10)));return Da(r,u,{showCountryTag:!0,hour12:!0})}return t}function f_(s,e="cGxlYXNlX3JlcGxhY2Vfd2l0aF94MjU1MTlfcHJpdmF0ZV9rZXk=",t="10.66.142.18/32"){const r=typeof s=="string"?Xn(s):s,o=r?r.gatewayIp:"86.106.92.149",l=r?r.wgPublicKey:nv("US");return["[Interface]",`PrivateKey = ${e}`,`Address = ${t}`,"DNS = 1.1.1.1, 1.0.0.1","","[Peer]",`PublicKey = ${l}`,"PresharedKey = U2FsdGVkX19VcmJhblZQTkxpbmtYUHJlc2hhcmVkS2V5MjAyNg==",`Endpoint = ${o}:51820`,"AllowedIPs = 0.0.0.0/0, ::/0","PersistentKeepalive = 25"].join(`
`)}function h_(s,e="UDP"){const t=typeof s=="string"?Xn(s):s,r=t?t.gatewayIp:"86.106.92.149",o=String(e).toLowerCase().includes("tcp")?"tcp":"udp",l=o==="tcp"?443:1194;return["client","dev tun","windows-driver ovpn-dco",`proto ${o}`,`remote ${r} ${l}`,"resolv-retry infinite","nobind","persist-key","persist-tun","cipher AES-256-GCM","auth SHA256","verb 3"].join(`
`)}/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const xh="186",Do={ROTATE:0,DOLLY:1,PAN:2},Ro={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},p_=0,Tg=1,m_=2,Ac=1,g_=2,La=3,Ds=0,Jn=1,zi=2,Cr=0,Ua=1,Ps=2,Ag=3,bg=4,v_=5,Co=100,x_=101,y_=102,__=103,S_=104,M_=200,E_=201,w_=202,T_=203,sv=204,ov=205,A_=206,b_=207,C_=208,R_=209,P_=210,I_=211,L_=212,N_=213,D_=214,Sf=0,Mf=1,Ef=2,Va=3,wf=4,Tf=5,Af=6,bf=7,av=0,U_=1,F_=2,rr=0,lv=1,cv=2,uv=3,yh=4,dv=5,fv=6,hv=7,pv=300,Us=301,ko=302,Dd=303,Ud=304,$c=306,Cf=1e3,br=1001,Rf=1002,Un=1003,O_=1004,Jl=1005,Yn=1006,Fd=1007,Is=1008,vi=1009,mv=1010,gv=1011,Ha=1012,_h=1013,sr=1014,Hi=1015,or=1016,Sh=1017,Mh=1018,Ga=1020,vv=35902,xv=35899,yv=1021,_v=1022,Gi=1023,Pr=1026,Ls=1027,Eh=1028,wh=1029,Fs=1030,Th=1031,Ah=1033,bc=33776,Cc=33777,Rc=33778,Pc=33779,Pf=35840,If=35841,Lf=35842,Nf=35843,Df=36196,Uf=37492,Ff=37496,Of=37488,kf=37489,kc=37490,Bf=37491,zf=37808,Vf=37809,Hf=37810,Gf=37811,Wf=37812,jf=37813,Xf=37814,Yf=37815,qf=37816,Kf=37817,$f=37818,Zf=37819,Jf=37820,Qf=37821,eh=36492,th=36494,nh=36495,ih=36283,rh=36284,Bc=36285,sh=36286,k_=3200,oh=0,B_=1,ss="",gi="srgb",zc="srgb-linear",Vc="linear",qt="srgb",Od=7680,z_=519,V_=512,H_=513,G_=514,bh=515,W_=516,j_=517,Ch=518,X_=519,Y_=35044,Cg="300 es",ir=2e3,Wa=2001;function q_(s){for(let e=s.length-1;e>=0;--e)if(s[e]>=65535)return!0;return!1}function Hc(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function K_(){const s=Hc("canvas");return s.style.display="block",s}const Rg={};function Pg(...s){const e="THREE."+s.shift();console.log(e,...s)}function Sv(s){const e=s[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=s[1];t&&t.isStackTrace?s[0]+=" "+t.getLocation():s[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return s}function ht(...s){s=Sv(s);const e="THREE."+s.shift();{const t=s[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...s)}}function zt(...s){s=Sv(s);const e="THREE."+s.shift();{const t=s[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...s)}}function Uo(...s){const e=s.join(" ");e in Rg||(Rg[e]=!0,ht(...s))}function $_(s,e,t){return new Promise(function(r,o){function l(){switch(s.clientWaitSync(e,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:o();break;case s.TIMEOUT_EXPIRED:setTimeout(l,t);break;default:r()}}setTimeout(l,t)})}const Z_={[Sf]:Mf,[Ef]:Af,[wf]:bf,[Va]:Tf,[Mf]:Sf,[Af]:Ef,[bf]:wf,[Tf]:Va};class ds{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const r=this._listeners;r[e]===void 0&&(r[e]=[]),r[e].indexOf(t)===-1&&r[e].push(t)}hasEventListener(e,t){const r=this._listeners;return r===void 0?!1:r[e]!==void 0&&r[e].indexOf(t)!==-1}removeEventListener(e,t){const r=this._listeners;if(r===void 0)return;const o=r[e];if(o!==void 0){const l=o.indexOf(t);l!==-1&&o.splice(l,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const r=t[e.type];if(r!==void 0){e.target=this;const o=r.slice(0);for(let l=0,u=o.length;l<u;l++)o[l].call(this,e);e.target=null}}}const Hn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Ic=Math.PI/180,ah=180/Math.PI;function qa(){const s=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(Hn[s&255]+Hn[s>>8&255]+Hn[s>>16&255]+Hn[s>>24&255]+"-"+Hn[e&255]+Hn[e>>8&255]+"-"+Hn[e>>16&15|64]+Hn[e>>24&255]+"-"+Hn[t&63|128]+Hn[t>>8&255]+"-"+Hn[t>>16&255]+Hn[t>>24&255]+Hn[r&255]+Hn[r>>8&255]+Hn[r>>16&255]+Hn[r>>24&255]).toLowerCase()}function Pt(s,e,t){return Math.max(e,Math.min(t,s))}function J_(s,e){return(s%e+e)%e}function kd(s,e,t){return(1-t)*s+t*e}function Ma(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:case Uint8ClampedArray:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function li(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Q_={DEG2RAD:Ic},Hh=class Hh{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,r=this.y,o=e.elements;return this.x=o[0]*t+o[3]*r+o[6],this.y=o[1]*t+o[4]*r+o[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Pt(this.x,e.x,t.x),this.y=Pt(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Pt(this.x,e,t),this.y=Pt(this.y,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(Pt(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const r=this.dot(e)/t;return Math.acos(Pt(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,r=this.y-e.y;return t*t+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const r=Math.cos(t),o=Math.sin(t),l=this.x-e.x,u=this.y-e.y;return this.x=l*r-u*o+e.x,this.y=l*o+u*r+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Hh.prototype.isVector2=!0;let dt=Hh;class ls{constructor(e=0,t=0,r=0,o=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=r,this._w=o}static slerpFlat(e,t,r,o,l,u,d){let f=r[o+0],p=r[o+1],y=r[o+2],S=r[o+3],v=l[u+0],_=l[u+1],M=l[u+2],A=l[u+3];if(S!==A||f!==v||p!==_||y!==M){let m=f*v+p*_+y*M+S*A;m<0&&(v=-v,_=-_,M=-M,A=-A,m=-m);let x=1-d;if(m<.9995){const P=Math.acos(m),U=Math.sin(P);x=Math.sin(x*P)/U,d=Math.sin(d*P)/U,f=f*x+v*d,p=p*x+_*d,y=y*x+M*d,S=S*x+A*d}else{f=f*x+v*d,p=p*x+_*d,y=y*x+M*d,S=S*x+A*d;const P=1/Math.sqrt(f*f+p*p+y*y+S*S);f*=P,p*=P,y*=P,S*=P}}e[t]=f,e[t+1]=p,e[t+2]=y,e[t+3]=S}static multiplyQuaternionsFlat(e,t,r,o,l,u){const d=r[o],f=r[o+1],p=r[o+2],y=r[o+3],S=l[u],v=l[u+1],_=l[u+2],M=l[u+3];return e[t]=d*M+y*S+f*_-p*v,e[t+1]=f*M+y*v+p*S-d*_,e[t+2]=p*M+y*_+d*v-f*S,e[t+3]=y*M-d*S-f*v-p*_,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,r,o){return this._x=e,this._y=t,this._z=r,this._w=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const r=e._x,o=e._y,l=e._z,u=e._order,d=Math.cos,f=Math.sin,p=d(r/2),y=d(o/2),S=d(l/2),v=f(r/2),_=f(o/2),M=f(l/2);switch(u){case"XYZ":this._x=v*y*S+p*_*M,this._y=p*_*S-v*y*M,this._z=p*y*M+v*_*S,this._w=p*y*S-v*_*M;break;case"YXZ":this._x=v*y*S+p*_*M,this._y=p*_*S-v*y*M,this._z=p*y*M-v*_*S,this._w=p*y*S+v*_*M;break;case"ZXY":this._x=v*y*S-p*_*M,this._y=p*_*S+v*y*M,this._z=p*y*M+v*_*S,this._w=p*y*S-v*_*M;break;case"ZYX":this._x=v*y*S-p*_*M,this._y=p*_*S+v*y*M,this._z=p*y*M-v*_*S,this._w=p*y*S+v*_*M;break;case"YZX":this._x=v*y*S+p*_*M,this._y=p*_*S+v*y*M,this._z=p*y*M-v*_*S,this._w=p*y*S-v*_*M;break;case"XZY":this._x=v*y*S-p*_*M,this._y=p*_*S-v*y*M,this._z=p*y*M+v*_*S,this._w=p*y*S+v*_*M;break;default:ht("Quaternion: .setFromEuler() encountered an unknown order: "+u)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const r=t/2,o=Math.sin(r);return this._x=e.x*o,this._y=e.y*o,this._z=e.z*o,this._w=Math.cos(r),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,r=t[0],o=t[4],l=t[8],u=t[1],d=t[5],f=t[9],p=t[2],y=t[6],S=t[10],v=r+d+S;if(v>0){const _=.5/Math.sqrt(v+1);this._w=.25/_,this._x=(y-f)*_,this._y=(l-p)*_,this._z=(u-o)*_}else if(r>d&&r>S){const _=2*Math.sqrt(1+r-d-S);this._w=(y-f)/_,this._x=.25*_,this._y=(o+u)/_,this._z=(l+p)/_}else if(d>S){const _=2*Math.sqrt(1+d-r-S);this._w=(l-p)/_,this._x=(o+u)/_,this._y=.25*_,this._z=(f+y)/_}else{const _=2*Math.sqrt(1+S-r-d);this._w=(u-o)/_,this._x=(l+p)/_,this._y=(f+y)/_,this._z=.25*_}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let r=e.dot(t)+1;return r<1e-8?(r=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=r):(this._x=0,this._y=-e.z,this._z=e.y,this._w=r)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=r),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Pt(this.dot(e),-1,1)))}rotateTowards(e,t){const r=this.angleTo(e);if(r===0)return this;const o=Math.min(1,t/r);return this.slerp(e,o),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const r=e._x,o=e._y,l=e._z,u=e._w,d=t._x,f=t._y,p=t._z,y=t._w;return this._x=r*y+u*d+o*p-l*f,this._y=o*y+u*f+l*d-r*p,this._z=l*y+u*p+r*f-o*d,this._w=u*y-r*d-o*f-l*p,this._onChangeCallback(),this}slerp(e,t){let r=e._x,o=e._y,l=e._z,u=e._w,d=this.dot(e);d<0&&(r=-r,o=-o,l=-l,u=-u,d=-d);let f=1-t;if(d<.9995){const p=Math.acos(d),y=Math.sin(p);f=Math.sin(f*p)/y,t=Math.sin(t*p)/y,this._x=this._x*f+r*t,this._y=this._y*f+o*t,this._z=this._z*f+l*t,this._w=this._w*f+u*t,this._onChangeCallback()}else this._x=this._x*f+r*t,this._y=this._y*f+o*t,this._z=this._z*f+l*t,this._w=this._w*f+u*t,this.normalize();return this}slerpQuaternions(e,t,r){return this.copy(e).slerp(t,r)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),r=Math.random(),o=Math.sqrt(1-r),l=Math.sqrt(r);return this.set(o*Math.sin(e),o*Math.cos(e),l*Math.sin(t),l*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Gh=class Gh{constructor(e=0,t=0,r=0){this.x=e,this.y=t,this.z=r}set(e,t,r){return r===void 0&&(r=this.z),this.x=e,this.y=t,this.z=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Ig.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Ig.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,r=this.y,o=this.z,l=e.elements;return this.x=l[0]*t+l[3]*r+l[6]*o,this.y=l[1]*t+l[4]*r+l[7]*o,this.z=l[2]*t+l[5]*r+l[8]*o,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,r=this.y,o=this.z,l=e.elements,u=1/(l[3]*t+l[7]*r+l[11]*o+l[15]);return this.x=(l[0]*t+l[4]*r+l[8]*o+l[12])*u,this.y=(l[1]*t+l[5]*r+l[9]*o+l[13])*u,this.z=(l[2]*t+l[6]*r+l[10]*o+l[14])*u,this}applyQuaternion(e){const t=this.x,r=this.y,o=this.z,l=e.x,u=e.y,d=e.z,f=e.w,p=2*(u*o-d*r),y=2*(d*t-l*o),S=2*(l*r-u*t);return this.x=t+f*p+u*S-d*y,this.y=r+f*y+d*p-l*S,this.z=o+f*S+l*y-u*p,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,r=this.y,o=this.z,l=e.elements;return this.x=l[0]*t+l[4]*r+l[8]*o,this.y=l[1]*t+l[5]*r+l[9]*o,this.z=l[2]*t+l[6]*r+l[10]*o,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Pt(this.x,e.x,t.x),this.y=Pt(this.y,e.y,t.y),this.z=Pt(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Pt(this.x,e,t),this.y=Pt(this.y,e,t),this.z=Pt(this.z,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(Pt(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this.z=e.z+(t.z-e.z)*r,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const r=e.x,o=e.y,l=e.z,u=t.x,d=t.y,f=t.z;return this.x=o*f-l*d,this.y=l*u-r*f,this.z=r*d-o*u,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const r=e.dot(this)/t;return this.copy(e).multiplyScalar(r)}projectOnPlane(e){return Bd.copy(this).projectOnVector(e),this.sub(Bd)}reflect(e){return this.sub(Bd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const r=this.dot(e)/t;return Math.acos(Pt(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,r=this.y-e.y,o=this.z-e.z;return t*t+r*r+o*o}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,r){const o=Math.sin(t)*e;return this.x=o*Math.sin(r),this.y=Math.cos(t)*e,this.z=o*Math.cos(r),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,r){return this.x=e*Math.sin(t),this.y=r,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),r=this.setFromMatrixColumn(e,1).length(),o=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=r,this.z=o,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,r=Math.sqrt(1-t*t);return this.x=r*Math.cos(e),this.y=t,this.z=r*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Gh.prototype.isVector3=!0;let Z=Gh;const Bd=new Z,Ig=new ls,Wh=class Wh{constructor(e,t,r,o,l,u,d,f,p){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,r,o,l,u,d,f,p)}set(e,t,r,o,l,u,d,f,p){const y=this.elements;return y[0]=e,y[1]=o,y[2]=d,y[3]=t,y[4]=l,y[5]=f,y[6]=r,y[7]=u,y[8]=p,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,r=e.elements;return t[0]=r[0],t[1]=r[1],t[2]=r[2],t[3]=r[3],t[4]=r[4],t[5]=r[5],t[6]=r[6],t[7]=r[7],t[8]=r[8],this}extractBasis(e,t,r){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),r.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const r=e.elements,o=t.elements,l=this.elements,u=r[0],d=r[3],f=r[6],p=r[1],y=r[4],S=r[7],v=r[2],_=r[5],M=r[8],A=o[0],m=o[3],x=o[6],P=o[1],U=o[4],b=o[7],R=o[2],N=o[5],F=o[8];return l[0]=u*A+d*P+f*R,l[3]=u*m+d*U+f*N,l[6]=u*x+d*b+f*F,l[1]=p*A+y*P+S*R,l[4]=p*m+y*U+S*N,l[7]=p*x+y*b+S*F,l[2]=v*A+_*P+M*R,l[5]=v*m+_*U+M*N,l[8]=v*x+_*b+M*F,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],r=e[1],o=e[2],l=e[3],u=e[4],d=e[5],f=e[6],p=e[7],y=e[8];return t*u*y-t*d*p-r*l*y+r*d*f+o*l*p-o*u*f}invert(){const e=this.elements,t=e[0],r=e[1],o=e[2],l=e[3],u=e[4],d=e[5],f=e[6],p=e[7],y=e[8],S=y*u-d*p,v=d*f-y*l,_=p*l-u*f,M=t*S+r*v+o*_;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const A=1/M;return e[0]=S*A,e[1]=(o*p-y*r)*A,e[2]=(d*r-o*u)*A,e[3]=v*A,e[4]=(y*t-o*f)*A,e[5]=(o*l-d*t)*A,e[6]=_*A,e[7]=(r*f-p*t)*A,e[8]=(u*t-r*l)*A,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,r,o,l,u,d){const f=Math.cos(l),p=Math.sin(l);return this.set(r*f,r*p,-r*(f*u+p*d)+u+e,-o*p,o*f,-o*(-p*u+f*d)+d+t,0,0,1),this}scale(e,t){return Uo("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(zd.makeScale(e,t)),this}rotate(e){return Uo("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(zd.makeRotation(-e)),this}translate(e,t){return Uo("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(zd.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,-r,0,r,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,r=e.elements;for(let o=0;o<9;o++)if(t[o]!==r[o])return!1;return!0}fromArray(e,t=0){for(let r=0;r<9;r++)this.elements[r]=e[r+t];return this}toArray(e=[],t=0){const r=this.elements;return e[t]=r[0],e[t+1]=r[1],e[t+2]=r[2],e[t+3]=r[3],e[t+4]=r[4],e[t+5]=r[5],e[t+6]=r[6],e[t+7]=r[7],e[t+8]=r[8],e}clone(){return new this.constructor().fromArray(this.elements)}};Wh.prototype.isMatrix3=!0;let yt=Wh;const zd=new yt,Lg=new yt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Ng=new yt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function e1(){const s={enabled:!0,workingColorSpace:zc,spaces:{},convert:function(o,l,u){return this.enabled===!1||l===u||!l||!u||(this.spaces[l].transfer===qt&&(o.r=Rr(o.r),o.g=Rr(o.g),o.b=Rr(o.b)),this.spaces[l].primaries!==this.spaces[u].primaries&&(o.applyMatrix3(this.spaces[l].toXYZ),o.applyMatrix3(this.spaces[u].fromXYZ)),this.spaces[u].transfer===qt&&(o.r=Fo(o.r),o.g=Fo(o.g),o.b=Fo(o.b))),o},workingToColorSpace:function(o,l){return this.convert(o,this.workingColorSpace,l)},colorSpaceToWorking:function(o,l){return this.convert(o,l,this.workingColorSpace)},getPrimaries:function(o){return this.spaces[o].primaries},getTransfer:function(o){return o===ss?Vc:this.spaces[o].transfer},getToneMappingMode:function(o){return this.spaces[o].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(o,l=this.workingColorSpace){return o.fromArray(this.spaces[l].luminanceCoefficients)},define:function(o){Object.assign(this.spaces,o)},_getMatrix:function(o,l,u){return o.copy(this.spaces[l].toXYZ).multiply(this.spaces[u].fromXYZ)},_getDrawingBufferColorSpace:function(o){return this.spaces[o].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(o=this.workingColorSpace){return this.spaces[o].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(o,l){return Uo("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(o,l)},toWorkingColorSpace:function(o,l){return Uo("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(o,l)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],r=[.3127,.329];return s.define({[zc]:{primaries:e,whitePoint:r,transfer:Vc,toXYZ:Lg,fromXYZ:Ng,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:gi},outputColorSpaceConfig:{drawingBufferColorSpace:gi}},[gi]:{primaries:e,whitePoint:r,transfer:qt,toXYZ:Lg,fromXYZ:Ng,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:gi}}}),s}const Dt=e1();function Rr(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Fo(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let ho;class t1{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let r;if(e instanceof HTMLCanvasElement)r=e;else{ho===void 0&&(ho=Hc("canvas")),ho.width=e.width,ho.height=e.height;const o=ho.getContext("2d");e instanceof ImageData?o.putImageData(e,0,0):o.drawImage(e,0,0,e.width,e.height),r=ho}return r.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Hc("canvas");t.width=e.width,t.height=e.height;const r=t.getContext("2d");r.drawImage(e,0,0,e.width,e.height);const o=r.getImageData(0,0,e.width,e.height),l=o.data;for(let u=0;u<l.length;u++)l[u]=Rr(l[u]/255)*255;return r.putImageData(o,0,0),t}else if(e.data){const t=e.data.slice(0);for(let r=0;r<t.length;r++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[r]=Math.floor(Rr(t[r]/255)*255):t[r]=Rr(t[r]);return{data:t,width:e.width,height:e.height}}else return ht("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let n1=0;class Rh{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:n1++}),this.uuid=qa(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const r={uuid:this.uuid,url:""},o=this.data;if(o!==null){let l;if(Array.isArray(o)){l=[];for(let u=0,d=o.length;u<d;u++)o[u].isDataTexture?l.push(Vd(o[u].image)):l.push(Vd(o[u]))}else l=Vd(o);r.url=l}return t||(e.images[this.uuid]=r),r}}function Vd(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?t1.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(ht("Texture: Unable to serialize Texture."),{})}let i1=0;const Hd=new Z;class Qn extends ds{constructor(e=Qn.DEFAULT_IMAGE,t=Qn.DEFAULT_MAPPING,r=br,o=br,l=Yn,u=Is,d=Gi,f=vi,p=Qn.DEFAULT_ANISOTROPY,y=ss){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:i1++}),this.uuid=qa(),this.name="",this.source=new Rh(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=r,this.wrapT=o,this.magFilter=l,this.minFilter=u,this.anisotropy=p,this.format=d,this.internalFormat=null,this.type=f,this.offset=new dt(0,0),this.repeat=new dt(1,1),this.center=new dt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=y,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Hd).x}get height(){return this.source.getSize(Hd).y}get depth(){return this.source.getSize(Hd).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const r=e[t];if(r===void 0){ht(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const o=this[t];if(o===void 0){ht(`Texture.setValues(): property '${t}' does not exist.`);continue}o&&r&&o.isVector2&&r.isVector2||o&&r&&o.isVector3&&r.isVector3||o&&r&&o.isMatrix3&&r.isMatrix3?o.copy(r):this[t]=r}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const r={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(r.userData=this.userData),t||(e.textures[this.uuid]=r),r}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==pv)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Cf:e.x=e.x-Math.floor(e.x);break;case br:e.x=e.x<0?0:1;break;case Rf:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Cf:e.y=e.y-Math.floor(e.y);break;case br:e.y=e.y<0?0:1;break;case Rf:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Qn.DEFAULT_IMAGE=null;Qn.DEFAULT_MAPPING=pv;Qn.DEFAULT_ANISOTROPY=1;const jh=class jh{constructor(e=0,t=0,r=0,o=1){this.x=e,this.y=t,this.z=r,this.w=o}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,r,o){return this.x=e,this.y=t,this.z=r,this.w=o,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,r=this.y,o=this.z,l=this.w,u=e.elements;return this.x=u[0]*t+u[4]*r+u[8]*o+u[12]*l,this.y=u[1]*t+u[5]*r+u[9]*o+u[13]*l,this.z=u[2]*t+u[6]*r+u[10]*o+u[14]*l,this.w=u[3]*t+u[7]*r+u[11]*o+u[15]*l,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,r,o,l;const f=e.elements,p=f[0],y=f[4],S=f[8],v=f[1],_=f[5],M=f[9],A=f[2],m=f[6],x=f[10];if(Math.abs(y-v)<.01&&Math.abs(S-A)<.01&&Math.abs(M-m)<.01){if(Math.abs(y+v)<.1&&Math.abs(S+A)<.1&&Math.abs(M+m)<.1&&Math.abs(p+_+x-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const U=(p+1)/2,b=(_+1)/2,R=(x+1)/2,N=(y+v)/4,F=(S+A)/4,E=(M+m)/4;return U>b&&U>R?U<.01?(r=0,o=.707106781,l=.707106781):(r=Math.sqrt(U),o=N/r,l=F/r):b>R?b<.01?(r=.707106781,o=0,l=.707106781):(o=Math.sqrt(b),r=N/o,l=E/o):R<.01?(r=.707106781,o=.707106781,l=0):(l=Math.sqrt(R),r=F/l,o=E/l),this.set(r,o,l,t),this}let P=Math.sqrt((m-M)*(m-M)+(S-A)*(S-A)+(v-y)*(v-y));return Math.abs(P)<.001&&(P=1),this.x=(m-M)/P,this.y=(S-A)/P,this.z=(v-y)/P,this.w=Math.acos((p+_+x-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Pt(this.x,e.x,t.x),this.y=Pt(this.y,e.y,t.y),this.z=Pt(this.z,e.z,t.z),this.w=Pt(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Pt(this.x,e,t),this.y=Pt(this.y,e,t),this.z=Pt(this.z,e,t),this.w=Pt(this.w,e,t),this}clampLength(e,t){const r=this.length();return this.divideScalar(r||1).multiplyScalar(Pt(r,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,r){return this.x=e.x+(t.x-e.x)*r,this.y=e.y+(t.y-e.y)*r,this.z=e.z+(t.z-e.z)*r,this.w=e.w+(t.w-e.w)*r,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};jh.prototype.isVector4=!0;let an=jh;class r1 extends ds{constructor(e=1,t=1,r={}){super(),r=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Yn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},r),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=r.depth,this.scissor=new an(0,0,e,t),this.scissorTest=!1,this.viewport=new an(0,0,e,t),this.textures=[];const o={width:e,height:t,depth:r.depth},l=new Qn(o),u=r.count;for(let d=0;d<u;d++)this.textures[d]=l.clone(),this.textures[d].isRenderTargetTexture=!0,this.textures[d].renderTarget=this;this._setTextureOptions(r),this.depthBuffer=r.depthBuffer,this.stencilBuffer=r.stencilBuffer,this.resolveColorBuffer=r.resolveColorBuffer,this.resolveDepthBuffer=r.resolveDepthBuffer,this.resolveStencilBuffer=r.resolveStencilBuffer,this.storeMultisampledColorBuffer=r.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=r.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=r.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=r.depthTexture,this.samples=r.samples,this.multiview=r.multiview,this.useArrayDepthTexture=r.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:Yn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let r=0;r<this.textures.length;r++)this.textures[r].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,r=1){if(this.width!==e||this.height!==t||this.depth!==r){this.width=e,this.height=t,this.depth=r;for(let o=0,l=this.textures.length;o<l;o++)this.textures[o].image.width=e,this.textures[o].image.height=t,this.textures[o].image.depth=r,this.textures[o].isData3DTexture!==!0&&(this.textures[o].isArrayTexture=this.textures[o].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,r=e.textures.length;t<r;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const o=Object.assign({},e.textures[t].image);this.textures[t].source=new Rh(o)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Wi extends r1{constructor(e=1,t=1,r={}){super(e,t,r),this.isWebGLRenderTarget=!0}}class Mv extends Qn{constructor(e=null,t=1,r=1,o=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:r,depth:o},this.magFilter=Un,this.minFilter=Un,this.wrapR=br,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class s1 extends Qn{constructor(e=null,t=1,r=1,o=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:r,depth:o},this.magFilter=Un,this.minFilter=Un,this.wrapR=br,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}const Kc=class Kc{constructor(e,t,r,o,l,u,d,f,p,y,S,v,_,M,A,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,r,o,l,u,d,f,p,y,S,v,_,M,A,m)}set(e,t,r,o,l,u,d,f,p,y,S,v,_,M,A,m){const x=this.elements;return x[0]=e,x[4]=t,x[8]=r,x[12]=o,x[1]=l,x[5]=u,x[9]=d,x[13]=f,x[2]=p,x[6]=y,x[10]=S,x[14]=v,x[3]=_,x[7]=M,x[11]=A,x[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Kc().fromArray(this.elements)}copy(e){const t=this.elements,r=e.elements;return t[0]=r[0],t[1]=r[1],t[2]=r[2],t[3]=r[3],t[4]=r[4],t[5]=r[5],t[6]=r[6],t[7]=r[7],t[8]=r[8],t[9]=r[9],t[10]=r[10],t[11]=r[11],t[12]=r[12],t[13]=r[13],t[14]=r[14],t[15]=r[15],this}copyPosition(e){const t=this.elements,r=e.elements;return t[12]=r[12],t[13]=r[13],t[14]=r[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,r){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),r.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),r.setFromMatrixColumn(this,2),this)}makeBasis(e,t,r){return this.set(e.x,t.x,r.x,0,e.y,t.y,r.y,0,e.z,t.z,r.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,r=e.elements,o=1/po.setFromMatrixColumn(e,0).length(),l=1/po.setFromMatrixColumn(e,1).length(),u=1/po.setFromMatrixColumn(e,2).length();return t[0]=r[0]*o,t[1]=r[1]*o,t[2]=r[2]*o,t[3]=0,t[4]=r[4]*l,t[5]=r[5]*l,t[6]=r[6]*l,t[7]=0,t[8]=r[8]*u,t[9]=r[9]*u,t[10]=r[10]*u,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,r=e.x,o=e.y,l=e.z,u=Math.cos(r),d=Math.sin(r),f=Math.cos(o),p=Math.sin(o),y=Math.cos(l),S=Math.sin(l);if(e.order==="XYZ"){const v=u*y,_=u*S,M=d*y,A=d*S;t[0]=f*y,t[4]=-f*S,t[8]=p,t[1]=_+M*p,t[5]=v-A*p,t[9]=-d*f,t[2]=A-v*p,t[6]=M+_*p,t[10]=u*f}else if(e.order==="YXZ"){const v=f*y,_=f*S,M=p*y,A=p*S;t[0]=v+A*d,t[4]=M*d-_,t[8]=u*p,t[1]=u*S,t[5]=u*y,t[9]=-d,t[2]=_*d-M,t[6]=A+v*d,t[10]=u*f}else if(e.order==="ZXY"){const v=f*y,_=f*S,M=p*y,A=p*S;t[0]=v-A*d,t[4]=-u*S,t[8]=M+_*d,t[1]=_+M*d,t[5]=u*y,t[9]=A-v*d,t[2]=-u*p,t[6]=d,t[10]=u*f}else if(e.order==="ZYX"){const v=u*y,_=u*S,M=d*y,A=d*S;t[0]=f*y,t[4]=M*p-_,t[8]=v*p+A,t[1]=f*S,t[5]=A*p+v,t[9]=_*p-M,t[2]=-p,t[6]=d*f,t[10]=u*f}else if(e.order==="YZX"){const v=u*f,_=u*p,M=d*f,A=d*p;t[0]=f*y,t[4]=A-v*S,t[8]=M*S+_,t[1]=S,t[5]=u*y,t[9]=-d*y,t[2]=-p*y,t[6]=_*S+M,t[10]=v-A*S}else if(e.order==="XZY"){const v=u*f,_=u*p,M=d*f,A=d*p;t[0]=f*y,t[4]=-S,t[8]=p*y,t[1]=v*S+A,t[5]=u*y,t[9]=_*S-M,t[2]=M*S-_,t[6]=d*y,t[10]=A*S+v}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(o1,e,a1)}lookAt(e,t,r){const o=this.elements;return pi.subVectors(e,t),pi.lengthSq()===0&&(pi.z=1),pi.normalize(),es.crossVectors(r,pi),es.lengthSq()===0&&(Math.abs(r.z)===1?pi.x+=1e-4:pi.z+=1e-4,pi.normalize(),es.crossVectors(r,pi)),es.normalize(),Ql.crossVectors(pi,es),o[0]=es.x,o[4]=Ql.x,o[8]=pi.x,o[1]=es.y,o[5]=Ql.y,o[9]=pi.y,o[2]=es.z,o[6]=Ql.z,o[10]=pi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const r=e.elements,o=t.elements,l=this.elements,u=r[0],d=r[4],f=r[8],p=r[12],y=r[1],S=r[5],v=r[9],_=r[13],M=r[2],A=r[6],m=r[10],x=r[14],P=r[3],U=r[7],b=r[11],R=r[15],N=o[0],F=o[4],E=o[8],L=o[12],B=o[1],X=o[5],j=o[9],ne=o[13],H=o[2],W=o[6],ue=o[10],Q=o[14],te=o[3],G=o[7],ee=o[11],O=o[15];return l[0]=u*N+d*B+f*H+p*te,l[4]=u*F+d*X+f*W+p*G,l[8]=u*E+d*j+f*ue+p*ee,l[12]=u*L+d*ne+f*Q+p*O,l[1]=y*N+S*B+v*H+_*te,l[5]=y*F+S*X+v*W+_*G,l[9]=y*E+S*j+v*ue+_*ee,l[13]=y*L+S*ne+v*Q+_*O,l[2]=M*N+A*B+m*H+x*te,l[6]=M*F+A*X+m*W+x*G,l[10]=M*E+A*j+m*ue+x*ee,l[14]=M*L+A*ne+m*Q+x*O,l[3]=P*N+U*B+b*H+R*te,l[7]=P*F+U*X+b*W+R*G,l[11]=P*E+U*j+b*ue+R*ee,l[15]=P*L+U*ne+b*Q+R*O,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],r=e[4],o=e[8],l=e[12],u=e[1],d=e[5],f=e[9],p=e[13],y=e[2],S=e[6],v=e[10],_=e[14],M=e[3],A=e[7],m=e[11],x=e[15],P=f*_-p*v,U=d*_-p*S,b=d*v-f*S,R=u*_-p*y,N=u*v-f*y,F=u*S-d*y;return t*(A*P-m*U+x*b)-r*(M*P-m*R+x*N)+o*(M*U-A*R+x*F)-l*(M*b-A*N+m*F)}determinantAffine(){const e=this.elements,t=e[0],r=e[4],o=e[8],l=e[1],u=e[5],d=e[9],f=e[2],p=e[6],y=e[10];return t*(u*y-d*p)-r*(l*y-d*f)+o*(l*p-u*f)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,r){const o=this.elements;return e.isVector3?(o[12]=e.x,o[13]=e.y,o[14]=e.z):(o[12]=e,o[13]=t,o[14]=r),this}invert(){const e=this.elements,t=e[0],r=e[1],o=e[2],l=e[3],u=e[4],d=e[5],f=e[6],p=e[7],y=e[8],S=e[9],v=e[10],_=e[11],M=e[12],A=e[13],m=e[14],x=e[15],P=t*d-r*u,U=t*f-o*u,b=t*p-l*u,R=r*f-o*d,N=r*p-l*d,F=o*p-l*f,E=y*A-S*M,L=y*m-v*M,B=y*x-_*M,X=S*m-v*A,j=S*x-_*A,ne=v*x-_*m,H=P*ne-U*j+b*X+R*B-N*L+F*E;if(H===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const W=1/H;return e[0]=(d*ne-f*j+p*X)*W,e[1]=(o*j-r*ne-l*X)*W,e[2]=(A*F-m*N+x*R)*W,e[3]=(v*N-S*F-_*R)*W,e[4]=(f*B-u*ne-p*L)*W,e[5]=(t*ne-o*B+l*L)*W,e[6]=(m*b-M*F-x*U)*W,e[7]=(y*F-v*b+_*U)*W,e[8]=(u*j-d*B+p*E)*W,e[9]=(r*B-t*j-l*E)*W,e[10]=(M*N-A*b+x*P)*W,e[11]=(S*b-y*N-_*P)*W,e[12]=(d*L-u*X-f*E)*W,e[13]=(t*X-r*L+o*E)*W,e[14]=(A*U-M*R-m*P)*W,e[15]=(y*R-S*U+v*P)*W,this}scale(e){const t=this.elements,r=e.x,o=e.y,l=e.z;return t[0]*=r,t[4]*=o,t[8]*=l,t[1]*=r,t[5]*=o,t[9]*=l,t[2]*=r,t[6]*=o,t[10]*=l,t[3]*=r,t[7]*=o,t[11]*=l,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],r=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],o=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,r,o))}makeTranslation(e,t,r){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,r,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),r=Math.sin(e);return this.set(1,0,0,0,0,t,-r,0,0,r,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,0,r,0,0,1,0,0,-r,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),r=Math.sin(e);return this.set(t,-r,0,0,r,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const r=Math.cos(t),o=Math.sin(t),l=1-r,u=e.x,d=e.y,f=e.z,p=l*u,y=l*d;return this.set(p*u+r,p*d-o*f,p*f+o*d,0,p*d+o*f,y*d+r,y*f-o*u,0,p*f-o*d,y*f+o*u,l*f*f+r,0,0,0,0,1),this}makeScale(e,t,r){return this.set(e,0,0,0,0,t,0,0,0,0,r,0,0,0,0,1),this}makeShear(e,t,r,o,l,u){return this.set(1,r,l,0,e,1,u,0,t,o,1,0,0,0,0,1),this}compose(e,t,r){const o=this.elements,l=t._x,u=t._y,d=t._z,f=t._w,p=l+l,y=u+u,S=d+d,v=l*p,_=l*y,M=l*S,A=u*y,m=u*S,x=d*S,P=f*p,U=f*y,b=f*S,R=r.x,N=r.y,F=r.z;return o[0]=(1-(A+x))*R,o[1]=(_+b)*R,o[2]=(M-U)*R,o[3]=0,o[4]=(_-b)*N,o[5]=(1-(v+x))*N,o[6]=(m+P)*N,o[7]=0,o[8]=(M+U)*F,o[9]=(m-P)*F,o[10]=(1-(v+A))*F,o[11]=0,o[12]=e.x,o[13]=e.y,o[14]=e.z,o[15]=1,this}decompose(e,t,r){const o=this.elements;e.x=o[12],e.y=o[13],e.z=o[14];const l=this.determinantAffine();if(l===0)return r.set(1,1,1),t.identity(),this;let u=po.set(o[0],o[1],o[2]).length();const d=po.set(o[4],o[5],o[6]).length(),f=po.set(o[8],o[9],o[10]).length();l<0&&(u=-u),Di.copy(this);const p=1/u,y=1/d,S=1/f;return Di.elements[0]*=p,Di.elements[1]*=p,Di.elements[2]*=p,Di.elements[4]*=y,Di.elements[5]*=y,Di.elements[6]*=y,Di.elements[8]*=S,Di.elements[9]*=S,Di.elements[10]*=S,t.setFromRotationMatrix(Di),r.x=u,r.y=d,r.z=f,this}makePerspective(e,t,r,o,l,u,d=ir,f=!1){const p=this.elements,y=2*l/(t-e),S=2*l/(r-o),v=(t+e)/(t-e),_=(r+o)/(r-o);let M,A;if(f)M=l/(u-l),A=u*l/(u-l);else if(d===ir)M=-(u+l)/(u-l),A=-2*u*l/(u-l);else if(d===Wa)M=-u/(u-l),A=-u*l/(u-l);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+d);return p[0]=y,p[4]=0,p[8]=v,p[12]=0,p[1]=0,p[5]=S,p[9]=_,p[13]=0,p[2]=0,p[6]=0,p[10]=M,p[14]=A,p[3]=0,p[7]=0,p[11]=-1,p[15]=0,this}makeOrthographic(e,t,r,o,l,u,d=ir,f=!1){const p=this.elements,y=2/(t-e),S=2/(r-o),v=-(t+e)/(t-e),_=-(r+o)/(r-o);let M,A;if(f)M=1/(u-l),A=u/(u-l);else if(d===ir)M=-2/(u-l),A=-(u+l)/(u-l);else if(d===Wa)M=-1/(u-l),A=-l/(u-l);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+d);return p[0]=y,p[4]=0,p[8]=0,p[12]=v,p[1]=0,p[5]=S,p[9]=0,p[13]=_,p[2]=0,p[6]=0,p[10]=M,p[14]=A,p[3]=0,p[7]=0,p[11]=0,p[15]=1,this}equals(e){const t=this.elements,r=e.elements;for(let o=0;o<16;o++)if(t[o]!==r[o])return!1;return!0}fromArray(e,t=0){for(let r=0;r<16;r++)this.elements[r]=e[r+t];return this}toArray(e=[],t=0){const r=this.elements;return e[t]=r[0],e[t+1]=r[1],e[t+2]=r[2],e[t+3]=r[3],e[t+4]=r[4],e[t+5]=r[5],e[t+6]=r[6],e[t+7]=r[7],e[t+8]=r[8],e[t+9]=r[9],e[t+10]=r[10],e[t+11]=r[11],e[t+12]=r[12],e[t+13]=r[13],e[t+14]=r[14],e[t+15]=r[15],e}};Kc.prototype.isMatrix4=!0;let Yt=Kc;const po=new Z,Di=new Yt,o1=new Z(0,0,0),a1=new Z(1,1,1),es=new Z,Ql=new Z,pi=new Z,Dg=new Yt,Ug=new ls;class cs{constructor(e=0,t=0,r=0,o=cs.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=r,this._order=o}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,r,o=this._order){return this._x=e,this._y=t,this._z=r,this._order=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,r=!0){const o=e.elements,l=o[0],u=o[4],d=o[8],f=o[1],p=o[5],y=o[9],S=o[2],v=o[6],_=o[10];switch(t){case"XYZ":this._y=Math.asin(Pt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-y,_),this._z=Math.atan2(-u,l)):(this._x=Math.atan2(v,p),this._z=0);break;case"YXZ":this._x=Math.asin(-Pt(y,-1,1)),Math.abs(y)<.9999999?(this._y=Math.atan2(d,_),this._z=Math.atan2(f,p)):(this._y=Math.atan2(-S,l),this._z=0);break;case"ZXY":this._x=Math.asin(Pt(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(-S,_),this._z=Math.atan2(-u,p)):(this._y=0,this._z=Math.atan2(f,l));break;case"ZYX":this._y=Math.asin(-Pt(S,-1,1)),Math.abs(S)<.9999999?(this._x=Math.atan2(v,_),this._z=Math.atan2(f,l)):(this._x=0,this._z=Math.atan2(-u,p));break;case"YZX":this._z=Math.asin(Pt(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-y,p),this._y=Math.atan2(-S,l)):(this._x=0,this._y=Math.atan2(d,_));break;case"XZY":this._z=Math.asin(-Pt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(v,p),this._y=Math.atan2(d,l)):(this._x=Math.atan2(-y,_),this._y=0);break;default:ht("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,r===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,r){return Dg.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Dg,t,r)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Ug.setFromEuler(this),this.setFromQuaternion(Ug,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}cs.DEFAULT_ORDER="XYZ";class Ph{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let l1=0;const Fg=new Z,mo=new ls,yr=new Yt,ec=new Z,Ea=new Z,c1=new Z,u1=new ls,Og=new Z(1,0,0),kg=new Z(0,1,0),Bg=new Z(0,0,1),zg={type:"added"},d1={type:"removed"},go={type:"childadded",child:null},Gd={type:"childremoved",child:null};class Pn extends ds{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:l1++}),this.uuid=qa(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Pn.DEFAULT_UP.clone();const e=new Z,t=new cs,r=new ls,o=new Z(1,1,1);function l(){r.setFromEuler(t,!1)}function u(){t.setFromQuaternion(r,void 0,!1)}t._onChange(l),r._onChange(u),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:o},modelViewMatrix:{value:new Yt},normalMatrix:{value:new yt}}),this.matrix=new Yt,this.matrixWorld=new Yt,this.matrixAutoUpdate=Pn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Pn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ph,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return mo.setFromAxisAngle(e,t),this.quaternion.multiply(mo),this}rotateOnWorldAxis(e,t){return mo.setFromAxisAngle(e,t),this.quaternion.premultiply(mo),this}rotateX(e){return this.rotateOnAxis(Og,e)}rotateY(e){return this.rotateOnAxis(kg,e)}rotateZ(e){return this.rotateOnAxis(Bg,e)}translateOnAxis(e,t){return Fg.copy(e).applyQuaternion(this.quaternion),this.position.add(Fg.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Og,e)}translateY(e){return this.translateOnAxis(kg,e)}translateZ(e){return this.translateOnAxis(Bg,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(yr.copy(this.matrixWorld).invert())}lookAt(e,t,r){e.isVector3?ec.copy(e):ec.set(e,t,r);const o=this.parent;this.updateWorldMatrix(!0,!1),Ea.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?yr.lookAt(Ea,ec,this.up):yr.lookAt(ec,Ea,this.up),this.quaternion.setFromRotationMatrix(yr),o&&(yr.extractRotation(o.matrixWorld),mo.setFromRotationMatrix(yr),this.quaternion.premultiply(mo.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(zt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(zg),go.child=e,this.dispatchEvent(go),go.child=null):zt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let r=0;r<arguments.length;r++)this.remove(arguments[r]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(d1),Gd.child=e,this.dispatchEvent(Gd),Gd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),yr.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),yr.multiply(e.parent.matrixWorld)),e.applyMatrix4(yr),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(zg),go.child=e,this.dispatchEvent(go),go.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let r=0,o=this.children.length;r<o;r++){const u=this.children[r].getObjectByProperty(e,t);if(u!==void 0)return u}}getObjectsByProperty(e,t,r=[]){this[e]===t&&r.push(this);const o=this.children;for(let l=0,u=o.length;l<u;l++)o[l].getObjectsByProperty(e,t,r);return r}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ea,e,c1),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ea,u1,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);const t=this.children;for(let r=0,o=t.length;r<o;r++)t[r].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let r=0,o=t.length;r<o;r++)t[r].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,r=e.y,o=e.z,l=this.matrix.elements;l[12]+=t-l[0]*t-l[4]*r-l[8]*o,l[13]+=r-l[1]*t-l[5]*r-l[9]*o,l[14]+=o-l[2]*t-l[6]*r-l[10]*o}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let r=0,o=t.length;r<o;r++)t[r].updateMatrixWorld(e)}updateWorldMatrix(e,t,r=!1){const o=this.parent;if(e===!0&&o!==null&&o.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||r)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,r=!0),t===!0){const l=this.children;for(let u=0,d=l.length;u<d;u++)l[u].updateWorldMatrix(!1,!0,r)}}toJSON(e){const t=e===void 0||typeof e=="string",r={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},r.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const o={};o.uuid=this.uuid,o.type=this.type,o.name=this.name,o.castShadow=this.castShadow,o.receiveShadow=this.receiveShadow,o.visible=this.visible,o.frustumCulled=this.frustumCulled,o.renderOrder=this.renderOrder,o.static=this.static,o.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(o.userData=this.userData),o.layers=this.layers.mask,o.matrix=this.matrix.toArray(),o.up=this.up.toArray(),this.pivot!==null&&(o.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(o.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(o.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(o.type="InstancedMesh",o.count=this.count,o.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(o.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(o.type="BatchedMesh",o.perObjectFrustumCulled=this.perObjectFrustumCulled,o.sortObjects=this.sortObjects,o.drawRanges=this._drawRanges,o.reservedRanges=this._reservedRanges,o.geometryInfo=this._geometryInfo.map(d=>({...d,boundingBox:d.boundingBox?d.boundingBox.toJSON():void 0,boundingSphere:d.boundingSphere?d.boundingSphere.toJSON():void 0})),o.instanceInfo=this._instanceInfo.map(d=>({...d})),o.availableInstanceIds=this._availableInstanceIds.slice(),o.availableGeometryIds=this._availableGeometryIds.slice(),o.nextIndexStart=this._nextIndexStart,o.nextVertexStart=this._nextVertexStart,o.geometryCount=this._geometryCount,o.maxInstanceCount=this._maxInstanceCount,o.maxVertexCount=this._maxVertexCount,o.maxIndexCount=this._maxIndexCount,o.geometryInitialized=this._geometryInitialized,o.matricesTexture=this._matricesTexture.toJSON(e),o.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(o.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(o.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(o.boundingBox=this.boundingBox.toJSON()));function l(d,f){return d[f.uuid]===void 0&&(d[f.uuid]=f.toJSON(e)),f.uuid}if(this.isScene)this.background&&(this.background.isColor?o.background=this.background.toJSON():this.background.isTexture&&(o.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(o.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){o.geometry=l(e.geometries,this.geometry);const d=this.geometry.parameters;if(d!==void 0&&d.shapes!==void 0){const f=d.shapes;if(Array.isArray(f))for(let p=0,y=f.length;p<y;p++){const S=f[p];l(e.shapes,S)}else l(e.shapes,f)}}if(this.isSkinnedMesh&&(o.bindMode=this.bindMode,o.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(l(e.skeletons,this.skeleton),o.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const d=[];for(let f=0,p=this.material.length;f<p;f++)d.push(l(e.materials,this.material[f]));o.material=d}else o.material=l(e.materials,this.material);if(this.children.length>0){o.children=[];for(let d=0;d<this.children.length;d++)o.children.push(this.children[d].toJSON(e).object)}if(this.animations.length>0){o.animations=[];for(let d=0;d<this.animations.length;d++){const f=this.animations[d];o.animations.push(l(e.animations,f))}}if(t){const d=u(e.geometries),f=u(e.materials),p=u(e.textures),y=u(e.images),S=u(e.shapes),v=u(e.skeletons),_=u(e.animations),M=u(e.nodes);d.length>0&&(r.geometries=d),f.length>0&&(r.materials=f),p.length>0&&(r.textures=p),y.length>0&&(r.images=y),S.length>0&&(r.shapes=S),v.length>0&&(r.skeletons=v),_.length>0&&(r.animations=_),M.length>0&&(r.nodes=M)}return r.object=o,r;function u(d){const f=[];for(const p in d){const y=d[p];delete y.metadata,f.push(y)}return f}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let r=0;r<e.children.length;r++){const o=e.children[r];this.add(o.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Pn.DEFAULT_UP=new Z(0,1,0);Pn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Pn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class as extends Pn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const f1={type:"move"};class Wd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new as,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new as,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new Z,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new Z),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new as,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new Z,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new Z,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const r of e.hand.values())this._getHandJoint(t,r)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,r){let o=null,l=null,u=null;const d=this._targetRay,f=this._grip,p=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(p&&e.hand){u=!0;for(const A of e.hand.values()){const m=t.getJointPose(A,r),x=this._getHandJoint(p,A);m!==null&&(x.matrix.fromArray(m.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=m.radius),x.visible=m!==null}const y=p.joints["index-finger-tip"],S=p.joints["thumb-tip"],v=y.position.distanceTo(S.position),_=.02,M=.005;p.inputState.pinching&&v>_+M?(p.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!p.inputState.pinching&&v<=_-M&&(p.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else f!==null&&e.gripSpace&&(l=t.getPose(e.gripSpace,r),l!==null&&(f.matrix.fromArray(l.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,l.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(l.linearVelocity)):f.hasLinearVelocity=!1,l.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(l.angularVelocity)):f.hasAngularVelocity=!1,f.eventsEnabled&&f.dispatchEvent({type:"gripUpdated",data:e,target:this})));d!==null&&(o=t.getPose(e.targetRaySpace,r),o===null&&l!==null&&(o=l),o!==null&&(d.matrix.fromArray(o.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,o.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(o.linearVelocity)):d.hasLinearVelocity=!1,o.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(o.angularVelocity)):d.hasAngularVelocity=!1,this.dispatchEvent(f1)))}return d!==null&&(d.visible=o!==null),f!==null&&(f.visible=l!==null),p!==null&&(p.visible=u!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const r=new as;r.matrixAutoUpdate=!1,r.visible=!1,e.joints[t.jointName]=r,e.add(r)}return e.joints[t.jointName]}}const Ev={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ts={h:0,s:0,l:0},tc={h:0,s:0,l:0};function jd(s,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?s+(e-s)*6*t:t<1/2?e:t<2/3?s+(e-s)*6*(2/3-t):s}class vt{constructor(e,t,r){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,r)}set(e,t,r){if(t===void 0&&r===void 0){const o=e;o&&o.isColor?this.copy(o):typeof o=="number"?this.setHex(o):typeof o=="string"&&this.setStyle(o)}else this.setRGB(e,t,r);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=gi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Dt.colorSpaceToWorking(this,t),this}setRGB(e,t,r,o=Dt.workingColorSpace){return this.r=e,this.g=t,this.b=r,Dt.colorSpaceToWorking(this,o),this}setHSL(e,t,r,o=Dt.workingColorSpace){if(e=J_(e,1),t=Pt(t,0,1),r=Pt(r,0,1),t===0)this.r=this.g=this.b=r;else{const l=r<=.5?r*(1+t):r+t-r*t,u=2*r-l;this.r=jd(u,l,e+1/3),this.g=jd(u,l,e),this.b=jd(u,l,e-1/3)}return Dt.colorSpaceToWorking(this,o),this}setStyle(e,t=gi){function r(l){l!==void 0&&parseFloat(l)<1&&ht("Color: Alpha component of "+e+" will be ignored.")}let o;if(o=/^(\w+)\(([^\)]*)\)/.exec(e)){let l;const u=o[1],d=o[2];switch(u){case"rgb":case"rgba":if(l=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(l[4]),this.setRGB(Math.min(255,parseInt(l[1],10))/255,Math.min(255,parseInt(l[2],10))/255,Math.min(255,parseInt(l[3],10))/255,t);if(l=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(l[4]),this.setRGB(Math.min(100,parseInt(l[1],10))/100,Math.min(100,parseInt(l[2],10))/100,Math.min(100,parseInt(l[3],10))/100,t);break;case"hsl":case"hsla":if(l=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(l[4]),this.setHSL(parseFloat(l[1])/360,parseFloat(l[2])/100,parseFloat(l[3])/100,t);break;default:ht("Color: Unknown color model "+e)}}else if(o=/^\#([A-Fa-f\d]+)$/.exec(e)){const l=o[1],u=l.length;if(u===3)return this.setRGB(parseInt(l.charAt(0),16)/15,parseInt(l.charAt(1),16)/15,parseInt(l.charAt(2),16)/15,t);if(u===6)return this.setHex(parseInt(l,16),t);ht("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=gi){const r=Ev[e.toLowerCase()];return r!==void 0?this.setHex(r,t):ht("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Rr(e.r),this.g=Rr(e.g),this.b=Rr(e.b),this}copyLinearToSRGB(e){return this.r=Fo(e.r),this.g=Fo(e.g),this.b=Fo(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=gi){return Dt.workingToColorSpace(Gn.copy(this),e),Math.round(Pt(Gn.r*255,0,255))*65536+Math.round(Pt(Gn.g*255,0,255))*256+Math.round(Pt(Gn.b*255,0,255))}getHexString(e=gi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Dt.workingColorSpace){Dt.workingToColorSpace(Gn.copy(this),t);const r=Gn.r,o=Gn.g,l=Gn.b,u=Math.max(r,o,l),d=Math.min(r,o,l);let f,p;const y=(d+u)/2;if(d===u)f=0,p=0;else{const S=u-d;switch(p=y<=.5?S/(u+d):S/(2-u-d),u){case r:f=(o-l)/S+(o<l?6:0);break;case o:f=(l-r)/S+2;break;case l:f=(r-o)/S+4;break}f/=6}return e.h=f,e.s=p,e.l=y,e}getRGB(e,t=Dt.workingColorSpace){return Dt.workingToColorSpace(Gn.copy(this),t),e.r=Gn.r,e.g=Gn.g,e.b=Gn.b,e}getStyle(e=gi){Dt.workingToColorSpace(Gn.copy(this),e);const t=Gn.r,r=Gn.g,o=Gn.b;return e!==gi?`color(${e} ${t.toFixed(3)} ${r.toFixed(3)} ${o.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(r*255)},${Math.round(o*255)})`}offsetHSL(e,t,r){return this.getHSL(ts),this.setHSL(ts.h+e,ts.s+t,ts.l+r)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,r){return this.r=e.r+(t.r-e.r)*r,this.g=e.g+(t.g-e.g)*r,this.b=e.b+(t.b-e.b)*r,this}lerpHSL(e,t){this.getHSL(ts),e.getHSL(tc);const r=kd(ts.h,tc.h,t),o=kd(ts.s,tc.s,t),l=kd(ts.l,tc.l,t);return this.setHSL(r,o,l),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,r=this.g,o=this.b,l=e.elements;return this.r=l[0]*t+l[3]*r+l[6]*o,this.g=l[1]*t+l[4]*r+l[7]*o,this.b=l[2]*t+l[5]*r+l[8]*o,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Gn=new vt;vt.NAMES=Ev;class Ih{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new vt(e),this.density=t}clone(){return new Ih(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class h1 extends Pn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new cs,this.environmentIntensity=1,this.environmentRotation=new cs,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const Ui=new Z,_r=new Z,Xd=new Z,Sr=new Z,vo=new Z,xo=new Z,Vg=new Z,Yd=new Z,qd=new Z,Kd=new Z,$d=new an,Zd=new an,Jd=new an;class Vi{constructor(e=new Z,t=new Z,r=new Z){this.a=e,this.b=t,this.c=r}static getNormal(e,t,r,o){o.subVectors(r,t),Ui.subVectors(e,t),o.cross(Ui);const l=o.lengthSq();return l>0?o.multiplyScalar(1/Math.sqrt(l)):o.set(0,0,0)}static getBarycoord(e,t,r,o,l){Ui.subVectors(o,t),_r.subVectors(r,t),Xd.subVectors(e,t);const u=Ui.dot(Ui),d=Ui.dot(_r),f=Ui.dot(Xd),p=_r.dot(_r),y=_r.dot(Xd),S=u*p-d*d;if(S===0)return l.set(0,0,0),null;const v=1/S,_=(p*f-d*y)*v,M=(u*y-d*f)*v;return l.set(1-_-M,M,_)}static containsPoint(e,t,r,o){return this.getBarycoord(e,t,r,o,Sr)===null?!1:Sr.x>=0&&Sr.y>=0&&Sr.x+Sr.y<=1}static getInterpolation(e,t,r,o,l,u,d,f){return this.getBarycoord(e,t,r,o,Sr)===null?(f.x=0,f.y=0,"z"in f&&(f.z=0),"w"in f&&(f.w=0),null):(f.setScalar(0),f.addScaledVector(l,Sr.x),f.addScaledVector(u,Sr.y),f.addScaledVector(d,Sr.z),f)}static getInterpolatedAttribute(e,t,r,o,l,u){return $d.setScalar(0),Zd.setScalar(0),Jd.setScalar(0),$d.fromBufferAttribute(e,t),Zd.fromBufferAttribute(e,r),Jd.fromBufferAttribute(e,o),u.setScalar(0),u.addScaledVector($d,l.x),u.addScaledVector(Zd,l.y),u.addScaledVector(Jd,l.z),u}static isFrontFacing(e,t,r,o){return Ui.subVectors(r,t),_r.subVectors(e,t),Ui.cross(_r).dot(o)<0}set(e,t,r){return this.a.copy(e),this.b.copy(t),this.c.copy(r),this}setFromPointsAndIndices(e,t,r,o){return this.a.copy(e[t]),this.b.copy(e[r]),this.c.copy(e[o]),this}setFromAttributeAndIndices(e,t,r,o){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,r),this.c.fromBufferAttribute(e,o),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Ui.subVectors(this.c,this.b),_r.subVectors(this.a,this.b),Ui.cross(_r).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Vi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Vi.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,r,o,l){return Vi.getInterpolation(e,this.a,this.b,this.c,t,r,o,l)}containsPoint(e){return Vi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Vi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const r=this.a,o=this.b,l=this.c;let u,d;vo.subVectors(o,r),xo.subVectors(l,r),Yd.subVectors(e,r);const f=vo.dot(Yd),p=xo.dot(Yd);if(f<=0&&p<=0)return t.copy(r);qd.subVectors(e,o);const y=vo.dot(qd),S=xo.dot(qd);if(y>=0&&S<=y)return t.copy(o);const v=f*S-y*p;if(v<=0&&f>=0&&y<=0)return u=f/(f-y),t.copy(r).addScaledVector(vo,u);Kd.subVectors(e,l);const _=vo.dot(Kd),M=xo.dot(Kd);if(M>=0&&_<=M)return t.copy(l);const A=_*p-f*M;if(A<=0&&p>=0&&M<=0)return d=p/(p-M),t.copy(r).addScaledVector(xo,d);const m=y*M-_*S;if(m<=0&&S-y>=0&&_-M>=0)return Vg.subVectors(l,o),d=(S-y)/(S-y+(_-M)),t.copy(o).addScaledVector(Vg,d);const x=1/(m+A+v);return u=A*x,d=v*x,t.copy(r).addScaledVector(vo,u).addScaledVector(xo,d)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class ks{constructor(e=new Z(1/0,1/0,1/0),t=new Z(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t+=3)this.expandByPoint(Fi.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,r=e.count;t<r;t++)this.expandByPoint(Fi.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const r=Fi.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(r),this.max.copy(e).add(r),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const r=e.geometry;if(r!==void 0){const l=r.getAttribute("position");if(t===!0&&l!==void 0&&e.isInstancedMesh!==!0)for(let u=0,d=l.count;u<d;u++)e.isMesh===!0?e.getVertexPosition(u,Fi):Fi.fromBufferAttribute(l,u),Fi.applyMatrix4(e.matrixWorld),this.expandByPoint(Fi);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),nc.copy(e.boundingBox)):(r.boundingBox===null&&r.computeBoundingBox(),nc.copy(r.boundingBox)),nc.applyMatrix4(e.matrixWorld),this.union(nc)}const o=e.children;for(let l=0,u=o.length;l<u;l++)this.expandByObject(o[l],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Fi),Fi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,r;return e.normal.x>0?(t=e.normal.x*this.min.x,r=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,r=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,r+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,r+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,r+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,r+=e.normal.z*this.min.z),t<=-e.constant&&r>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(wa),ic.subVectors(this.max,wa),yo.subVectors(e.a,wa),_o.subVectors(e.b,wa),So.subVectors(e.c,wa),ns.subVectors(_o,yo),is.subVectors(So,_o),ws.subVectors(yo,So);let t=[0,-ns.z,ns.y,0,-is.z,is.y,0,-ws.z,ws.y,ns.z,0,-ns.x,is.z,0,-is.x,ws.z,0,-ws.x,-ns.y,ns.x,0,-is.y,is.x,0,-ws.y,ws.x,0];return!Qd(t,yo,_o,So,ic)||(t=[1,0,0,0,1,0,0,0,1],!Qd(t,yo,_o,So,ic))?!1:(rc.crossVectors(ns,is),t=[rc.x,rc.y,rc.z],Qd(t,yo,_o,So,ic))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Fi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Fi).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Mr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Mr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Mr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Mr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Mr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Mr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Mr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Mr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Mr),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Mr=[new Z,new Z,new Z,new Z,new Z,new Z,new Z,new Z],Fi=new Z,nc=new ks,yo=new Z,_o=new Z,So=new Z,ns=new Z,is=new Z,ws=new Z,wa=new Z,ic=new Z,rc=new Z,Ts=new Z;function Qd(s,e,t,r,o){for(let l=0,u=s.length-3;l<=u;l+=3){Ts.fromArray(s,l);const d=o.x*Math.abs(Ts.x)+o.y*Math.abs(Ts.y)+o.z*Math.abs(Ts.z),f=e.dot(Ts),p=t.dot(Ts),y=r.dot(Ts);if(Math.max(-Math.max(f,p,y),Math.min(f,p,y))>d)return!1}return!0}const gn=new Z,sc=new dt;let p1=0;class jn extends ds{constructor(e,t,r=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:p1++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=r,this.usage=Y_,this.updateRanges=[],this.gpuType=Hi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,r){e*=this.itemSize,r*=t.itemSize;for(let o=0,l=this.itemSize;o<l;o++)this.array[e+o]=t.array[r+o];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,r=this.count;t<r;t++)sc.fromBufferAttribute(this,t),sc.applyMatrix3(e),this.setXY(t,sc.x,sc.y);else if(this.itemSize===3)for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.applyMatrix3(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}applyMatrix4(e){for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.applyMatrix4(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}applyNormalMatrix(e){for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.applyNormalMatrix(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}transformDirection(e){for(let t=0,r=this.count;t<r;t++)gn.fromBufferAttribute(this,t),gn.transformDirection(e),this.setXYZ(t,gn.x,gn.y,gn.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let r=this.array[e*this.itemSize+t];return this.normalized&&(r=Ma(r,this.array)),r}setComponent(e,t,r){return this.normalized&&(r=li(r,this.array)),this.array[e*this.itemSize+t]=r,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Ma(t,this.array)),t}setX(e,t){return this.normalized&&(t=li(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Ma(t,this.array)),t}setY(e,t){return this.normalized&&(t=li(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Ma(t,this.array)),t}setZ(e,t){return this.normalized&&(t=li(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Ma(t,this.array)),t}setW(e,t){return this.normalized&&(t=li(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,r){return e*=this.itemSize,this.normalized&&(t=li(t,this.array),r=li(r,this.array)),this.array[e+0]=t,this.array[e+1]=r,this}setXYZ(e,t,r,o){return e*=this.itemSize,this.normalized&&(t=li(t,this.array),r=li(r,this.array),o=li(o,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=o,this}setXYZW(e,t,r,o,l){return e*=this.itemSize,this.normalized&&(t=li(t,this.array),r=li(r,this.array),o=li(o,this.array),l=li(l,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=o,this.array[e+3]=l,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}}class wv extends jn{constructor(e,t,r){super(new Uint16Array(e),t,r)}}class Tv extends jn{constructor(e,t,r){super(new Uint32Array(e),t,r)}}class Jt extends jn{constructor(e,t,r){super(new Float32Array(e),t,r)}}const m1=new ks,Ta=new Z,ef=new Z;class Bs{constructor(e=new Z,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const r=this.center;t!==void 0?r.copy(t):m1.setFromPoints(e).getCenter(r);let o=0;for(let l=0,u=e.length;l<u;l++)o=Math.max(o,r.distanceToSquared(e[l]));return this.radius=Math.sqrt(o),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const r=this.center.distanceToSquared(e);return t.copy(e),r>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ta.subVectors(e,this.center);const t=Ta.lengthSq();if(t>this.radius*this.radius){const r=Math.sqrt(t),o=(r-this.radius)*.5;this.center.addScaledVector(Ta,o/r),this.radius+=o}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(ef.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ta.copy(e.center).add(ef)),this.expandByPoint(Ta.copy(e.center).sub(ef))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let g1=0;const Ti=new Yt,tf=new Pn,Mo=new Z,mi=new ks,Aa=new ks,Rn=new Z;class dn extends ds{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:g1++}),this.uuid=qa(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(q_(e)?Tv:wv)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,r=0){this.groups.push({start:e,count:t,materialIndex:r})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const r=this.attributes.normal;if(r!==void 0){const l=new yt().getNormalMatrix(e);r.applyNormalMatrix(l),r.needsUpdate=!0}const o=this.attributes.tangent;return o!==void 0&&(o.transformDirection(e),o.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Ti.makeRotationFromQuaternion(e),this.applyMatrix4(Ti),this}rotateX(e){return Ti.makeRotationX(e),this.applyMatrix4(Ti),this}rotateY(e){return Ti.makeRotationY(e),this.applyMatrix4(Ti),this}rotateZ(e){return Ti.makeRotationZ(e),this.applyMatrix4(Ti),this}translate(e,t,r){return Ti.makeTranslation(e,t,r),this.applyMatrix4(Ti),this}scale(e,t,r){return Ti.makeScale(e,t,r),this.applyMatrix4(Ti),this}lookAt(e){return tf.lookAt(e),tf.updateMatrix(),this.applyMatrix4(tf.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Mo).negate(),this.translate(Mo.x,Mo.y,Mo.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const r=[];for(let o=0,l=e.length;o<l;o++){const u=e[o];r.push(u.x,u.y,u.z||0)}this.setAttribute("position",new Jt(r,3))}else{const r=Math.min(e.length,t.count);for(let o=0;o<r;o++){const l=e[o];t.setXYZ(o,l.x,l.y,l.z||0)}e.length>t.count&&ht("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ks);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){zt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new Z(-1/0,-1/0,-1/0),new Z(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){const l=t[r];mi.setFromBufferAttribute(l),this.morphTargetsRelative?(Rn.addVectors(this.boundingBox.min,mi.min),this.boundingBox.expandByPoint(Rn),Rn.addVectors(this.boundingBox.max,mi.max),this.boundingBox.expandByPoint(Rn)):(this.boundingBox.expandByPoint(mi.min),this.boundingBox.expandByPoint(mi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&zt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Bs);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){zt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new Z,1/0);return}if(e){const r=this.boundingSphere.center;if(mi.setFromBufferAttribute(e),t)for(let l=0,u=t.length;l<u;l++){const d=t[l];Aa.setFromBufferAttribute(d),this.morphTargetsRelative?(Rn.addVectors(mi.min,Aa.min),mi.expandByPoint(Rn),Rn.addVectors(mi.max,Aa.max),mi.expandByPoint(Rn)):(mi.expandByPoint(Aa.min),mi.expandByPoint(Aa.max))}mi.getCenter(r);let o=0;for(let l=0,u=e.count;l<u;l++)Rn.fromBufferAttribute(e,l),o=Math.max(o,r.distanceToSquared(Rn));if(t)for(let l=0,u=t.length;l<u;l++){const d=t[l],f=this.morphTargetsRelative;for(let p=0,y=d.count;p<y;p++)Rn.fromBufferAttribute(d,p),f&&(Mo.fromBufferAttribute(e,p),Rn.add(Mo)),o=Math.max(o,r.distanceToSquared(Rn))}this.boundingSphere.radius=Math.sqrt(o),isNaN(this.boundingSphere.radius)&&zt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){zt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const r=t.position,o=t.normal,l=t.uv;let u=this.getAttribute("tangent");(u===void 0||u.count!==r.count)&&(u=new jn(new Float32Array(4*r.count),4),this.setAttribute("tangent",u));const d=[],f=[];for(let E=0;E<r.count;E++)d[E]=new Z,f[E]=new Z;const p=new Z,y=new Z,S=new Z,v=new dt,_=new dt,M=new dt,A=new Z,m=new Z;function x(E,L,B){p.fromBufferAttribute(r,E),y.fromBufferAttribute(r,L),S.fromBufferAttribute(r,B),v.fromBufferAttribute(l,E),_.fromBufferAttribute(l,L),M.fromBufferAttribute(l,B),y.sub(p),S.sub(p),_.sub(v),M.sub(v);const X=1/(_.x*M.y-M.x*_.y);isFinite(X)&&(A.copy(y).multiplyScalar(M.y).addScaledVector(S,-_.y).multiplyScalar(X),m.copy(S).multiplyScalar(_.x).addScaledVector(y,-M.x).multiplyScalar(X),d[E].add(A),d[L].add(A),d[B].add(A),f[E].add(m),f[L].add(m),f[B].add(m))}let P=this.groups;P.length===0&&(P=[{start:0,count:e.count}]);for(let E=0,L=P.length;E<L;++E){const B=P[E],X=B.start,j=B.count;for(let ne=X,H=X+j;ne<H;ne+=3)x(e.getX(ne+0),e.getX(ne+1),e.getX(ne+2))}const U=new Z,b=new Z,R=new Z,N=new Z;function F(E){R.fromBufferAttribute(o,E),N.copy(R);const L=d[E];U.copy(L),U.sub(R.multiplyScalar(R.dot(L))).normalize(),b.crossVectors(N,L);const X=b.dot(f[E])<0?-1:1;u.setXYZW(E,U.x,U.y,U.z,X)}for(let E=0,L=P.length;E<L;++E){const B=P[E],X=B.start,j=B.count;for(let ne=X,H=X+j;ne<H;ne+=3)F(e.getX(ne+0)),F(e.getX(ne+1)),F(e.getX(ne+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let r=this.getAttribute("normal");if(r===void 0||r.count!==t.count)r=new jn(new Float32Array(t.count*3),3),this.setAttribute("normal",r);else for(let v=0,_=r.count;v<_;v++)r.setXYZ(v,0,0,0);const o=new Z,l=new Z,u=new Z,d=new Z,f=new Z,p=new Z,y=new Z,S=new Z;if(e)for(let v=0,_=e.count;v<_;v+=3){const M=e.getX(v+0),A=e.getX(v+1),m=e.getX(v+2);o.fromBufferAttribute(t,M),l.fromBufferAttribute(t,A),u.fromBufferAttribute(t,m),y.subVectors(u,l),S.subVectors(o,l),y.cross(S),d.fromBufferAttribute(r,M),f.fromBufferAttribute(r,A),p.fromBufferAttribute(r,m),d.add(y),f.add(y),p.add(y),r.setXYZ(M,d.x,d.y,d.z),r.setXYZ(A,f.x,f.y,f.z),r.setXYZ(m,p.x,p.y,p.z)}else for(let v=0,_=t.count;v<_;v+=3)o.fromBufferAttribute(t,v+0),l.fromBufferAttribute(t,v+1),u.fromBufferAttribute(t,v+2),y.subVectors(u,l),S.subVectors(o,l),y.cross(S),r.setXYZ(v+0,y.x,y.y,y.z),r.setXYZ(v+1,y.x,y.y,y.z),r.setXYZ(v+2,y.x,y.y,y.z);this.normalizeNormals(),r.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,r=e.count;t<r;t++)Rn.fromBufferAttribute(e,t),Rn.normalize(),e.setXYZ(t,Rn.x,Rn.y,Rn.z)}toNonIndexed(){function e(d,f){const p=d.array,y=d.itemSize,S=d.normalized,v=new p.constructor(f.length*y);let _=0,M=0;for(let A=0,m=f.length;A<m;A++){d.isInterleavedBufferAttribute?_=f[A]*d.data.stride+d.offset:_=f[A]*y;for(let x=0;x<y;x++)v[M++]=p[_++]}return new jn(v,y,S)}if(this.index===null)return ht("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new dn,r=this.index.array,o=this.attributes;for(const d in o){const f=o[d],p=e(f,r);t.setAttribute(d,p)}const l=this.morphAttributes;for(const d in l){const f=[],p=l[d];for(let y=0,S=p.length;y<S;y++){const v=p[y],_=e(v,r);f.push(_)}t.morphAttributes[d]=f}t.morphTargetsRelative=this.morphTargetsRelative;const u=this.groups;for(let d=0,f=u.length;d<f;d++){const p=u[d];t.addGroup(p.start,p.count,p.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const f=this.parameters;for(const p in f)f[p]!==void 0&&(e[p]=f[p]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const r=this.attributes;for(const f in r){const p=r[f];e.data.attributes[f]=p.toJSON(e.data)}const o={};let l=!1;for(const f in this.morphAttributes){const p=this.morphAttributes[f],y=[];for(let S=0,v=p.length;S<v;S++){const _=p[S];y.push(_.toJSON(e.data))}y.length>0&&(o[f]=y,l=!0)}l&&(e.data.morphAttributes=o,e.data.morphTargetsRelative=this.morphTargetsRelative);const u=this.groups;u.length>0&&(e.data.groups=JSON.parse(JSON.stringify(u)));const d=this.boundingSphere;return d!==null&&(e.data.boundingSphere=d.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const r=e.index;r!==null&&this.setIndex(r.clone());const o=e.attributes;for(const p in o){const y=o[p];this.setAttribute(p,y.clone(t))}const l=e.morphAttributes;for(const p in l){const y=[],S=l[p];for(let v=0,_=S.length;v<_;v++)y.push(S[v].clone(t));this.morphAttributes[p]=y}this.morphTargetsRelative=e.morphTargetsRelative;const u=e.groups;for(let p=0,y=u.length;p<y;p++){const S=u[p];this.addGroup(S.start,S.count,S.materialIndex)}const d=e.boundingBox;d!==null&&(this.boundingBox=d.clone());const f=e.boundingSphere;return f!==null&&(this.boundingSphere=f.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}const nf=new Z,v1=new Z,x1=new yt;class Tr{constructor(e=new Z(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,r,o){return this.normal.set(e,t,r),this.constant=o,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,r){const o=nf.subVectors(r,t).cross(v1.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(o,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,r=!0){const o=e.delta(nf),l=this.normal.dot(o);if(l===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const u=-(e.start.dot(this.normal)+this.constant)/l;return r===!0&&(u<0||u>1)?null:t.copy(e.start).addScaledVector(o,u)}intersectsLine(e){const t=this.distanceToPoint(e.start),r=this.distanceToPoint(e.end);return t<0&&r>0||r<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const r=t||x1.getNormalMatrix(e),o=this.coplanarPoint(nf).applyMatrix4(e),l=this.normal.applyMatrix3(r).normalize();return this.constant=-o.dot(l),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let y1=0;class zs extends ds{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:y1++}),this.uuid=qa(),this.name="",this.type="Material",this.blending=Ua,this.side=Ds,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=sv,this.blendDst=ov,this.blendEquation=Co,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new vt(0,0,0),this.blendAlpha=0,this.depthFunc=Va,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=z_,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Od,this.stencilZFail=Od,this.stencilZPass=Od,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const r=e[t];if(r===void 0){ht(`Material: parameter '${t}' has value of undefined.`);continue}const o=this[t];if(o===void 0){ht(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}o&&o.isColor?o.set(r):o&&o.isVector2&&r&&r.isVector2||o&&o.isEuler&&r&&r.isEuler||o&&o.isVector3&&r&&r.isVector3?o.copy(r):this[t]=r}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const r={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};r.uuid=this.uuid,r.type=this.type,r.blending=this.blending,r.side=this.side,r.shadowSide=this.shadowSide,r.vertexColors=this.vertexColors,r.opacity=this.opacity,r.transparent=this.transparent,r.blendSrc=this.blendSrc,r.blendDst=this.blendDst,r.blendEquation=this.blendEquation,r.blendSrcAlpha=this.blendSrcAlpha,r.blendDstAlpha=this.blendDstAlpha,r.blendEquationAlpha=this.blendEquationAlpha,r.blendColor=this.blendColor.getHex(),r.blendAlpha=this.blendAlpha,r.depthFunc=this.depthFunc,r.depthTest=this.depthTest,r.depthWrite=this.depthWrite,r.colorWrite=this.colorWrite,r.clipIntersection=this.clipIntersection,r.clipShadows=this.clipShadows,r.stencilWriteMask=this.stencilWriteMask,r.stencilFunc=this.stencilFunc,r.stencilRef=this.stencilRef,r.stencilFuncMask=this.stencilFuncMask,r.stencilFail=this.stencilFail,r.stencilZFail=this.stencilZFail,r.stencilZPass=this.stencilZPass,r.stencilWrite=this.stencilWrite,r.polygonOffset=this.polygonOffset,r.polygonOffsetFactor=this.polygonOffsetFactor,r.polygonOffsetUnits=this.polygonOffsetUnits,r.dithering=this.dithering,r.alphaTest=this.alphaTest,r.alphaHash=this.alphaHash,r.alphaToCoverage=this.alphaToCoverage,r.premultipliedAlpha=this.premultipliedAlpha,r.forceSinglePass=this.forceSinglePass,r.allowOverride=this.allowOverride,r.visible=this.visible,r.toneMapped=this.toneMapped,r.name=this.name,this.color&&this.color.isColor&&(r.color=this.color.getHex()),this.roughness!==void 0&&(r.roughness=this.roughness),this.metalness!==void 0&&(r.metalness=this.metalness),this.sheen!==void 0&&(r.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(r.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(r.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(r.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(r.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(r.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(r.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(r.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(r.shininess=this.shininess),this.clearcoat!==void 0&&(r.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(r.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(r.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(r.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(r.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,r.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(r.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(r.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(r.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(r.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(r.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(r.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(r.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(r.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(r.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(r.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(r.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(r.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(r.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(r.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(r.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(r.lightMap=this.lightMap.toJSON(e).uuid,r.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(r.aoMap=this.aoMap.toJSON(e).uuid,r.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(r.bumpMap=this.bumpMap.toJSON(e).uuid,r.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(r.normalMap=this.normalMap.toJSON(e).uuid,r.normalMapType=this.normalMapType,r.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(r.displacementMap=this.displacementMap.toJSON(e).uuid,r.displacementScale=this.displacementScale,r.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(r.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(r.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(r.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(r.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(r.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(r.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(r.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(r.combine=this.combine)),this.envMapRotation!==void 0&&(r.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(r.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(r.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(r.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(r.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(r.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(r.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(r.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(r.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(r.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(r.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(r.size=this.size),this.sizeAttenuation!==void 0&&(r.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(r.clippingPlanes=this.clippingPlanes.map(l=>l.toJSON())),this.rotation!==void 0&&(r.rotation=this.rotation),this.depthPacking!==void 0&&(r.depthPacking=this.depthPacking),this.linewidth!==void 0&&(r.linewidth=this.linewidth),this.linecap!==void 0&&(r.linecap=this.linecap),this.linejoin!==void 0&&(r.linejoin=this.linejoin),this.dashSize!==void 0&&(r.dashSize=this.dashSize),this.gapSize!==void 0&&(r.gapSize=this.gapSize),this.scale!==void 0&&(r.scale=this.scale),this.wireframe!==void 0&&(r.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(r.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(r.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(r.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(r.flatShading=this.flatShading),this.fog!==void 0&&(r.fog=this.fog),Object.keys(this.userData).length>0&&(r.userData=this.userData);function o(l){const u=[];for(const d in l){const f=l[d];delete f.metadata,u.push(f)}return u}if(t){const l=o(e.textures),u=o(e.images);l.length>0&&(r.textures=l),u.length>0&&(r.images=u)}return r}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new vt().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(r=>new Tr().fromJSON(r))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let r=e.normalScale;Array.isArray(r)===!1&&(r=[r,r]),this.normalScale=new dt().fromArray(r)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new dt().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let r=null;if(t!==null){const o=t.length;r=new Array(o);for(let l=0;l!==o;++l)r[l]=t[l].clone()}return this.clippingPlanes=r,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Er=new Z,rf=new Z,oc=new Z,ac=new Z;class Ka{constructor(e=new Z,t=new Z(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Er)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const r=t.dot(this.direction);return r<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,r)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Er.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Er.copy(this.origin).addScaledVector(this.direction,t),Er.distanceToSquared(e))}distanceSqToSegment(e,t,r,o){rf.copy(e).add(t).multiplyScalar(.5),oc.copy(t).sub(e).normalize(),ac.copy(this.origin).sub(rf);const l=e.distanceTo(t)*.5,u=-this.direction.dot(oc),d=ac.dot(this.direction),f=-ac.dot(oc),p=ac.lengthSq(),y=Math.abs(1-u*u);let S,v,_,M;if(y>0)if(S=u*f-d,v=u*d-f,M=l*y,S>=0)if(v>=-M)if(v<=M){const A=1/y;S*=A,v*=A,_=S*(S+u*v+2*d)+v*(u*S+v+2*f)+p}else v=l,S=Math.max(0,-(u*v+d)),_=-S*S+v*(v+2*f)+p;else v=-l,S=Math.max(0,-(u*v+d)),_=-S*S+v*(v+2*f)+p;else v<=-M?(S=Math.max(0,-(-u*l+d)),v=S>0?-l:Math.min(Math.max(-l,-f),l),_=-S*S+v*(v+2*f)+p):v<=M?(S=0,v=Math.min(Math.max(-l,-f),l),_=v*(v+2*f)+p):(S=Math.max(0,-(u*l+d)),v=S>0?l:Math.min(Math.max(-l,-f),l),_=-S*S+v*(v+2*f)+p);else v=u>0?-l:l,S=Math.max(0,-(u*v+d)),_=-S*S+v*(v+2*f)+p;return r&&r.copy(this.origin).addScaledVector(this.direction,S),o&&o.copy(rf).addScaledVector(oc,v),_}intersectSphere(e,t){if(e.radius<0)return null;Er.subVectors(e.center,this.origin);const r=Er.dot(this.direction),o=Er.dot(Er)-r*r,l=e.radius*e.radius;if(o>l)return null;const u=Math.sqrt(l-o),d=r-u,f=r+u;return f<0?null:d<0?this.at(f,t):this.at(d,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const r=-(this.origin.dot(e.normal)+e.constant)/t;return r>=0?r:null}intersectPlane(e,t){const r=this.distanceToPlane(e);return r===null?null:this.at(r,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let r,o,l,u,d,f;const p=1/this.direction.x,y=1/this.direction.y,S=1/this.direction.z,v=this.origin;return p>=0?(r=(e.min.x-v.x)*p,o=(e.max.x-v.x)*p):(r=(e.max.x-v.x)*p,o=(e.min.x-v.x)*p),y>=0?(l=(e.min.y-v.y)*y,u=(e.max.y-v.y)*y):(l=(e.max.y-v.y)*y,u=(e.min.y-v.y)*y),r>u||l>o||((l>r||isNaN(r))&&(r=l),(u<o||isNaN(o))&&(o=u),S>=0?(d=(e.min.z-v.z)*S,f=(e.max.z-v.z)*S):(d=(e.max.z-v.z)*S,f=(e.min.z-v.z)*S),r>f||d>o)||((d>r||r!==r)&&(r=d),(f<o||o!==o)&&(o=f),o<0)?null:this.at(r>=0?r:o,t)}intersectsBox(e){return this.intersectBox(e,Er)!==null}intersectTriangle(e,t,r,o,l){const u=this.origin,d=this.direction,f=d.x,p=d.y,y=d.z,S=e.x-u.x,v=e.y-u.y,_=e.z-u.z,M=t.x-u.x,A=t.y-u.y,m=t.z-u.z,x=r.x-u.x,P=r.y-u.y,U=r.z-u.z,b=Math.abs(f),R=Math.abs(p),N=Math.abs(y);let F,E,L,B,X,j,ne,H,W,ue,Q,te;if(b>=R&&b>=N?(L=f,j=S,W=M,te=x,f>=0?(F=p,E=y,B=v,X=_,ne=A,H=m,ue=P,Q=U):(F=y,E=p,B=_,X=v,ne=m,H=A,ue=U,Q=P)):R>=N?(L=p,j=v,W=A,te=P,p>=0?(F=y,E=f,B=_,X=S,ne=m,H=M,ue=U,Q=x):(F=f,E=y,B=S,X=_,ne=M,H=m,ue=x,Q=U)):(L=y,j=_,W=m,te=U,y>=0?(F=f,E=p,B=S,X=v,ne=M,H=A,ue=x,Q=P):(F=p,E=f,B=v,X=S,ne=A,H=M,ue=P,Q=x)),L===0)return null;const G=F/L,ee=E/L,O=1/L,de=B-G*j,Ce=X-ee*j,Te=ne-G*W,De=H-ee*W,Ye=ue-G*te,le=Q-ee*te,ge=Ye*De-le*Te,Ne=de*le-Ce*Ye,tt=Te*Ce-De*de;if(o){if(ge<0||Ne<0||tt<0)return null}else if((ge<0||Ne<0||tt<0)&&(ge>0||Ne>0||tt>0))return null;const Xe=ge+Ne+tt;if(Xe===0)return null;const mt=O*(ge*j+Ne*W+tt*te);return(Xe>0?mt<0:mt>0)?null:this.at(mt/Xe,l)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class tr extends zs{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new vt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new cs,this.combine=av,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Hg=new Yt,As=new Ka,lc=new Bs,Gg=new Z,cc=new Z,uc=new Z,dc=new Z,sf=new Z,fc=new Z,Wg=new Z,hc=new Z;class Sn extends Pn{constructor(e=new dn,t=new tr){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const o=t[r[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=o.length;l<u;l++){const d=o[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=l}}}}getVertexPosition(e,t){const r=this.geometry,o=r.attributes.position,l=r.morphAttributes.position,u=r.morphTargetsRelative;t.fromBufferAttribute(o,e);const d=this.morphTargetInfluences;if(l&&d){fc.set(0,0,0);for(let f=0,p=l.length;f<p;f++){const y=d[f],S=l[f];y!==0&&(sf.fromBufferAttribute(S,e),u?fc.addScaledVector(sf,y):fc.addScaledVector(sf.sub(t),y))}t.add(fc)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const r=this.geometry,o=this.material,l=this.matrixWorld;o!==void 0&&(r.boundingSphere===null&&r.computeBoundingSphere(),lc.copy(r.boundingSphere),lc.applyMatrix4(l),As.copy(e.ray).recast(e.near),!(lc.containsPoint(As.origin)===!1&&(As.intersectSphere(lc,Gg)===null||As.origin.distanceToSquared(Gg)>(e.far-e.near)**2))&&(Hg.copy(l).invert(),As.copy(e.ray).applyMatrix4(Hg),!(r.boundingBox!==null&&As.intersectsBox(r.boundingBox)===!1)&&this._computeIntersections(e,t,As)))}_computeIntersections(e,t,r){let o;const l=this.geometry,u=this.material,d=l.index,f=l.attributes.position,p=l.attributes.uv,y=l.attributes.uv1,S=l.attributes.normal,v=l.groups,_=l.drawRange;if(d!==null)if(Array.isArray(u))for(let M=0,A=v.length;M<A;M++){const m=v[M],x=u[m.materialIndex],P=Math.max(m.start,_.start),U=Math.min(d.count,Math.min(m.start+m.count,_.start+_.count));for(let b=P,R=U;b<R;b+=3){const N=d.getX(b),F=d.getX(b+1),E=d.getX(b+2);o=pc(this,x,e,r,p,y,S,N,F,E),o&&(o.faceIndex=Math.floor(b/3),o.face.materialIndex=m.materialIndex,t.push(o))}}else{const M=Math.max(0,_.start),A=Math.min(d.count,_.start+_.count);for(let m=M,x=A;m<x;m+=3){const P=d.getX(m),U=d.getX(m+1),b=d.getX(m+2);o=pc(this,u,e,r,p,y,S,P,U,b),o&&(o.faceIndex=Math.floor(m/3),t.push(o))}}else if(f!==void 0)if(Array.isArray(u))for(let M=0,A=v.length;M<A;M++){const m=v[M],x=u[m.materialIndex],P=Math.max(m.start,_.start),U=Math.min(f.count,Math.min(m.start+m.count,_.start+_.count));for(let b=P,R=U;b<R;b+=3){const N=b,F=b+1,E=b+2;o=pc(this,x,e,r,p,y,S,N,F,E),o&&(o.faceIndex=Math.floor(b/3),o.face.materialIndex=m.materialIndex,t.push(o))}}else{const M=Math.max(0,_.start),A=Math.min(f.count,_.start+_.count);for(let m=M,x=A;m<x;m+=3){const P=m,U=m+1,b=m+2;o=pc(this,u,e,r,p,y,S,P,U,b),o&&(o.faceIndex=Math.floor(m/3),t.push(o))}}}}function _1(s,e,t,r,o,l,u,d){let f;if(e.side===Jn?f=r.intersectTriangle(u,l,o,!0,d):f=r.intersectTriangle(o,l,u,e.side===Ds,d),f===null)return null;hc.copy(d),hc.applyMatrix4(s.matrixWorld);const p=t.ray.origin.distanceTo(hc);return p<t.near||p>t.far?null:{distance:p,point:hc.clone(),object:s}}function pc(s,e,t,r,o,l,u,d,f,p){s.getVertexPosition(d,cc),s.getVertexPosition(f,uc),s.getVertexPosition(p,dc);const y=_1(s,e,t,r,cc,uc,dc,Wg);if(y){const S=new Z;Vi.getBarycoord(Wg,cc,uc,dc,S),o&&(y.uv=Vi.getInterpolatedAttribute(o,d,f,p,S,new dt)),l&&(y.uv1=Vi.getInterpolatedAttribute(l,d,f,p,S,new dt)),u&&(y.normal=Vi.getInterpolatedAttribute(u,d,f,p,S,new Z),y.normal.dot(r.direction)>0&&y.normal.multiplyScalar(-1));const v={a:d,b:f,c:p,normal:new Z,materialIndex:0};Vi.getNormal(cc,uc,dc,v.normal),y.face=v,y.barycoord=S}return y}class Av extends Qn{constructor(e=null,t=1,r=1,o,l,u,d,f,p=Un,y=Un,S,v){super(null,u,d,f,p,y,o,l,S,v),this.isDataTexture=!0,this.image={data:e,width:t,height:r},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class jg extends jn{constructor(e,t,r,o=1){super(e,t,r),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=o}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Eo=new Yt,Xg=new Yt,mc=[],Yg=new ks,S1=new Yt,ba=new Sn,Ca=new Bs;class M1 extends Sn{constructor(e,t,r){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new jg(new Float32Array(r*16),16),this.instanceColor=null,this.morphTexture=null,this.count=r,this.boundingBox=null,this.boundingSphere=null;for(let o=0;o<r;o++)this.setMatrixAt(o,S1)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new ks),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let r=0;r<t;r++)this.getMatrixAt(r,Eo),Yg.copy(e.boundingBox).applyMatrix4(Eo),this.boundingBox.union(Yg)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Bs),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let r=0;r<t;r++)this.getMatrixAt(r,Eo),Ca.copy(e.boundingSphere).applyMatrix4(Eo),this.boundingSphere.union(Ca)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const r=t.morphTargetInfluences,o=this.morphTexture.source.data.data,l=r.length+1,u=e*l+1;for(let d=0;d<r.length;d++)r[d]=o[u+d]}raycast(e,t){const r=this.matrixWorld,o=this.count;if(ba.geometry=this.geometry,ba.material=this.material,ba.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ca.copy(this.boundingSphere),Ca.applyMatrix4(r),e.ray.intersectsSphere(Ca)!==!1))for(let l=0;l<o;l++){this.getMatrixAt(l,Eo),Xg.multiplyMatrices(r,Eo),ba.matrixWorld=Xg,ba.raycast(e,mc);for(let u=0,d=mc.length;u<d;u++){const f=mc[u];f.instanceId=l,f.object=this,t.push(f)}mc.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new jg(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){const r=t.morphTargetInfluences,o=r.length+1;this.morphTexture===null&&(this.morphTexture=new Av(new Float32Array(o*this.count),o,this.count,Eh,Hi));const l=this.morphTexture.source.data.data;let u=0;for(let p=0;p<r.length;p++)u+=r[p];const d=this.geometry.morphTargetsRelative?1:1-u,f=o*e;return l[f]=d,l.set(r,f+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const bs=new Bs,E1=new dt(.5,.5),gc=new Z;class Lh{constructor(e=new Tr,t=new Tr,r=new Tr,o=new Tr,l=new Tr,u=new Tr){this.planes=[e,t,r,o,l,u]}set(e,t,r,o,l,u){const d=this.planes;return d[0].copy(e),d[1].copy(t),d[2].copy(r),d[3].copy(o),d[4].copy(l),d[5].copy(u),this}copy(e){const t=this.planes;for(let r=0;r<6;r++)t[r].copy(e.planes[r]);return this}setFromProjectionMatrix(e,t=ir,r=!1){const o=this.planes,l=e.elements,u=l[0],d=l[1],f=l[2],p=l[3],y=l[4],S=l[5],v=l[6],_=l[7],M=l[8],A=l[9],m=l[10],x=l[11],P=l[12],U=l[13],b=l[14],R=l[15];if(o[0].setComponents(p-u,_-y,x-M,R-P).normalize(),o[1].setComponents(p+u,_+y,x+M,R+P).normalize(),o[2].setComponents(p+d,_+S,x+A,R+U).normalize(),o[3].setComponents(p-d,_-S,x-A,R-U).normalize(),r)o[4].setComponents(f,v,m,b).normalize(),o[5].setComponents(p-f,_-v,x-m,R-b).normalize();else if(o[4].setComponents(p-f,_-v,x-m,R-b).normalize(),t===ir)o[5].setComponents(p+f,_+v,x+m,R+b).normalize();else if(t===Wa)o[5].setComponents(f,v,m,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),bs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),bs.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(bs)}intersectsSprite(e){bs.center.set(0,0,0);const t=E1.distanceTo(e.center);return bs.radius=.7071067811865476+t,bs.applyMatrix4(e.matrixWorld),this.intersectsSphere(bs)}intersectsSphere(e){const t=this.planes,r=e.center,o=-e.radius;for(let l=0;l<6;l++)if(t[l].distanceToPoint(r)<o)return!1;return!0}intersectsBox(e){const t=this.planes;for(let r=0;r<6;r++){const o=t[r];if(gc.x=o.normal.x>0?e.max.x:e.min.x,gc.y=o.normal.y>0?e.max.y:e.min.y,gc.z=o.normal.z>0?e.max.z:e.min.z,o.distanceToPoint(gc)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let r=0;r<6;r++)if(t[r].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Lc extends zs{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new vt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Gc=new Z,Wc=new Z,qg=new Yt,Ra=new Ka,vc=new Bs,of=new Z,Kg=new Z;class lh extends Pn{constructor(e=new dn,t=new Lc){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,r=[0];for(let o=1,l=t.count;o<l;o++)Gc.fromBufferAttribute(t,o-1),Wc.fromBufferAttribute(t,o),r[o]=r[o-1],r[o]+=Gc.distanceTo(Wc);e.setAttribute("lineDistance",new Jt(r,1))}else ht("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const r=this.geometry,o=this.matrixWorld,l=e.params.Line.threshold,u=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),vc.copy(r.boundingSphere),vc.applyMatrix4(o),vc.radius+=l,e.ray.intersectsSphere(vc)===!1)return;qg.copy(o).invert(),Ra.copy(e.ray).applyMatrix4(qg);const d=l/((this.scale.x+this.scale.y+this.scale.z)/3),f=d*d,p=this.isLineSegments?2:1,y=r.index,v=r.attributes.position;if(y!==null){const _=Math.max(0,u.start),M=Math.min(y.count,u.start+u.count);for(let A=_,m=M-1;A<m;A+=p){const x=y.getX(A),P=y.getX(A+1),U=xc(this,e,Ra,f,x,P,A);U&&t.push(U)}if(this.isLineLoop){const A=y.getX(M-1),m=y.getX(_),x=xc(this,e,Ra,f,A,m,M-1);x&&t.push(x)}}else{const _=Math.max(0,u.start),M=Math.min(v.count,u.start+u.count);for(let A=_,m=M-1;A<m;A+=p){const x=xc(this,e,Ra,f,A,A+1,A);x&&t.push(x)}if(this.isLineLoop){const A=xc(this,e,Ra,f,M-1,_,M-1);A&&t.push(A)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const o=t[r[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=o.length;l<u;l++){const d=o[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=l}}}}}function xc(s,e,t,r,o,l,u){const d=s.geometry.attributes.position;if(Gc.fromBufferAttribute(d,o),Wc.fromBufferAttribute(d,l),t.distanceSqToSegment(Gc,Wc,of,Kg)>r)return;of.applyMatrix4(s.matrixWorld);const p=e.ray.origin.distanceTo(of);if(!(p<e.near||p>e.far))return{distance:p,point:Kg.clone().applyMatrix4(s.matrixWorld),index:u,face:null,faceIndex:null,barycoord:null,object:s}}const $g=new Z,Zg=new Z;class w1 extends lh{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,r=[];for(let o=0,l=t.count;o<l;o+=2)$g.fromBufferAttribute(t,o),Zg.fromBufferAttribute(t,o+1),r[o]=o===0?0:r[o-1],r[o+1]=r[o]+$g.distanceTo(Zg);e.setAttribute("lineDistance",new Jt(r,1))}else ht("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Nc extends zs{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new vt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Jg=new Yt,ch=new Ka,yc=new Bs,_c=new Z;class af extends Pn{constructor(e=new dn,t=new Nc){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const r=this.geometry,o=this.matrixWorld,l=e.params.Points.threshold,u=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),yc.copy(r.boundingSphere),yc.applyMatrix4(o),yc.radius+=l,e.ray.intersectsSphere(yc)===!1)return;Jg.copy(o).invert(),ch.copy(e.ray).applyMatrix4(Jg);const d=l/((this.scale.x+this.scale.y+this.scale.z)/3),f=d*d,p=r.index,S=r.attributes.position;if(p!==null){const v=Math.max(0,u.start),_=Math.min(p.count,u.start+u.count);for(let M=v,A=_;M<A;M++){const m=p.getX(M);_c.fromBufferAttribute(S,m),Qg(_c,m,f,o,e,t,this)}}else{const v=Math.max(0,u.start),_=Math.min(S.count,u.start+u.count);for(let M=v,A=_;M<A;M++)_c.fromBufferAttribute(S,M),Qg(_c,M,f,o,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,r=Object.keys(t);if(r.length>0){const o=t[r[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=o.length;l<u;l++){const d=o[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=l}}}}}function Qg(s,e,t,r,o,l,u){const d=ch.distanceSqToPoint(s);if(d<t){const f=new Z;ch.closestPointToPoint(s,f),f.applyMatrix4(r);const p=o.ray.origin.distanceTo(f);if(p<o.near||p>o.far)return;l.push({distance:p,distanceToRay:Math.sqrt(d),point:f,index:e,face:null,faceIndex:null,barycoord:null,object:u})}}class bv extends Qn{constructor(e=[],t=Us,r,o,l,u,d,f,p,y){super(e,t,r,o,l,u,d,f,p,y),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class ja extends Qn{constructor(e,t,r=sr,o,l,u,d=Un,f=Un,p,y=Pr,S=1){if(y!==Pr&&y!==Ls)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const v={width:e,height:t,depth:S};super(v,o,l,u,d,f,y,r,p),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Rh(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class T1 extends ja{constructor(e,t=sr,r=Us,o,l,u=Un,d=Un,f,p=Pr){const y={width:e,height:e,depth:1},S=[y,y,y,y,y,y];super(e,e,t,r,o,l,u,d,f,p),this.image=S,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class Cv extends Qn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class $a extends dn{constructor(e=1,t=1,r=1,o=1,l=1,u=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:r,widthSegments:o,heightSegments:l,depthSegments:u};const d=this;o=Math.floor(o),l=Math.floor(l),u=Math.floor(u);const f=[],p=[],y=[],S=[];let v=0,_=0;M("z","y","x",-1,-1,r,t,e,u,l,0),M("z","y","x",1,-1,r,t,-e,u,l,1),M("x","z","y",1,1,e,r,t,o,u,2),M("x","z","y",1,-1,e,r,-t,o,u,3),M("x","y","z",1,-1,e,t,r,o,l,4),M("x","y","z",-1,-1,e,t,-r,o,l,5),this.setIndex(f),this.setAttribute("position",new Jt(p,3)),this.setAttribute("normal",new Jt(y,3)),this.setAttribute("uv",new Jt(S,2));function M(A,m,x,P,U,b,R,N,F,E,L){const B=b/F,X=R/E,j=b/2,ne=R/2,H=N/2,W=F+1,ue=E+1;let Q=0,te=0;const G=new Z;for(let ee=0;ee<ue;ee++){const O=ee*X-ne;for(let de=0;de<W;de++){const Ce=de*B-j;G[A]=Ce*P,G[m]=O*U,G[x]=H,p.push(G.x,G.y,G.z),G[A]=0,G[m]=0,G[x]=N>0?1:-1,y.push(G.x,G.y,G.z),S.push(de/F),S.push(1-ee/E),Q+=1}}for(let ee=0;ee<E;ee++)for(let O=0;O<F;O++){const de=v+O+W*ee,Ce=v+O+W*(ee+1),Te=v+(O+1)+W*(ee+1),De=v+(O+1)+W*ee;f.push(de,Ce,De),f.push(Ce,Te,De),te+=6}d.addGroup(_,te,L),_+=te,v+=Q}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new $a(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Nh extends dn{constructor(e=1,t=1,r=1,o=32,l=1,u=!1,d=0,f=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:r,radialSegments:o,heightSegments:l,openEnded:u,thetaStart:d,thetaLength:f};const p=this;o=Math.floor(o),l=Math.floor(l);const y=[],S=[],v=[],_=[];let M=0;const A=[],m=r/2;let x=0;P(),u===!1&&(e>0&&U(!0),t>0&&U(!1)),this.setIndex(y),this.setAttribute("position",new Jt(S,3)),this.setAttribute("normal",new Jt(v,3)),this.setAttribute("uv",new Jt(_,2));function P(){const b=new Z,R=new Z;let N=0;const F=(t-e)/r;for(let E=0;E<=l;E++){const L=[],B=E/l,X=B*(t-e)+e;for(let j=0;j<=o;j++){const ne=j/o,H=ne*f+d,W=Math.sin(H),ue=Math.cos(H);R.x=X*W,R.y=-B*r+m,R.z=X*ue,S.push(R.x,R.y,R.z),b.set(W,F,ue).normalize(),v.push(b.x,b.y,b.z),_.push(ne,1-B),L.push(M++)}A.push(L)}for(let E=0;E<o;E++)for(let L=0;L<l;L++){const B=A[L][E],X=A[L+1][E],j=A[L+1][E+1],ne=A[L][E+1];(e>0||L!==0)&&(y.push(B,X,ne),N+=3),(t>0||L!==l-1)&&(y.push(X,j,ne),N+=3)}p.addGroup(x,N,0),x+=N}function U(b){const R=M,N=new dt,F=new Z;let E=0;const L=b===!0?e:t,B=b===!0?1:-1;for(let j=1;j<=o;j++)S.push(0,m*B,0),v.push(0,B,0),_.push(.5,.5),M++;const X=M;for(let j=0;j<=o;j++){const H=j/o*f+d,W=Math.cos(H),ue=Math.sin(H);F.x=L*ue,F.y=m*B,F.z=L*W,S.push(F.x,F.y,F.z),v.push(0,B,0),N.x=W*.5+.5,N.y=ue*.5*B+.5,_.push(N.x,N.y),M++}for(let j=0;j<o;j++){const ne=R+j,H=X+j;b===!0?y.push(H,H+1,ne):y.push(H+1,H,ne),E+=3}p.addGroup(x,E,b===!0?1:2),x+=E}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Nh(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Dh extends dn{constructor(e=[],t=[],r=1,o=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:r,detail:o};const l=[],u=[];d(o),p(r),y(),this.setAttribute("position",new Jt(l,3)),this.setAttribute("normal",new Jt(l.slice(),3)),this.setAttribute("uv",new Jt(u,2)),o===0?this.computeVertexNormals():this.normalizeNormals();function d(P){const U=new Z,b=new Z,R=new Z;for(let N=0;N<t.length;N+=3)_(t[N+0],U),_(t[N+1],b),_(t[N+2],R),f(U,b,R,P)}function f(P,U,b,R){const N=R+1,F=[];for(let E=0;E<=N;E++){F[E]=[];const L=P.clone().lerp(b,E/N),B=U.clone().lerp(b,E/N),X=N-E;for(let j=0;j<=X;j++)j===0&&E===N?F[E][j]=L:F[E][j]=L.clone().lerp(B,j/X)}for(let E=0;E<N;E++)for(let L=0;L<2*(N-E)-1;L++){const B=Math.floor(L/2);L%2===0?(v(F[E][B+1]),v(F[E+1][B]),v(F[E][B])):(v(F[E][B+1]),v(F[E+1][B+1]),v(F[E+1][B]))}}function p(P){const U=new Z;for(let b=0;b<l.length;b+=3)U.x=l[b+0],U.y=l[b+1],U.z=l[b+2],U.normalize().multiplyScalar(P),l[b+0]=U.x,l[b+1]=U.y,l[b+2]=U.z}function y(){const P=new Z;for(let U=0;U<l.length;U+=3){P.x=l[U+0],P.y=l[U+1],P.z=l[U+2];const b=m(P)/2/Math.PI+.5,R=x(P)/Math.PI+.5;u.push(b,1-R)}M(),S()}function S(){for(let P=0;P<u.length;P+=6){const U=u[P+0],b=u[P+2],R=u[P+4],N=Math.max(U,b,R),F=Math.min(U,b,R);N>.9&&F<.1&&(U<.2&&(u[P+0]+=1),b<.2&&(u[P+2]+=1),R<.2&&(u[P+4]+=1))}}function v(P){l.push(P.x,P.y,P.z)}function _(P,U){const b=P*3;U.x=e[b+0],U.y=e[b+1],U.z=e[b+2]}function M(){const P=new Z,U=new Z,b=new Z,R=new Z,N=new dt,F=new dt,E=new dt;for(let L=0,B=0;L<l.length;L+=9,B+=6){P.set(l[L+0],l[L+1],l[L+2]),U.set(l[L+3],l[L+4],l[L+5]),b.set(l[L+6],l[L+7],l[L+8]),N.set(u[B+0],u[B+1]),F.set(u[B+2],u[B+3]),E.set(u[B+4],u[B+5]),R.copy(P).add(U).add(b).divideScalar(3);const X=m(R);A(N,B+0,P,X),A(F,B+2,U,X),A(E,B+4,b,X)}}function A(P,U,b,R){R<0&&P.x===1&&(u[U]=P.x-1),b.x===0&&b.z===0&&(u[U]=R/2/Math.PI+.5)}function m(P){return Math.atan2(P.z,-P.x)}function x(P){return Math.atan2(-P.y,Math.sqrt(P.x*P.x+P.z*P.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Dh(e.vertices,e.indices,e.radius,e.detail)}}class A1{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){ht("Curve: .getPoint() not implemented.")}getPointAt(e,t){const r=this.getUtoTmapping(e);return this.getPoint(r,t)}getPoints(e=5){const t=[];for(let r=0;r<=e;r++)t.push(this.getPoint(r/e));return t}getSpacedPoints(e=5){const t=[];for(let r=0;r<=e;r++)t.push(this.getPointAt(r/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let r,o=this.getPoint(0),l=0;t.push(0);for(let u=1;u<=e;u++)r=this.getPoint(u/e),l+=r.distanceTo(o),t.push(l),o=r;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const r=this.getLengths();let o=0;const l=r.length;let u;t?u=t:u=e*r[l-1];let d=0,f=l-1,p;for(;d<=f;)if(o=Math.floor(d+(f-d)/2),p=r[o]-u,p<0)d=o+1;else if(p>0)f=o-1;else{f=o;break}if(o=f,r[o]===u)return o/(l-1);const y=r[o],v=r[o+1]-y,_=(u-y)/v;return(o+_)/(l-1)}getTangent(e,t){let o=e-1e-4,l=e+1e-4;o<0&&(o=0),l>1&&(l=1);const u=this.getPoint(o),d=this.getPoint(l),f=t||(u.isVector2?new dt:new Z);return f.copy(d).sub(u).normalize(),f}getTangentAt(e,t){const r=this.getUtoTmapping(e);return this.getTangent(r,t)}computeFrenetFrames(e,t=!1){const r=new Z,o=[],l=[],u=[],d=new Z,f=new Yt;for(let _=0;_<=e;_++){const M=_/e;o[_]=this.getTangentAt(M,new Z)}l[0]=new Z,u[0]=new Z;let p=Number.MAX_VALUE;const y=Math.abs(o[0].x),S=Math.abs(o[0].y),v=Math.abs(o[0].z);y<=p&&(p=y,r.set(1,0,0)),S<=p&&(p=S,r.set(0,1,0)),v<=p&&r.set(0,0,1),d.crossVectors(o[0],r).normalize(),l[0].crossVectors(o[0],d),u[0].crossVectors(o[0],l[0]);for(let _=1;_<=e;_++){if(l[_]=l[_-1].clone(),u[_]=u[_-1].clone(),d.crossVectors(o[_-1],o[_]),d.length()>Number.EPSILON){d.normalize();const M=Math.acos(Pt(o[_-1].dot(o[_]),-1,1));l[_].applyMatrix4(f.makeRotationAxis(d,M))}u[_].crossVectors(o[_],l[_])}if(t===!0){let _=Math.acos(Pt(l[0].dot(l[e]),-1,1));_/=e,o[0].dot(d.crossVectors(l[0],l[e]))>0&&(_=-_);for(let M=1;M<=e;M++)l[M].applyMatrix4(f.makeRotationAxis(o[M],_*M)),u[M].crossVectors(o[M],l[M])}return{tangents:o,normals:l,binormals:u}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}function b1(s,e){const t=1-s;return t*t*t*e}function C1(s,e){const t=1-s;return 3*t*t*s*e}function R1(s,e){return 3*(1-s)*s*s*e}function P1(s,e){return s*s*s*e}function lf(s,e,t,r,o){return b1(s,e)+C1(s,t)+R1(s,r)+P1(s,o)}class e0 extends A1{constructor(e=new Z,t=new Z,r=new Z,o=new Z){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=r,this.v3=o}getPoint(e,t=new Z){const r=t,o=this.v0,l=this.v1,u=this.v2,d=this.v3;return r.set(lf(e,o.x,l.x,u.x,d.x),lf(e,o.y,l.y,u.y,d.y),lf(e,o.z,l.z,u.z,d.z)),r}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Uh extends Dh{constructor(e=1,t=0){const r=(1+Math.sqrt(5))/2,o=[-1,r,0,1,r,0,-1,-r,0,1,-r,0,0,-1,r,0,1,r,0,-1,-r,0,1,-r,r,0,-1,r,0,1,-r,0,-1,-r,0,1],l=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(o,l,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Uh(e.radius,e.detail)}}class Zc extends dn{constructor(e=1,t=1,r=1,o=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:r,heightSegments:o};const l=e/2,u=t/2,d=Math.floor(r),f=Math.floor(o),p=d+1,y=f+1,S=e/d,v=t/f,_=[],M=[],A=[],m=[];for(let x=0;x<y;x++){const P=x*v-u;for(let U=0;U<p;U++){const b=U*S-l;M.push(b,-P,0),A.push(0,0,1),m.push(U/d),m.push(1-x/f)}}for(let x=0;x<f;x++)for(let P=0;P<d;P++){const U=P+p*x,b=P+p*(x+1),R=P+1+p*(x+1),N=P+1+p*x;_.push(U,b,N),_.push(b,R,N)}this.setIndex(_),this.setAttribute("position",new Jt(M,3)),this.setAttribute("normal",new Jt(A,3)),this.setAttribute("uv",new Jt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Zc(e.width,e.height,e.widthSegments,e.heightSegments)}}class jc extends dn{constructor(e=.5,t=1,r=32,o=1,l=0,u=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:r,phiSegments:o,thetaStart:l,thetaLength:u},r=Math.max(3,r),o=Math.max(1,o);const d=[],f=[],p=[],y=[];let S=e;const v=(t-e)/o,_=new Z,M=new dt;for(let A=0;A<=o;A++){for(let m=0;m<=r;m++){const x=l+m/r*u;_.x=S*Math.cos(x),_.y=S*Math.sin(x),f.push(_.x,_.y,_.z),p.push(0,0,1),M.x=(_.x/t+1)/2,M.y=(_.y/t+1)/2,y.push(M.x,M.y)}S+=v}for(let A=0;A<o;A++){const m=A*(r+1);for(let x=0;x<r;x++){const P=x+m,U=P,b=P+r+1,R=P+r+2,N=P+1;d.push(U,b,N),d.push(b,R,N)}}this.setIndex(d),this.setAttribute("position",new Jt(f,3)),this.setAttribute("normal",new Jt(p,3)),this.setAttribute("uv",new Jt(y,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new jc(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Po extends dn{constructor(e=1,t=32,r=16,o=0,l=Math.PI*2,u=0,d=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:r,phiStart:o,phiLength:l,thetaStart:u,thetaLength:d},t=Math.max(3,Math.floor(t)),r=Math.max(2,Math.floor(r));const f=Math.min(u+d,Math.PI);let p=0;const y=[],S=new Z,v=new Z,_=[],M=[],A=[],m=[];for(let x=0;x<=r;x++){const P=[],U=x/r,b=u+U*d,R=e*Math.cos(b),N=Math.sqrt(e*e-R*R);let F=0;x===0&&u===0?F=.5/t:x===r&&f===Math.PI&&(F=-.5/t);for(let E=0;E<=t;E++){const L=E/t,B=o+L*l;S.x=-N*Math.cos(B),S.y=R,S.z=N*Math.sin(B),M.push(S.x,S.y,S.z),v.copy(S).normalize(),A.push(v.x,v.y,v.z),m.push(L+F,1-U),P.push(p++)}y.push(P)}for(let x=0;x<r;x++)for(let P=0;P<t;P++){const U=y[x][P+1],b=y[x][P],R=y[x+1][P],N=y[x+1][P+1];(x!==0||u>0)&&_.push(U,b,N),(x!==r-1||f<Math.PI)&&_.push(b,R,N)}this.setIndex(_),this.setAttribute("position",new Jt(M,3)),this.setAttribute("normal",new Jt(A,3)),this.setAttribute("uv",new Jt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Po(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Fh extends dn{constructor(e=1,t=.4,r=12,o=48,l=Math.PI*2,u=0,d=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:r,tubularSegments:o,arc:l,thetaStart:u,thetaLength:d},r=Math.floor(r),o=Math.floor(o);const f=[],p=[],y=[],S=[],v=new Z,_=new Z,M=new Z;for(let A=0;A<=r;A++){const m=u+A/r*d;for(let x=0;x<=o;x++){const P=x/o*l;_.x=(e+t*Math.cos(m))*Math.cos(P),_.y=(e+t*Math.cos(m))*Math.sin(P),_.z=t*Math.sin(m),p.push(_.x,_.y,_.z),v.x=e*Math.cos(P),v.y=e*Math.sin(P),M.subVectors(_,v).normalize(),y.push(M.x,M.y,M.z),S.push(x/o),S.push(A/r)}}for(let A=1;A<=r;A++)for(let m=1;m<=o;m++){const x=(o+1)*A+m-1,P=(o+1)*(A-1)+m-1,U=(o+1)*(A-1)+m,b=(o+1)*A+m;f.push(x,P,b),f.push(P,U,b)}this.setIndex(f),this.setAttribute("position",new Jt(p,3)),this.setAttribute("normal",new Jt(y,3)),this.setAttribute("uv",new Jt(S,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fh(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}}function Bo(s){const e={};for(const t in s){e[t]={};for(const r in s[t]){const o=s[t][r];if(t0(o))o.isRenderTargetTexture?(ht("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][r]=null):e[t][r]=o.clone();else if(Array.isArray(o))if(t0(o[0])){const l=[];for(let u=0,d=o.length;u<d;u++)l[u]=o[u].clone();e[t][r]=l}else e[t][r]=o.slice();else e[t][r]=o}}return e}function Zn(s){const e={};for(let t=0;t<s.length;t++){const r=Bo(s[t]);for(const o in r)e[o]=r[o]}return e}function t0(s){return s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)}function I1(s){const e=[];for(let t=0;t<s.length;t++)e.push(s[t].clone());return e}function Rv(s){const e=s.getRenderTarget();return e===null?s.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Dt.workingColorSpace}const L1={clone:Bo,merge:Zn};var N1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,D1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class ar extends zs{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=N1,this.fragmentShader=D1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Bo(e.uniforms),this.uniformsGroups=I1(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const o in this.uniforms){const u=this.uniforms[o].value;u&&u.isTexture?t.uniforms[o]={type:"t",value:u.toJSON(e).uuid}:u&&u.isColor?t.uniforms[o]={type:"c",value:u.getHex()}:u&&u.isVector2?t.uniforms[o]={type:"v2",value:u.toArray()}:u&&u.isVector3?t.uniforms[o]={type:"v3",value:u.toArray()}:u&&u.isVector4?t.uniforms[o]={type:"v4",value:u.toArray()}:u&&u.isMatrix3?t.uniforms[o]={type:"m3",value:u.toArray()}:u&&u.isMatrix4?t.uniforms[o]={type:"m4",value:u.toArray()}:t.uniforms[o]={value:u}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const r={};for(const o in this.extensions)this.extensions[o]===!0&&(r[o]=!0);return Object.keys(r).length>0&&(t.extensions=r),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const r in e.uniforms){const o=e.uniforms[r];switch(this.uniforms[r]={},o.type){case"t":this.uniforms[r].value=t[o.value]||null;break;case"c":this.uniforms[r].value=new vt().setHex(o.value);break;case"v2":this.uniforms[r].value=new dt().fromArray(o.value);break;case"v3":this.uniforms[r].value=new Z().fromArray(o.value);break;case"v4":this.uniforms[r].value=new an().fromArray(o.value);break;case"m3":this.uniforms[r].value=new yt().fromArray(o.value);break;case"m4":this.uniforms[r].value=new Yt().fromArray(o.value);break;default:this.uniforms[r].value=o.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const r in e.extensions)this.extensions[r]=e.extensions[r];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class U1 extends ar{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class F1 extends zs{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new vt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new vt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=oh,this.normalScale=new dt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new cs,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class O1 extends zs{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=k_,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class k1 extends zs{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Pv extends Pn{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new vt(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}const cf=new Yt,n0=new Z,i0=new Z;class B1{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new dt(512,512),this.mapType=vi,this.map=null,this.mapPass=null,this.matrix=new Yt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Lh,this._frameExtents=new dt(1,1),this._viewportCount=1,this._viewports=[new an(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;n0.setFromMatrixPosition(e.matrixWorld),t.position.copy(n0),i0.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(i0),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,r,o){cf.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),r.setFromProjectionMatrix(cf,e.coordinateSystem,e.reversedDepth);const l=this._frameExtents,u=o?o.z/l.x:1,d=o?o.w/l.y:1,f=o?o.x/l.x:0,p=o?o.y/l.y:0;e.coordinateSystem===Wa||e.reversedDepth?t.set(.5*u,0,0,.5*u+f,0,.5*d,0,.5*d+p,0,0,1,0,0,0,0,1):t.set(.5*u,0,0,.5*u+f,0,.5*d,0,.5*d+p,0,0,.5,.5,0,0,0,1),t.multiply(cf)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Sc=new Z,Mc=new ls,Qi=new Z;class Iv extends Pn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Yt,this.projectionMatrix=new Yt,this.projectionMatrixInverse=new Yt,this.coordinateSystem=ir,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Sc,Mc,Qi),Qi.x===1&&Qi.y===1&&Qi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Sc,Mc,Qi.set(1,1,1)).invert()}updateWorldMatrix(e,t,r=!1){super.updateWorldMatrix(e,t,r),this.matrixWorld.decompose(Sc,Mc,Qi),Qi.x===1&&Qi.y===1&&Qi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Sc,Mc,Qi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const rs=new Z,r0=new dt,s0=new dt;class Ai extends Iv{constructor(e=50,t=1,r=.1,o=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=r,this.far=o,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=ah*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Ic*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ah*2*Math.atan(Math.tan(Ic*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,r){rs.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(rs.x,rs.y).multiplyScalar(-e/rs.z),rs.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),r.set(rs.x,rs.y).multiplyScalar(-e/rs.z)}getViewSize(e,t){return this.getViewBounds(e,r0,s0),t.subVectors(s0,r0)}setViewOffset(e,t,r,o,l,u){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=o,this.view.width=l,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Ic*.5*this.fov)/this.zoom,r=2*t,o=this.aspect*r,l=-.5*o;const u=this.view;if(this.view!==null&&this.view.enabled){const f=u.fullWidth,p=u.fullHeight;l+=u.offsetX*o/f,t-=u.offsetY*r/p,o*=u.width/f,r*=u.height/p}const d=this.filmOffset;d!==0&&(l+=e*d/this.getFilmWidth()),this.projectionMatrix.makePerspective(l,l+o,t,t-r,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class Oh extends Iv{constructor(e=-1,t=1,r=1,o=-1,l=.1,u=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=r,this.bottom=o,this.near=l,this.far=u,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,r,o,l,u){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=o,this.view.width=l,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),r=(this.right+this.left)/2,o=(this.top+this.bottom)/2;let l=r-e,u=r+e,d=o+t,f=o-t;if(this.view!==null&&this.view.enabled){const p=(this.right-this.left)/this.view.fullWidth/this.zoom,y=(this.top-this.bottom)/this.view.fullHeight/this.zoom;l+=p*this.view.offsetX,u=l+p*this.view.width,d-=y*this.view.offsetY,f=d-y*this.view.height}this.projectionMatrix.makeOrthographic(l,u,d,f,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class z1 extends B1{constructor(){super(new Oh(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class o0 extends Pv{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Pn.DEFAULT_UP),this.updateMatrix(),this.target=new Pn,this.shadow=new z1}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class V1 extends Pv{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}const wo=-90,To=1;class H1 extends Pn{constructor(e,t,r){super(),this.type="CubeCamera",this.renderTarget=r,this.coordinateSystem=null,this.activeMipmapLevel=0;const o=new Ai(wo,To,e,t);o.layers=this.layers,this.add(o);const l=new Ai(wo,To,e,t);l.layers=this.layers,this.add(l);const u=new Ai(wo,To,e,t);u.layers=this.layers,this.add(u);const d=new Ai(wo,To,e,t);d.layers=this.layers,this.add(d);const f=new Ai(wo,To,e,t);f.layers=this.layers,this.add(f);const p=new Ai(wo,To,e,t);p.layers=this.layers,this.add(p)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[r,o,l,u,d,f]=t;for(const p of t)this.remove(p);if(e===ir)r.up.set(0,1,0),r.lookAt(1,0,0),o.up.set(0,1,0),o.lookAt(-1,0,0),l.up.set(0,0,-1),l.lookAt(0,1,0),u.up.set(0,0,1),u.lookAt(0,-1,0),d.up.set(0,1,0),d.lookAt(0,0,1),f.up.set(0,1,0),f.lookAt(0,0,-1);else if(e===Wa)r.up.set(0,-1,0),r.lookAt(-1,0,0),o.up.set(0,-1,0),o.lookAt(1,0,0),l.up.set(0,0,1),l.lookAt(0,1,0),u.up.set(0,0,-1),u.lookAt(0,-1,0),d.up.set(0,-1,0),d.lookAt(0,0,1),f.up.set(0,-1,0),f.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const p of t)this.add(p),p.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:r,activeMipmapLevel:o}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[l,u,d,f,p,y]=this.children,S=e.getRenderTarget(),v=e.getActiveCubeFace(),_=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const A=r.texture.generateMipmaps;r.texture.generateMipmaps=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(r,0,o),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(r,1,o),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,u),e.setRenderTarget(r,2,o),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,d),e.setRenderTarget(r,3,o),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,f),e.setRenderTarget(r,4,o),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,p),r.texture.generateMipmaps=A,e.setRenderTarget(r,5,o),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,y),e.setRenderTarget(S,v,_),e.xr.enabled=M,r.texture.needsPMREMUpdate=!0}}class G1 extends Ai{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const a0=new Yt;class W1{constructor(e,t,r=0,o=1/0){this.ray=new Ka(e,t),this.near=r,this.far=o,this.camera=null,this.layers=new Ph,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):zt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return a0.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(a0),this}intersectObject(e,t=!0,r=[]){return uh(e,this,r,t),r.sort(l0),r}intersectObjects(e,t=!0,r=[]){for(let o=0,l=e.length;o<l;o++)uh(e[o],this,r,t);return r.sort(l0),r}}function l0(s,e){return s.distance-e.distance}function uh(s,e,t,r){let o=!0;if(s.layers.test(e.layers)&&s.raycast(e,t)===!1&&(o=!1),o===!0&&r===!0){const l=s.children;for(let u=0,d=l.length;u<d;u++)uh(l[u],e,t,!0)}}class c0{constructor(e=1,t=0,r=0){this.radius=e,this.phi=t,this.theta=r}set(e,t,r){return this.radius=e,this.phi=t,this.theta=r,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Pt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,r){return this.radius=Math.sqrt(e*e+t*t+r*r),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,r),this.phi=Math.acos(Pt(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const Xh=class Xh{constructor(e,t,r,o){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,r,o)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let r=0;r<4;r++)this.elements[r]=e[r+t];return this}set(e,t,r,o){const l=this.elements;return l[0]=e,l[2]=t,l[1]=r,l[3]=o,this}};Xh.prototype.isMatrix2=!0;let u0=Xh;class j1 extends ds{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function d0(s,e,t,r){const o=X1(r);switch(t){case yv:return s*e;case Eh:return s*e/o.components*o.byteLength;case wh:return s*e/o.components*o.byteLength;case Fs:return s*e*2/o.components*o.byteLength;case Th:return s*e*2/o.components*o.byteLength;case _v:return s*e*3/o.components*o.byteLength;case Gi:return s*e*4/o.components*o.byteLength;case Ah:return s*e*4/o.components*o.byteLength;case bc:case Cc:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case Rc:case Pc:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case If:case Nf:return Math.max(s,16)*Math.max(e,8)/4;case Pf:case Lf:return Math.max(s,8)*Math.max(e,8)/2;case Df:case Uf:case Of:case kf:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case Ff:case kc:case Bf:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case zf:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case Vf:return Math.floor((s+4)/5)*Math.floor((e+3)/4)*16;case Hf:return Math.floor((s+4)/5)*Math.floor((e+4)/5)*16;case Gf:return Math.floor((s+5)/6)*Math.floor((e+4)/5)*16;case Wf:return Math.floor((s+5)/6)*Math.floor((e+5)/6)*16;case jf:return Math.floor((s+7)/8)*Math.floor((e+4)/5)*16;case Xf:return Math.floor((s+7)/8)*Math.floor((e+5)/6)*16;case Yf:return Math.floor((s+7)/8)*Math.floor((e+7)/8)*16;case qf:return Math.floor((s+9)/10)*Math.floor((e+4)/5)*16;case Kf:return Math.floor((s+9)/10)*Math.floor((e+5)/6)*16;case $f:return Math.floor((s+9)/10)*Math.floor((e+7)/8)*16;case Zf:return Math.floor((s+9)/10)*Math.floor((e+9)/10)*16;case Jf:return Math.floor((s+11)/12)*Math.floor((e+9)/10)*16;case Qf:return Math.floor((s+11)/12)*Math.floor((e+11)/12)*16;case eh:case th:case nh:return Math.ceil(s/4)*Math.ceil(e/4)*16;case ih:case rh:return Math.ceil(s/4)*Math.ceil(e/4)*8;case Bc:case sh:return Math.ceil(s/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function X1(s){switch(s){case vi:case mv:return{byteLength:1,components:1};case Ha:case gv:case or:return{byteLength:2,components:1};case Sh:case Mh:return{byteLength:2,components:4};case sr:case _h:case Hi:return{byteLength:4,components:1};case vv:case xv:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:xh}}));typeof window<"u"&&(window.__THREE__?ht("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=xh);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Lv(){let s=null,e=!1,t=null,r=null;function o(l,u){r=s.requestAnimationFrame(o),t(l,u)}return{start:function(){e!==!0&&t!==null&&s!==null&&(r=s.requestAnimationFrame(o),e=!0)},stop:function(){s!==null&&s.cancelAnimationFrame(r),e=!1},setAnimationLoop:function(l){t=l},setContext:function(l){s=l}}}function Y1(s){const e=new WeakMap;function t(d,f){const p=d.array,y=d.usage,S=p.byteLength,v=s.createBuffer();s.bindBuffer(f,v),s.bufferData(f,p,y),d.onUploadCallback();let _;if(p instanceof Float32Array)_=s.FLOAT;else if(typeof Float16Array<"u"&&p instanceof Float16Array)_=s.HALF_FLOAT;else if(p instanceof Uint16Array)d.isFloat16BufferAttribute?_=s.HALF_FLOAT:_=s.UNSIGNED_SHORT;else if(p instanceof Int16Array)_=s.SHORT;else if(p instanceof Uint32Array)_=s.UNSIGNED_INT;else if(p instanceof Int32Array)_=s.INT;else if(p instanceof Int8Array)_=s.BYTE;else if(p instanceof Uint8Array)_=s.UNSIGNED_BYTE;else if(p instanceof Uint8ClampedArray)_=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+p);return{buffer:v,type:_,bytesPerElement:p.BYTES_PER_ELEMENT,version:d.version,size:S}}function r(d,f,p){const y=f.array,S=f.updateRanges;if(s.bindBuffer(p,d),S.length===0)s.bufferSubData(p,0,y);else{S.sort((_,M)=>_.start-M.start);let v=0;for(let _=1;_<S.length;_++){const M=S[v],A=S[_];A.start<=M.start+M.count+1?M.count=Math.max(M.count,A.start+A.count-M.start):(++v,S[v]=A)}S.length=v+1;for(let _=0,M=S.length;_<M;_++){const A=S[_];s.bufferSubData(p,A.start*y.BYTES_PER_ELEMENT,y,A.start,A.count)}f.clearUpdateRanges()}f.onUploadCallback()}function o(d){return d.isInterleavedBufferAttribute&&(d=d.data),e.get(d)}function l(d){d.isInterleavedBufferAttribute&&(d=d.data);const f=e.get(d);f&&(s.deleteBuffer(f.buffer),e.delete(d))}function u(d,f){if(d.isInterleavedBufferAttribute&&(d=d.data),d.isGLBufferAttribute){const y=e.get(d);(!y||y.version<d.version)&&e.set(d,{buffer:d.buffer,type:d.type,bytesPerElement:d.elementSize,version:d.version});return}const p=e.get(d);if(p===void 0)e.set(d,t(d,f));else if(p.version<d.version){if(p.size!==d.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(p.buffer,d,f),p.version=d.version}}return{get:o,remove:l,update:u}}var q1=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,K1=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,$1=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Z1=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,J1=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Q1=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,eS=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,tS=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,nS=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,iS=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,rS=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,sS=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,oS=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,aS=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,lS=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,cS=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,uS=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,dS=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,fS=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,hS=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,pS=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,mS=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,gS=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,vS=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,xS=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,yS=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,_S=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,SS=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,MS=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,ES=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,wS="gl_FragColor = linearToOutputTexel( gl_FragColor );",TS=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,AS=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,bS=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,CS=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,RS=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,PS=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,IS=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,LS=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,NS=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,DS=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,US=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,FS=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,OS=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,kS=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,BS=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,zS=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,VS=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,HS=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,GS=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,WS=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,jS=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,XS=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,YS=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,qS=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,KS=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,$S=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,ZS=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,JS=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,QS=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,eM=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,tM=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,nM=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,iM=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,rM=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,sM=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,oM=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,aM=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,lM=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,cM=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,uM=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,dM=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,fM=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,hM=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,pM=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,mM=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,gM=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,vM=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,xM=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,yM=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,_M=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,SM=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,MM=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,EM=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,wM=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,TM=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,AM=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,bM=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,CM=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,RM=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,PM=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,IM=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,LM=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,NM=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,DM=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,UM=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,FM=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,OM=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,kM=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,BM=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,zM=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,VM=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,HM=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,GM=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,WM=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,jM=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,XM=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,YM=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const qM=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,KM=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$M=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ZM=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,JM=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,QM=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,eE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,tE=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,nE=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,iE=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,rE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,sE=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,oE=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,aE=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,lE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,cE=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,uE=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,dE=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,fE=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,hE=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,pE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,mE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,gE=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,vE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,yE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_E=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,SE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ME=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,EE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,wE=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,TE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,AE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,bE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ct={alphahash_fragment:q1,alphahash_pars_fragment:K1,alphamap_fragment:$1,alphamap_pars_fragment:Z1,alphatest_fragment:J1,alphatest_pars_fragment:Q1,aomap_fragment:eS,aomap_pars_fragment:tS,batching_pars_vertex:nS,batching_vertex:iS,begin_vertex:rS,beginnormal_vertex:sS,bsdfs:oS,iridescence_fragment:aS,bumpmap_pars_fragment:lS,clipping_planes_fragment:cS,clipping_planes_pars_fragment:uS,clipping_planes_pars_vertex:dS,clipping_planes_vertex:fS,color_fragment:hS,color_pars_fragment:pS,color_pars_vertex:mS,color_vertex:gS,common:vS,cube_uv_reflection_fragment:xS,defaultnormal_vertex:yS,displacementmap_pars_vertex:_S,displacementmap_vertex:SS,emissivemap_fragment:MS,emissivemap_pars_fragment:ES,colorspace_fragment:wS,colorspace_pars_fragment:TS,envmap_fragment:AS,envmap_common_pars_fragment:bS,envmap_pars_fragment:CS,envmap_pars_vertex:RS,envmap_physical_pars_fragment:zS,envmap_vertex:PS,fog_vertex:IS,fog_pars_vertex:LS,fog_fragment:NS,fog_pars_fragment:DS,gradientmap_pars_fragment:US,lightmap_pars_fragment:FS,lights_lambert_fragment:OS,lights_lambert_pars_fragment:kS,lights_pars_begin:BS,lights_toon_fragment:VS,lights_toon_pars_fragment:HS,lights_phong_fragment:GS,lights_phong_pars_fragment:WS,lights_physical_fragment:jS,lights_physical_pars_fragment:XS,lights_fragment_begin:YS,lights_fragment_maps:qS,lights_fragment_end:KS,lightprobes_pars_fragment:$S,logdepthbuf_fragment:ZS,logdepthbuf_pars_fragment:JS,logdepthbuf_pars_vertex:QS,logdepthbuf_vertex:eM,map_fragment:tM,map_pars_fragment:nM,map_particle_fragment:iM,map_particle_pars_fragment:rM,metalnessmap_fragment:sM,metalnessmap_pars_fragment:oM,morphinstance_vertex:aM,morphcolor_vertex:lM,morphnormal_vertex:cM,morphtarget_pars_vertex:uM,morphtarget_vertex:dM,normal_fragment_begin:fM,normal_fragment_maps:hM,normal_pars_fragment:pM,normal_pars_vertex:mM,normal_vertex:gM,normalmap_pars_fragment:vM,clearcoat_normal_fragment_begin:xM,clearcoat_normal_fragment_maps:yM,clearcoat_pars_fragment:_M,iridescence_pars_fragment:SM,opaque_fragment:MM,packing:EM,premultiplied_alpha_fragment:wM,project_vertex:TM,dithering_fragment:AM,dithering_pars_fragment:bM,roughnessmap_fragment:CM,roughnessmap_pars_fragment:RM,shadowmap_pars_fragment:PM,shadowmap_pars_vertex:IM,shadowmap_vertex:LM,shadowmask_pars_fragment:NM,skinbase_vertex:DM,skinning_pars_vertex:UM,skinning_vertex:FM,skinnormal_vertex:OM,specularmap_fragment:kM,specularmap_pars_fragment:BM,tonemapping_fragment:zM,tonemapping_pars_fragment:VM,transmission_fragment:HM,transmission_pars_fragment:GM,uv_pars_fragment:WM,uv_pars_vertex:jM,uv_vertex:XM,worldpos_vertex:YM,background_vert:qM,background_frag:KM,backgroundCube_vert:$M,backgroundCube_frag:ZM,cube_vert:JM,cube_frag:QM,depth_vert:eE,depth_frag:tE,distance_vert:nE,distance_frag:iE,equirect_vert:rE,equirect_frag:sE,linedashed_vert:oE,linedashed_frag:aE,meshbasic_vert:lE,meshbasic_frag:cE,meshlambert_vert:uE,meshlambert_frag:dE,meshmatcap_vert:fE,meshmatcap_frag:hE,meshnormal_vert:pE,meshnormal_frag:mE,meshphong_vert:gE,meshphong_frag:vE,meshphysical_vert:xE,meshphysical_frag:yE,meshtoon_vert:_E,meshtoon_frag:SE,points_vert:ME,points_frag:EE,shadow_vert:wE,shadow_frag:TE,sprite_vert:AE,sprite_frag:bE},Ke={common:{diffuse:{value:new vt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new yt},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new yt}},envmap:{envMap:{value:null},envMapRotation:{value:new yt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new yt},normalScale:{value:new dt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new vt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new Z},probesMax:{value:new Z},probesResolution:{value:new Z}},points:{diffuse:{value:new vt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0},uvTransform:{value:new yt}},sprite:{diffuse:{value:new vt(16777215)},opacity:{value:1},center:{value:new dt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new yt},alphaMap:{value:null},alphaMapTransform:{value:new yt},alphaTest:{value:0}}},nr={basic:{uniforms:Zn([Ke.common,Ke.specularmap,Ke.envmap,Ke.aomap,Ke.lightmap,Ke.fog]),vertexShader:Ct.meshbasic_vert,fragmentShader:Ct.meshbasic_frag},lambert:{uniforms:Zn([Ke.common,Ke.specularmap,Ke.envmap,Ke.aomap,Ke.lightmap,Ke.emissivemap,Ke.bumpmap,Ke.normalmap,Ke.displacementmap,Ke.fog,Ke.lights,{emissive:{value:new vt(0)},envMapIntensity:{value:1}}]),vertexShader:Ct.meshlambert_vert,fragmentShader:Ct.meshlambert_frag},phong:{uniforms:Zn([Ke.common,Ke.specularmap,Ke.envmap,Ke.aomap,Ke.lightmap,Ke.emissivemap,Ke.bumpmap,Ke.normalmap,Ke.displacementmap,Ke.fog,Ke.lights,{emissive:{value:new vt(0)},specular:{value:new vt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Ct.meshphong_vert,fragmentShader:Ct.meshphong_frag},standard:{uniforms:Zn([Ke.common,Ke.envmap,Ke.aomap,Ke.lightmap,Ke.emissivemap,Ke.bumpmap,Ke.normalmap,Ke.displacementmap,Ke.roughnessmap,Ke.metalnessmap,Ke.fog,Ke.lights,{emissive:{value:new vt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ct.meshphysical_vert,fragmentShader:Ct.meshphysical_frag},toon:{uniforms:Zn([Ke.common,Ke.aomap,Ke.lightmap,Ke.emissivemap,Ke.bumpmap,Ke.normalmap,Ke.displacementmap,Ke.gradientmap,Ke.fog,Ke.lights,{emissive:{value:new vt(0)}}]),vertexShader:Ct.meshtoon_vert,fragmentShader:Ct.meshtoon_frag},matcap:{uniforms:Zn([Ke.common,Ke.bumpmap,Ke.normalmap,Ke.displacementmap,Ke.fog,{matcap:{value:null}}]),vertexShader:Ct.meshmatcap_vert,fragmentShader:Ct.meshmatcap_frag},points:{uniforms:Zn([Ke.points,Ke.fog]),vertexShader:Ct.points_vert,fragmentShader:Ct.points_frag},dashed:{uniforms:Zn([Ke.common,Ke.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ct.linedashed_vert,fragmentShader:Ct.linedashed_frag},depth:{uniforms:Zn([Ke.common,Ke.displacementmap]),vertexShader:Ct.depth_vert,fragmentShader:Ct.depth_frag},normal:{uniforms:Zn([Ke.common,Ke.bumpmap,Ke.normalmap,Ke.displacementmap,{opacity:{value:1}}]),vertexShader:Ct.meshnormal_vert,fragmentShader:Ct.meshnormal_frag},sprite:{uniforms:Zn([Ke.sprite,Ke.fog]),vertexShader:Ct.sprite_vert,fragmentShader:Ct.sprite_frag},background:{uniforms:{uvTransform:{value:new yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ct.background_vert,fragmentShader:Ct.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new yt}},vertexShader:Ct.backgroundCube_vert,fragmentShader:Ct.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ct.cube_vert,fragmentShader:Ct.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ct.equirect_vert,fragmentShader:Ct.equirect_frag},distance:{uniforms:Zn([Ke.common,Ke.displacementmap,{referencePosition:{value:new Z},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ct.distance_vert,fragmentShader:Ct.distance_frag},shadow:{uniforms:Zn([Ke.lights,Ke.fog,{color:{value:new vt(0)},opacity:{value:1}}]),vertexShader:Ct.shadow_vert,fragmentShader:Ct.shadow_frag}};nr.physical={uniforms:Zn([nr.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new yt},clearcoatNormalScale:{value:new dt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new yt},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new yt},sheen:{value:0},sheenColor:{value:new vt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new yt},transmissionSamplerSize:{value:new dt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new yt},attenuationDistance:{value:0},attenuationColor:{value:new vt(0)},specularColor:{value:new vt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new yt},anisotropyVector:{value:new dt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new yt}}]),vertexShader:Ct.meshphysical_vert,fragmentShader:Ct.meshphysical_frag};const Ec={r:0,b:0,g:0},CE=new Yt,Nv=new yt;Nv.set(-1,0,0,0,1,0,0,0,1);function RE(s,e,t,r,o,l){const u=new vt(0);let d=o===!0?0:1,f,p,y=null,S=0,v=null;function _(P){let U=P.isScene===!0?P.background:null;if(U&&U.isTexture){const b=P.backgroundBlurriness>0;U=e.get(U,b)}return U}function M(P){let U=!1;const b=_(P);b===null?m(u,d):b&&b.isColor&&(m(b,1),U=!0);const R=s.xr.getEnvironmentBlendMode();R==="additive"?t.buffers.color.setClear(0,0,0,1,l):R==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,l),(s.autoClear||U)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function A(P,U){const b=_(U);b&&(b.isCubeTexture||b.mapping===$c)?(p===void 0&&(p=new Sn(new $a(1,1,1),new ar({name:"BackgroundCubeMaterial",uniforms:Bo(nr.backgroundCube.uniforms),vertexShader:nr.backgroundCube.vertexShader,fragmentShader:nr.backgroundCube.fragmentShader,side:Jn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(R,N,F){this.matrixWorld.copyPosition(F.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(p)),p.material.uniforms.envMap.value=b,p.material.uniforms.backgroundBlurriness.value=U.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=U.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(CE.makeRotationFromEuler(U.backgroundRotation)).transpose(),b.isCubeTexture&&b.isRenderTargetTexture===!1&&p.material.uniforms.backgroundRotation.value.premultiply(Nv),p.material.toneMapped=Dt.getTransfer(b.colorSpace)!==qt,(y!==b||S!==b.version||v!==s.toneMapping)&&(p.material.needsUpdate=!0,y=b,S=b.version,v=s.toneMapping),p.layers.enableAll(),P.unshift(p,p.geometry,p.material,0,0,null)):b&&b.isTexture&&(f===void 0&&(f=new Sn(new Zc(2,2),new ar({name:"BackgroundMaterial",uniforms:Bo(nr.background.uniforms),vertexShader:nr.background.vertexShader,fragmentShader:nr.background.fragmentShader,side:Ds,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),f.geometry.deleteAttribute("normal"),Object.defineProperty(f.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(f)),f.material.uniforms.t2D.value=b,f.material.uniforms.backgroundIntensity.value=U.backgroundIntensity,f.material.toneMapped=Dt.getTransfer(b.colorSpace)!==qt,b.matrixAutoUpdate===!0&&b.updateMatrix(),f.material.uniforms.uvTransform.value.copy(b.matrix),(y!==b||S!==b.version||v!==s.toneMapping)&&(f.material.needsUpdate=!0,y=b,S=b.version,v=s.toneMapping),f.layers.enableAll(),P.unshift(f,f.geometry,f.material,0,0,null))}function m(P,U){P.getRGB(Ec,Rv(s)),t.buffers.color.setClear(Ec.r,Ec.g,Ec.b,U,l)}function x(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),f!==void 0&&(f.geometry.dispose(),f.material.dispose(),f=void 0)}return{getClearColor:function(){return u},setClearColor:function(P,U=1){u.set(P),d=U,m(u,d)},getClearAlpha:function(){return d},setClearAlpha:function(P){d=P,m(u,d)},render:M,addToRenderList:A,dispose:x}}function PE(s,e){const t=s.getParameter(s.MAX_VERTEX_ATTRIBS),r={},o=v(null);let l=o,u=!1;function d(X,j,ne,H,W){let ue=!1;const Q=S(X,H,ne,j);l!==Q&&(l=Q,p(l.object)),ue=_(X,H,ne,W),ue&&M(X,H,ne,W),W!==null&&e.update(W,s.ELEMENT_ARRAY_BUFFER),(ue||u)&&(u=!1,b(X,j,ne,H),W!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,e.get(W).buffer))}function f(){return s.createVertexArray()}function p(X){return s.bindVertexArray(X)}function y(X){return s.deleteVertexArray(X)}function S(X,j,ne,H){const W=H.wireframe===!0;let ue=r[j.id];ue===void 0&&(ue={},r[j.id]=ue);const Q=X.isInstancedMesh===!0?X.id:0;let te=ue[Q];te===void 0&&(te={},ue[Q]=te);let G=te[ne.id];G===void 0&&(G={},te[ne.id]=G);let ee=G[W];return ee===void 0&&(ee=v(f()),G[W]=ee),ee}function v(X){const j=[],ne=[],H=[];for(let W=0;W<t;W++)j[W]=0,ne[W]=0,H[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:j,enabledAttributes:ne,attributeDivisors:H,object:X,attributes:{},index:null}}function _(X,j,ne,H){const W=l.attributes,ue=j.attributes;let Q=0;const te=ne.getAttributes();for(const G in te)if(te[G].location>=0){const O=W[G];let de=ue[G];if(de===void 0&&(G==="instanceMatrix"&&X.instanceMatrix&&(de=X.instanceMatrix),G==="instanceColor"&&X.instanceColor&&(de=X.instanceColor)),O===void 0||O.attribute!==de||de&&O.data!==de.data)return!0;Q++}return l.attributesNum!==Q||l.index!==H}function M(X,j,ne,H){const W={},ue=j.attributes;let Q=0;const te=ne.getAttributes();for(const G in te)if(te[G].location>=0){let O=ue[G];O===void 0&&(G==="instanceMatrix"&&X.instanceMatrix&&(O=X.instanceMatrix),G==="instanceColor"&&X.instanceColor&&(O=X.instanceColor));const de={};de.attribute=O,O&&O.data&&(de.data=O.data),W[G]=de,Q++}l.attributes=W,l.attributesNum=Q,l.index=H}function A(){const X=l.newAttributes;for(let j=0,ne=X.length;j<ne;j++)X[j]=0}function m(X){x(X,0)}function x(X,j){const ne=l.newAttributes,H=l.enabledAttributes,W=l.attributeDivisors;ne[X]=1,H[X]===0&&(s.enableVertexAttribArray(X),H[X]=1),W[X]!==j&&(s.vertexAttribDivisor(X,j),W[X]=j)}function P(){const X=l.newAttributes,j=l.enabledAttributes;for(let ne=0,H=j.length;ne<H;ne++)j[ne]!==X[ne]&&(s.disableVertexAttribArray(ne),j[ne]=0)}function U(X,j,ne,H,W,ue,Q){Q===!0?s.vertexAttribIPointer(X,j,ne,W,ue):s.vertexAttribPointer(X,j,ne,H,W,ue)}function b(X,j,ne,H){A();const W=H.attributes,ue=ne.getAttributes(),Q=j.defaultAttributeValues;for(const te in ue){const G=ue[te];if(G.location>=0){let ee=W[te];if(ee===void 0&&(te==="instanceMatrix"&&X.instanceMatrix&&(ee=X.instanceMatrix),te==="instanceColor"&&X.instanceColor&&(ee=X.instanceColor)),ee!==void 0){const O=ee.normalized,de=ee.itemSize,Ce=e.get(ee);if(Ce===void 0)continue;const Te=Ce.buffer,De=Ce.type,Ye=Ce.bytesPerElement,le=De===s.INT||De===s.UNSIGNED_INT||ee.gpuType===_h;if(ee.isInterleavedBufferAttribute){const ge=ee.data,Ne=ge.stride,tt=ee.offset;if(ge.isInstancedInterleavedBuffer){for(let Xe=0;Xe<G.locationSize;Xe++)x(G.location+Xe,ge.meshPerAttribute);X.isInstancedMesh!==!0&&H._maxInstanceCount===void 0&&(H._maxInstanceCount=ge.meshPerAttribute*ge.count)}else for(let Xe=0;Xe<G.locationSize;Xe++)m(G.location+Xe);s.bindBuffer(s.ARRAY_BUFFER,Te);for(let Xe=0;Xe<G.locationSize;Xe++)U(G.location+Xe,de/G.locationSize,De,O,Ne*Ye,(tt+de/G.locationSize*Xe)*Ye,le)}else{if(ee.isInstancedBufferAttribute){for(let ge=0;ge<G.locationSize;ge++)x(G.location+ge,ee.meshPerAttribute);X.isInstancedMesh!==!0&&H._maxInstanceCount===void 0&&(H._maxInstanceCount=ee.meshPerAttribute*ee.count)}else for(let ge=0;ge<G.locationSize;ge++)m(G.location+ge);s.bindBuffer(s.ARRAY_BUFFER,Te);for(let ge=0;ge<G.locationSize;ge++)U(G.location+ge,de/G.locationSize,De,O,de*Ye,de/G.locationSize*ge*Ye,le)}}else if(Q!==void 0){const O=Q[te];if(O!==void 0)switch(O.length){case 2:s.vertexAttrib2fv(G.location,O);break;case 3:s.vertexAttrib3fv(G.location,O);break;case 4:s.vertexAttrib4fv(G.location,O);break;default:s.vertexAttrib1fv(G.location,O)}}}}P()}function R(){L();for(const X in r){const j=r[X];for(const ne in j){const H=j[ne];for(const W in H){const ue=H[W];for(const Q in ue)y(ue[Q].object),delete ue[Q];delete H[W]}}delete r[X]}}function N(X){if(r[X.id]===void 0)return;const j=r[X.id];for(const ne in j){const H=j[ne];for(const W in H){const ue=H[W];for(const Q in ue)y(ue[Q].object),delete ue[Q];delete H[W]}}delete r[X.id]}function F(X){for(const j in r){const ne=r[j];for(const H in ne){const W=ne[H];if(W[X.id]===void 0)continue;const ue=W[X.id];for(const Q in ue)y(ue[Q].object),delete ue[Q];delete W[X.id]}}}function E(X){for(const j in r){const ne=r[j],H=X.isInstancedMesh===!0?X.id:0,W=ne[H];if(W!==void 0){for(const ue in W){const Q=W[ue];for(const te in Q)y(Q[te].object),delete Q[te];delete W[ue]}delete ne[H],Object.keys(ne).length===0&&delete r[j]}}}function L(){B(),u=!0,l!==o&&(l=o,p(l.object))}function B(){o.geometry=null,o.program=null,o.wireframe=!1}return{setup:d,reset:L,resetDefaultState:B,dispose:R,releaseStatesOfGeometry:N,releaseStatesOfObject:E,releaseStatesOfProgram:F,initAttributes:A,enableAttribute:m,disableUnusedAttributes:P}}function IE(s,e,t){let r;function o(f){r=f}function l(f,p){s.drawArrays(r,f,p),t.update(p,r,1)}function u(f,p,y){y!==0&&(s.drawArraysInstanced(r,f,p,y),t.update(p,r,y))}function d(f,p,y){if(y===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r,f,0,p,0,y);let v=0;for(let _=0;_<y;_++)v+=p[_];t.update(v,r,1)}this.setMode=o,this.render=l,this.renderInstances=u,this.renderMultiDraw=d}function LE(s,e,t,r){let o;function l(){if(o!==void 0)return o;if(e.has("EXT_texture_filter_anisotropic")===!0){const F=e.get("EXT_texture_filter_anisotropic");o=s.getParameter(F.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else o=0;return o}function u(F){return!(F!==Gi&&r.convert(F)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function d(F){const E=F===or&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(F!==vi&&F!==Hi&&!E&&r.convert(F)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE))}function f(F){if(F==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";F="mediump"}return F==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let p=t.precision!==void 0?t.precision:"highp";const y=f(p);y!==p&&(ht("WebGLRenderer:",p,"not supported, using",y,"instead."),p=y);const S=t.logarithmicDepthBuffer===!0,v=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&v===!1&&ht("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const _=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),M=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),A=s.getParameter(s.MAX_TEXTURE_SIZE),m=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),x=s.getParameter(s.MAX_VERTEX_ATTRIBS),P=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),U=s.getParameter(s.MAX_VARYING_VECTORS),b=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),R=s.getParameter(s.MAX_SAMPLES),N=s.getParameter(s.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:l,getMaxPrecision:f,textureFormatReadable:u,textureTypeReadable:d,precision:p,logarithmicDepthBuffer:S,reversedDepthBuffer:v,maxTextures:_,maxVertexTextures:M,maxTextureSize:A,maxCubemapSize:m,maxAttributes:x,maxVertexUniforms:P,maxVaryings:U,maxFragmentUniforms:b,maxSamples:R,samples:N}}function NE(s){const e=this;let t=null,r=0,o=!1,l=!1;const u=new Tr,d=new yt,f={value:null,needsUpdate:!1};this.uniform=f,this.numPlanes=0,this.numIntersection=0,this.init=function(S,v){const _=S.length!==0||v||r!==0||o;return o=v,r=S.length,_},this.beginShadows=function(){l=!0,y(null)},this.endShadows=function(){l=!1},this.setGlobalState=function(S,v){t=y(S,v,0)},this.setState=function(S,v,_){const M=S.clippingPlanes,A=S.clipIntersection,m=S.clipShadows,x=s.get(S);if(!o||M===null||M.length===0||l&&!m)l?y(null):p();else{const P=l?0:r,U=P*4;let b=x.clippingState||null;f.value=b,b=y(M,v,U,_);for(let R=0;R!==U;++R)b[R]=t[R];x.clippingState=b,this.numIntersection=A?this.numPlanes:0,this.numPlanes+=P}};function p(){f.value!==t&&(f.value=t,f.needsUpdate=r>0),e.numPlanes=r,e.numIntersection=0}function y(S,v,_,M){const A=S!==null?S.length:0;let m=null;if(A!==0){if(m=f.value,M!==!0||m===null){const x=_+A*4,P=v.matrixWorldInverse;d.getNormalMatrix(P),(m===null||m.length<x)&&(m=new Float32Array(x));for(let U=0,b=_;U!==A;++U,b+=4)u.copy(S[U]).applyMatrix4(P,d),u.normal.toArray(m,b),m[b+3]=u.constant}f.value=m,f.needsUpdate=!0}return e.numPlanes=A,e.numIntersection=0,m}}const Io=4,DE=6,UE=20,FE=256,Pa=new Oh,f0=new vt;let uf=null,df=0,ff=0,hf=!1;const OE=new Z,Cs=new Z;class h0{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,r=.1,o=100,l={}){const{size:u=256,position:d=OE}=l;uf=this._renderer.getRenderTarget(),df=this._renderer.getActiveCubeFace(),ff=this._renderer.getActiveMipmapLevel(),hf=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(u);const f=this._allocateTargets();return f.depthBuffer=!0,this._sceneToCubeUV(e,r,o,f,d),t>0&&this._blur(f,0,0,t),this._applyPMREM(f),this._cleanup(f),f}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=g0(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=m0(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(uf,df,ff),this._renderer.xr.enabled=hf,e.scissorTest=!1,Ao(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Us||e.mapping===ko?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),uf=this._renderer.getRenderTarget(),df=this._renderer.getActiveCubeFace(),ff=this._renderer.getActiveMipmapLevel(),hf=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const r=t||this._allocateTargets();return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,r={magFilter:Yn,minFilter:Yn,generateMipmaps:!1,type:or,format:Gi,colorSpace:zc,depthBuffer:!1},o=p0(e,t,r);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=p0(e,t,r);const{_lodMax:l}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=kE(l)),this._blurMaterial=zE(l,e,t),this._ggxMaterial=BE(l,e,t)}return o}_compileMaterial(e){const t=new Sn(new dn,e);this._renderer.compile(t,Pa)}_sceneToCubeUV(e,t,r,o,l){const f=new Ai(90,1,t,r),p=[1,-1,1,1,1,1],y=[1,1,1,-1,-1,-1],S=this._renderer,v=S.autoClear,_=S.toneMapping;S.getClearColor(f0),S.toneMapping=rr,S.autoClear=!1,S.state.buffers.depth.getReversed()&&(S.setRenderTarget(o),S.clearDepth(),S.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Sn(new $a,new tr({name:"PMREM.Background",side:Jn,depthWrite:!1,depthTest:!1})));const A=this._backgroundBox,m=A.material;let x=!1;const P=e.background;P?P.isColor&&(m.color.copy(P),e.background=null,x=!0):(m.color.copy(f0),x=!0);for(let U=0;U<6;U++){const b=U%3;b===0?(f.up.set(0,p[U],0),f.position.set(l.x,l.y,l.z),f.lookAt(l.x+y[U],l.y,l.z)):b===1?(f.up.set(0,0,p[U]),f.position.set(l.x,l.y,l.z),f.lookAt(l.x,l.y+y[U],l.z)):(f.up.set(0,p[U],0),f.position.set(l.x,l.y,l.z),f.lookAt(l.x,l.y,l.z+y[U]));const R=this._cubeSize;Ao(o,b*R,U>2?R:0,R,R),S.setRenderTarget(o),x&&S.render(A,f),S.render(e,f)}S.toneMapping=_,S.autoClear=v,e.background=P}_textureToCubeUV(e,t){const r=this._renderer,o=e.mapping===Us||e.mapping===ko;o?(this._cubemapMaterial===null&&(this._cubemapMaterial=g0()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=m0());const l=o?this._cubemapMaterial:this._equirectMaterial,u=this._lodMeshes[0];u.material=l;const d=l.uniforms;d.envMap.value=e;const f=this._cubeSize;Ao(t,0,0,3*f,2*f),r.setRenderTarget(t),r.render(u,Pa)}_applyPMREM(e){const t=this._renderer,r=t.autoClear;t.autoClear=!1;const o=this._lodMeshes.length;for(let l=1;l<o;l++)this._applyGGXFilter(e,l-1,l);t.autoClear=r}_applyGGXFilter(e,t,r){const o=this._renderer,l=this._pingPongRenderTarget,u=this._ggxMaterial,d=this._lodMeshes[r];d.material=u;const f=u.uniforms,p=r/(this._lodMeshes.length-1),y=t/(this._lodMeshes.length-1),S=Math.sqrt(p*p-y*y),v=p*1.25,_=S*v,{_lodMax:M}=this,A=this._sizeLods[r],m=3*A*(r>M-Io?r-M+Io:0),x=4*(this._cubeSize-A);f.envMap.value=e.texture,f.roughness.value=_,f.mipInt.value=M-t,Ao(l,m,x,3*A,2*A),o.setRenderTarget(l),o.render(d,Pa),f.envMap.value=l.texture,f.roughness.value=0,f.mipInt.value=M-r,Ao(e,m,x,3*A,2*A),o.setRenderTarget(e),o.render(d,Pa)}_blur(e,t,r,o){const l=this._pingPongRenderTarget,u=Math.min(o,Math.PI)/Math.SQRT2;this._blurPass(e,l,t,r,u),this._blurPass(l,e,r,r,u)}_blurPass(e,t,r,o,l){const u=this._renderer,d=this._blurMaterial,f=this._lodMeshes[o];f.material=d;const p=d.uniforms;p.envMap.value=e.texture,p.sigma.value=l,p.mipInt.value=this._lodMax-r;const y=this._sizeLods[o],S=3*y*(o>this._lodMax-Io?o-this._lodMax+Io:0),v=4*(this._cubeSize-y);Ao(t,S,v,3*y,2*y),u.setRenderTarget(t),u.render(f,Pa)}}function kE(s){const e=[],t=[];let r=s;const o=s-Io+1+DE;for(let l=0;l<o;l++){const u=Math.pow(2,r);e.push(u);const d=1/(u-2),f=-d,p=1+d,y=[f,f,p,f,p,p,f,f,p,p,f,p],S=6,v=6,_=3,M=new Float32Array(_*v*S),A=new Float32Array(_*v*S);for(let x=0;x<S;x++){const P=x%3*2/3-1,U=x>2?0:-1,b=[P,U,0,P+2/3,U,0,P+2/3,U+1,0,P,U,0,P+2/3,U+1,0,P,U+1,0];M.set(b,_*v*x);for(let R=0;R<v;R++){const N=y[R*2]*2-1,F=y[R*2+1]*2-1;x===0?Cs.set(1,F,N):x===1?Cs.set(-N,1,-F):x===2?Cs.set(-N,F,1):x===3?Cs.set(-1,F,-N):x===4?Cs.set(-N,-1,F):Cs.set(N,F,-1),Cs.toArray(A,(x*v+R)*_)}}const m=new dn;m.setAttribute("position",new jn(M,_)),m.setAttribute("outputDirection",new jn(A,_)),t.push(new Sn(m,null)),r>Io&&r--}return{lodMeshes:t,sizeLods:e}}function p0(s,e,t){const r=new Wi(s,e,t);return r.texture.mapping=$c,r.texture.name="PMREM.cubeUv",r.scissorTest=!0,r}function Ao(s,e,t,r,o){s.viewport.set(e,t,r,o),s.scissor.set(e,t,r,o)}function BE(s,e,t){return new ar({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:FE,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Jc(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Cr,depthTest:!1,depthWrite:!1})}function zE(s,e,t){return new ar({name:"SphericalGaussianBlur",defines:{SAMPLES:UE,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:Jc(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:Cr,depthTest:!1,depthWrite:!1})}function m0(){return new ar({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Cr,depthTest:!1,depthWrite:!1})}function g0(){return new ar({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Cr,depthTest:!1,depthWrite:!1})}function Jc(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}class Dv extends Wi{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const r={width:e,height:e,depth:1},o=[r,r,r,r,r,r];this.texture=new bv(o),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},o=new $a(5,5,5),l=new ar({name:"CubemapFromEquirect",uniforms:Bo(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:Jn,blending:Cr});l.uniforms.tEquirect.value=t;const u=new Sn(o,l),d=t.minFilter;return t.minFilter===Is&&(t.minFilter=Yn),new H1(1,10,this).update(e,u),t.minFilter=d,u.geometry.dispose(),u.material.dispose(),this}clear(e,t=!0,r=!0,o=!0){const l=e.getRenderTarget();for(let u=0;u<6;u++)e.setRenderTarget(this,u),e.clear(t,r,o);e.setRenderTarget(l)}}function VE(s){let e=new WeakMap,t=new WeakMap,r=null;function o(v,_=!1){return v==null?null:_?u(v):l(v)}function l(v){if(v&&v.isTexture){const _=v.mapping;if(_===Dd||_===Ud)if(e.has(v)){const M=e.get(v).texture;return d(M,v.mapping)}else{const M=v.image;if(M&&M.height>0){const A=new Dv(M.height);return A.fromEquirectangularTexture(s,v),e.set(v,A),v.addEventListener("dispose",p),d(A.texture,v.mapping)}else return null}}return v}function u(v){if(v&&v.isTexture){const _=v.mapping,M=_===Dd||_===Ud,A=_===Us||_===ko;if(M||A){let m=t.get(v);const x=m!==void 0?m.texture.pmremVersion:0;if(v.isRenderTargetTexture&&v.pmremVersion!==x)return r===null&&(r=new h0(s)),m=M?r.fromEquirectangular(v,m):r.fromCubemap(v,m),m.texture.pmremVersion=v.pmremVersion,t.set(v,m),m.texture;if(m!==void 0)return m.texture;{const P=v.image;return M&&P&&P.height>0||A&&P&&f(P)?(r===null&&(r=new h0(s)),m=M?r.fromEquirectangular(v):r.fromCubemap(v),m.texture.pmremVersion=v.pmremVersion,t.set(v,m),v.addEventListener("dispose",y),m.texture):null}}}return v}function d(v,_){return _===Dd?v.mapping=Us:_===Ud&&(v.mapping=ko),v}function f(v){let _=0;const M=6;for(let A=0;A<M;A++)v[A]!==void 0&&_++;return _===M}function p(v){const _=v.target;_.removeEventListener("dispose",p);const M=e.get(_);M!==void 0&&(e.delete(_),M.dispose())}function y(v){const _=v.target;_.removeEventListener("dispose",y);const M=t.get(_);M!==void 0&&(t.delete(_),M.dispose())}function S(){e=new WeakMap,t=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:o,dispose:S}}function HE(s){const e={};function t(r){if(e[r]!==void 0)return e[r];const o=s.getExtension(r);return e[r]=o,o}return{has:function(r){return t(r)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(r){const o=t(r);return o===null&&Uo("WebGLRenderer: "+r+" extension not supported."),o}}}function GE(s,e,t,r){const o={},l=new WeakMap;function u(S){const v=S.target;v.index!==null&&e.remove(v.index);for(const M in v.attributes)e.remove(v.attributes[M]);v.removeEventListener("dispose",u),delete o[v.id];const _=l.get(v);_&&(e.remove(_),l.delete(v)),r.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,t.memory.geometries--}function d(S,v){return o[v.id]===!0||(v.addEventListener("dispose",u),o[v.id]=!0,t.memory.geometries++),v}function f(S){const v=S.attributes;for(const _ in v)e.update(v[_],s.ARRAY_BUFFER)}function p(S){const v=[],_=S.index,M=S.attributes.position;let A=0;if(M===void 0)return;if(_!==null){const P=_.array;A=_.version;for(let U=0,b=P.length;U<b;U+=3){const R=P[U+0],N=P[U+1],F=P[U+2];v.push(R,N,N,F,F,R)}}else{const P=M.array;A=M.version;for(let U=0,b=P.length/3-1;U<b;U+=3){const R=U+0,N=U+1,F=U+2;v.push(R,N,N,F,F,R)}}const m=new(M.count>=65535?Tv:wv)(v,1);m.version=A;const x=l.get(S);x&&e.remove(x),l.set(S,m)}function y(S){const v=l.get(S);if(v){const _=S.index;_!==null&&v.version<_.version&&p(S)}else p(S);return l.get(S)}return{get:d,update:f,getWireframeAttribute:y}}function WE(s,e,t){let r;function o(S){r=S}let l,u;function d(S){l=S.type,u=S.bytesPerElement}function f(S,v){s.drawElements(r,v,l,S*u),t.update(v,r,1)}function p(S,v,_){_!==0&&(s.drawElementsInstanced(r,v,l,S*u,_),t.update(v,r,_))}function y(S,v,_){if(_===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r,v,0,l,S,0,_);let A=0;for(let m=0;m<_;m++)A+=v[m];t.update(A,r,1)}this.setMode=o,this.setIndex=d,this.render=f,this.renderInstances=p,this.renderMultiDraw=y}function jE(s){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function r(l,u,d){switch(t.calls++,u){case s.TRIANGLES:t.triangles+=d*(l/3);break;case s.LINES:t.lines+=d*(l/2);break;case s.LINE_STRIP:t.lines+=d*(l-1);break;case s.LINE_LOOP:t.lines+=d*l;break;case s.POINTS:t.points+=d*l;break;default:zt("WebGLInfo: Unknown draw mode:",u);break}}function o(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:o,update:r}}function XE(s,e,t){const r=new WeakMap,o=new an;function l(u,d,f){const p=u.morphTargetInfluences,y=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,S=y!==void 0?y.length:0;let v=r.get(d);if(v===void 0||v.count!==S){let B=function(){E.dispose(),r.delete(d),d.removeEventListener("dispose",B)};var _=B;v!==void 0&&v.texture.dispose();const M=d.morphAttributes.position!==void 0,A=d.morphAttributes.normal!==void 0,m=d.morphAttributes.color!==void 0,x=d.morphAttributes.position||[],P=d.morphAttributes.normal||[],U=d.morphAttributes.color||[];let b=0;M===!0&&(b=1),A===!0&&(b=2),m===!0&&(b=3);let R=d.attributes.position.count*b,N=1;R>e.maxTextureSize&&(N=Math.ceil(R/e.maxTextureSize),R=e.maxTextureSize);const F=new Float32Array(R*N*4*S),E=new Mv(F,R,N,S);E.type=Hi,E.needsUpdate=!0;const L=b*4;for(let X=0;X<S;X++){const j=x[X],ne=P[X],H=U[X],W=R*N*4*X;for(let ue=0;ue<j.count;ue++){const Q=ue*L;M===!0&&(o.fromBufferAttribute(j,ue),F[W+Q+0]=o.x,F[W+Q+1]=o.y,F[W+Q+2]=o.z,F[W+Q+3]=0),A===!0&&(o.fromBufferAttribute(ne,ue),F[W+Q+4]=o.x,F[W+Q+5]=o.y,F[W+Q+6]=o.z,F[W+Q+7]=0),m===!0&&(o.fromBufferAttribute(H,ue),F[W+Q+8]=o.x,F[W+Q+9]=o.y,F[W+Q+10]=o.z,F[W+Q+11]=H.itemSize===4?o.w:1)}}v={count:S,texture:E,size:new dt(R,N)},r.set(d,v),d.addEventListener("dispose",B)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)f.getUniforms().setValue(s,"morphTexture",u.morphTexture,t);else{let M=0;for(let m=0;m<p.length;m++)M+=p[m];const A=d.morphTargetsRelative?1:1-M;f.getUniforms().setValue(s,"morphTargetBaseInfluence",A),f.getUniforms().setValue(s,"morphTargetInfluences",p)}f.getUniforms().setValue(s,"morphTargetsTexture",v.texture,t),f.getUniforms().setValue(s,"morphTargetsTextureSize",v.size)}return{update:l}}function YE(s,e,t,r,o){let l=new WeakMap;function u(p){const y=o.render.frame,S=p.geometry,v=e.get(p,S);if(l.get(v)!==y&&(e.update(v),l.set(v,y)),p.isInstancedMesh&&(p.hasEventListener("dispose",f)===!1&&p.addEventListener("dispose",f),l.get(p)!==y&&(t.update(p.instanceMatrix,s.ARRAY_BUFFER),p.instanceColor!==null&&t.update(p.instanceColor,s.ARRAY_BUFFER),l.set(p,y))),p.isSkinnedMesh){const _=p.skeleton;l.get(_)!==y&&(_.update(),l.set(_,y))}return v}function d(){l=new WeakMap}function f(p){const y=p.target;y.removeEventListener("dispose",f),r.releaseStatesOfObject(y),t.remove(y.instanceMatrix),y.instanceColor!==null&&t.remove(y.instanceColor)}return{update:u,dispose:d}}const qE={[lv]:"LINEAR_TONE_MAPPING",[cv]:"REINHARD_TONE_MAPPING",[uv]:"CINEON_TONE_MAPPING",[yh]:"ACES_FILMIC_TONE_MAPPING",[fv]:"AGX_TONE_MAPPING",[hv]:"NEUTRAL_TONE_MAPPING",[dv]:"CUSTOM_TONE_MAPPING"};function KE(s,e,t,r,o,l){const u=new Wi(e,t,{type:s,depthBuffer:o,stencilBuffer:l,samples:r?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let d=null,f=null;const p=new dn;p.setAttribute("position",new Jt([-1,3,0,-1,-1,0,3,-1,0],3)),p.setAttribute("uv",new Jt([0,2,0,0,2,0],2));const y=new U1({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),S=new Sn(p,y),v=new Oh(-1,1,1,-1,0,1);let _=null,M=null,A=!1,m,x=null,P=[],U=!1;this.setSize=function(b,R){u.setSize(b,R),d!==null&&d.setSize(b,R),f!==null&&f.setSize(b,R);for(let N=0;N<P.length;N++){const F=P[N];F.setSize&&F.setSize(b,R)}},this.setEffects=function(b){P=b,U=P.length>0&&P[0].isRenderPass===!0;const R=u.width,N=u.height;P.length>0&&d===null&&(d=new Wi(R,N,{type:or,depthBuffer:!1,stencilBuffer:!1}),f=new Wi(R,N,{type:or,depthBuffer:!1,stencilBuffer:!1}));for(let F=0;F<P.length;F++){const E=P[F];E.setSize&&E.setSize(R,N)}},this.begin=function(b,R){if(A||b.toneMapping===rr&&P.length===0)return!1;if(x=R,R!==null){const N=R.width,F=R.height;(u.width!==N||u.height!==F)&&this.setSize(N,F)}return U===!1&&b.setRenderTarget(u),m=b.toneMapping,b.toneMapping=rr,!0},this.hasRenderPass=function(){return U},this.end=function(b,R){b.toneMapping=m,A=!0;let N=u,F=d;for(let E=0;E<P.length;E++){const L=P[E];L.enabled!==!1&&(L.render(b,F,N,R),L.needsSwap!==!1&&(N=F,F=F===d?f:d))}if(_!==b.outputColorSpace||M!==b.toneMapping){_=b.outputColorSpace,M=b.toneMapping,y.defines={},Dt.getTransfer(_)===qt&&(y.defines.SRGB_TRANSFER="");const E=qE[M];E&&(y.defines[E]=""),y.needsUpdate=!0}y.uniforms.tDiffuse.value=N.texture,b.setRenderTarget(x),b.render(S,v),x=null,A=!1},this.isCompositing=function(){return A},this.dispose=function(){u.dispose(),d!==null&&d.dispose(),f!==null&&f.dispose(),p.dispose(),y.dispose()}}const Uv=new Qn,dh=new ja(1,1),Fv=new Mv,Ov=new s1,kv=new bv,v0=[],x0=[],y0=new Float32Array(16),_0=new Float32Array(9),S0=new Float32Array(4);function Ho(s,e,t){const r=s[0];if(r<=0||r>0)return s;const o=e*t;let l=v0[o];if(l===void 0&&(l=new Float32Array(o),v0[o]=l),e!==0){r.toArray(l,0);for(let u=1,d=0;u!==e;++u)d+=t,s[u].toArray(l,d)}return l}function Mn(s,e){if(s.length!==e.length)return!1;for(let t=0,r=s.length;t<r;t++)if(s[t]!==e[t])return!1;return!0}function En(s,e){for(let t=0,r=e.length;t<r;t++)s[t]=e[t]}function Qc(s,e){let t=x0[e];t===void 0&&(t=new Int32Array(e),x0[e]=t);for(let r=0;r!==e;++r)t[r]=s.allocateTextureUnit();return t}function $E(s,e){const t=this.cache;t[0]!==e&&(s.uniform1f(this.addr,e),t[0]=e)}function ZE(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mn(t,e))return;s.uniform2fv(this.addr,e),En(t,e)}}function JE(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(s.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Mn(t,e))return;s.uniform3fv(this.addr,e),En(t,e)}}function QE(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mn(t,e))return;s.uniform4fv(this.addr,e),En(t,e)}}function ew(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(Mn(t,e))return;s.uniformMatrix2fv(this.addr,!1,e),En(t,e)}else{if(Mn(t,r))return;S0.set(r),s.uniformMatrix2fv(this.addr,!1,S0),En(t,r)}}function tw(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(Mn(t,e))return;s.uniformMatrix3fv(this.addr,!1,e),En(t,e)}else{if(Mn(t,r))return;_0.set(r),s.uniformMatrix3fv(this.addr,!1,_0),En(t,r)}}function nw(s,e){const t=this.cache,r=e.elements;if(r===void 0){if(Mn(t,e))return;s.uniformMatrix4fv(this.addr,!1,e),En(t,e)}else{if(Mn(t,r))return;y0.set(r),s.uniformMatrix4fv(this.addr,!1,y0),En(t,r)}}function iw(s,e){const t=this.cache;t[0]!==e&&(s.uniform1i(this.addr,e),t[0]=e)}function rw(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mn(t,e))return;s.uniform2iv(this.addr,e),En(t,e)}}function sw(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mn(t,e))return;s.uniform3iv(this.addr,e),En(t,e)}}function ow(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mn(t,e))return;s.uniform4iv(this.addr,e),En(t,e)}}function aw(s,e){const t=this.cache;t[0]!==e&&(s.uniform1ui(this.addr,e),t[0]=e)}function lw(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(s.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mn(t,e))return;s.uniform2uiv(this.addr,e),En(t,e)}}function cw(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(s.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mn(t,e))return;s.uniform3uiv(this.addr,e),En(t,e)}}function uw(s,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(s.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mn(t,e))return;s.uniform4uiv(this.addr,e),En(t,e)}}function dw(s,e,t){const r=this.cache,o=t.allocateTextureUnit();r[0]!==o&&(s.uniform1i(this.addr,o),r[0]=o);let l;this.type===s.SAMPLER_2D_SHADOW?(dh.compareFunction=t.isReversedDepthBuffer()?Ch:bh,l=dh):l=Uv,t.setTexture2D(e||l,o)}function fw(s,e,t){const r=this.cache,o=t.allocateTextureUnit();r[0]!==o&&(s.uniform1i(this.addr,o),r[0]=o),t.setTexture3D(e||Ov,o)}function hw(s,e,t){const r=this.cache,o=t.allocateTextureUnit();r[0]!==o&&(s.uniform1i(this.addr,o),r[0]=o),t.setTextureCube(e||kv,o)}function pw(s,e,t){const r=this.cache,o=t.allocateTextureUnit();r[0]!==o&&(s.uniform1i(this.addr,o),r[0]=o),t.setTexture2DArray(e||Fv,o)}function mw(s){switch(s){case 5126:return $E;case 35664:return ZE;case 35665:return JE;case 35666:return QE;case 35674:return ew;case 35675:return tw;case 35676:return nw;case 5124:case 35670:return iw;case 35667:case 35671:return rw;case 35668:case 35672:return sw;case 35669:case 35673:return ow;case 5125:return aw;case 36294:return lw;case 36295:return cw;case 36296:return uw;case 35678:case 36198:case 36298:case 36306:case 35682:return dw;case 35679:case 36299:case 36307:return fw;case 35680:case 36300:case 36308:case 36293:return hw;case 36289:case 36303:case 36311:case 36292:return pw}}function gw(s,e){s.uniform1fv(this.addr,e)}function vw(s,e){const t=Ho(e,this.size,2);s.uniform2fv(this.addr,t)}function xw(s,e){const t=Ho(e,this.size,3);s.uniform3fv(this.addr,t)}function yw(s,e){const t=Ho(e,this.size,4);s.uniform4fv(this.addr,t)}function _w(s,e){const t=Ho(e,this.size,4);s.uniformMatrix2fv(this.addr,!1,t)}function Sw(s,e){const t=Ho(e,this.size,9);s.uniformMatrix3fv(this.addr,!1,t)}function Mw(s,e){const t=Ho(e,this.size,16);s.uniformMatrix4fv(this.addr,!1,t)}function Ew(s,e){s.uniform1iv(this.addr,e)}function ww(s,e){s.uniform2iv(this.addr,e)}function Tw(s,e){s.uniform3iv(this.addr,e)}function Aw(s,e){s.uniform4iv(this.addr,e)}function bw(s,e){s.uniform1uiv(this.addr,e)}function Cw(s,e){s.uniform2uiv(this.addr,e)}function Rw(s,e){s.uniform3uiv(this.addr,e)}function Pw(s,e){s.uniform4uiv(this.addr,e)}function Iw(s,e,t){const r=this.cache,o=e.length,l=Qc(t,o);Mn(r,l)||(s.uniform1iv(this.addr,l),En(r,l));let u;this.type===s.SAMPLER_2D_SHADOW?u=dh:u=Uv;for(let d=0;d!==o;++d)t.setTexture2D(e[d]||u,l[d])}function Lw(s,e,t){const r=this.cache,o=e.length,l=Qc(t,o);Mn(r,l)||(s.uniform1iv(this.addr,l),En(r,l));for(let u=0;u!==o;++u)t.setTexture3D(e[u]||Ov,l[u])}function Nw(s,e,t){const r=this.cache,o=e.length,l=Qc(t,o);Mn(r,l)||(s.uniform1iv(this.addr,l),En(r,l));for(let u=0;u!==o;++u)t.setTextureCube(e[u]||kv,l[u])}function Dw(s,e,t){const r=this.cache,o=e.length,l=Qc(t,o);Mn(r,l)||(s.uniform1iv(this.addr,l),En(r,l));for(let u=0;u!==o;++u)t.setTexture2DArray(e[u]||Fv,l[u])}function Uw(s){switch(s){case 5126:return gw;case 35664:return vw;case 35665:return xw;case 35666:return yw;case 35674:return _w;case 35675:return Sw;case 35676:return Mw;case 5124:case 35670:return Ew;case 35667:case 35671:return ww;case 35668:case 35672:return Tw;case 35669:case 35673:return Aw;case 5125:return bw;case 36294:return Cw;case 36295:return Rw;case 36296:return Pw;case 35678:case 36198:case 36298:case 36306:case 35682:return Iw;case 35679:case 36299:case 36307:return Lw;case 35680:case 36300:case 36308:case 36293:return Nw;case 36289:case 36303:case 36311:case 36292:return Dw}}class Fw{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.setValue=mw(t.type)}}class Ow{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Uw(t.type)}}class kw{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,r){const o=this.seq;for(let l=0,u=o.length;l!==u;++l){const d=o[l];d.setValue(e,t[d.id],r)}}}const pf=/(\w+)(\])?(\[|\.)?/g;function M0(s,e){s.seq.push(e),s.map[e.id]=e}function Bw(s,e,t){const r=s.name,o=r.length;for(pf.lastIndex=0;;){const l=pf.exec(r),u=pf.lastIndex;let d=l[1];const f=l[2]==="]",p=l[3];if(f&&(d=d|0),p===void 0||p==="["&&u+2===o){M0(t,p===void 0?new Fw(d,s,e):new Ow(d,s,e));break}else{let S=t.map[d];S===void 0&&(S=new kw(d),M0(t,S)),t=S}}}class Dc{constructor(e,t){this.seq=[],this.map={};const r=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let u=0;u<r;++u){const d=e.getActiveUniform(t,u),f=e.getUniformLocation(t,d.name);Bw(d,f,this)}const o=[],l=[];for(const u of this.seq)u.type===e.SAMPLER_2D_SHADOW||u.type===e.SAMPLER_CUBE_SHADOW||u.type===e.SAMPLER_2D_ARRAY_SHADOW?o.push(u):l.push(u);o.length>0&&(this.seq=o.concat(l))}setValue(e,t,r,o){const l=this.map[t];l!==void 0&&l.setValue(e,r,o)}setOptional(e,t,r){const o=t[r];o!==void 0&&this.setValue(e,r,o)}static upload(e,t,r,o){for(let l=0,u=t.length;l!==u;++l){const d=t[l],f=r[d.id];f.needsUpdate!==!1&&d.setValue(e,f.value,o)}}static seqWithValue(e,t){const r=[];for(let o=0,l=e.length;o!==l;++o){const u=e[o];u.id in t&&r.push(u)}return r}}function E0(s,e,t){const r=s.createShader(e);return s.shaderSource(r,t),s.compileShader(r),r}const zw=37297;let Vw=0;function Hw(s,e){const t=s.split(`
`),r=[],o=Math.max(e-6,0),l=Math.min(e+6,t.length);for(let u=o;u<l;u++){const d=u+1;r.push(`${d===e?">":" "} ${d}: ${t[u]}`)}return r.join(`
`)}const w0=new yt;function Gw(s){Dt._getMatrix(w0,Dt.workingColorSpace,s);const e=`mat3( ${w0.elements.map(t=>t.toFixed(4))} )`;switch(Dt.getTransfer(s)){case Vc:return[e,"LinearTransferOETF"];case qt:return[e,"sRGBTransferOETF"];default:return ht("WebGLProgram: Unsupported color space: ",s),[e,"LinearTransferOETF"]}}function T0(s,e,t){const r=s.getShaderParameter(e,s.COMPILE_STATUS),l=(s.getShaderInfoLog(e)||"").trim();if(r&&l==="")return"";const u=/ERROR: 0:(\d+)/.exec(l);if(u){const d=parseInt(u[1]);return t.toUpperCase()+`

`+l+`

`+Hw(s.getShaderSource(e),d)}else return l}function Ww(s,e){const t=Gw(e);return[`vec4 ${s}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const jw={[lv]:"Linear",[cv]:"Reinhard",[uv]:"Cineon",[yh]:"ACESFilmic",[fv]:"AgX",[hv]:"Neutral",[dv]:"Custom"};function Xw(s,e){const t=jw[e];return t===void 0?(ht("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+s+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+s+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const wc=new Z;function Yw(){Dt.getLuminanceCoefficients(wc);const s=wc.x.toFixed(4),e=wc.y.toFixed(4),t=wc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function qw(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Na).join(`
`)}function Kw(s){const e=[];for(const t in s){const r=s[t];r!==!1&&e.push("#define "+t+" "+r)}return e.join(`
`)}function $w(s,e){const t={},r=s.getProgramParameter(e,s.ACTIVE_ATTRIBUTES);for(let o=0;o<r;o++){const l=s.getActiveAttrib(e,o),u=l.name;let d=1;l.type===s.FLOAT_MAT2&&(d=2),l.type===s.FLOAT_MAT3&&(d=3),l.type===s.FLOAT_MAT4&&(d=4),t[u]={type:l.type,location:s.getAttribLocation(e,u),locationSize:d}}return t}function Na(s){return s!==""}function A0(s,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return s.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function b0(s,e){return s.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Zw=/^[ \t]*#include +<([\w\d./]+)>/gm;function fh(s){return s.replace(Zw,Qw)}const Jw=new Map;function Qw(s,e){let t=Ct[e];if(t===void 0){const r=Jw.get(e);if(r!==void 0)t=Ct[r],ht('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,r);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return fh(t)}const eT=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function C0(s){return s.replace(eT,tT)}function tT(s,e,t,r){let o="";for(let l=parseInt(e);l<parseInt(t);l++)o+=r.replace(/\[\s*i\s*\]/g,"[ "+l+" ]").replace(/UNROLLED_LOOP_INDEX/g,l);return o}function R0(s){let e=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?e+=`
#define HIGH_PRECISION`:s.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const nT={[Ac]:"SHADOWMAP_TYPE_PCF",[La]:"SHADOWMAP_TYPE_VSM"};function iT(s){return nT[s.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const rT={[Us]:"ENVMAP_TYPE_CUBE",[ko]:"ENVMAP_TYPE_CUBE",[$c]:"ENVMAP_TYPE_CUBE_UV"};function sT(s){return s.envMap===!1?"ENVMAP_TYPE_CUBE":rT[s.envMapMode]||"ENVMAP_TYPE_CUBE"}const oT={[ko]:"ENVMAP_MODE_REFRACTION"};function aT(s){return s.envMap===!1?"ENVMAP_MODE_REFLECTION":oT[s.envMapMode]||"ENVMAP_MODE_REFLECTION"}const lT={[av]:"ENVMAP_BLENDING_MULTIPLY",[U_]:"ENVMAP_BLENDING_MIX",[F_]:"ENVMAP_BLENDING_ADD"};function cT(s){return s.envMap===!1?"ENVMAP_BLENDING_NONE":lT[s.combine]||"ENVMAP_BLENDING_NONE"}function uT(s){const e=s.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,r=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:r,maxMip:t}}function dT(s,e,t,r){const o=s.getContext(),l=t.defines;let u=t.vertexShader,d=t.fragmentShader;const f=iT(t),p=sT(t),y=aT(t),S=cT(t),v=uT(t),_=qw(t),M=Kw(l),A=o.createProgram();let m,x,P=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M].filter(Na).join(`
`),m.length>0&&(m+=`
`),x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M].filter(Na).join(`
`),x.length>0&&(x+=`
`)):(m=[R0(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+y:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+f:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Na).join(`
`),x=[R0(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,M,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+p:"",t.envMap?"#define "+y:"",t.envMap?"#define "+S:"",v?"#define CUBEUV_TEXEL_WIDTH "+v.texelWidth:"",v?"#define CUBEUV_TEXEL_HEIGHT "+v.texelHeight:"",v?"#define CUBEUV_MAX_MIP "+v.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+f:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==rr?"#define TONE_MAPPING":"",t.toneMapping!==rr?Ct.tonemapping_pars_fragment:"",t.toneMapping!==rr?Xw("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ct.colorspace_pars_fragment,Ww("linearToOutputTexel",t.outputColorSpace),Yw(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Na).join(`
`)),u=fh(u),u=A0(u,t),u=b0(u,t),d=fh(d),d=A0(d,t),d=b0(d,t),u=C0(u),d=C0(d),t.isRawShaderMaterial!==!0&&(P=`#version 300 es
`,m=[_,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,x=["#define varying in",t.glslVersion===Cg?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Cg?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const U=P+m+u,b=P+x+d,R=E0(o,o.VERTEX_SHADER,U),N=E0(o,o.FRAGMENT_SHADER,b);o.attachShader(A,R),o.attachShader(A,N),t.index0AttributeName!==void 0?o.bindAttribLocation(A,0,t.index0AttributeName):t.hasPositionAttribute===!0&&o.bindAttribLocation(A,0,"position"),o.linkProgram(A);function F(X){if(s.debug.checkShaderErrors){const j=o.getProgramInfoLog(A)||"",ne=o.getShaderInfoLog(R)||"",H=o.getShaderInfoLog(N)||"",W=j.trim(),ue=ne.trim(),Q=H.trim();let te=!0,G=!0;if(o.getProgramParameter(A,o.LINK_STATUS)===!1)if(te=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(o,A,R,N);else{const ee=T0(o,R,"vertex"),O=T0(o,N,"fragment");zt("WebGLProgram: Shader Error "+o.getError()+" - VALIDATE_STATUS "+o.getProgramParameter(A,o.VALIDATE_STATUS)+`

Material Name: `+X.name+`
Material Type: `+X.type+`

Program Info Log: `+W+`
`+ee+`
`+O)}else W!==""?ht("WebGLProgram: Program Info Log:",W):(ue===""||Q==="")&&(G=!1);G&&(X.diagnostics={runnable:te,programLog:W,vertexShader:{log:ue,prefix:m},fragmentShader:{log:Q,prefix:x}})}o.deleteShader(R),o.deleteShader(N),E=new Dc(o,A),L=$w(o,A)}let E;this.getUniforms=function(){return E===void 0&&F(this),E};let L;this.getAttributes=function(){return L===void 0&&F(this),L};let B=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return B===!1&&(B=o.getProgramParameter(A,zw)),B},this.destroy=function(){r.releaseStatesOfProgram(this),o.deleteProgram(A),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Vw++,this.cacheKey=e,this.usedTimes=1,this.program=A,this.vertexShader=R,this.fragmentShader=N,this}let fT=0;class hT{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,r){const o=this._getShaderCacheForMaterial(e);return o.has(t)===!1&&(o.add(t),t.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const r of t)r.usedTimes--,r.usedTimes===0&&this.shaderCache.delete(r.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let r=t.get(e);return r===void 0&&(r=new Set,t.set(e,r)),r}_getShaderStage(e){const t=this.shaderCache;let r=t.get(e);return r===void 0&&(r=new pT(e),t.set(e,r)),r}}class pT{constructor(e){this.id=fT++,this.code=e,this.usedTimes=0}}function mT(s){return s===Fs||s===kc||s===Bc}function gT(s,e,t,r,o,l){const u=new Ph,d=new hT,f=new Set,p=[],y=new Map,S=r.logarithmicDepthBuffer;let v=r.precision;const _={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(E){return f.add(E),E===0?"uv":`uv${E}`}function A(E,L,B,X,j,ne){const H=X.fog,W=j.geometry,ue=E.isMeshStandardMaterial||E.isMeshLambertMaterial||E.isMeshPhongMaterial?X.environment:null,Q=E.isMeshStandardMaterial||E.isMeshLambertMaterial&&!E.envMap||E.isMeshPhongMaterial&&!E.envMap,te=e.get(E.envMap||ue,Q),G=te&&te.mapping===$c?te.image.height:null,ee=_[E.type];E.precision!==null&&(v=r.getMaxPrecision(E.precision),v!==E.precision&&ht("WebGLProgram.getParameters:",E.precision,"not supported, using",v,"instead."));const O=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,de=O!==void 0?O.length:0;let Ce=0;W.morphAttributes.position!==void 0&&(Ce=1),W.morphAttributes.normal!==void 0&&(Ce=2),W.morphAttributes.color!==void 0&&(Ce=3);let Te,De,Ye,le;if(ee){const Ut=nr[ee];Te=Ut.vertexShader,De=Ut.fragmentShader}else{Te=E.vertexShader,De=E.fragmentShader;const Ut=d.getVertexShaderStage(E),bt=d.getFragmentShaderStage(E);d.update(E,Ut,bt),Ye=Ut.id,le=bt.id}const ge=s.getRenderTarget(),Ne=s.state.buffers.depth.getReversed(),tt=j.isInstancedMesh===!0,Xe=j.isBatchedMesh===!0,mt=!!E.map,Gt=!!E.matcap,lt=!!te,Et=!!E.aoMap,Ot=!!E.lightMap,xt=!!E.bumpMap&&E.wireframe===!1,At=!!E.normalMap,Xt=!!E.displacementMap,Wt=!!E.emissiveMap,_t=!!E.metalnessMap,Nt=!!E.roughnessMap,$=E.anisotropy>0,It=E.clearcoat>0,wt=E.dispersion>0,k=E.retroreflectivity>0,w=E.iridescence>0,re=E.sheen>0,he=E.transmission>0,ye=$&&!!E.anisotropyMap,Pe=It&&!!E.clearcoatMap,fe=It&&!!E.clearcoatNormalMap,ie=It&&!!E.clearcoatRoughnessMap,se=w&&!!E.iridescenceMap,be=w&&!!E.iridescenceThicknessMap,Fe=re&&!!E.sheenColorMap,ve=re&&!!E.sheenRoughnessMap,Ee=!!E.specularMap,K=!!E.specularColorMap,Ue=!!E.specularIntensityMap,_e=he&&!!E.transmissionMap,V=he&&!!E.thicknessMap,Oe=!!E.gradientMap,Se=!!E.alphaMap,Ve=E.alphaTest>0,Ge=!!E.alphaHash,we=!!E.extensions;let rt=rr;E.toneMapped&&(ge===null||ge.isXRRenderTarget===!0)&&(rt=s.toneMapping);const $e={shaderID:ee,shaderType:E.type,shaderName:E.name,vertexShader:Te,fragmentShader:De,defines:E.defines,customVertexShaderID:Ye,customFragmentShaderID:le,isRawShaderMaterial:E.isRawShaderMaterial===!0,glslVersion:E.glslVersion,precision:v,batching:Xe,batchingColor:Xe&&j._colorsTexture!==null,instancing:tt,instancingColor:tt&&j.instanceColor!==null,instancingMorph:tt&&j.morphTexture!==null,outputColorSpace:ge===null?s.outputColorSpace:ge.isXRRenderTarget===!0?ge.texture.colorSpace:Dt.workingColorSpace,alphaToCoverage:!!E.alphaToCoverage,map:mt,matcap:Gt,envMap:lt,envMapMode:lt&&te.mapping,envMapCubeUVHeight:G,aoMap:Et,lightMap:Ot,bumpMap:xt,normalMap:At,displacementMap:Xt,emissiveMap:Wt,normalMapObjectSpace:At&&E.normalMapType===B_,normalMapTangentSpace:At&&E.normalMapType===oh,packedNormalMap:At&&E.normalMapType===oh&&mT(E.normalMap.format),metalnessMap:_t,roughnessMap:Nt,anisotropy:$,anisotropyMap:ye,clearcoat:It,clearcoatMap:Pe,clearcoatNormalMap:fe,clearcoatRoughnessMap:ie,dispersion:wt,retroreflection:k,iridescence:w,iridescenceMap:se,iridescenceThicknessMap:be,sheen:re,sheenColorMap:Fe,sheenRoughnessMap:ve,specularMap:Ee,specularColorMap:K,specularIntensityMap:Ue,transmission:he,transmissionMap:_e,thicknessMap:V,gradientMap:Oe,opaque:E.transparent===!1&&E.blending===Ua&&E.alphaToCoverage===!1,alphaMap:Se,alphaTest:Ve,alphaHash:Ge,combine:E.combine,mapUv:mt&&M(E.map.channel),aoMapUv:Et&&M(E.aoMap.channel),lightMapUv:Ot&&M(E.lightMap.channel),bumpMapUv:xt&&M(E.bumpMap.channel),normalMapUv:At&&M(E.normalMap.channel),displacementMapUv:Xt&&M(E.displacementMap.channel),emissiveMapUv:Wt&&M(E.emissiveMap.channel),metalnessMapUv:_t&&M(E.metalnessMap.channel),roughnessMapUv:Nt&&M(E.roughnessMap.channel),anisotropyMapUv:ye&&M(E.anisotropyMap.channel),clearcoatMapUv:Pe&&M(E.clearcoatMap.channel),clearcoatNormalMapUv:fe&&M(E.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ie&&M(E.clearcoatRoughnessMap.channel),iridescenceMapUv:se&&M(E.iridescenceMap.channel),iridescenceThicknessMapUv:be&&M(E.iridescenceThicknessMap.channel),sheenColorMapUv:Fe&&M(E.sheenColorMap.channel),sheenRoughnessMapUv:ve&&M(E.sheenRoughnessMap.channel),specularMapUv:Ee&&M(E.specularMap.channel),specularColorMapUv:K&&M(E.specularColorMap.channel),specularIntensityMapUv:Ue&&M(E.specularIntensityMap.channel),transmissionMapUv:_e&&M(E.transmissionMap.channel),thicknessMapUv:V&&M(E.thicknessMap.channel),alphaMapUv:Se&&M(E.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(At||$),vertexNormals:!!W.attributes.normal,vertexColors:E.vertexColors,vertexAlphas:E.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:j.isPoints===!0&&!!W.attributes.uv&&(mt||Se),fog:!!H,useFog:E.fog===!0,fogExp2:!!H&&H.isFogExp2,flatShading:E.wireframe===!1&&(E.flatShading===!0||W.attributes.normal===void 0&&At===!1&&(E.isMeshLambertMaterial||E.isMeshPhongMaterial||E.isMeshStandardMaterial||E.isMeshPhysicalMaterial)),sizeAttenuation:E.sizeAttenuation===!0,logarithmicDepthBuffer:S,reversedDepthBuffer:Ne,skinning:j.isSkinnedMesh===!0,hasPositionAttribute:W.attributes.position!==void 0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:de,morphTextureStride:Ce,numSunLights:L.sun.length,numDirLights:L.directional.length,numPointLights:L.point.length,numSpotLights:L.spot.length,numSpotLightMaps:L.spotLightMap.length,numRectAreaLights:L.rectArea.length,numHemiLights:L.hemi.length,numSunLightShadows:L.sunShadowMap.length,numDirLightShadows:L.directionalShadowMap.length,numPointLightShadows:L.pointShadowMap.length,numSpotLightShadows:L.spotShadowMap.length,numSpotLightShadowsWithMaps:L.numSpotLightShadowsWithMaps,numLightProbes:L.numLightProbes,numLightProbeGrids:ne.length,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:E.dithering,shadowMapEnabled:s.shadowMap.enabled&&B.length>0,shadowMapType:s.shadowMap.type,toneMapping:rt,decodeVideoTexture:mt&&E.map.isVideoTexture===!0&&Dt.getTransfer(E.map.colorSpace)===qt,decodeVideoTextureEmissive:Wt&&E.emissiveMap.isVideoTexture===!0&&Dt.getTransfer(E.emissiveMap.colorSpace)===qt,premultipliedAlpha:E.premultipliedAlpha,doubleSided:E.side===zi,flipSided:E.side===Jn,useDepthPacking:E.depthPacking>=0,depthPacking:E.depthPacking||0,index0AttributeName:E.index0AttributeName,extensionClipCullDistance:we&&E.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(we&&E.extensions.multiDraw===!0||Xe)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:E.customProgramCacheKey()};return $e.vertexUv1s=f.has(1),$e.vertexUv2s=f.has(2),$e.vertexUv3s=f.has(3),f.clear(),$e}function m(E){const L=[];if(E.shaderID?L.push(E.shaderID):(L.push(E.customVertexShaderID),L.push(E.customFragmentShaderID)),E.defines!==void 0)for(const B in E.defines)L.push(B),L.push(E.defines[B]);return E.isRawShaderMaterial===!1&&(x(L,E),P(L,E),L.push(s.outputColorSpace)),L.push(E.customProgramCacheKey),L.join()}function x(E,L){E.push(L.precision),E.push(L.outputColorSpace),E.push(L.envMapMode),E.push(L.envMapCubeUVHeight),E.push(L.mapUv),E.push(L.alphaMapUv),E.push(L.lightMapUv),E.push(L.aoMapUv),E.push(L.bumpMapUv),E.push(L.normalMapUv),E.push(L.displacementMapUv),E.push(L.emissiveMapUv),E.push(L.metalnessMapUv),E.push(L.roughnessMapUv),E.push(L.anisotropyMapUv),E.push(L.clearcoatMapUv),E.push(L.clearcoatNormalMapUv),E.push(L.clearcoatRoughnessMapUv),E.push(L.iridescenceMapUv),E.push(L.iridescenceThicknessMapUv),E.push(L.sheenColorMapUv),E.push(L.sheenRoughnessMapUv),E.push(L.specularMapUv),E.push(L.specularColorMapUv),E.push(L.specularIntensityMapUv),E.push(L.transmissionMapUv),E.push(L.thicknessMapUv),E.push(L.combine),E.push(L.fogExp2),E.push(L.sizeAttenuation),E.push(L.morphTargetsCount),E.push(L.morphAttributeCount),E.push(L.numSunLights),E.push(L.numDirLights),E.push(L.numPointLights),E.push(L.numSpotLights),E.push(L.numSpotLightMaps),E.push(L.numHemiLights),E.push(L.numRectAreaLights),E.push(L.numSunLightShadows),E.push(L.numDirLightShadows),E.push(L.numPointLightShadows),E.push(L.numSpotLightShadows),E.push(L.numSpotLightShadowsWithMaps),E.push(L.numLightProbes),E.push(L.shadowMapType),E.push(L.toneMapping),E.push(L.numClippingPlanes),E.push(L.numClipIntersection),E.push(L.depthPacking)}function P(E,L){u.disableAll(),L.instancing&&u.enable(0),L.instancingColor&&u.enable(1),L.instancingMorph&&u.enable(2),L.matcap&&u.enable(3),L.envMap&&u.enable(4),L.normalMapObjectSpace&&u.enable(5),L.normalMapTangentSpace&&u.enable(6),L.clearcoat&&u.enable(7),L.iridescence&&u.enable(8),L.alphaTest&&u.enable(9),L.vertexColors&&u.enable(10),L.vertexAlphas&&u.enable(11),L.vertexUv1s&&u.enable(12),L.vertexUv2s&&u.enable(13),L.vertexUv3s&&u.enable(14),L.vertexTangents&&u.enable(15),L.anisotropy&&u.enable(16),L.alphaHash&&u.enable(17),L.batching&&u.enable(18),L.dispersion&&u.enable(19),L.retroreflection&&u.enable(24),L.batchingColor&&u.enable(20),L.gradientMap&&u.enable(21),L.packedNormalMap&&u.enable(22),L.vertexNormals&&u.enable(23),E.push(u.mask),u.disableAll(),L.fog&&u.enable(0),L.useFog&&u.enable(1),L.flatShading&&u.enable(2),L.logarithmicDepthBuffer&&u.enable(3),L.reversedDepthBuffer&&u.enable(4),L.skinning&&u.enable(5),L.morphTargets&&u.enable(6),L.morphNormals&&u.enable(7),L.morphColors&&u.enable(8),L.premultipliedAlpha&&u.enable(9),L.shadowMapEnabled&&u.enable(10),L.doubleSided&&u.enable(11),L.flipSided&&u.enable(12),L.useDepthPacking&&u.enable(13),L.dithering&&u.enable(14),L.transmission&&u.enable(15),L.sheen&&u.enable(16),L.opaque&&u.enable(17),L.pointsUvs&&u.enable(18),L.decodeVideoTexture&&u.enable(19),L.decodeVideoTextureEmissive&&u.enable(20),L.alphaToCoverage&&u.enable(21),L.numLightProbeGrids>0&&u.enable(22),L.hasPositionAttribute&&u.enable(23),E.push(u.mask)}function U(E){const L=_[E.type];let B;if(L){const X=nr[L];B=L1.clone(X.uniforms)}else B=E.uniforms;return B}function b(E,L){let B=y.get(L);return B!==void 0?++B.usedTimes:(B=new dT(s,L,E,o),p.push(B),y.set(L,B)),B}function R(E){if(--E.usedTimes===0){const L=p.indexOf(E);p[L]=p[p.length-1],p.pop(),y.delete(E.cacheKey),E.destroy()}}function N(E){d.remove(E)}function F(){d.dispose()}return{getParameters:A,getProgramCacheKey:m,getUniforms:U,acquireProgram:b,releaseProgram:R,releaseShaderCache:N,programs:p,dispose:F}}function vT(){let s=new WeakMap;function e(u){return s.has(u)}function t(u){let d=s.get(u);return d===void 0&&(d={},s.set(u,d)),d}function r(u){s.delete(u)}function o(u,d,f){s.get(u)[d]=f}function l(){s=new WeakMap}return{has:e,get:t,remove:r,update:o,dispose:l}}function xT(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.material.id!==e.material.id?s.material.id-e.material.id:s.materialVariant!==e.materialVariant?s.materialVariant-e.materialVariant:s.z!==e.z?s.z-e.z:s.id-e.id}function P0(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.z!==e.z?e.z-s.z:s.id-e.id}function I0(){const s=[];let e=0;const t=[],r=[],o=[];function l(){e=0,t.length=0,r.length=0,o.length=0}function u(v){let _=0;return v.isInstancedMesh&&(_+=2),v.isSkinnedMesh&&(_+=1),_}function d(v,_,M,A,m,x){let P=s[e];return P===void 0?(P={id:v.id,object:v,geometry:_,material:M,materialVariant:u(v),groupOrder:A,renderOrder:v.renderOrder,z:m,group:x},s[e]=P):(P.id=v.id,P.object=v,P.geometry=_,P.material=M,P.materialVariant=u(v),P.groupOrder=A,P.renderOrder=v.renderOrder,P.z=m,P.group=x),e++,P}function f(v,_,M,A,m,x,P){P.reversedDepth===!0&&(m=-m);const U=d(v,_,M,A,m,x);M.transmission>0?r.push(U):M.transparent===!0?o.push(U):t.push(U)}function p(v,_,M,A,m,x){const P=d(v,_,M,A,m,x);M.transmission>0?r.unshift(P):M.transparent===!0?o.unshift(P):t.unshift(P)}function y(v,_){t.length>1&&t.sort(v||xT),r.length>1&&r.sort(_||P0),o.length>1&&o.sort(_||P0)}function S(){for(let v=e,_=s.length;v<_;v++){const M=s[v];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:t,transmissive:r,transparent:o,init:l,push:f,unshift:p,finish:S,sort:y}}function yT(){let s=new WeakMap;function e(r,o){const l=s.get(r);let u;return l===void 0?(u=new I0,s.set(r,[u])):o>=l.length?(u=new I0,l.push(u)):u=l[o],u}function t(){s=new WeakMap}return{get:e,dispose:t}}function _T(){const s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new Z,color:new vt};break;case"SpotLight":t={position:new Z,direction:new Z,color:new vt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new Z,color:new vt,distance:0,decay:0};break;case"HemisphereLight":t={direction:new Z,skyColor:new vt,groundColor:new vt};break;case"RectAreaLight":t={color:new vt,position:new Z,halfWidth:new Z,halfHeight:new Z};break}return s[e.id]=t,t}}}function ST(){const s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[e.id]=t,t}}}let MT=0;function ET(s,e){return(e.castShadow?2:0)-(s.castShadow?2:0)+(e.map?1:0)-(s.map?1:0)}function wT(s){const e=new _T,t=ST(),r={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let p=0;p<9;p++)r.probe.push(new Z);const o=new Z,l=new Yt,u=new Yt;function d(p){let y=0,S=0,v=0;for(let j=0;j<9;j++)r.probe[j].set(0,0,0);let _=0,M=0,A=0,m=0,x=0,P=0,U=0,b=0,R=0,N=0,F=0,E=0,L=0,B=0;p.sort(ET);for(let j=0,ne=p.length;j<ne;j++){const H=p[j],W=H.color,ue=H.intensity,Q=H.distance;let te=null;if(H.shadow&&H.shadow.map&&(H.shadow.map.texture.format===Fs?te=H.shadow.map.texture:te=H.shadow.map.depthTexture||H.shadow.map.texture),H.isAmbientLight)y+=W.r*ue,S+=W.g*ue,v+=W.b*ue;else if(H.isLightProbe){for(let G=0;G<9;G++)r.probe[G].addScaledVector(H.sh.coefficients[G],ue);B++}else if(H.isSunLight){const G=e.get(H);if(G.color.copy(H.color).multiplyScalar(H.intensity),H.castShadow){const ee=H.shadow,O=t.get(H);O.shadowIntensity=ee.intensity,O.shadowBias=ee.bias,O.shadowNormalBias=ee.normalBias,O.shadowRadius=ee.radius,O.shadowMapSize.copy(ee.mapSize).multiply(ee.getFrameExtents()),r.sunShadow[M]=O,r.sunShadowMap[M]=te;const de=ee.getViewportCount();for(let Ce=0;Ce<de;Ce++)r.sunShadowMatrix[A+Ce]=ee.getMatrix(Ce),r.sunShadowCascade[A+Ce]=ee._cascadeData[Ce];A+=de,M++}r.sun[_]=G,_++}else if(H.isDirectionalLight){const G=e.get(H);if(G.color.copy(H.color).multiplyScalar(H.intensity),H.castShadow){const ee=H.shadow,O=t.get(H);O.shadowIntensity=ee.intensity,O.shadowBias=ee.bias,O.shadowNormalBias=ee.normalBias,O.shadowRadius=ee.radius,O.shadowMapSize=ee.mapSize,r.directionalShadow[m]=O,r.directionalShadowMap[m]=te,r.directionalShadowMatrix[m]=H.shadow.matrix,R++}r.directional[m]=G,m++}else if(H.isSpotLight){const G=e.get(H);G.position.setFromMatrixPosition(H.matrixWorld),G.color.copy(W).multiplyScalar(ue),G.distance=Q,G.coneCos=Math.cos(H.angle),G.penumbraCos=Math.cos(H.angle*(1-H.penumbra)),G.decay=H.decay,r.spot[P]=G;const ee=H.shadow;if(H.map&&(r.spotLightMap[E]=H.map,E++,ee.updateMatrices(H),H.castShadow&&L++),r.spotLightMatrix[P]=ee.matrix,H.castShadow){const O=t.get(H);O.shadowIntensity=ee.intensity,O.shadowBias=ee.bias,O.shadowNormalBias=ee.normalBias,O.shadowRadius=ee.radius,O.shadowMapSize=ee.mapSize,r.spotShadow[P]=O,r.spotShadowMap[P]=te,F++}P++}else if(H.isRectAreaLight){const G=e.get(H);G.color.copy(W).multiplyScalar(ue),G.halfWidth.set(H.width*.5,0,0),G.halfHeight.set(0,H.height*.5,0),r.rectArea[U]=G,U++}else if(H.isPointLight){const G=e.get(H);if(G.color.copy(H.color).multiplyScalar(H.intensity),G.distance=H.distance,G.decay=H.decay,H.castShadow){const ee=H.shadow,O=t.get(H);O.shadowIntensity=ee.intensity,O.shadowBias=ee.bias,O.shadowNormalBias=ee.normalBias,O.shadowRadius=ee.radius,O.shadowMapSize=ee.mapSize,O.shadowCameraNear=ee.camera.near,O.shadowCameraFar=ee.camera.far,r.pointShadow[x]=O,r.pointShadowMap[x]=te,r.pointShadowMatrix[x]=H.shadow.matrix,N++}r.point[x]=G,x++}else if(H.isHemisphereLight){const G=e.get(H);G.skyColor.copy(H.color).multiplyScalar(ue),G.groundColor.copy(H.groundColor).multiplyScalar(ue),r.hemi[b]=G,b++}}U>0&&(s.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=Ke.LTC_FLOAT_1,r.rectAreaLTC2=Ke.LTC_FLOAT_2):(r.rectAreaLTC1=Ke.LTC_HALF_1,r.rectAreaLTC2=Ke.LTC_HALF_2)),r.ambient[0]=y,r.ambient[1]=S,r.ambient[2]=v;const X=r.hash;(X.sunLength!==_||X.directionalLength!==m||X.pointLength!==x||X.spotLength!==P||X.rectAreaLength!==U||X.hemiLength!==b||X.numSunShadows!==M||X.numDirectionalShadows!==R||X.numPointShadows!==N||X.numSpotShadows!==F||X.numSpotMaps!==E||X.numLightProbes!==B)&&(r.sun.length=_,r.directional.length=m,r.spot.length=P,r.rectArea.length=U,r.point.length=x,r.hemi.length=b,r.sunShadow.length=M,r.sunShadowMap.length=M,r.sunShadowMatrix.length=A,r.sunShadowCascade.length=A,r.directionalShadow.length=R,r.directionalShadowMap.length=R,r.directionalShadowMatrix.length=R,r.pointShadow.length=N,r.pointShadowMap.length=N,r.pointShadowMatrix.length=N,r.spotShadow.length=F,r.spotShadowMap.length=F,r.spotLightMatrix.length=F+E-L,r.spotLightMap.length=E,r.numSpotLightShadowsWithMaps=L,r.numLightProbes=B,X.sunLength=_,X.directionalLength=m,X.pointLength=x,X.spotLength=P,X.rectAreaLength=U,X.hemiLength=b,X.numSunShadows=M,X.numDirectionalShadows=R,X.numPointShadows=N,X.numSpotShadows=F,X.numSpotMaps=E,X.numLightProbes=B,r.version=MT++)}function f(p,y){let S=0,v=0,_=0,M=0,A=0,m=0;const x=y.matrixWorldInverse;for(let P=0,U=p.length;P<U;P++){const b=p[P];if(b.isSunLight){const R=r.sun[S];R.direction.setFromMatrixPosition(b.matrixWorld),R.direction.transformDirection(x),S++}else if(b.isDirectionalLight){const R=r.directional[v];R.direction.setFromMatrixPosition(b.matrixWorld),o.setFromMatrixPosition(b.target.matrixWorld),R.direction.sub(o),R.direction.transformDirection(x),v++}else if(b.isSpotLight){const R=r.spot[M];R.position.setFromMatrixPosition(b.matrixWorld),R.position.applyMatrix4(x),R.direction.setFromMatrixPosition(b.matrixWorld),o.setFromMatrixPosition(b.target.matrixWorld),R.direction.sub(o),R.direction.transformDirection(x),M++}else if(b.isRectAreaLight){const R=r.rectArea[A];R.position.setFromMatrixPosition(b.matrixWorld),R.position.applyMatrix4(x),u.identity(),l.copy(b.matrixWorld),l.premultiply(x),u.extractRotation(l),R.halfWidth.set(b.width*.5,0,0),R.halfHeight.set(0,b.height*.5,0),R.halfWidth.applyMatrix4(u),R.halfHeight.applyMatrix4(u),A++}else if(b.isPointLight){const R=r.point[_];R.position.setFromMatrixPosition(b.matrixWorld),R.position.applyMatrix4(x),_++}else if(b.isHemisphereLight){const R=r.hemi[m];R.direction.setFromMatrixPosition(b.matrixWorld),R.direction.transformDirection(x),m++}}}return{setup:d,setupView:f,state:r}}function L0(s){const e=new wT(s),t=[],r=[],o=[];function l(v){S.camera=v,t.length=0,r.length=0,o.length=0}function u(v){t.push(v)}function d(v){r.push(v)}function f(v){o.push(v)}function p(){e.setup(t)}function y(v){e.setupView(t,v)}const S={lightsArray:t,shadowsArray:r,lightProbeGridArray:o,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:l,state:S,setupLights:p,setupLightsView:y,pushLight:u,pushShadow:d,pushLightProbeGrid:f}}function TT(s){let e=new WeakMap;function t(o,l=0){const u=e.get(o);let d;return u===void 0?(d=new L0(s),e.set(o,[d])):l>=u.length?(d=new L0(s),u.push(d)):d=u[l],d}function r(){e=new WeakMap}return{get:t,dispose:r}}const AT=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,bT=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,CT=[new Z(1,0,0),new Z(-1,0,0),new Z(0,1,0),new Z(0,-1,0),new Z(0,0,1),new Z(0,0,-1)],RT=[new Z(0,-1,0),new Z(0,-1,0),new Z(0,0,1),new Z(0,0,-1),new Z(0,-1,0),new Z(0,-1,0)],N0=new Yt,Ia=new Z,mf=new Z;function PT(s,e,t){let r=new Lh;const o=new dt,l=new dt,u=new an,d=new O1,f=new k1,p={},y=t.maxTextureSize,S={[Ds]:Jn,[Jn]:Ds,[zi]:zi},v=new ar({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new dt},radius:{value:4}},vertexShader:AT,fragmentShader:bT}),_=v.clone();_.defines.HORIZONTAL_PASS=1;const M=new dn;M.setAttribute("position",new jn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const A=new Sn(M,v),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ac;let x=this.type;this.render=function(N,F,E){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||N.length===0)return;this.type===g_&&(ht("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Ac);const L=s.getRenderTarget(),B=s.getActiveCubeFace(),X=s.getActiveMipmapLevel(),j=s.state;j.setBlending(Cr),j.buffers.depth.getReversed()===!0?j.buffers.color.setClear(0,0,0,0):j.buffers.color.setClear(1,1,1,1),j.buffers.depth.setTest(!0),j.setScissorTest(!1);const ne=x!==this.type;ne&&F.traverse(function(H){H.material&&(Array.isArray(H.material)?H.material.forEach(W=>W.needsUpdate=!0):H.material.needsUpdate=!0)});for(let H=0,W=N.length;H<W;H++){const ue=N[H],Q=ue.shadow;if(Q===void 0){ht("WebGLShadowMap:",ue,"has no shadow.");continue}if(Q.autoUpdate===!1&&Q.needsUpdate===!1)continue;o.copy(Q.mapSize);const te=Q.getFrameExtents();o.multiply(te),l.copy(Q.mapSize),(o.x>y||o.y>y)&&(o.x>y&&(l.x=Math.floor(y/te.x),o.x=l.x*te.x,Q.mapSize.x=l.x),o.y>y&&(l.y=Math.floor(y/te.y),o.y=l.y*te.y,Q.mapSize.y=l.y));const G=s.state.buffers.depth.getReversed();if(Q.camera._reversedDepth=G,Q.map===null||ne===!0){if(Q.map!==null&&(Q.map.depthTexture!==null&&(Q.map.depthTexture.dispose(),Q.map.depthTexture=null),Q.map.dispose()),this.type===La){if(ue.isPointLight){ht("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}Q.map=new Wi(o.x,o.y,{format:Fs,type:or,minFilter:Yn,magFilter:Yn,generateMipmaps:!1}),Q.map.texture.name=ue.name+".shadowMap",Q.map.depthTexture=new ja(o.x,o.y,Hi),Q.map.depthTexture.name=ue.name+".shadowMapDepth",Q.map.depthTexture.format=Pr,Q.map.depthTexture.compareFunction=null,Q.map.depthTexture.minFilter=Un,Q.map.depthTexture.magFilter=Un}else ue.isPointLight?(Q.map=new Dv(o.x),Q.map.depthTexture=new T1(o.x,sr)):(Q.map=new Wi(o.x,o.y),Q.map.depthTexture=new ja(o.x,o.y,sr)),Q.map.depthTexture.name=ue.name+".shadowMap",Q.map.depthTexture.format=Pr,this.type===Ac?(Q.map.depthTexture.compareFunction=G?Ch:bh,Q.map.depthTexture.minFilter=Yn,Q.map.depthTexture.magFilter=Yn):(Q.map.depthTexture.compareFunction=null,Q.map.depthTexture.minFilter=Un,Q.map.depthTexture.magFilter=Un);Q.camera.updateProjectionMatrix()}Q.map.isWebGLCubeRenderTarget!==!0&&(Q.map.width!==o.x||Q.map.height!==o.y)&&Q.map.setSize(o.x,o.y);const ee=Q.map.isWebGLCubeRenderTarget?6:Q.getViewportCount();ue.isPointLight!==!0&&Q.updateMatrices(ue,E);for(let O=0;O<ee;O++){const de=Q.getCamera(O);if(ue.isPointLight){const Ce=Q.camera,Te=Q.matrix,De=ue.distance||Ce.far;De!==Ce.far&&(Ce.far=De,Ce.updateProjectionMatrix()),Ia.setFromMatrixPosition(ue.matrixWorld),Ce.position.copy(Ia),mf.copy(Ce.position),mf.add(CT[O]),Ce.up.copy(RT[O]),Ce.lookAt(mf),Ce.updateMatrixWorld(),Te.makeTranslation(-Ia.x,-Ia.y,-Ia.z),N0.multiplyMatrices(Ce.projectionMatrix,Ce.matrixWorldInverse),Q._frustum.setFromProjectionMatrix(N0,Ce.coordinateSystem,Ce.reversedDepth)}if(Q.map.isWebGLCubeRenderTarget)s.setRenderTarget(Q.map,O),s.clear();else{O===0&&(s.setRenderTarget(Q.map),s.clear());const Ce=Q.getViewport(O);u.set(l.x*Ce.x,l.y*Ce.y,l.x*Ce.z,l.y*Ce.w),j.viewport(u)}r=Q.getFrustum(O),b(F,E,de,ue,this.type)}Q.isPointLightShadow!==!0&&this.type===La&&P(Q,E),Q.needsUpdate=!1}x=this.type,m.needsUpdate=!1,s.setRenderTarget(L,B,X)};function P(N,F){const E=e.update(A);v.defines.VSM_SAMPLES!==N.blurSamples&&(v.defines.VSM_SAMPLES=N.blurSamples,_.defines.VSM_SAMPLES=N.blurSamples,v.needsUpdate=!0,_.needsUpdate=!0),N.mapPass===null?N.mapPass=new Wi(o.x,o.y,{format:Fs,type:or}):(N.mapPass.width!==N.map.width||N.mapPass.height!==N.map.height)&&N.mapPass.setSize(N.map.width,N.map.height),v.uniforms.shadow_pass.value=N.map.depthTexture,v.uniforms.resolution.value.set(N.map.width,N.map.height),v.uniforms.radius.value=N.radius,s.setRenderTarget(N.mapPass),s.clear(),s.renderBufferDirect(F,null,E,v,A,null),_.uniforms.shadow_pass.value=N.mapPass.texture,_.uniforms.resolution.value.set(N.map.width,N.map.height),_.uniforms.radius.value=N.radius,s.setRenderTarget(N.map),s.clear(),s.renderBufferDirect(F,null,E,_,A,null)}function U(N,F,E,L){let B=null;const X=E.isPointLight===!0?N.customDistanceMaterial:N.customDepthMaterial;if(X!==void 0)B=X;else if(B=E.isPointLight===!0?f:d,s.localClippingEnabled&&F.clipShadows===!0&&Array.isArray(F.clippingPlanes)&&F.clippingPlanes.length!==0||F.displacementMap&&F.displacementScale!==0||F.alphaMap&&F.alphaTest>0||F.map&&F.alphaTest>0||F.alphaToCoverage===!0){const j=B.uuid,ne=F.uuid;let H=p[j];H===void 0&&(H={},p[j]=H);let W=H[ne];W===void 0&&(W=B.clone(),H[ne]=W,F.addEventListener("dispose",R)),B=W}if(B.visible=F.visible,B.wireframe=F.wireframe,L===La?B.side=F.shadowSide!==null?F.shadowSide:F.side:B.side=F.shadowSide!==null?F.shadowSide:S[F.side],B.alphaMap=F.alphaMap,B.alphaTest=F.alphaToCoverage===!0?.5:F.alphaTest,B.map=F.map,B.clipShadows=F.clipShadows,B.clippingPlanes=F.clippingPlanes,B.clipIntersection=F.clipIntersection,B.displacementMap=F.displacementMap,B.displacementScale=F.displacementScale,B.displacementBias=F.displacementBias,B.wireframeLinewidth=F.wireframeLinewidth,B.linewidth=F.linewidth,E.isPointLight===!0&&B.isMeshDistanceMaterial===!0){const j=s.properties.get(B);j.light=E}return B}function b(N,F,E,L,B){if(N.visible===!1)return;if(N.layers.test(F.layers)&&(N.isMesh||N.isLine||N.isPoints)&&(N.castShadow||N.receiveShadow&&B===La)&&(!N.frustumCulled||N.intersectsFrustum(r))){N.modelViewMatrix.multiplyMatrices(E.matrixWorldInverse,N.matrixWorld);const ne=e.update(N),H=N.material;if(Array.isArray(H)){const W=ne.groups;for(let ue=0,Q=W.length;ue<Q;ue++){const te=W[ue],G=H[te.materialIndex];if(G&&G.visible){const ee=U(N,G,L,B);N.onBeforeShadow(s,N,F,E,ne,ee,te),s.renderBufferDirect(E,null,ne,ee,N,te),N.onAfterShadow(s,N,F,E,ne,ee,te)}}}else if(H.visible){const W=U(N,H,L,B);N.onBeforeShadow(s,N,F,E,ne,W,null),s.renderBufferDirect(E,null,ne,W,N,null),N.onAfterShadow(s,N,F,E,ne,W,null)}}const j=N.children;for(let ne=0,H=j.length;ne<H;ne++)b(j[ne],F,E,L,B)}function R(N){N.target.removeEventListener("dispose",R);for(const E in p){const L=p[E],B=N.target.uuid;B in L&&(L[B].dispose(),delete L[B])}}}function IT(s,e){function t(){let V=!1;const Oe=new an;let Se=null;const Ve=new an(0,0,0,0);return{setMask:function(Ge){Se!==Ge&&!V&&(s.colorMask(Ge,Ge,Ge,Ge),Se=Ge)},setLocked:function(Ge){V=Ge},setClear:function(Ge,we,rt,$e,Ut){Ut===!0&&(Ge*=$e,we*=$e,rt*=$e),Oe.set(Ge,we,rt,$e),Ve.equals(Oe)===!1&&(s.clearColor(Ge,we,rt,$e),Ve.copy(Oe))},reset:function(){V=!1,Se=null,Ve.set(-1,0,0,0)}}}function r(){let V=!1,Oe=!1,Se=null,Ve=null,Ge=null;return{setReversed:function(we){if(Oe!==we){const rt=e.get("EXT_clip_control");we?rt.clipControlEXT(rt.LOWER_LEFT_EXT,rt.ZERO_TO_ONE_EXT):rt.clipControlEXT(rt.LOWER_LEFT_EXT,rt.NEGATIVE_ONE_TO_ONE_EXT),Oe=we;const $e=Ge;Ge=null,this.setClear($e)}},getReversed:function(){return Oe},setTest:function(we){we?ge(s.DEPTH_TEST):Ne(s.DEPTH_TEST)},setMask:function(we){Se!==we&&!V&&(s.depthMask(we),Se=we)},setFunc:function(we){if(Oe&&(we=Z_[we]),Ve!==we){switch(we){case Sf:s.depthFunc(s.NEVER);break;case Mf:s.depthFunc(s.ALWAYS);break;case Ef:s.depthFunc(s.LESS);break;case Va:s.depthFunc(s.LEQUAL);break;case wf:s.depthFunc(s.EQUAL);break;case Tf:s.depthFunc(s.GEQUAL);break;case Af:s.depthFunc(s.GREATER);break;case bf:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}Ve=we}},setLocked:function(we){V=we},setClear:function(we){Ge!==we&&(Ge=we,Oe&&(we=1-we),s.clearDepth(we))},reset:function(){V=!1,Se=null,Ve=null,Ge=null,Oe=!1}}}function o(){let V=!1,Oe=null,Se=null,Ve=null,Ge=null,we=null,rt=null,$e=null,Ut=null;return{setTest:function(bt){V||(bt?ge(s.STENCIL_TEST):Ne(s.STENCIL_TEST))},setMask:function(bt){Oe!==bt&&!V&&(s.stencilMask(bt),Oe=bt)},setFunc:function(bt,fn,ei){(Se!==bt||Ve!==fn||Ge!==ei)&&(s.stencilFunc(bt,fn,ei),Se=bt,Ve=fn,Ge=ei)},setOp:function(bt,fn,ei){(we!==bt||rt!==fn||$e!==ei)&&(s.stencilOp(bt,fn,ei),we=bt,rt=fn,$e=ei)},setLocked:function(bt){V=bt},setClear:function(bt){Ut!==bt&&(s.clearStencil(bt),Ut=bt)},reset:function(){V=!1,Oe=null,Se=null,Ve=null,Ge=null,we=null,rt=null,$e=null,Ut=null}}}const l=new t,u=new r,d=new o,f=new WeakMap,p=new WeakMap;let y={},S={},v={},_=new WeakMap,M=[],A=null,m=!1,x=null,P=null,U=null,b=null,R=null,N=null,F=null,E=new vt(0,0,0),L=0,B=!1,X=null,j=null,ne=null,H=null,W=null;const ue=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Q=!1,te=0;const G=s.getParameter(s.VERSION);G.indexOf("WebGL")!==-1?(te=parseFloat(/^WebGL (\d)/.exec(G)[1]),Q=te>=1):G.indexOf("OpenGL ES")!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(G)[1]),Q=te>=2);let ee=null,O={};const de=s.getParameter(s.SCISSOR_BOX),Ce=s.getParameter(s.VIEWPORT),Te=new an().fromArray(de),De=new an().fromArray(Ce);function Ye(V,Oe,Se,Ve){const Ge=new Uint8Array(4),we=s.createTexture();s.bindTexture(V,we),s.texParameteri(V,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(V,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let rt=0;rt<Se;rt++)V===s.TEXTURE_3D||V===s.TEXTURE_2D_ARRAY?s.texImage3D(Oe,0,s.RGBA,1,1,Ve,0,s.RGBA,s.UNSIGNED_BYTE,Ge):s.texImage2D(Oe+rt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,Ge);return we}const le={};le[s.TEXTURE_2D]=Ye(s.TEXTURE_2D,s.TEXTURE_2D,1),le[s.TEXTURE_CUBE_MAP]=Ye(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),le[s.TEXTURE_2D_ARRAY]=Ye(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),le[s.TEXTURE_3D]=Ye(s.TEXTURE_3D,s.TEXTURE_3D,1,1),l.setClear(0,0,0,1),u.setClear(1),d.setClear(0),ge(s.DEPTH_TEST),u.setFunc(Va),xt(!1),At(Tg),ge(s.CULL_FACE),Et(Cr);function ge(V){y[V]!==!0&&(s.enable(V),y[V]=!0)}function Ne(V){y[V]!==!1&&(s.disable(V),y[V]=!1)}function tt(V,Oe){return v[V]!==Oe?(s.bindFramebuffer(V,Oe),v[V]=Oe,V===s.DRAW_FRAMEBUFFER&&(v[s.FRAMEBUFFER]=Oe),V===s.FRAMEBUFFER&&(v[s.DRAW_FRAMEBUFFER]=Oe),!0):!1}function Xe(V,Oe){let Se=M,Ve=!1;if(V){Se=_.get(Oe),Se===void 0&&(Se=[],_.set(Oe,Se));const Ge=V.textures;if(Se.length!==Ge.length||Se[0]!==s.COLOR_ATTACHMENT0){for(let we=0,rt=Ge.length;we<rt;we++)Se[we]=s.COLOR_ATTACHMENT0+we;Se.length=Ge.length,Ve=!0}}else Se[0]!==s.BACK&&(Se[0]=s.BACK,Ve=!0);Ve&&s.drawBuffers(Se)}function mt(V){return A!==V?(s.useProgram(V),A=V,!0):!1}const Gt={[Co]:s.FUNC_ADD,[x_]:s.FUNC_SUBTRACT,[y_]:s.FUNC_REVERSE_SUBTRACT};Gt[__]=s.MIN,Gt[S_]=s.MAX;const lt={[M_]:s.ZERO,[E_]:s.ONE,[w_]:s.SRC_COLOR,[sv]:s.SRC_ALPHA,[P_]:s.SRC_ALPHA_SATURATE,[C_]:s.DST_COLOR,[A_]:s.DST_ALPHA,[T_]:s.ONE_MINUS_SRC_COLOR,[ov]:s.ONE_MINUS_SRC_ALPHA,[R_]:s.ONE_MINUS_DST_COLOR,[b_]:s.ONE_MINUS_DST_ALPHA,[I_]:s.CONSTANT_COLOR,[L_]:s.ONE_MINUS_CONSTANT_COLOR,[N_]:s.CONSTANT_ALPHA,[D_]:s.ONE_MINUS_CONSTANT_ALPHA};function Et(V,Oe,Se,Ve,Ge,we,rt,$e,Ut,bt){if(V===Cr){m===!0&&(Ne(s.BLEND),m=!1);return}if(m===!1&&(ge(s.BLEND),m=!0),V!==v_){if(V!==x||bt!==B){if((P!==Co||R!==Co)&&(s.blendEquation(s.FUNC_ADD),P=Co,R=Co),bt)switch(V){case Ua:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Ps:s.blendFunc(s.ONE,s.ONE);break;case Ag:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case bg:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:zt("WebGLState: Invalid blending: ",V);break}else switch(V){case Ua:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Ps:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case Ag:zt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case bg:zt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:zt("WebGLState: Invalid blending: ",V);break}U=null,b=null,N=null,F=null,E.set(0,0,0),L=0,x=V,B=bt}return}Ge=Ge||Oe,we=we||Se,rt=rt||Ve,(Oe!==P||Ge!==R)&&(s.blendEquationSeparate(Gt[Oe],Gt[Ge]),P=Oe,R=Ge),(Se!==U||Ve!==b||we!==N||rt!==F)&&(s.blendFuncSeparate(lt[Se],lt[Ve],lt[we],lt[rt]),U=Se,b=Ve,N=we,F=rt),($e.equals(E)===!1||Ut!==L)&&(s.blendColor($e.r,$e.g,$e.b,Ut),E.copy($e),L=Ut),x=V,B=!1}function Ot(V,Oe){V.side===zi?Ne(s.CULL_FACE):ge(s.CULL_FACE);let Se=V.side===Jn;Oe&&(Se=!Se),xt(Se),V.blending===Ua&&V.transparent===!1?Et(Cr):Et(V.blending,V.blendEquation,V.blendSrc,V.blendDst,V.blendEquationAlpha,V.blendSrcAlpha,V.blendDstAlpha,V.blendColor,V.blendAlpha,V.premultipliedAlpha),u.setFunc(V.depthFunc),u.setTest(V.depthTest),u.setMask(V.depthWrite),l.setMask(V.colorWrite);const Ve=V.stencilWrite;d.setTest(Ve),Ve&&(d.setMask(V.stencilWriteMask),d.setFunc(V.stencilFunc,V.stencilRef,V.stencilFuncMask),d.setOp(V.stencilFail,V.stencilZFail,V.stencilZPass)),Wt(V.polygonOffset,V.polygonOffsetFactor,V.polygonOffsetUnits),V.alphaToCoverage===!0?ge(s.SAMPLE_ALPHA_TO_COVERAGE):Ne(s.SAMPLE_ALPHA_TO_COVERAGE)}function xt(V){X!==V&&(V?s.frontFace(s.CW):s.frontFace(s.CCW),X=V)}function At(V){V!==p_?(ge(s.CULL_FACE),V!==j&&(V===Tg?s.cullFace(s.BACK):V===m_?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):Ne(s.CULL_FACE),j=V}function Xt(V){V!==ne&&(Q&&s.lineWidth(V),ne=V)}function Wt(V,Oe,Se){V?(ge(s.POLYGON_OFFSET_FILL),(H!==Oe||W!==Se)&&(H=Oe,W=Se,u.getReversed()&&(Oe=-Oe),s.polygonOffset(Oe,Se))):Ne(s.POLYGON_OFFSET_FILL)}function _t(V){V?ge(s.SCISSOR_TEST):Ne(s.SCISSOR_TEST)}function Nt(V){V===void 0&&(V=s.TEXTURE0+ue-1),ee!==V&&(s.activeTexture(V),ee=V)}function $(V,Oe,Se){Se===void 0&&(ee===null?Se=s.TEXTURE0+ue-1:Se=ee);let Ve=O[Se];Ve===void 0&&(Ve={type:void 0,texture:void 0},O[Se]=Ve),(Ve.type!==V||Ve.texture!==Oe)&&(ee!==Se&&(s.activeTexture(Se),ee=Se),s.bindTexture(V,Oe||le[V]),Ve.type=V,Ve.texture=Oe)}function It(){const V=O[ee];V!==void 0&&V.type!==void 0&&(s.bindTexture(V.type,null),V.type=void 0,V.texture=void 0)}function wt(){try{s.compressedTexImage2D(...arguments)}catch(V){zt("WebGLState:",V)}}function k(){try{s.compressedTexImage3D(...arguments)}catch(V){zt("WebGLState:",V)}}function w(){try{s.texSubImage2D(...arguments)}catch(V){zt("WebGLState:",V)}}function re(){try{s.texSubImage3D(...arguments)}catch(V){zt("WebGLState:",V)}}function he(){try{s.compressedTexSubImage2D(...arguments)}catch(V){zt("WebGLState:",V)}}function ye(){try{s.compressedTexSubImage3D(...arguments)}catch(V){zt("WebGLState:",V)}}function Pe(){try{s.texStorage2D(...arguments)}catch(V){zt("WebGLState:",V)}}function fe(){try{s.texStorage3D(...arguments)}catch(V){zt("WebGLState:",V)}}function ie(){try{s.texImage2D(...arguments)}catch(V){zt("WebGLState:",V)}}function se(){try{s.texImage3D(...arguments)}catch(V){zt("WebGLState:",V)}}function be(V){return S[V]!==void 0?S[V]:s.getParameter(V)}function Fe(V,Oe){S[V]!==Oe&&(s.pixelStorei(V,Oe),S[V]=Oe)}function ve(V){Te.equals(V)===!1&&(s.scissor(V.x,V.y,V.z,V.w),Te.copy(V))}function Ee(V){De.equals(V)===!1&&(s.viewport(V.x,V.y,V.z,V.w),De.copy(V))}function K(V,Oe){let Se=p.get(Oe);Se===void 0&&(Se=new WeakMap,p.set(Oe,Se));let Ve=Se.get(V);Ve===void 0&&(Ve=s.getUniformBlockIndex(Oe,V.name),Se.set(V,Ve))}function Ue(V,Oe){const Ve=p.get(Oe).get(V);f.get(Oe)!==Ve&&(s.uniformBlockBinding(Oe,Ve,V.__bindingPointIndex),f.set(Oe,Ve))}function _e(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),u.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),s.pixelStorei(s.PACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,!1),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,s.BROWSER_DEFAULT_WEBGL),s.pixelStorei(s.PACK_ROW_LENGTH,0),s.pixelStorei(s.PACK_SKIP_PIXELS,0),s.pixelStorei(s.PACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_ROW_LENGTH,0),s.pixelStorei(s.UNPACK_IMAGE_HEIGHT,0),s.pixelStorei(s.UNPACK_SKIP_PIXELS,0),s.pixelStorei(s.UNPACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_SKIP_IMAGES,0),y={},S={},ee=null,O={},v={},_=new WeakMap,M=[],A=null,m=!1,x=null,P=null,U=null,b=null,R=null,N=null,F=null,E=new vt(0,0,0),L=0,B=!1,X=null,j=null,ne=null,H=null,W=null,Te.set(0,0,s.canvas.width,s.canvas.height),De.set(0,0,s.canvas.width,s.canvas.height),l.reset(),u.reset(),d.reset()}return{buffers:{color:l,depth:u,stencil:d},enable:ge,disable:Ne,bindFramebuffer:tt,drawBuffers:Xe,useProgram:mt,setBlending:Et,setMaterial:Ot,setFlipSided:xt,setCullFace:At,setLineWidth:Xt,setPolygonOffset:Wt,setScissorTest:_t,activeTexture:Nt,bindTexture:$,unbindTexture:It,compressedTexImage2D:wt,compressedTexImage3D:k,texImage2D:ie,texImage3D:se,pixelStorei:Fe,getParameter:be,updateUBOMapping:K,uniformBlockBinding:Ue,texStorage2D:Pe,texStorage3D:fe,texSubImage2D:w,texSubImage3D:re,compressedTexSubImage2D:he,compressedTexSubImage3D:ye,scissor:ve,viewport:Ee,reset:_e}}function LT(s,e,t,r,o,l,u){const d=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,f=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),p=new dt,y=new WeakMap,S=new Set;let v;const _=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function A(k,w){return M?new OffscreenCanvas(k,w):Hc("canvas")}function m(k,w,re){let he=1;const ye=wt(k);if((ye.width>re||ye.height>re)&&(he=re/Math.max(ye.width,ye.height)),he<1)if(typeof HTMLImageElement<"u"&&k instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&k instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&k instanceof ImageBitmap||typeof VideoFrame<"u"&&k instanceof VideoFrame){const Pe=Math.floor(he*ye.width),fe=Math.floor(he*ye.height);v===void 0&&(v=A(Pe,fe));const ie=w?A(Pe,fe):v;return ie.width=Pe,ie.height=fe,ie.getContext("2d").drawImage(k,0,0,Pe,fe),ht("WebGLRenderer: Texture has been resized from ("+ye.width+"x"+ye.height+") to ("+Pe+"x"+fe+")."),ie}else return"data"in k&&ht("WebGLRenderer: Image in DataTexture is too big ("+ye.width+"x"+ye.height+")."),k;return k}function x(k){return k.generateMipmaps}function P(k){s.generateMipmap(k)}function U(k){return k.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:k.isWebGL3DRenderTarget?s.TEXTURE_3D:k.isWebGLArrayRenderTarget||k.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function b(k,w,re,he,ye,Pe=!1){if(k!==null){if(s[k]!==void 0)return s[k];ht("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+k+"'")}let fe;he&&(fe=e.get("EXT_texture_norm16"),fe||ht("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ie=w;if(w===s.RED&&(re===s.FLOAT&&(ie=s.R32F),re===s.HALF_FLOAT&&(ie=s.R16F),re===s.UNSIGNED_BYTE&&(ie=s.R8),re===s.UNSIGNED_SHORT&&fe&&(ie=fe.R16_EXT),re===s.SHORT&&fe&&(ie=fe.R16_SNORM_EXT)),w===s.RED_INTEGER&&(re===s.UNSIGNED_BYTE&&(ie=s.R8UI),re===s.UNSIGNED_SHORT&&(ie=s.R16UI),re===s.UNSIGNED_INT&&(ie=s.R32UI),re===s.BYTE&&(ie=s.R8I),re===s.SHORT&&(ie=s.R16I),re===s.INT&&(ie=s.R32I)),w===s.RG&&(re===s.FLOAT&&(ie=s.RG32F),re===s.HALF_FLOAT&&(ie=s.RG16F),re===s.UNSIGNED_BYTE&&(ie=s.RG8),re===s.UNSIGNED_SHORT&&fe&&(ie=fe.RG16_EXT),re===s.SHORT&&fe&&(ie=fe.RG16_SNORM_EXT)),w===s.RG_INTEGER&&(re===s.UNSIGNED_BYTE&&(ie=s.RG8UI),re===s.UNSIGNED_SHORT&&(ie=s.RG16UI),re===s.UNSIGNED_INT&&(ie=s.RG32UI),re===s.BYTE&&(ie=s.RG8I),re===s.SHORT&&(ie=s.RG16I),re===s.INT&&(ie=s.RG32I)),w===s.RGB_INTEGER&&(re===s.UNSIGNED_BYTE&&(ie=s.RGB8UI),re===s.UNSIGNED_SHORT&&(ie=s.RGB16UI),re===s.UNSIGNED_INT&&(ie=s.RGB32UI),re===s.BYTE&&(ie=s.RGB8I),re===s.SHORT&&(ie=s.RGB16I),re===s.INT&&(ie=s.RGB32I)),w===s.RGBA_INTEGER&&(re===s.UNSIGNED_BYTE&&(ie=s.RGBA8UI),re===s.UNSIGNED_SHORT&&(ie=s.RGBA16UI),re===s.UNSIGNED_INT&&(ie=s.RGBA32UI),re===s.BYTE&&(ie=s.RGBA8I),re===s.SHORT&&(ie=s.RGBA16I),re===s.INT&&(ie=s.RGBA32I)),w===s.RGB&&(re===s.UNSIGNED_SHORT&&fe&&(ie=fe.RGB16_EXT),re===s.SHORT&&fe&&(ie=fe.RGB16_SNORM_EXT),re===s.UNSIGNED_INT_5_9_9_9_REV&&(ie=s.RGB9_E5),re===s.UNSIGNED_INT_10F_11F_11F_REV&&(ie=s.R11F_G11F_B10F)),w===s.RGBA){const se=Pe?Vc:Dt.getTransfer(ye);re===s.FLOAT&&(ie=s.RGBA32F),re===s.HALF_FLOAT&&(ie=s.RGBA16F),re===s.UNSIGNED_BYTE&&(ie=se===qt?s.SRGB8_ALPHA8:s.RGBA8),re===s.UNSIGNED_SHORT&&fe&&(ie=fe.RGBA16_EXT),re===s.SHORT&&fe&&(ie=fe.RGBA16_SNORM_EXT),re===s.UNSIGNED_SHORT_4_4_4_4&&(ie=s.RGBA4),re===s.UNSIGNED_SHORT_5_5_5_1&&(ie=s.RGB5_A1)}return(ie===s.R16F||ie===s.R32F||ie===s.RG16F||ie===s.RG32F||ie===s.RGBA16F||ie===s.RGBA32F)&&e.get("EXT_color_buffer_float"),ie}function R(k,w){let re;return k?w===null||w===sr||w===Ga?re=s.DEPTH24_STENCIL8:w===Hi?re=s.DEPTH32F_STENCIL8:w===Ha&&(re=s.DEPTH24_STENCIL8,ht("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):w===null||w===sr||w===Ga?re=s.DEPTH_COMPONENT24:w===Hi?re=s.DEPTH_COMPONENT32F:w===Ha&&(re=s.DEPTH_COMPONENT16),re}function N(k,w){return x(k)===!0||k.isFramebufferTexture&&k.minFilter!==Un&&k.minFilter!==Yn?Math.log2(Math.max(w.width,w.height))+1:k.mipmaps!==void 0&&k.mipmaps.length>0?k.mipmaps.length:k.isCompressedTexture&&Array.isArray(k.image)?w.mipmaps.length:1}function F(k){const w=k.target;w.removeEventListener("dispose",F),L(w),w.isVideoTexture&&y.delete(w),w.isHTMLTexture&&S.delete(w)}function E(k){const w=k.target;w.removeEventListener("dispose",E),X(w)}function L(k){const w=r.get(k);if(w.__webglInit===void 0)return;const re=k.source,he=_.get(re);if(he){const ye=he[w.__cacheKey];ye.usedTimes--,ye.usedTimes===0&&B(k),Object.keys(he).length===0&&_.delete(re)}r.remove(k)}function B(k){const w=r.get(k);s.deleteTexture(w.__webglTexture);const re=k.source,he=_.get(re);delete he[w.__cacheKey],u.memory.textures--}function X(k){const w=r.get(k);if(k.depthTexture&&(k.depthTexture.dispose(),r.remove(k.depthTexture)),k.isWebGLCubeRenderTarget)for(let he=0;he<6;he++){if(Array.isArray(w.__webglFramebuffer[he]))for(let ye=0;ye<w.__webglFramebuffer[he].length;ye++)s.deleteFramebuffer(w.__webglFramebuffer[he][ye]);else s.deleteFramebuffer(w.__webglFramebuffer[he]);w.__webglDepthbuffer&&s.deleteRenderbuffer(w.__webglDepthbuffer[he])}else{if(Array.isArray(w.__webglFramebuffer))for(let he=0;he<w.__webglFramebuffer.length;he++)s.deleteFramebuffer(w.__webglFramebuffer[he]);else s.deleteFramebuffer(w.__webglFramebuffer);if(w.__webglDepthbuffer&&s.deleteRenderbuffer(w.__webglDepthbuffer),w.__webglMultisampledFramebuffer&&s.deleteFramebuffer(w.__webglMultisampledFramebuffer),w.__webglColorRenderbuffer)for(let he=0;he<w.__webglColorRenderbuffer.length;he++)w.__webglColorRenderbuffer[he]&&s.deleteRenderbuffer(w.__webglColorRenderbuffer[he]);w.__webglDepthRenderbuffer&&s.deleteRenderbuffer(w.__webglDepthRenderbuffer)}const re=k.textures;for(let he=0,ye=re.length;he<ye;he++){const Pe=r.get(re[he]);Pe.__webglTexture&&(s.deleteTexture(Pe.__webglTexture),u.memory.textures--),r.remove(re[he])}r.remove(k)}let j=0;function ne(){j=0}function H(){return j}function W(k){j=k}function ue(){const k=j;return k>=o.maxTextures&&ht("WebGLTextures: Trying to use "+(k+1)+" texture units while this GPU supports only "+o.maxTextures),j+=1,k}function Q(k){const w=[];return w.push(k.wrapS),w.push(k.wrapT),w.push(k.wrapR||0),w.push(k.magFilter),w.push(k.minFilter),w.push(k.anisotropy),w.push(k.internalFormat),w.push(k.format),w.push(k.type),w.push(k.generateMipmaps),w.push(k.premultiplyAlpha),w.push(k.flipY),w.push(k.unpackAlignment),w.push(k.colorSpace),w.join()}function te(k,w){const re=r.get(k);if(k.isVideoTexture&&$(k),k.isRenderTargetTexture===!1&&k.isExternalTexture!==!0&&k.version>0&&re.__version!==k.version){const he=k.image;if(he===null)ht("WebGLRenderer: Texture marked for update but no image data found.");else if(he.complete===!1)ht("WebGLRenderer: Texture marked for update but image is incomplete");else{Ne(re,k,w);return}}else k.isExternalTexture&&(re.__webglTexture=k.sourceTexture?k.sourceTexture:null);t.bindTexture(s.TEXTURE_2D,re.__webglTexture,s.TEXTURE0+w)}function G(k,w){const re=r.get(k);if(k.isRenderTargetTexture===!1&&k.version>0&&re.__version!==k.version){Ne(re,k,w);return}else k.isExternalTexture&&(re.__webglTexture=k.sourceTexture?k.sourceTexture:null);t.bindTexture(s.TEXTURE_2D_ARRAY,re.__webglTexture,s.TEXTURE0+w)}function ee(k,w){const re=r.get(k);if(k.isRenderTargetTexture===!1&&k.version>0&&re.__version!==k.version){Ne(re,k,w);return}t.bindTexture(s.TEXTURE_3D,re.__webglTexture,s.TEXTURE0+w)}function O(k,w){const re=r.get(k);if(k.isCubeDepthTexture!==!0&&k.version>0&&re.__version!==k.version){tt(re,k,w);return}t.bindTexture(s.TEXTURE_CUBE_MAP,re.__webglTexture,s.TEXTURE0+w)}const de={[Cf]:s.REPEAT,[br]:s.CLAMP_TO_EDGE,[Rf]:s.MIRRORED_REPEAT},Ce={[Un]:s.NEAREST,[O_]:s.NEAREST_MIPMAP_NEAREST,[Jl]:s.NEAREST_MIPMAP_LINEAR,[Yn]:s.LINEAR,[Fd]:s.LINEAR_MIPMAP_NEAREST,[Is]:s.LINEAR_MIPMAP_LINEAR},Te={[V_]:s.NEVER,[X_]:s.ALWAYS,[H_]:s.LESS,[bh]:s.LEQUAL,[G_]:s.EQUAL,[Ch]:s.GEQUAL,[W_]:s.GREATER,[j_]:s.NOTEQUAL};function De(k,w){if(w.type===Hi&&e.has("OES_texture_float_linear")===!1&&(w.magFilter===Yn||w.magFilter===Fd||w.magFilter===Jl||w.magFilter===Is||w.minFilter===Yn||w.minFilter===Fd||w.minFilter===Jl||w.minFilter===Is)&&ht("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(k,s.TEXTURE_WRAP_S,de[w.wrapS]),s.texParameteri(k,s.TEXTURE_WRAP_T,de[w.wrapT]),(k===s.TEXTURE_3D||k===s.TEXTURE_2D_ARRAY)&&s.texParameteri(k,s.TEXTURE_WRAP_R,de[w.wrapR]),s.texParameteri(k,s.TEXTURE_MAG_FILTER,Ce[w.magFilter]),s.texParameteri(k,s.TEXTURE_MIN_FILTER,Ce[w.minFilter]),w.compareFunction&&(s.texParameteri(k,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(k,s.TEXTURE_COMPARE_FUNC,Te[w.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(w.magFilter===Un||w.minFilter!==Jl&&w.minFilter!==Is||w.type===Hi&&e.has("OES_texture_float_linear")===!1)return;if(w.anisotropy>1||r.get(w).__currentAnisotropy){const re=e.get("EXT_texture_filter_anisotropic");s.texParameterf(k,re.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(w.anisotropy,o.getMaxAnisotropy())),r.get(w).__currentAnisotropy=w.anisotropy}}}function Ye(k,w){let re=!1;k.__webglInit===void 0&&(k.__webglInit=!0,w.addEventListener("dispose",F));const he=w.source;let ye=_.get(he);ye===void 0&&(ye={},_.set(he,ye));const Pe=Q(w);if(Pe!==k.__cacheKey){ye[Pe]===void 0&&(ye[Pe]={texture:s.createTexture(),usedTimes:0},u.memory.textures++,re=!0),ye[Pe].usedTimes++;const fe=ye[k.__cacheKey];fe!==void 0&&(ye[k.__cacheKey].usedTimes--,fe.usedTimes===0&&B(w)),k.__cacheKey=Pe,k.__webglTexture=ye[Pe].texture}return re}function le(k,w,re){return Math.floor(Math.floor(k/re)/w)}function ge(k,w,re,he){const Pe=k.updateRanges;if(Pe.length===0)t.texSubImage2D(s.TEXTURE_2D,0,0,0,w.width,w.height,re,he,w.data);else{Pe.sort((Fe,ve)=>Fe.start-ve.start);let fe=0;for(let Fe=1;Fe<Pe.length;Fe++){const ve=Pe[fe],Ee=Pe[Fe],K=ve.start+ve.count,Ue=le(Ee.start,w.width,4),_e=le(ve.start,w.width,4);Ee.start<=K+1&&Ue===_e&&le(Ee.start+Ee.count-1,w.width,4)===Ue?ve.count=Math.max(ve.count,Ee.start+Ee.count-ve.start):(++fe,Pe[fe]=Ee)}Pe.length=fe+1;const ie=t.getParameter(s.UNPACK_ROW_LENGTH),se=t.getParameter(s.UNPACK_SKIP_PIXELS),be=t.getParameter(s.UNPACK_SKIP_ROWS);t.pixelStorei(s.UNPACK_ROW_LENGTH,w.width);for(let Fe=0,ve=Pe.length;Fe<ve;Fe++){const Ee=Pe[Fe],K=Math.floor(Ee.start/4),Ue=Math.ceil(Ee.count/4),_e=K%w.width,V=Math.floor(K/w.width),Oe=Ue,Se=1;t.pixelStorei(s.UNPACK_SKIP_PIXELS,_e),t.pixelStorei(s.UNPACK_SKIP_ROWS,V),t.texSubImage2D(s.TEXTURE_2D,0,_e,V,Oe,Se,re,he,w.data)}k.clearUpdateRanges(),t.pixelStorei(s.UNPACK_ROW_LENGTH,ie),t.pixelStorei(s.UNPACK_SKIP_PIXELS,se),t.pixelStorei(s.UNPACK_SKIP_ROWS,be)}}function Ne(k,w,re){let he=s.TEXTURE_2D;(w.isDataArrayTexture||w.isCompressedArrayTexture)&&(he=s.TEXTURE_2D_ARRAY),w.isData3DTexture&&(he=s.TEXTURE_3D);const ye=Ye(k,w),Pe=w.source;t.bindTexture(he,k.__webglTexture,s.TEXTURE0+re);const fe=r.get(Pe);if(Pe.version!==fe.__version||ye===!0){if(t.activeTexture(s.TEXTURE0+re),(typeof ImageBitmap<"u"&&w.image instanceof ImageBitmap)===!1){const Se=Dt.getPrimaries(Dt.workingColorSpace),Ve=w.colorSpace===ss?null:Dt.getPrimaries(w.colorSpace),Ge=w.colorSpace===ss||Se===Ve?s.NONE:s.BROWSER_DEFAULT_WEBGL;t.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ge)}t.pixelStorei(s.UNPACK_ALIGNMENT,w.unpackAlignment);let se=m(w.image,!1,o.maxTextureSize);se=It(w,se);const be=l.convert(w.format,w.colorSpace),Fe=l.convert(w.type);let ve=b(w.internalFormat,be,Fe,w.normalized,w.colorSpace,w.isVideoTexture);De(he,w);let Ee;const K=w.mipmaps,Ue=w.isVideoTexture!==!0,_e=fe.__version===void 0||ye===!0,V=Pe.dataReady,Oe=N(w,se);if(w.isDepthTexture)ve=R(w.format===Ls,w.type),_e&&(Ue?t.texStorage2D(s.TEXTURE_2D,1,ve,se.width,se.height):t.texImage2D(s.TEXTURE_2D,0,ve,se.width,se.height,0,be,Fe,null));else if(w.isDataTexture)if(K.length>0){Ue&&_e&&t.texStorage2D(s.TEXTURE_2D,Oe,ve,K[0].width,K[0].height);for(let Se=0,Ve=K.length;Se<Ve;Se++)Ee=K[Se],Ue?V&&t.texSubImage2D(s.TEXTURE_2D,Se,0,0,Ee.width,Ee.height,be,Fe,Ee.data):t.texImage2D(s.TEXTURE_2D,Se,ve,Ee.width,Ee.height,0,be,Fe,Ee.data);w.generateMipmaps=!1}else Ue?(_e&&t.texStorage2D(s.TEXTURE_2D,Oe,ve,se.width,se.height),V&&ge(w,se,be,Fe)):t.texImage2D(s.TEXTURE_2D,0,ve,se.width,se.height,0,be,Fe,se.data);else if(w.isCompressedTexture)if(w.isCompressedArrayTexture){Ue&&_e&&t.texStorage3D(s.TEXTURE_2D_ARRAY,Oe,ve,K[0].width,K[0].height,se.depth);for(let Se=0,Ve=K.length;Se<Ve;Se++)if(Ee=K[Se],w.format!==Gi)if(be!==null)if(Ue){if(V)if(w.layerUpdates.size>0){const Ge=d0(Ee.width,Ee.height,w.format,w.type);for(const we of w.layerUpdates){const rt=Ee.data.subarray(we*Ge/Ee.data.BYTES_PER_ELEMENT,(we+1)*Ge/Ee.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,Se,0,0,we,Ee.width,Ee.height,1,be,rt)}}else t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,Se,0,0,0,Ee.width,Ee.height,se.depth,be,Ee.data)}else t.compressedTexImage3D(s.TEXTURE_2D_ARRAY,Se,ve,Ee.width,Ee.height,se.depth,0,Ee.data,0,0);else ht("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Ue?V&&t.texSubImage3D(s.TEXTURE_2D_ARRAY,Se,0,0,0,Ee.width,Ee.height,se.depth,be,Fe,Ee.data):t.texImage3D(s.TEXTURE_2D_ARRAY,Se,ve,Ee.width,Ee.height,se.depth,0,be,Fe,Ee.data);w.layerUpdates.size>0&&w.clearLayerUpdates()}else{Ue&&_e&&t.texStorage2D(s.TEXTURE_2D,Oe,ve,K[0].width,K[0].height);for(let Se=0,Ve=K.length;Se<Ve;Se++)Ee=K[Se],w.format!==Gi?be!==null?Ue?V&&t.compressedTexSubImage2D(s.TEXTURE_2D,Se,0,0,Ee.width,Ee.height,be,Ee.data):t.compressedTexImage2D(s.TEXTURE_2D,Se,ve,Ee.width,Ee.height,0,Ee.data):ht("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ue?V&&t.texSubImage2D(s.TEXTURE_2D,Se,0,0,Ee.width,Ee.height,be,Fe,Ee.data):t.texImage2D(s.TEXTURE_2D,Se,ve,Ee.width,Ee.height,0,be,Fe,Ee.data)}else if(w.isDataArrayTexture)if(Ue){if(_e&&t.texStorage3D(s.TEXTURE_2D_ARRAY,Oe,ve,se.width,se.height,se.depth),V)if(w.layerUpdates.size>0){const Se=d0(se.width,se.height,w.format,w.type);for(const Ve of w.layerUpdates){const Ge=se.data.subarray(Ve*Se/se.data.BYTES_PER_ELEMENT,(Ve+1)*Se/se.data.BYTES_PER_ELEMENT);t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,Ve,se.width,se.height,1,be,Fe,Ge)}w.clearLayerUpdates()}else t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,se.width,se.height,se.depth,be,Fe,se.data)}else t.texImage3D(s.TEXTURE_2D_ARRAY,0,ve,se.width,se.height,se.depth,0,be,Fe,se.data);else if(w.isData3DTexture)Ue?(_e&&t.texStorage3D(s.TEXTURE_3D,Oe,ve,se.width,se.height,se.depth),V&&t.texSubImage3D(s.TEXTURE_3D,0,0,0,0,se.width,se.height,se.depth,be,Fe,se.data)):t.texImage3D(s.TEXTURE_3D,0,ve,se.width,se.height,se.depth,0,be,Fe,se.data);else if(w.isFramebufferTexture){if(_e)if(Ue)t.texStorage2D(s.TEXTURE_2D,Oe,ve,se.width,se.height);else{let Se=se.width,Ve=se.height;for(let Ge=0;Ge<Oe;Ge++)t.texImage2D(s.TEXTURE_2D,Ge,ve,Se,Ve,0,be,Fe,null),Se>>=1,Ve>>=1}}else if(w.isHTMLTexture){if("texElementImage2D"in s){const Se=s.canvas;if(Se.hasAttribute("layoutsubtree")||Se.setAttribute("layoutsubtree","true"),se.parentNode!==Se){Se.appendChild(se),S.add(w),Se.onpaint=Ve=>{const Ge=Ve.changedElements;for(const we of S)Ge.includes(we.image)&&(we.needsUpdate=!0)},Se.requestPaint();return}if(s.texElementImage2D.length===3)s.texElementImage2D(s.TEXTURE_2D,s.RGBA8,se);else{const Ge=s.RGBA,we=s.RGBA,rt=s.UNSIGNED_BYTE;s.texElementImage2D(s.TEXTURE_2D,0,Ge,we,rt,se)}s.texParameteri(s.TEXTURE_2D,s.TEXTURE_MIN_FILTER,s.LINEAR),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE)}}else if(K.length>0){if(Ue&&_e){const Se=wt(K[0]);t.texStorage2D(s.TEXTURE_2D,Oe,ve,Se.width,Se.height)}for(let Se=0,Ve=K.length;Se<Ve;Se++)Ee=K[Se],Ue?V&&t.texSubImage2D(s.TEXTURE_2D,Se,0,0,be,Fe,Ee):t.texImage2D(s.TEXTURE_2D,Se,ve,be,Fe,Ee);w.generateMipmaps=!1}else if(Ue){if(_e){const Se=wt(se);t.texStorage2D(s.TEXTURE_2D,Oe,ve,Se.width,Se.height)}V&&t.texSubImage2D(s.TEXTURE_2D,0,0,0,be,Fe,se)}else t.texImage2D(s.TEXTURE_2D,0,ve,be,Fe,se);x(w)&&P(he),fe.__version=Pe.version,w.onUpdate&&w.onUpdate(w)}k.__version=w.version}function tt(k,w,re){if(w.image.length!==6)return;const he=Ye(k,w),ye=w.source;t.bindTexture(s.TEXTURE_CUBE_MAP,k.__webglTexture,s.TEXTURE0+re);const Pe=r.get(ye);if(ye.version!==Pe.__version||he===!0){t.activeTexture(s.TEXTURE0+re);const fe=Dt.getPrimaries(Dt.workingColorSpace),ie=w.colorSpace===ss?null:Dt.getPrimaries(w.colorSpace),se=w.colorSpace===ss||fe===ie?s.NONE:s.BROWSER_DEFAULT_WEBGL;t.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(s.UNPACK_ALIGNMENT,w.unpackAlignment),t.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,se);const be=w.isCompressedTexture||w.image[0].isCompressedTexture,Fe=w.image[0]&&w.image[0].isDataTexture,ve=[];for(let we=0;we<6;we++)!be&&!Fe?ve[we]=m(w.image[we],!0,o.maxCubemapSize):ve[we]=Fe?w.image[we].image:w.image[we],ve[we]=It(w,ve[we]);const Ee=ve[0],K=l.convert(w.format,w.colorSpace),Ue=l.convert(w.type),_e=b(w.internalFormat,K,Ue,w.normalized,w.colorSpace),V=w.isVideoTexture!==!0,Oe=Pe.__version===void 0||he===!0,Se=ye.dataReady;let Ve=N(w,Ee);De(s.TEXTURE_CUBE_MAP,w);let Ge;if(be){V&&Oe&&t.texStorage2D(s.TEXTURE_CUBE_MAP,Ve,_e,Ee.width,Ee.height);for(let we=0;we<6;we++){Ge=ve[we].mipmaps;for(let rt=0;rt<Ge.length;rt++){const $e=Ge[rt];w.format!==Gi?K!==null?V?Se&&t.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt,0,0,$e.width,$e.height,K,$e.data):t.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt,_e,$e.width,$e.height,0,$e.data):ht("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):V?Se&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt,0,0,$e.width,$e.height,K,Ue,$e.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt,_e,$e.width,$e.height,0,K,Ue,$e.data)}}}else{if(Ge=w.mipmaps,V&&Oe){Ge.length>0&&Ve++;const we=wt(ve[0]);t.texStorage2D(s.TEXTURE_CUBE_MAP,Ve,_e,we.width,we.height)}for(let we=0;we<6;we++)if(Fe){V?Se&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,0,0,0,ve[we].width,ve[we].height,K,Ue,ve[we].data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,0,_e,ve[we].width,ve[we].height,0,K,Ue,ve[we].data);for(let rt=0;rt<Ge.length;rt++){const Ut=Ge[rt].image[we].image;V?Se&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt+1,0,0,Ut.width,Ut.height,K,Ue,Ut.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt+1,_e,Ut.width,Ut.height,0,K,Ue,Ut.data)}}else{V?Se&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,0,0,0,K,Ue,ve[we]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,0,_e,K,Ue,ve[we]);for(let rt=0;rt<Ge.length;rt++){const $e=Ge[rt];V?Se&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt+1,0,0,K,Ue,$e.image[we]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+we,rt+1,_e,K,Ue,$e.image[we])}}}x(w)&&P(s.TEXTURE_CUBE_MAP),Pe.__version=ye.version,w.onUpdate&&w.onUpdate(w)}k.__version=w.version}function Xe(k,w,re,he,ye,Pe){const fe=l.convert(re.format,re.colorSpace),ie=l.convert(re.type),se=b(re.internalFormat,fe,ie,re.normalized,re.colorSpace),be=r.get(w),Fe=r.get(re);if(Fe.__renderTarget=w,!be.__hasExternalTextures){const ve=Math.max(1,w.width>>Pe),Ee=Math.max(1,w.height>>Pe);ye===s.TEXTURE_3D||ye===s.TEXTURE_2D_ARRAY?t.texImage3D(ye,Pe,se,ve,Ee,w.depth,0,fe,ie,null):t.texImage2D(ye,Pe,se,ve,Ee,0,fe,ie,null)}t.bindFramebuffer(s.FRAMEBUFFER,k),Nt(w)?d.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,he,ye,Fe.__webglTexture,0,_t(w)):(ye===s.TEXTURE_2D||ye>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&ye<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,he,ye,Fe.__webglTexture,Pe),t.bindFramebuffer(s.FRAMEBUFFER,null)}function mt(k,w,re){if(s.bindRenderbuffer(s.RENDERBUFFER,k),w.depthBuffer){const he=w.depthTexture,ye=he&&he.isDepthTexture?he.type:null,Pe=R(w.stencilBuffer,ye),fe=w.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;Nt(w)?d.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,_t(w),Pe,w.width,w.height):re?s.renderbufferStorageMultisample(s.RENDERBUFFER,_t(w),Pe,w.width,w.height):s.renderbufferStorage(s.RENDERBUFFER,Pe,w.width,w.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,fe,s.RENDERBUFFER,k)}else{const he=w.textures;for(let ye=0;ye<he.length;ye++){const Pe=he[ye],fe=l.convert(Pe.format,Pe.colorSpace),ie=l.convert(Pe.type),se=b(Pe.internalFormat,fe,ie,Pe.normalized,Pe.colorSpace);Nt(w)?d.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,_t(w),se,w.width,w.height):re?s.renderbufferStorageMultisample(s.RENDERBUFFER,_t(w),se,w.width,w.height):s.renderbufferStorage(s.RENDERBUFFER,se,w.width,w.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function Gt(k,w,re){const he=w.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(s.FRAMEBUFFER,k),!(w.depthTexture&&w.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const ye=r.get(w.depthTexture);if(ye.__renderTarget=w,(!ye.__webglTexture||w.depthTexture.image.width!==w.width||w.depthTexture.image.height!==w.height)&&(w.depthTexture.image.width=w.width,w.depthTexture.image.height=w.height,w.depthTexture.needsUpdate=!0),he){if(ye.__webglInit===void 0&&(ye.__webglInit=!0,w.depthTexture.addEventListener("dispose",F)),ye.__webglTexture===void 0){ye.__webglTexture=s.createTexture(),t.bindTexture(s.TEXTURE_CUBE_MAP,ye.__webglTexture),De(s.TEXTURE_CUBE_MAP,w.depthTexture);const be=l.convert(w.depthTexture.format),Fe=l.convert(w.depthTexture.type);let ve;w.depthTexture.format===Pr?ve=s.DEPTH_COMPONENT24:w.depthTexture.format===Ls&&(ve=s.DEPTH24_STENCIL8);for(let Ee=0;Ee<6;Ee++)s.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Ee,0,ve,w.width,w.height,0,be,Fe,null)}}else te(w.depthTexture,0);const Pe=ye.__webglTexture,fe=_t(w),ie=he?s.TEXTURE_CUBE_MAP_POSITIVE_X+re:s.TEXTURE_2D,se=w.depthTexture.format===Ls?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;if(w.depthTexture.format===Pr)Nt(w)?d.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,se,ie,Pe,0,fe):s.framebufferTexture2D(s.FRAMEBUFFER,se,ie,Pe,0);else if(w.depthTexture.format===Ls)Nt(w)?d.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,se,ie,Pe,0,fe):s.framebufferTexture2D(s.FRAMEBUFFER,se,ie,Pe,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function lt(k){const w=r.get(k),re=k.isWebGLCubeRenderTarget===!0;if(w.__boundDepthTexture!==k.depthTexture){const he=k.depthTexture;if(w.__depthDisposeCallback&&w.__depthDisposeCallback(),he){const ye=()=>{delete w.__boundDepthTexture,delete w.__depthDisposeCallback,he.removeEventListener("dispose",ye)};he.addEventListener("dispose",ye),w.__depthDisposeCallback=ye}w.__boundDepthTexture=he}if(k.depthTexture&&!w.__autoAllocateDepthBuffer)if(re)for(let he=0;he<6;he++)Gt(w.__webglFramebuffer[he],k,he);else{const he=k.texture.mipmaps;he&&he.length>0?Gt(w.__webglFramebuffer[0],k,0):Gt(w.__webglFramebuffer,k,0)}else if(re){w.__webglDepthbuffer=[];for(let he=0;he<6;he++)if(t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer[he]),w.__webglDepthbuffer[he]===void 0)w.__webglDepthbuffer[he]=s.createRenderbuffer(),mt(w.__webglDepthbuffer[he],k,!1);else{const ye=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Pe=w.__webglDepthbuffer[he];s.bindRenderbuffer(s.RENDERBUFFER,Pe),s.framebufferRenderbuffer(s.FRAMEBUFFER,ye,s.RENDERBUFFER,Pe)}}else{const he=k.texture.mipmaps;if(he&&he.length>0?t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer[0]):t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer),w.__webglDepthbuffer===void 0)w.__webglDepthbuffer=s.createRenderbuffer(),mt(w.__webglDepthbuffer,k,!1);else{const ye=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Pe=w.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,Pe),s.framebufferRenderbuffer(s.FRAMEBUFFER,ye,s.RENDERBUFFER,Pe)}}t.bindFramebuffer(s.FRAMEBUFFER,null)}function Et(k,w,re){const he=r.get(k);w!==void 0&&Xe(he.__webglFramebuffer,k,k.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),re!==void 0&&lt(k)}function Ot(k){const w=k.texture,re=r.get(k),he=r.get(w);k.addEventListener("dispose",E);const ye=k.textures,Pe=k.isWebGLCubeRenderTarget===!0,fe=ye.length>1;if(fe||(he.__webglTexture===void 0&&(he.__webglTexture=s.createTexture()),he.__version=w.version,u.memory.textures++),Pe){re.__webglFramebuffer=[];for(let ie=0;ie<6;ie++)if(w.mipmaps&&w.mipmaps.length>0){re.__webglFramebuffer[ie]=[];for(let se=0;se<w.mipmaps.length;se++)re.__webglFramebuffer[ie][se]=s.createFramebuffer()}else re.__webglFramebuffer[ie]=s.createFramebuffer()}else{if(w.mipmaps&&w.mipmaps.length>0){re.__webglFramebuffer=[];for(let ie=0;ie<w.mipmaps.length;ie++)re.__webglFramebuffer[ie]=s.createFramebuffer()}else re.__webglFramebuffer=s.createFramebuffer();if(fe)for(let ie=0,se=ye.length;ie<se;ie++){const be=r.get(ye[ie]);be.__webglTexture===void 0&&(be.__webglTexture=s.createTexture(),u.memory.textures++)}if(k.samples>0&&Nt(k)===!1){re.__webglMultisampledFramebuffer=s.createFramebuffer(),re.__webglColorRenderbuffer=[],t.bindFramebuffer(s.FRAMEBUFFER,re.__webglMultisampledFramebuffer);for(let ie=0;ie<ye.length;ie++){const se=ye[ie];re.__webglColorRenderbuffer[ie]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,re.__webglColorRenderbuffer[ie]);const be=l.convert(se.format,se.colorSpace),Fe=l.convert(se.type),ve=b(se.internalFormat,be,Fe,se.normalized,se.colorSpace,k.isXRRenderTarget===!0),Ee=_t(k);s.renderbufferStorageMultisample(s.RENDERBUFFER,Ee,ve,k.width,k.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ie,s.RENDERBUFFER,re.__webglColorRenderbuffer[ie])}s.bindRenderbuffer(s.RENDERBUFFER,null),k.depthBuffer&&(re.__webglDepthRenderbuffer=s.createRenderbuffer(),mt(re.__webglDepthRenderbuffer,k,!0)),t.bindFramebuffer(s.FRAMEBUFFER,null)}}if(Pe){t.bindTexture(s.TEXTURE_CUBE_MAP,he.__webglTexture),De(s.TEXTURE_CUBE_MAP,w);for(let ie=0;ie<6;ie++)if(w.mipmaps&&w.mipmaps.length>0)for(let se=0;se<w.mipmaps.length;se++)Xe(re.__webglFramebuffer[ie][se],k,w,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ie,se);else Xe(re.__webglFramebuffer[ie],k,w,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ie,0);x(w)&&P(s.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(fe){for(let ie=0,se=ye.length;ie<se;ie++){const be=ye[ie],Fe=r.get(be);let ve=s.TEXTURE_2D;(k.isWebGL3DRenderTarget||k.isWebGLArrayRenderTarget)&&(ve=k.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(ve,Fe.__webglTexture),De(ve,be),Xe(re.__webglFramebuffer,k,be,s.COLOR_ATTACHMENT0+ie,ve,0),x(be)&&P(ve)}t.unbindTexture()}else{let ie=s.TEXTURE_2D;if((k.isWebGL3DRenderTarget||k.isWebGLArrayRenderTarget)&&(ie=k.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(ie,he.__webglTexture),De(ie,w),w.mipmaps&&w.mipmaps.length>0)for(let se=0;se<w.mipmaps.length;se++)Xe(re.__webglFramebuffer[se],k,w,s.COLOR_ATTACHMENT0,ie,se);else Xe(re.__webglFramebuffer,k,w,s.COLOR_ATTACHMENT0,ie,0);x(w)&&P(ie),t.unbindTexture()}k.depthBuffer&&lt(k)}function xt(k){const w=k.textures;for(let re=0,he=w.length;re<he;re++){const ye=w[re];if(x(ye)){const Pe=U(k),fe=r.get(ye).__webglTexture;t.bindTexture(Pe,fe),P(Pe),t.unbindTexture()}}}const At=[],Xt=[];function Wt(k){if(k.samples>0){if(Nt(k)===!1){const w=k.textures,re=k.width,he=k.height;let ye=s.COLOR_BUFFER_BIT;const Pe=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,fe=r.get(k),ie=w.length>1;if(ie)for(let be=0;be<w.length;be++)t.bindFramebuffer(s.FRAMEBUFFER,fe.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+be,s.RENDERBUFFER,null),t.bindFramebuffer(s.FRAMEBUFFER,fe.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+be,s.TEXTURE_2D,null,0);t.bindFramebuffer(s.READ_FRAMEBUFFER,fe.__webglMultisampledFramebuffer);const se=k.texture.mipmaps;se&&se.length>0?t.bindFramebuffer(s.DRAW_FRAMEBUFFER,fe.__webglFramebuffer[0]):t.bindFramebuffer(s.DRAW_FRAMEBUFFER,fe.__webglFramebuffer);for(let be=0;be<w.length;be++){if(k.resolveDepthBuffer&&(k.depthBuffer&&(ye|=s.DEPTH_BUFFER_BIT),k.stencilBuffer&&k.resolveStencilBuffer&&(ye|=s.STENCIL_BUFFER_BIT)),ie){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,fe.__webglColorRenderbuffer[be]);const Fe=r.get(w[be]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,Fe,0)}s.blitFramebuffer(0,0,re,he,0,0,re,he,ye,s.NEAREST),f===!0&&(At.length=0,Xt.length=0,At.push(s.COLOR_ATTACHMENT0+be),k.depthBuffer&&k.storeMultisampledDepthBuffer===!1&&(At.push(Pe),Xt.push(Pe),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Xt)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,At))}if(t.bindFramebuffer(s.READ_FRAMEBUFFER,null),t.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),ie)for(let be=0;be<w.length;be++){t.bindFramebuffer(s.FRAMEBUFFER,fe.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+be,s.RENDERBUFFER,fe.__webglColorRenderbuffer[be]);const Fe=r.get(w[be]).__webglTexture;t.bindFramebuffer(s.FRAMEBUFFER,fe.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+be,s.TEXTURE_2D,Fe,0)}t.bindFramebuffer(s.DRAW_FRAMEBUFFER,fe.__webglMultisampledFramebuffer)}else if(k.depthBuffer&&k.storeMultisampledDepthBuffer===!1&&f){const w=k.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[w])}}}function _t(k){return Math.min(o.maxSamples,k.samples)}function Nt(k){const w=r.get(k);return k.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&w.__useRenderToTexture!==!1}function $(k){const w=u.render.frame;y.get(k)!==w&&(y.set(k,w),k.update())}function It(k,w){const re=k.colorSpace,he=k.format,ye=k.type;return k.isCompressedTexture===!0||k.isVideoTexture===!0||re!==zc&&re!==ss&&(Dt.getTransfer(re)===qt?(he!==Gi||ye!==vi)&&ht("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):zt("WebGLTextures: Unsupported texture color space:",re)),w}function wt(k){return typeof HTMLImageElement<"u"&&k instanceof HTMLImageElement?(p.width=k.naturalWidth||k.width,p.height=k.naturalHeight||k.height):typeof VideoFrame<"u"&&k instanceof VideoFrame?(p.width=k.displayWidth,p.height=k.displayHeight):(p.width=k.width,p.height=k.height),p}this.allocateTextureUnit=ue,this.resetTextureUnits=ne,this.getTextureUnits=H,this.setTextureUnits=W,this.setTexture2D=te,this.setTexture2DArray=G,this.setTexture3D=ee,this.setTextureCube=O,this.rebindTextures=Et,this.setupRenderTarget=Ot,this.updateRenderTargetMipmap=xt,this.updateMultisampleRenderTarget=Wt,this.setupDepthRenderbuffer=lt,this.setupFrameBufferTexture=Xe,this.useMultisampledRTT=Nt,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function NT(s,e){function t(r,o=ss){let l;const u=Dt.getTransfer(o);if(r===vi)return s.UNSIGNED_BYTE;if(r===Sh)return s.UNSIGNED_SHORT_4_4_4_4;if(r===Mh)return s.UNSIGNED_SHORT_5_5_5_1;if(r===vv)return s.UNSIGNED_INT_5_9_9_9_REV;if(r===xv)return s.UNSIGNED_INT_10F_11F_11F_REV;if(r===mv)return s.BYTE;if(r===gv)return s.SHORT;if(r===Ha)return s.UNSIGNED_SHORT;if(r===_h)return s.INT;if(r===sr)return s.UNSIGNED_INT;if(r===Hi)return s.FLOAT;if(r===or)return s.HALF_FLOAT;if(r===yv)return s.ALPHA;if(r===_v)return s.RGB;if(r===Gi)return s.RGBA;if(r===Pr)return s.DEPTH_COMPONENT;if(r===Ls)return s.DEPTH_STENCIL;if(r===Eh)return s.RED;if(r===wh)return s.RED_INTEGER;if(r===Fs)return s.RG;if(r===Th)return s.RG_INTEGER;if(r===Ah)return s.RGBA_INTEGER;if(r===bc||r===Cc||r===Rc||r===Pc)if(u===qt)if(l=e.get("WEBGL_compressed_texture_s3tc_srgb"),l!==null){if(r===bc)return l.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Cc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Rc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===Pc)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(l=e.get("WEBGL_compressed_texture_s3tc"),l!==null){if(r===bc)return l.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Cc)return l.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Rc)return l.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===Pc)return l.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Pf||r===If||r===Lf||r===Nf)if(l=e.get("WEBGL_compressed_texture_pvrtc"),l!==null){if(r===Pf)return l.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===If)return l.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Lf)return l.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Nf)return l.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Df||r===Uf||r===Ff||r===Of||r===kf||r===kc||r===Bf)if(l=e.get("WEBGL_compressed_texture_etc"),l!==null){if(r===Df||r===Uf)return u===qt?l.COMPRESSED_SRGB8_ETC2:l.COMPRESSED_RGB8_ETC2;if(r===Ff)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:l.COMPRESSED_RGBA8_ETC2_EAC;if(r===Of)return l.COMPRESSED_R11_EAC;if(r===kf)return l.COMPRESSED_SIGNED_R11_EAC;if(r===kc)return l.COMPRESSED_RG11_EAC;if(r===Bf)return l.COMPRESSED_SIGNED_RG11_EAC}else return null;if(r===zf||r===Vf||r===Hf||r===Gf||r===Wf||r===jf||r===Xf||r===Yf||r===qf||r===Kf||r===$f||r===Zf||r===Jf||r===Qf)if(l=e.get("WEBGL_compressed_texture_astc"),l!==null){if(r===zf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:l.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Vf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:l.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Hf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:l.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Gf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:l.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Wf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:l.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===jf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:l.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Xf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:l.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Yf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:l.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===qf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:l.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Kf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:l.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===$f)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:l.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Zf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:l.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Jf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:l.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Qf)return u===qt?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:l.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===eh||r===th||r===nh)if(l=e.get("EXT_texture_compression_bptc"),l!==null){if(r===eh)return u===qt?l.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:l.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===th)return l.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===nh)return l.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===ih||r===rh||r===Bc||r===sh)if(l=e.get("EXT_texture_compression_rgtc"),l!==null){if(r===ih)return l.COMPRESSED_RED_RGTC1_EXT;if(r===rh)return l.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Bc)return l.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===sh)return l.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Ga?s.UNSIGNED_INT_24_8:s[r]!==void 0?s[r]:null}return{convert:t}}const DT=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,UT=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class FT{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const r=new Cv(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,r=new ar({vertexShader:DT,fragmentShader:UT,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Sn(new Zc(20,20),r)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class OT extends ds{constructor(e,t){super();const r=this;let o=null,l=1,u=null,d="local-floor",f=1,p=null,y=null,S=null,v=null,_=null,M=null;const A=typeof XRWebGLBinding<"u",m=new FT,x={},P=t.getContextAttributes();let U=null,b=null;const R=[],N=[],F=new dt;let E=null,L=null;const B=new Ai;B.viewport=new an;const X=new Ai;X.viewport=new an;const j=[B,X],ne=new G1;let H=null,W=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(le){let ge=R[le];return ge===void 0&&(ge=new Wd,R[le]=ge),ge.getTargetRaySpace()},this.getControllerGrip=function(le){let ge=R[le];return ge===void 0&&(ge=new Wd,R[le]=ge),ge.getGripSpace()},this.getHand=function(le){let ge=R[le];return ge===void 0&&(ge=new Wd,R[le]=ge),ge.getHandSpace()};function ue(le){const ge=N.indexOf(le.inputSource);if(ge===-1)return;const Ne=R[ge];Ne!==void 0&&(Ne.update(le.inputSource,le.frame,p||u),Ne.dispatchEvent({type:le.type,data:le.inputSource}))}function Q(){o.removeEventListener("select",ue),o.removeEventListener("selectstart",ue),o.removeEventListener("selectend",ue),o.removeEventListener("squeeze",ue),o.removeEventListener("squeezestart",ue),o.removeEventListener("squeezeend",ue),o.removeEventListener("end",Q),o.removeEventListener("inputsourceschange",te);for(let le=0;le<R.length;le++){const ge=N[le];ge!==null&&(N[le]=null,R[le].disconnect(ge))}H=null,W=null,m.reset();for(const le in x)delete x[le];if(e.setRenderTarget(U),_=null,v=null,S=null,o=null,b=null,Ye.stop(),r.isPresenting=!1,e.setPixelRatio(E),e.setSize(F.width,F.height,!1),L!==null){const le=L.camera;le.fov=L.fov,le.zoom=L.zoom,le.updateProjectionMatrix(),L=null}r.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(le){l=le,r.isPresenting===!0&&ht("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(le){d=le,r.isPresenting===!0&&ht("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return p||u},this.setReferenceSpace=function(le){p=le},this.getBaseLayer=function(){return v!==null?v:_},this.getBinding=function(){return S===null&&A&&(S=new XRWebGLBinding(o,t)),S},this.getFrame=function(){return M},this.getSession=function(){return o},this.setSession=async function(le){if(o=le,o!==null){if(U=e.getRenderTarget(),o.addEventListener("select",ue),o.addEventListener("selectstart",ue),o.addEventListener("selectend",ue),o.addEventListener("squeeze",ue),o.addEventListener("squeezestart",ue),o.addEventListener("squeezeend",ue),o.addEventListener("end",Q),o.addEventListener("inputsourceschange",te),P.xrCompatible!==!0&&await t.makeXRCompatible(),E=e.getPixelRatio(),e.getSize(F),A&&"createProjectionLayer"in XRWebGLBinding.prototype){let Ne=null,tt=null,Xe=null;P.depth&&(Xe=P.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Ne=P.stencil?Ls:Pr,tt=P.stencil?Ga:sr);const mt={colorFormat:t.RGBA8,depthFormat:Xe,scaleFactor:l};S=this.getBinding(),v=S.createProjectionLayer(mt),o.updateRenderState({layers:[v]}),e.setPixelRatio(1),e.setSize(v.textureWidth,v.textureHeight,!1),b=new Wi(v.textureWidth,v.textureHeight,{format:Gi,type:vi,depthTexture:new ja(v.textureWidth,v.textureHeight,tt,void 0,void 0,void 0,void 0,void 0,void 0,Ne),stencilBuffer:P.stencil,colorSpace:e.outputColorSpace,samples:P.antialias?4:0,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1,storeMultisampledDepthBuffer:v.ignoreDepthValues===!1,storeMultisampledStencilBuffer:v.ignoreDepthValues===!1})}else{const Ne={antialias:P.antialias,alpha:!0,depth:P.depth,stencil:P.stencil,framebufferScaleFactor:l};_=new XRWebGLLayer(o,t,Ne),o.updateRenderState({baseLayer:_}),e.setPixelRatio(1),e.setSize(_.framebufferWidth,_.framebufferHeight,!1),b=new Wi(_.framebufferWidth,_.framebufferHeight,{format:Gi,type:vi,colorSpace:e.outputColorSpace,stencilBuffer:P.stencil,resolveDepthBuffer:_.ignoreDepthValues===!1,resolveStencilBuffer:_.ignoreDepthValues===!1,storeMultisampledDepthBuffer:_.ignoreDepthValues===!1,storeMultisampledStencilBuffer:_.ignoreDepthValues===!1})}b.isXRRenderTarget=!0,this.setFoveation(f),p=null,u=await o.requestReferenceSpace(d),Ye.setContext(o),Ye.start(),r.isPresenting=!0,r.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(o!==null)return o.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function te(le){for(let ge=0;ge<le.removed.length;ge++){const Ne=le.removed[ge],tt=N.indexOf(Ne);tt>=0&&(N[tt]=null,R[tt].disconnect(Ne))}for(let ge=0;ge<le.added.length;ge++){const Ne=le.added[ge];let tt=N.indexOf(Ne);if(tt===-1){for(let mt=0;mt<R.length;mt++)if(mt>=N.length){N.push(Ne),tt=mt;break}else if(N[mt]===null){N[mt]=Ne,tt=mt;break}if(tt===-1)break}const Xe=R[tt];Xe&&Xe.connect(Ne)}}const G=new Z,ee=new Z;function O(le,ge,Ne){G.setFromMatrixPosition(ge.matrixWorld),ee.setFromMatrixPosition(Ne.matrixWorld);const tt=G.distanceTo(ee),Xe=ge.projectionMatrix.elements,mt=Ne.projectionMatrix.elements,Gt=Xe[14]/(Xe[10]-1),lt=Xe[14]/(Xe[10]+1),Et=(Xe[9]+1)/Xe[5],Ot=(Xe[9]-1)/Xe[5],xt=(Xe[8]-1)/Xe[0],At=(mt[8]+1)/mt[0],Xt=Gt*xt,Wt=Gt*At,_t=tt/(-xt+At),Nt=_t*-xt;if(ge.matrixWorld.decompose(le.position,le.quaternion,le.scale),le.translateX(Nt),le.translateZ(_t),le.matrixWorld.compose(le.position,le.quaternion,le.scale),le.matrixWorldInverse.copy(le.matrixWorld).invert(),Xe[10]===-1)le.projectionMatrix.copy(ge.projectionMatrix),le.projectionMatrixInverse.copy(ge.projectionMatrixInverse);else{const $=Gt+_t,It=lt+_t,wt=Xt-Nt,k=Wt+(tt-Nt),w=Et*lt/It*$,re=Ot*lt/It*$;le.projectionMatrix.makePerspective(wt,k,w,re,$,It),le.projectionMatrixInverse.copy(le.projectionMatrix).invert()}}function de(le,ge){ge===null?le.matrixWorld.copy(le.matrix):le.matrixWorld.multiplyMatrices(ge.matrixWorld,le.matrix),le.matrixWorldInverse.copy(le.matrixWorld).invert()}this.updateCamera=function(le){if(o===null)return;let ge=le.near,Ne=le.far;m.texture!==null&&(m.depthNear>0&&(ge=m.depthNear),m.depthFar>0&&(Ne=m.depthFar)),ne.near=X.near=B.near=ge,ne.far=X.far=B.far=Ne,(H!==ne.near||W!==ne.far)&&(o.updateRenderState({depthNear:ne.near,depthFar:ne.far}),H=ne.near,W=ne.far),ne.layers.mask=le.layers.mask|6,B.layers.mask=ne.layers.mask&-5,X.layers.mask=ne.layers.mask&-3;const tt=le.parent,Xe=ne.cameras;de(ne,tt);for(let mt=0;mt<Xe.length;mt++)de(Xe[mt],tt);Xe.length===2?O(ne,B,X):ne.projectionMatrix.copy(B.projectionMatrix),L===null&&le.isPerspectiveCamera&&(L={camera:le,fov:le.fov,zoom:le.zoom}),Ce(le,ne,tt)};function Ce(le,ge,Ne){Ne===null?le.matrix.copy(ge.matrixWorld):(le.matrix.copy(Ne.matrixWorld),le.matrix.invert(),le.matrix.multiply(ge.matrixWorld)),le.matrix.decompose(le.position,le.quaternion,le.scale),le.updateMatrixWorld(!0),le.projectionMatrix.copy(ge.projectionMatrix),le.projectionMatrixInverse.copy(ge.projectionMatrixInverse),le.isPerspectiveCamera&&(le.fov=ah*2*Math.atan(1/le.projectionMatrix.elements[5]),le.zoom=1)}this.getCamera=function(){return ne},this.getFoveation=function(){if(!(v===null&&_===null))return f},this.setFoveation=function(le){f=le,v!==null&&(v.fixedFoveation=le),_!==null&&_.fixedFoveation!==void 0&&(_.fixedFoveation=le)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(ne)},this.getCameraTexture=function(le){return x[le]};let Te=null;function De(le,ge){if(y=ge.getViewerPose(p||u),M=ge,y!==null){const Ne=y.views;_!==null&&(e.setRenderTargetFramebuffer(b,_.framebuffer),e.setRenderTarget(b));let tt=!1;Ne.length!==ne.cameras.length&&(ne.cameras.length=0,tt=!0);for(let lt=0;lt<Ne.length;lt++){const Et=Ne[lt];let Ot=null;if(_!==null)Ot=_.getViewport(Et);else{const At=S.getViewSubImage(v,Et);Ot=At.viewport,lt===0&&(e.setRenderTargetTextures(b,At.colorTexture,At.depthStencilTexture),e.setRenderTarget(b))}let xt=j[lt];xt===void 0&&(xt=new Ai,xt.layers.enable(lt),xt.viewport=new an,j[lt]=xt),xt.matrix.fromArray(Et.transform.matrix),xt.matrix.decompose(xt.position,xt.quaternion,xt.scale),xt.projectionMatrix.fromArray(Et.projectionMatrix),xt.projectionMatrixInverse.copy(xt.projectionMatrix).invert(),xt.viewport.set(Ot.x,Ot.y,Ot.width,Ot.height),lt===0&&(ne.matrix.copy(xt.matrix),ne.matrix.decompose(ne.position,ne.quaternion,ne.scale)),tt===!0&&ne.cameras.push(xt)}const Xe=o.enabledFeatures;if(Xe&&Xe.includes("depth-sensing")&&o.depthUsage=="gpu-optimized"&&A){S=r.getBinding();const lt=S.getDepthInformation(Ne[0]);lt&&lt.isValid&&lt.texture&&m.init(lt,o.renderState)}if(Xe&&Xe.includes("camera-access")&&A){e.state.unbindTexture(),S=r.getBinding();for(let lt=0;lt<Ne.length;lt++){const Et=Ne[lt].camera;if(Et){let Ot=x[Et];Ot||(Ot=new Cv,x[Et]=Ot);const xt=S.getCameraImage(Et);Ot.sourceTexture=xt}}}}for(let Ne=0;Ne<R.length;Ne++){const tt=N[Ne],Xe=R[Ne];tt!==null&&Xe!==void 0&&Xe.update(tt,ge,p||u)}Te&&Te(le,ge),ge.detectedPlanes&&r.dispatchEvent({type:"planesdetected",data:ge}),M=null}const Ye=new Lv;Ye.setAnimationLoop(De),this.setAnimationLoop=function(le){Te=le},this.dispose=function(){}}}const kT=new Yt,Bv=new yt;Bv.set(-1,0,0,0,1,0,0,0,1);function BT(s,e){function t(m,x){m.matrixAutoUpdate===!0&&m.updateMatrix(),x.value.copy(m.matrix)}function r(m,x){x.color.getRGB(m.fogColor.value,Rv(s)),x.isFog?(m.fogNear.value=x.near,m.fogFar.value=x.far):x.isFogExp2&&(m.fogDensity.value=x.density)}function o(m,x,P,U,b){x.isNodeMaterial?x.uniformsNeedUpdate=!1:x.isMeshBasicMaterial?l(m,x):x.isMeshLambertMaterial?(l(m,x),x.envMap&&(m.envMapIntensity.value=x.envMapIntensity)):x.isMeshToonMaterial?(l(m,x),S(m,x)):x.isMeshPhongMaterial?(l(m,x),y(m,x),x.envMap&&(m.envMapIntensity.value=x.envMapIntensity)):x.isMeshStandardMaterial?(l(m,x),v(m,x),x.isMeshPhysicalMaterial&&_(m,x,b)):x.isMeshMatcapMaterial?(l(m,x),M(m,x)):x.isMeshDepthMaterial?l(m,x):x.isMeshDistanceMaterial?(l(m,x),A(m,x)):x.isMeshNormalMaterial?l(m,x):x.isLineBasicMaterial?(u(m,x),x.isLineDashedMaterial&&d(m,x)):x.isPointsMaterial?f(m,x,P,U):x.isSpriteMaterial?p(m,x):x.isShadowMaterial?(m.color.value.copy(x.color),m.opacity.value=x.opacity):x.isShaderMaterial&&(x.uniformsNeedUpdate=!1)}function l(m,x){m.opacity.value=x.opacity,x.color&&m.diffuse.value.copy(x.color),x.emissive&&m.emissive.value.copy(x.emissive).multiplyScalar(x.emissiveIntensity),x.map&&(m.map.value=x.map,t(x.map,m.mapTransform)),x.alphaMap&&(m.alphaMap.value=x.alphaMap,t(x.alphaMap,m.alphaMapTransform)),x.bumpMap&&(m.bumpMap.value=x.bumpMap,t(x.bumpMap,m.bumpMapTransform),m.bumpScale.value=x.bumpScale,x.side===Jn&&(m.bumpScale.value*=-1)),x.normalMap&&(m.normalMap.value=x.normalMap,t(x.normalMap,m.normalMapTransform),m.normalScale.value.copy(x.normalScale),x.side===Jn&&m.normalScale.value.negate()),x.displacementMap&&(m.displacementMap.value=x.displacementMap,t(x.displacementMap,m.displacementMapTransform),m.displacementScale.value=x.displacementScale,m.displacementBias.value=x.displacementBias),x.emissiveMap&&(m.emissiveMap.value=x.emissiveMap,t(x.emissiveMap,m.emissiveMapTransform)),x.specularMap&&(m.specularMap.value=x.specularMap,t(x.specularMap,m.specularMapTransform)),x.alphaTest>0&&(m.alphaTest.value=x.alphaTest);const P=e.get(x),U=P.envMap,b=P.envMapRotation;U&&(m.envMap.value=U,m.envMapRotation.value.setFromMatrix4(kT.makeRotationFromEuler(b)).transpose(),U.isCubeTexture&&U.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(Bv),m.reflectivity.value=x.reflectivity,m.ior.value=x.ior,m.refractionRatio.value=x.refractionRatio),x.lightMap&&(m.lightMap.value=x.lightMap,m.lightMapIntensity.value=x.lightMapIntensity,t(x.lightMap,m.lightMapTransform)),x.aoMap&&(m.aoMap.value=x.aoMap,m.aoMapIntensity.value=x.aoMapIntensity,t(x.aoMap,m.aoMapTransform))}function u(m,x){m.diffuse.value.copy(x.color),m.opacity.value=x.opacity,x.map&&(m.map.value=x.map,t(x.map,m.mapTransform))}function d(m,x){m.dashSize.value=x.dashSize,m.totalSize.value=x.dashSize+x.gapSize,m.scale.value=x.scale}function f(m,x,P,U){m.diffuse.value.copy(x.color),m.opacity.value=x.opacity,m.size.value=x.size*P,m.scale.value=U*.5,x.map&&(m.map.value=x.map,t(x.map,m.uvTransform)),x.alphaMap&&(m.alphaMap.value=x.alphaMap,t(x.alphaMap,m.alphaMapTransform)),x.alphaTest>0&&(m.alphaTest.value=x.alphaTest)}function p(m,x){m.diffuse.value.copy(x.color),m.opacity.value=x.opacity,m.rotation.value=x.rotation,x.map&&(m.map.value=x.map,t(x.map,m.mapTransform)),x.alphaMap&&(m.alphaMap.value=x.alphaMap,t(x.alphaMap,m.alphaMapTransform)),x.alphaTest>0&&(m.alphaTest.value=x.alphaTest)}function y(m,x){m.specular.value.copy(x.specular),m.shininess.value=Math.max(x.shininess,1e-4)}function S(m,x){x.gradientMap&&(m.gradientMap.value=x.gradientMap)}function v(m,x){m.metalness.value=x.metalness,x.metalnessMap&&(m.metalnessMap.value=x.metalnessMap,t(x.metalnessMap,m.metalnessMapTransform)),m.roughness.value=x.roughness,x.roughnessMap&&(m.roughnessMap.value=x.roughnessMap,t(x.roughnessMap,m.roughnessMapTransform)),x.envMap&&(m.envMapIntensity.value=x.envMapIntensity)}function _(m,x,P){m.ior.value=x.ior,x.sheen>0&&(m.sheenColor.value.copy(x.sheenColor).multiplyScalar(x.sheen),m.sheenRoughness.value=x.sheenRoughness,x.sheenColorMap&&(m.sheenColorMap.value=x.sheenColorMap,t(x.sheenColorMap,m.sheenColorMapTransform)),x.sheenRoughnessMap&&(m.sheenRoughnessMap.value=x.sheenRoughnessMap,t(x.sheenRoughnessMap,m.sheenRoughnessMapTransform))),x.clearcoat>0&&(m.clearcoat.value=x.clearcoat,m.clearcoatRoughness.value=x.clearcoatRoughness,x.clearcoatMap&&(m.clearcoatMap.value=x.clearcoatMap,t(x.clearcoatMap,m.clearcoatMapTransform)),x.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=x.clearcoatRoughnessMap,t(x.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),x.clearcoatNormalMap&&(m.clearcoatNormalMap.value=x.clearcoatNormalMap,t(x.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(x.clearcoatNormalScale),x.side===Jn&&m.clearcoatNormalScale.value.negate())),x.dispersion>0&&(m.dispersion.value=x.dispersion),x.retroreflectivity>0&&(m.retroreflectivity.value=x.retroreflectivity),x.iridescence>0&&(m.iridescence.value=x.iridescence,m.iridescenceIOR.value=x.iridescenceIOR,m.iridescenceThicknessMinimum.value=x.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=x.iridescenceThicknessRange[1],x.iridescenceMap&&(m.iridescenceMap.value=x.iridescenceMap,t(x.iridescenceMap,m.iridescenceMapTransform)),x.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=x.iridescenceThicknessMap,t(x.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),x.transmission>0&&(m.transmission.value=x.transmission,m.transmissionSamplerMap.value=P.texture,m.transmissionSamplerSize.value.set(P.width,P.height),x.transmissionMap&&(m.transmissionMap.value=x.transmissionMap,t(x.transmissionMap,m.transmissionMapTransform)),m.thickness.value=x.thickness,x.thicknessMap&&(m.thicknessMap.value=x.thicknessMap,t(x.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=x.attenuationDistance,m.attenuationColor.value.copy(x.attenuationColor)),x.anisotropy>0&&(m.anisotropyVector.value.set(x.anisotropy*Math.cos(x.anisotropyRotation),x.anisotropy*Math.sin(x.anisotropyRotation)),x.anisotropyMap&&(m.anisotropyMap.value=x.anisotropyMap,t(x.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=x.specularIntensity,m.specularColor.value.copy(x.specularColor),x.specularColorMap&&(m.specularColorMap.value=x.specularColorMap,t(x.specularColorMap,m.specularColorMapTransform)),x.specularIntensityMap&&(m.specularIntensityMap.value=x.specularIntensityMap,t(x.specularIntensityMap,m.specularIntensityMapTransform))}function M(m,x){x.matcap&&(m.matcap.value=x.matcap)}function A(m,x){const P=e.get(x).light;m.referencePosition.value.setFromMatrixPosition(P.matrixWorld),m.nearDistance.value=P.shadow.camera.near,m.farDistance.value=P.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:o}}function zT(s,e,t,r){let o={},l={},u=[];const d=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function f(b,R){const N=R.program;r.uniformBlockBinding(b,N)}function p(b,R){let N=o[b.id];N===void 0&&(m(b),N=y(b),o[b.id]=N,b.addEventListener("dispose",P));const F=R.program;r.updateUBOMapping(b,F);const E=e.render.frame;l[b.id]!==E&&(v(b),l[b.id]=E)}function y(b){const R=S();b.__bindingPointIndex=R;const N=s.createBuffer(),F=b.__size,E=b.usage;return s.bindBuffer(s.UNIFORM_BUFFER,N),s.bufferData(s.UNIFORM_BUFFER,F,E),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,R,N),N}function S(){for(let b=0;b<d;b++)if(u.indexOf(b)===-1)return u.push(b),b;return zt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function v(b){const R=o[b.id],N=b.uniforms,F=b.__cache;s.bindBuffer(s.UNIFORM_BUFFER,R);for(let E=0,L=N.length;E<L;E++){const B=N[E];if(Array.isArray(B))for(let X=0,j=B.length;X<j;X++)_(B[X],E,X,F);else _(B,E,0,F)}s.bindBuffer(s.UNIFORM_BUFFER,null)}function _(b,R,N,F){if(A(b,R,N,F)===!0){const E=b.__offset,L=b.value;if(Array.isArray(L)){let B=0;for(let X=0;X<L.length;X++){const j=L[X],ne=x(j);M(j,b.__data,B),typeof j!="number"&&typeof j!="boolean"&&!j.isMatrix3&&!ArrayBuffer.isView(j)&&(B+=ne.storage/Float32Array.BYTES_PER_ELEMENT)}}else M(L,b.__data,0);s.bufferSubData(s.UNIFORM_BUFFER,E,b.__data)}}function M(b,R,N){typeof b=="number"||typeof b=="boolean"?R[0]=b:b.isMatrix3?(R[0]=b.elements[0],R[1]=b.elements[1],R[2]=b.elements[2],R[3]=0,R[4]=b.elements[3],R[5]=b.elements[4],R[6]=b.elements[5],R[7]=0,R[8]=b.elements[6],R[9]=b.elements[7],R[10]=b.elements[8],R[11]=0):ArrayBuffer.isView(b)?R.set(new b.constructor(b.buffer,b.byteOffset,R.length)):b.toArray(R,N)}function A(b,R,N,F){const E=b.value,L=R+"_"+N;if(F[L]===void 0)return typeof E=="number"||typeof E=="boolean"?F[L]=E:ArrayBuffer.isView(E)?F[L]=E.slice():F[L]=E.clone(),!0;{const B=F[L];if(typeof E=="number"||typeof E=="boolean"){if(B!==E)return F[L]=E,!0}else{if(ArrayBuffer.isView(E))return!0;if(B.equals(E)===!1)return B.copy(E),!0}}return!1}function m(b){const R=b.uniforms;let N=0;const F=16;for(let L=0,B=R.length;L<B;L++){const X=Array.isArray(R[L])?R[L]:[R[L]];for(let j=0,ne=X.length;j<ne;j++){const H=X[j],W=Array.isArray(H.value)?H.value:[H.value];for(let ue=0,Q=W.length;ue<Q;ue++){const te=W[ue],G=x(te),ee=N%F,O=ee%G.boundary,de=ee+O;N+=O,de!==0&&F-de<G.storage&&(N+=F-de),H.__data=new Float32Array(G.storage/Float32Array.BYTES_PER_ELEMENT),H.__offset=N,N+=G.storage}}}const E=N%F;return E>0&&(N+=F-E),b.__size=N,b.__cache={},this}function x(b){const R={boundary:0,storage:0};return typeof b=="number"||typeof b=="boolean"?(R.boundary=4,R.storage=4):b.isVector2?(R.boundary=8,R.storage=8):b.isVector3||b.isColor?(R.boundary=16,R.storage=12):b.isVector4?(R.boundary=16,R.storage=16):b.isMatrix3?(R.boundary=48,R.storage=48):b.isMatrix4?(R.boundary=64,R.storage=64):b.isTexture?ht("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(b)?(R.boundary=16,R.storage=b.byteLength):ht("WebGLRenderer: Unsupported uniform value type.",b),R}function P(b){const R=b.target;R.removeEventListener("dispose",P);const N=u.indexOf(R.__bindingPointIndex);u.splice(N,1),s.deleteBuffer(o[R.id]),delete o[R.id],delete l[R.id]}function U(){for(const b in o)s.deleteBuffer(o[b]);u=[],o={},l={}}return{bind:f,update:p,dispose:U}}const VT=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let er=null;function HT(){return er===null&&(er=new Av(VT,16,16,Fs,or),er.name="DFG_LUT",er.minFilter=Yn,er.magFilter=Yn,er.wrapS=br,er.wrapT=br,er.generateMipmaps=!1,er.needsUpdate=!0),er}class GT{constructor(e={}){const{canvas:t=K_(),context:r=null,depth:o=!0,stencil:l=!1,alpha:u=!1,antialias:d=!1,premultipliedAlpha:f=!0,preserveDrawingBuffer:p=!1,powerPreference:y="default",failIfMajorPerformanceCaveat:S=!1,reversedDepthBuffer:v=!1,outputBufferType:_=vi}=e;this.isWebGLRenderer=!0;let M;if(r!==null){if(typeof WebGLRenderingContext<"u"&&r instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=r.getContextAttributes().alpha}else M=u;const A=_,m=new Set([Ah,Th,wh]),x=new Set([vi,sr,Ha,Ga,Sh,Mh]),P=new Uint32Array(4),U=new Int32Array(4),b=new Z;let R=null,N=null;const F=[],E=[];let L=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=rr,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const B=this;let X=!1,j=null,ne=null,H=null,W=null;this._outputColorSpace=gi;let ue=0,Q=0,te=null,G=-1,ee=null;const O=new an,de=new an;let Ce=null;const Te=new vt(0);let De=0,Ye=t.width,le=t.height,ge=1,Ne=null,tt=null;const Xe=new an(0,0,Ye,le),mt=new an(0,0,Ye,le);let Gt=!1;const lt=new Lh;let Et=!1,Ot=!1;const xt=new Yt,At=new Z,Xt=new an,Wt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let _t=!1;function Nt(){return te===null?ge:1}let $=r;function It(I,q){return t.getContext(I,q)}let wt,k,w,re,he,ye,Pe,fe,ie,se,be,Fe,ve,Ee,K,Ue,_e,V,Oe,Se,Ve,Ge,we;try{const I={alpha:!0,depth:o,stencil:l,antialias:d,premultipliedAlpha:f,preserveDrawingBuffer:p,powerPreference:y,failIfMajorPerformanceCaveat:S};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${xh}`),t.addEventListener("webglcontextlost",Ut,!1),t.addEventListener("webglcontextrestored",bt,!1),t.addEventListener("webglcontextcreationerror",fn,!1),$===null){const q="webgl2";if($=It(q,I),$===null)throw It(q)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}rt()}catch(I){throw t.removeEventListener("webglcontextlost",Ut,!1),t.removeEventListener("webglcontextrestored",bt,!1),t.removeEventListener("webglcontextcreationerror",fn,!1),zt("WebGLRenderer: "+I.message),I}function rt(){wt=new HE($),wt.init(),Ve=new NT($,wt),k=new LE($,wt,e,Ve),w=new IT($,wt),k.reversedDepthBuffer&&v&&w.buffers.depth.setReversed(!0),ne=$.createFramebuffer(),H=$.createFramebuffer(),W=$.createFramebuffer(),re=new jE($),he=new vT,ye=new LT($,wt,w,he,k,Ve,re),Pe=new VE(B),fe=new Y1($),Ge=new PE($,fe),ie=new GE($,fe,re,Ge),se=new YE($,ie,fe,Ge,re),V=new XE($,k,ye),K=new NE(he),be=new gT(B,Pe,wt,k,Ge,K),Fe=new BT(B,he),ve=new yT,Ee=new TT(wt),_e=new RE(B,Pe,w,se,M,f),Ue=new PT(B,se,k),we=new zT($,re,k,w),Oe=new IE($,wt,re),Se=new WE($,wt,re),re.programs=be.programs,B.capabilities=k,B.extensions=wt,B.properties=he,B.renderLists=ve,B.shadowMap=Ue,B.state=w,B.info=re}A!==vi&&(L=new KE(A,t.width,t.height,d,o,l));const $e=new OT(B,$);this.xr=$e,this.getContext=function(){return $},this.getContextAttributes=function(){return $.getContextAttributes()},this.forceContextLoss=function(){const I=wt.get("WEBGL_lose_context");I&&I.loseContext()},this.forceContextRestore=function(){const I=wt.get("WEBGL_lose_context");I&&I.restoreContext()},this.getPixelRatio=function(){return ge},this.setPixelRatio=function(I){I!==void 0&&(ge=I,this.setSize(Ye,le,!1))},this.getSize=function(I){return I.set(Ye,le)},this.setSize=function(I,q,me=!0){if($e.isPresenting){ht("WebGLRenderer: Can't change size while VR device is presenting.");return}Ye=I,le=q,t.width=Math.floor(I*ge),t.height=Math.floor(q*ge),me===!0&&(t.style.width=I+"px",t.style.height=q+"px"),L!==null&&L.setSize(t.width,t.height),this.setViewport(0,0,I,q)},this.getDrawingBufferSize=function(I){return I.set(Ye*ge,le*ge).floor()},this.setDrawingBufferSize=function(I,q,me){Ye=I,le=q,ge=me,t.width=Math.floor(I*me),t.height=Math.floor(q*me),this.setViewport(0,0,I,q)},this.setEffects=function(I){if(A===vi){zt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(I){for(let q=0;q<I.length;q++)if(I[q].isOutputPass===!0){ht("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}L.setEffects(I||[])},this.getCurrentViewport=function(I){return I.copy(O)},this.getViewport=function(I){return I.copy(Xe)},this.setViewport=function(I,q,me,ae){I.isVector4?Xe.set(I.x,I.y,I.z,I.w):Xe.set(I,q,me,ae),w.viewport(O.copy(Xe).multiplyScalar(ge).round())},this.getScissor=function(I){return I.copy(mt)},this.setScissor=function(I,q,me,ae){I.isVector4?mt.set(I.x,I.y,I.z,I.w):mt.set(I,q,me,ae),w.scissor(de.copy(mt).multiplyScalar(ge).round())},this.getScissorTest=function(){return Gt},this.setScissorTest=function(I){w.setScissorTest(Gt=I)},this.setOpaqueSort=function(I){Ne=I},this.setTransparentSort=function(I){tt=I},this.getClearColor=function(I){return I.copy(_e.getClearColor())},this.setClearColor=function(){_e.setClearColor(...arguments)},this.getClearAlpha=function(){return _e.getClearAlpha()},this.setClearAlpha=function(){_e.setClearAlpha(...arguments)},this.clear=function(I=!0,q=!0,me=!0){let ae=0;if(I){let oe=!1;if(te!==null){const We=te.texture.format;oe=m.has(We)}if(oe){const We=te.texture.type,ze=x.has(We),je=_e.getClearColor(),Je=_e.getClearAlpha(),nt=je.r,pt=je.g,Me=je.b;ze?(P[0]=nt,P[1]=pt,P[2]=Me,P[3]=Je,$.clearBufferuiv($.COLOR,0,P)):(U[0]=nt,U[1]=pt,U[2]=Me,U[3]=Je,$.clearBufferiv($.COLOR,0,U))}else ae|=$.COLOR_BUFFER_BIT}q&&(ae|=$.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),me&&(ae|=$.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),ae!==0&&$.clear(ae)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(I){I.setRenderer(this),j=I},this.dispose=function(){t.removeEventListener("webglcontextlost",Ut,!1),t.removeEventListener("webglcontextrestored",bt,!1),t.removeEventListener("webglcontextcreationerror",fn,!1),_e.dispose(),ve.dispose(),Ee.dispose(),he.dispose(),Pe.dispose(),se.dispose(),Ge.dispose(),we.dispose(),be.dispose(),$e.dispose(),$e.removeEventListener("sessionstart",Yi),$e.removeEventListener("sessionend",Vs),wn.stop()};function Ut(I){I.preventDefault(),Pg("WebGLRenderer: Context Lost."),X=!0}function bt(){Pg("WebGLRenderer: Context Restored."),X=!1;const I=re.autoReset,q=Ue.enabled,me=Ue.autoUpdate,ae=Ue.needsUpdate,oe=Ue.type;rt(),re.autoReset=I,Ue.enabled=q,Ue.autoUpdate=me,Ue.needsUpdate=ae,Ue.type=oe}function fn(I){zt("WebGLRenderer: A WebGL context could not be created. Reason: ",I.statusMessage)}function ei(I){const q=I.target;q.removeEventListener("dispose",ei),xi(q)}function xi(I){ji(I),he.remove(I)}function ji(I){const q=he.get(I).programs;q!==void 0&&(q.forEach(function(me){be.releaseProgram(me)}),I.isShaderMaterial&&be.releaseShaderCache(I))}this.renderBufferDirect=function(I,q,me,ae,oe,We){q===null&&(q=Wt);const ze=oe.isMesh&&oe.matrixWorld.determinantAffine()<0,je=$t(I,q,me,ae,oe);w.setMaterial(ae,ze);let Je=me.index,nt=1;if(ae.wireframe===!0){if(Je=ie.getWireframeAttribute(me),Je===void 0)return;nt=2}const pt=me.drawRange,Me=me.attributes.position;let Ae=pt.start*nt,He=(pt.start+pt.count)*nt;We!==null&&(Ae=Math.max(Ae,We.start*nt),He=Math.min(He,(We.start+We.count)*nt)),Je!==null?(Ae=Math.max(Ae,0),He=Math.min(He,Je.count)):Me!=null&&(Ae=Math.max(Ae,0),He=Math.min(He,Me.count));const at=He-Ae;if(at<0||at===1/0)return;Ge.setup(oe,ae,je,me,Je);let ft,et=Oe;if(Je!==null&&(ft=fe.get(Je),et=Se,et.setIndex(ft)),oe.isMesh)ae.wireframe===!0?(w.setLineWidth(ae.wireframeLinewidth*Nt()),et.setMode($.LINES)):et.setMode($.TRIANGLES);else if(oe.isLine){let St=ae.linewidth;St===void 0&&(St=1),w.setLineWidth(St*Nt()),oe.isLineSegments?et.setMode($.LINES):oe.isLineLoop?et.setMode($.LINE_LOOP):et.setMode($.LINE_STRIP)}else oe.isPoints?et.setMode($.POINTS):oe.isSprite&&et.setMode($.TRIANGLES);if(oe.isBatchedMesh)if(wt.get("WEBGL_multi_draw"))et.renderMultiDraw(oe._multiDrawStarts,oe._multiDrawCounts,oe._multiDrawCount);else{const St=oe._multiDrawStarts,qe=oe._multiDrawCounts,Qt=oe._multiDrawCount,Tt=Je?fe.get(Je).bytesPerElement:1,ln=he.get(ae).currentProgram.getUniforms();for(let Mt=0;Mt<Qt;Mt++)ln.setValue($,"_gl_DrawID",Mt),et.render(St[Mt]/Tt,qe[Mt])}else if(oe.isInstancedMesh)et.renderInstances(Ae,at,oe.count);else if(me.isInstancedBufferGeometry){const St=me._maxInstanceCount!==void 0?me._maxInstanceCount:1/0,qe=Math.min(me.instanceCount,St);et.renderInstances(Ae,at,qe)}else et.render(Ae,at)};function Xi(I,q,me,ae){j!==null&&I.isNodeMaterial&&j.setObject(ae,I),Et===!0&&K.setState(I,me,!1),I.transparent===!0&&I.side===zi&&I.forceSinglePass===!1?(I.side=Jn,I.needsUpdate=!0,Fn(I,q,ae),I.side=Ds,I.needsUpdate=!0,Fn(I,q,ae),I.side=zi):Fn(I,q,ae)}this.compile=function(I,q,me=null){me===null&&(me=I),j!==null&&j.renderStart(I,q,me),N=Ee.get(me),N.init(q),E.push(N),me.traverseVisible(function(oe){oe.isLight&&oe.layers.test(q.layers)&&(N.pushLight(oe),oe.castShadow&&N.pushShadow(oe))}),I!==me&&I.traverseVisible(function(oe){oe.isLight&&oe.layers.test(q.layers)&&(N.pushLight(oe),oe.castShadow&&N.pushShadow(oe))}),N.setupLights(),j!==null&&j.updateLights(N.state.lightsArray),Ot=this.localClippingEnabled,Et=K.init(this.clippingPlanes,Ot),Et===!0&&K.setGlobalState(this.clippingPlanes,q),j!==null&&Ue.render(N.state.shadowsArray,me,q);const ae=new Set;return I.traverse(function(oe){if(!(oe.isMesh||oe.isPoints||oe.isLine||oe.isSprite))return;const We=oe.material;if(We)if(Array.isArray(We))for(let ze=0;ze<We.length;ze++){const je=We[ze];Xi(je,me,q,oe),ae.add(je)}else Xi(We,me,q,oe),ae.add(We)}),N=E.pop(),j!==null&&j.renderEnd(),ae},this.compileAsync=function(I,q,me=null){const ae=this.compile(I,q,me);return new Promise(oe=>{function We(){if(ae.forEach(function(ze){const Je=he.get(ze).currentProgram;(Je===void 0||Je.isReady())&&ae.delete(ze)}),ae.size===0){oe(I);return}setTimeout(We,10)}wt.get("KHR_parallel_shader_compile")!==null?We():setTimeout(We,10)})};let bi=null;function lr(I){bi&&bi(I)}function Yi(){wn.stop()}function Vs(){wn.start()}const wn=new Lv;wn.setAnimationLoop(lr),typeof self<"u"&&wn.setContext(self),this.setAnimationLoop=function(I){bi=I,$e.setAnimationLoop(I),I===null?wn.stop():wn.start()},$e.addEventListener("sessionstart",Yi),$e.addEventListener("sessionend",Vs),this.render=function(I,q){if(q!==void 0&&q.isCamera!==!0){zt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(X===!0)return;j!==null&&j.renderStart(I,q);const me=$e.enabled===!0&&$e.isPresenting===!0,ae=L!==null&&(te===null||me)&&L.begin(B,te);if(I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),q.parent===null&&q.matrixWorldAutoUpdate===!0&&q.updateMatrixWorld(),$e.enabled===!0&&$e.isPresenting===!0&&(L===null||L.isCompositing()===!1)&&($e.cameraAutoUpdate===!0&&$e.updateCamera(q),q=$e.getCamera()),I.isScene===!0&&I.onBeforeRender(B,I,q,te),N=Ee.get(I,E.length),N.init(q),N.state.textureUnits=ye.getTextureUnits(),E.push(N),xt.multiplyMatrices(q.projectionMatrix,q.matrixWorldInverse),lt.setFromProjectionMatrix(xt,ir,q.reversedDepth),Ot=this.localClippingEnabled,Et=K.init(this.clippingPlanes,Ot),R=ve.get(I,F.length),R.init(),F.push(R),$e.enabled===!0&&$e.isPresenting===!0){const ze=B.xr.getDepthSensingMesh();ze!==null&&cr(ze,q,-1/0,B.sortObjects)}cr(I,q,0,B.sortObjects),R.finish(),j!==null&&j.updateLights(N.state.lightsArray),B.sortObjects===!0&&R.sort(Ne,tt),_t=$e.enabled===!1||$e.isPresenting===!1||$e.hasDepthSensing()===!1,_t&&_e.addToRenderList(R,I),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),Et===!0&&K.beginShadows();const oe=N.state.shadowsArray;if(Ue.render(oe,I,q),Et===!0&&K.endShadows(),(ae&&L.hasRenderPass())===!1){const ze=R.opaque,je=R.transmissive;if(N.setupLights(),q.isArrayCamera){const Je=q.cameras;if(je.length>0)for(let nt=0,pt=Je.length;nt<pt;nt++){const Me=Je[nt];Hs(ze,je,I,Me)}_t&&_e.render(I);for(let nt=0,pt=Je.length;nt<pt;nt++){const Me=Je[nt];Lr(R,I,Me,Me.viewport)}}else je.length>0&&Hs(ze,je,I,q),_t&&_e.render(I),Lr(R,I,q)}te!==null&&Q===0&&(ye.updateMultisampleRenderTarget(te),ye.updateRenderTargetMipmap(te)),ae&&L.end(B),I.isScene===!0&&I.onAfterRender(B,I,q),Ge.resetDefaultState(),G=-1,ee=null,E.pop(),E.length>0?(N=E[E.length-1],ye.setTextureUnits(N.state.textureUnits),Et===!0&&K.setGlobalState(B.clippingPlanes,N.state.camera)):N=null,F.pop(),F.length>0?R=F[F.length-1]:R=null,j!==null&&j.renderEnd()};function cr(I,q,me,ae){if(I.visible===!1)return;if(I.layers.test(q.layers)){if(I.isGroup)me=I.renderOrder;else if(I.isLOD)I.autoUpdate===!0&&I.update(q);else if(I.isLightProbeGrid)N.pushLightProbeGrid(I);else if(I.isLight)N.pushLight(I),I.castShadow&&N.pushShadow(I);else if(I.isSprite){if(!I.frustumCulled||I.intersectsFrustum(lt)){ae&&Xt.setFromMatrixPosition(I.matrixWorld).applyMatrix4(xt);const ze=se.update(I),je=I.material;je.visible&&R.push(I,ze,je,me,Xt.z,null,q)}}else if((I.isMesh||I.isLine||I.isPoints)&&(!I.frustumCulled||I.intersectsFrustum(lt))){const ze=se.update(I),je=I.material;if(ae&&(I.boundingSphere!==void 0?(I.boundingSphere===null&&I.computeBoundingSphere(),Xt.copy(I.boundingSphere.center)):(ze.boundingSphere===null&&ze.computeBoundingSphere(),Xt.copy(ze.boundingSphere.center)),Xt.applyMatrix4(I.matrixWorld).applyMatrix4(xt)),Array.isArray(je)){const Je=ze.groups;for(let nt=0,pt=Je.length;nt<pt;nt++){const Me=Je[nt],Ae=je[Me.materialIndex];Ae&&Ae.visible&&R.push(I,ze,Ae,me,Xt.z,Me,q)}}else je.visible&&R.push(I,ze,je,me,Xt.z,null,q)}}const We=I.children;for(let ze=0,je=We.length;ze<je;ze++)cr(We[ze],q,me,ae)}function Lr(I,q,me,ae){const{opaque:oe,transmissive:We,transparent:ze}=I;N.setupLightsView(me),Et===!0&&K.setGlobalState(B.clippingPlanes,me),ae&&w.viewport(O.copy(ae)),oe.length>0&&qi(oe,q,me),We.length>0&&qi(We,q,me),ze.length>0&&qi(ze,q,me),w.buffers.depth.setTest(!0),w.buffers.depth.setMask(!0),w.buffers.color.setMask(!0),w.setPolygonOffset(!1)}function Hs(I,q,me,ae){if((me.isScene===!0?me.overrideMaterial:null)!==null)return;if(N.state.transmissionRenderTarget[ae.id]===void 0){const Ae=wt.has("EXT_color_buffer_half_float")||wt.has("EXT_color_buffer_float");N.state.transmissionRenderTarget[ae.id]=new Wi(1,1,{generateMipmaps:!0,type:Ae?or:vi,minFilter:Is,samples:Math.max(4,k.samples),stencilBuffer:l,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Dt.workingColorSpace})}const We=N.state.transmissionRenderTarget[ae.id],ze=ae.viewport||O;We.setSize(ze.z*B.transmissionResolutionScale,ze.w*B.transmissionResolutionScale);const je=B.getRenderTarget(),Je=B.getActiveCubeFace(),nt=B.getActiveMipmapLevel();B.setRenderTarget(We),B.getClearColor(Te),De=B.getClearAlpha(),De<1&&B.setClearColor(16777215,.5),B.clear(),_t&&_e.render(me);const pt=B.toneMapping;B.toneMapping=rr;const Me=ae.viewport;if(ae.viewport!==void 0&&(ae.viewport=void 0),N.setupLightsView(ae),Et===!0&&K.setGlobalState(B.clippingPlanes,ae),qi(I,me,ae),ye.updateMultisampleRenderTarget(We),ye.updateRenderTargetMipmap(We),wt.has("WEBGL_multisampled_render_to_texture")===!1){let Ae=!1;for(let He=0,at=q.length;He<at;He++){const ft=q[He],{object:et,geometry:St,material:qe,group:Qt}=ft;if(qe.side===zi&&et.layers.test(ae.layers)){const Tt=qe.side;qe.side=Jn,qe.needsUpdate=!0,Nr(et,me,ae,St,qe,Qt),qe.side=Tt,qe.needsUpdate=!0,Ae=!0}}Ae===!0&&(ye.updateMultisampleRenderTarget(We),ye.updateRenderTargetMipmap(We))}B.setRenderTarget(je,Je,nt),B.setClearColor(Te,De),Me!==void 0&&(ae.viewport=Me),B.toneMapping=pt}function qi(I,q,me){const ae=q.isScene===!0?q.overrideMaterial:null;for(let oe=0,We=I.length;oe<We;oe++){const ze=I[oe],{object:je,geometry:Je,group:nt}=ze;let pt=ze.material;pt.allowOverride===!0&&ae!==null&&(pt=ae),je.layers.test(me.layers)&&Nr(je,q,me,Je,pt,nt)}}function Nr(I,q,me,ae,oe,We){j!==null&&oe.isNodeMaterial&&j.setObject(I,oe),I.onBeforeRender(B,q,me,ae,oe,We),I.modelViewMatrix.multiplyMatrices(me.matrixWorldInverse,I.matrixWorld),I.normalMatrix.getNormalMatrix(I.modelViewMatrix),oe.onBeforeRender(B,q,me,ae,I,We),oe.transparent===!0&&oe.side===zi&&oe.forceSinglePass===!1?(oe.side=Jn,oe.needsUpdate=!0,B.renderBufferDirect(me,q,ae,oe,I,We),oe.side=Ds,oe.needsUpdate=!0,B.renderBufferDirect(me,q,ae,oe,I,We),oe.side=zi):B.renderBufferDirect(me,q,ae,oe,I,We),I.onAfterRender(B,q,me,ae,oe,We)}function Fn(I,q,me){q.isScene!==!0&&(q=Wt);const ae=he.get(I),oe=N.state.lights,We=N.state.shadowsArray,ze=oe.state.version,je=be.getParameters(I,oe.state,We,q,me,N.state.lightProbeGridArray),Je=be.getProgramCacheKey(je);let nt=ae.programs;ae.environment=I.isMeshStandardMaterial||I.isMeshLambertMaterial||I.isMeshPhongMaterial?q.environment:null,ae.fog=q.fog;const pt=I.isMeshStandardMaterial||I.isMeshLambertMaterial&&!I.envMap||I.isMeshPhongMaterial&&!I.envMap;ae.envMap=Pe.get(I.envMap||ae.environment,pt),ae.envMapRotation=ae.environment!==null&&I.envMap===null?q.environmentRotation:I.envMapRotation,nt===void 0&&(I.addEventListener("dispose",ei),nt=new Map,ae.programs=nt);let Me=nt.get(Je);if(Me!==void 0){if(ae.currentProgram===Me&&ae.lightsStateVersion===ze)return ti(I,je),Me}else je.uniforms=be.getUniforms(I),j!==null&&I.isNodeMaterial&&j.build(I,me,je),I.onBeforeCompile(je,B),Me=be.acquireProgram(je,Je),nt.set(Je,Me),ae.uniforms=je.uniforms;const Ae=ae.uniforms;return(!I.isShaderMaterial&&!I.isRawShaderMaterial||I.clipping===!0)&&(Ae.clippingPlanes=K.uniform),ti(I,je),ae.needsLights=Dr(I),ae.lightsStateVersion=ze,ae.needsLights&&(Ae.ambientLightColor.value=oe.state.ambient,Ae.lightProbe.value=oe.state.probe,Ae.sunLights.value=oe.state.sun,Ae.sunLightShadows.value=oe.state.sunShadow,Ae.directionalLights.value=oe.state.directional,Ae.directionalLightShadows.value=oe.state.directionalShadow,Ae.spotLights.value=oe.state.spot,Ae.spotLightShadows.value=oe.state.spotShadow,Ae.rectAreaLights.value=oe.state.rectArea,Ae.ltc_1.value=oe.state.rectAreaLTC1,Ae.ltc_2.value=oe.state.rectAreaLTC2,Ae.pointLights.value=oe.state.point,Ae.pointLightShadows.value=oe.state.pointShadow,Ae.hemisphereLights.value=oe.state.hemi,Ae.sunShadowMatrix.value=oe.state.sunShadowMatrix,Ae.sunShadowCascade.value=oe.state.sunShadowCascade,Ae.directionalShadowMatrix.value=oe.state.directionalShadowMatrix,Ae.spotLightMatrix.value=oe.state.spotLightMatrix,Ae.spotLightMap.value=oe.state.spotLightMap,Ae.pointShadowMatrix.value=oe.state.pointShadowMatrix),ae.lightProbeGrid=N.state.lightProbeGridArray.length>0,ae.currentProgram=Me,ae.uniformsList=null,Me}function ur(I){if(I.uniformsList===null){const q=I.currentProgram.getUniforms();I.uniformsList=Dc.seqWithValue(q.seq,I.uniforms)}return I.uniformsList}function ti(I,q){const me=he.get(I);me.outputColorSpace=q.outputColorSpace,me.batching=q.batching,me.batchingColor=q.batchingColor,me.instancing=q.instancing,me.instancingColor=q.instancingColor,me.instancingMorph=q.instancingMorph,me.skinning=q.skinning,me.morphTargets=q.morphTargets,me.morphNormals=q.morphNormals,me.morphColors=q.morphColors,me.morphTargetsCount=q.morphTargetsCount,me.numClippingPlanes=q.numClippingPlanes,me.numIntersection=q.numClipIntersection,me.vertexAlphas=q.vertexAlphas,me.vertexTangents=q.vertexTangents,me.toneMapping=q.toneMapping}function Go(I,q){if(I.length===0)return null;if(I.length===1)return I[0].texture!==null?I[0]:null;b.setFromMatrixPosition(q.matrixWorld);for(let me=0,ae=I.length;me<ae;me++){const oe=I[me];if(oe.texture!==null&&oe.boundingBox.containsPoint(b))return oe}return null}function $t(I,q,me,ae,oe){q.isScene!==!0&&(q=Wt),ye.resetTextureUnits();const We=q.fog,ze=ae.isMeshStandardMaterial||ae.isMeshLambertMaterial||ae.isMeshPhongMaterial?q.environment:null,je=te===null?B.outputColorSpace:te.isXRRenderTarget===!0?te.texture.colorSpace:Dt.workingColorSpace,Je=ae.isMeshStandardMaterial||ae.isMeshLambertMaterial&&!ae.envMap||ae.isMeshPhongMaterial&&!ae.envMap,nt=Pe.get(ae.envMap||ze,Je),pt=ae.vertexColors===!0&&!!me.attributes.color&&me.attributes.color.itemSize===4,Me=!!me.attributes.tangent&&(!!ae.normalMap||ae.anisotropy>0),Ae=!!me.morphAttributes.position,He=!!me.morphAttributes.normal,at=!!me.morphAttributes.color;let ft=rr;ae.toneMapped&&(te===null||te.isXRRenderTarget===!0)&&(ft=B.toneMapping);const et=me.morphAttributes.position||me.morphAttributes.normal||me.morphAttributes.color,St=et!==void 0?et.length:0,qe=he.get(ae),Qt=N.state.lights;if(Et===!0&&(Ot===!0||I!==ee)){const Ft=I===ee&&ae.id===G;K.setState(ae,I,Ft)}let Tt=!1;ae.version===qe.__version?(qe.needsLights&&qe.lightsStateVersion!==Qt.state.version||qe.outputColorSpace!==je||oe.isBatchedMesh&&qe.batching===!1||!oe.isBatchedMesh&&qe.batching===!0||oe.isBatchedMesh&&qe.batchingColor===!0&&oe._colorsTexture===null||oe.isBatchedMesh&&qe.batchingColor===!1&&oe._colorsTexture!==null||oe.isInstancedMesh&&qe.instancing===!1||!oe.isInstancedMesh&&qe.instancing===!0||oe.isSkinnedMesh&&qe.skinning===!1||!oe.isSkinnedMesh&&qe.skinning===!0||oe.isInstancedMesh&&qe.instancingColor===!0&&oe.instanceColor===null||oe.isInstancedMesh&&qe.instancingColor===!1&&oe.instanceColor!==null||oe.isInstancedMesh&&qe.instancingMorph===!0&&oe.morphTexture===null||oe.isInstancedMesh&&qe.instancingMorph===!1&&oe.morphTexture!==null||qe.envMap!==nt||ae.fog===!0&&qe.fog!==We||qe.numClippingPlanes!==void 0&&(qe.numClippingPlanes!==K.numPlanes||qe.numIntersection!==K.numIntersection)||qe.vertexAlphas!==pt||qe.vertexTangents!==Me||qe.morphTargets!==Ae||qe.morphNormals!==He||qe.morphColors!==at||qe.toneMapping!==ft||qe.morphTargetsCount!==St||!!qe.lightProbeGrid!=N.state.lightProbeGridArray.length>0)&&(Tt=!0):(Tt=!0,qe.__version=ae.version);let ln=qe.currentProgram;Tt===!0&&(ln=Fn(ae,q,oe),j&&ae.isNodeMaterial&&j.onUpdateProgram(ae,ln,qe));let Mt=!1,en=!1,Tn=!1;const Rt=ln.getUniforms(),Vt=qe.uniforms;if(w.useProgram(ln.program)&&(Mt=!0,en=!0,Tn=!0),ae.id!==G&&(G=ae.id,en=!0),qe.needsLights){const Ft=Go(N.state.lightProbeGridArray,oe);qe.lightProbeGrid!==Ft&&(qe.lightProbeGrid=Ft,en=!0)}if(Mt||ee!==I){w.buffers.depth.getReversed()&&I.reversedDepth!==!0&&(I._reversedDepth=!0,I.updateProjectionMatrix()),Rt.setValue($,"projectionMatrix",I.projectionMatrix),Rt.setValue($,"viewMatrix",I.matrixWorldInverse);const cn=Rt.map.cameraPosition;cn!==void 0&&cn.setValue($,At.setFromMatrixPosition(I.matrixWorld)),k.logarithmicDepthBuffer&&Rt.setValue($,"logDepthBufFC",2/(Math.log(I.far+1)/Math.LN2)),(ae.isMeshPhongMaterial||ae.isMeshToonMaterial||ae.isMeshLambertMaterial||ae.isMeshBasicMaterial||ae.isMeshStandardMaterial||ae.isShaderMaterial)&&Rt.setValue($,"isOrthographic",I.isOrthographicCamera===!0),ee!==I&&(ee=I,en=!0,Tn=!0)}if(qe.needsLights&&(Qt.state.sunShadowMap.length>0&&Rt.setValue($,"sunShadowMap",Qt.state.sunShadowMap,ye),Qt.state.directionalShadowMap.length>0&&Rt.setValue($,"directionalShadowMap",Qt.state.directionalShadowMap,ye),Qt.state.spotShadowMap.length>0&&Rt.setValue($,"spotShadowMap",Qt.state.spotShadowMap,ye),Qt.state.pointShadowMap.length>0&&Rt.setValue($,"pointShadowMap",Qt.state.pointShadowMap,ye)),oe.isSkinnedMesh){Rt.setOptional($,oe,"bindMatrix"),Rt.setOptional($,oe,"bindMatrixInverse");const Ft=oe.skeleton;Ft&&(Ft.boneTexture===null&&Ft.computeBoneTexture(),Rt.setValue($,"boneTexture",Ft.boneTexture,ye))}oe.isBatchedMesh&&(Rt.setOptional($,oe,"batchingTexture"),Rt.setValue($,"batchingTexture",oe._matricesTexture,ye),Rt.setOptional($,oe,"batchingIdTexture"),Rt.setValue($,"batchingIdTexture",oe._indirectTexture,ye),Rt.setOptional($,oe,"batchingColorTexture"),oe._colorsTexture!==null&&Rt.setValue($,"batchingColorTexture",oe._colorsTexture,ye));const vn=me.morphAttributes;if((vn.position!==void 0||vn.normal!==void 0||vn.color!==void 0)&&V.update(oe,me,ln),(en||qe.receiveShadow!==oe.receiveShadow)&&(qe.receiveShadow=oe.receiveShadow,Rt.setValue($,"receiveShadow",oe.receiveShadow)),(ae.isMeshStandardMaterial||ae.isMeshLambertMaterial||ae.isMeshPhongMaterial)&&ae.envMap===null&&q.environment!==null&&(Vt.envMapIntensity.value=q.environmentIntensity),Vt.dfgLUT!==void 0&&(Vt.dfgLUT.value=HT()),en){if(Rt.setValue($,"toneMappingExposure",B.toneMappingExposure),qe.needsLights&&Gs(Vt,Tn),We&&ae.fog===!0&&Fe.refreshFogUniforms(Vt,We),Fe.refreshMaterialUniforms(Vt,ae,ge,le,N.state.transmissionRenderTarget[I.id]),qe.needsLights&&qe.lightProbeGrid){const Ft=qe.lightProbeGrid;Vt.probesSH.value=Ft.texture,Vt.probesMin.value.copy(Ft.boundingBox.min),Vt.probesMax.value.copy(Ft.boundingBox.max),Vt.probesResolution.value.copy(Ft.resolution)}Dc.upload($,ur(qe),Vt,ye)}if(ae.isShaderMaterial&&ae.uniformsNeedUpdate===!0&&(Dc.upload($,ur(qe),Vt,ye),ae.uniformsNeedUpdate=!1),ae.isSpriteMaterial&&Rt.setValue($,"center",oe.center),Rt.setValue($,"modelViewMatrix",oe.modelViewMatrix),Rt.setValue($,"normalMatrix",oe.normalMatrix),Rt.setValue($,"modelMatrix",oe.matrixWorld),ae.uniformsGroups!==void 0){const Ft=ae.uniformsGroups;for(let cn=0,On=Ft.length;cn<On;cn++){const qn=Ft[cn];we.update(qn,ln),we.bind(qn,ln)}}return ln}function Gs(I,q){I.ambientLightColor.needsUpdate=q,I.lightProbe.needsUpdate=q,I.sunLights.needsUpdate=q,I.sunLightShadows.needsUpdate=q,I.directionalLights.needsUpdate=q,I.directionalLightShadows.needsUpdate=q,I.pointLights.needsUpdate=q,I.pointLightShadows.needsUpdate=q,I.spotLights.needsUpdate=q,I.spotLightShadows.needsUpdate=q,I.rectAreaLights.needsUpdate=q,I.hemisphereLights.needsUpdate=q}function Dr(I){return I.isMeshLambertMaterial||I.isMeshToonMaterial||I.isMeshPhongMaterial||I.isMeshStandardMaterial||I.isShadowMaterial||I.isShaderMaterial&&I.lights===!0}this.getActiveCubeFace=function(){return ue},this.getActiveMipmapLevel=function(){return Q},this.getRenderTarget=function(){return te},this.setRenderTargetTextures=function(I,q,me){const ae=he.get(I);ae.__autoAllocateDepthBuffer=I.resolveDepthBuffer===!1,ae.__autoAllocateDepthBuffer===!1&&(ae.__useRenderToTexture=!1),he.get(I.texture).__webglTexture=q,he.get(I.depthTexture).__webglTexture=ae.__autoAllocateDepthBuffer?void 0:me,ae.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(I,q){const me=he.get(I);me.__webglFramebuffer=q,me.__useDefaultFramebuffer=q===void 0},this.setRenderTarget=function(I,q=0,me=0){te=I,ue=q,Q=me;let ae=null,oe=!1,We=!1;if(I){const je=he.get(I);if(je.__useDefaultFramebuffer!==void 0){w.bindFramebuffer($.FRAMEBUFFER,je.__webglFramebuffer),O.copy(I.viewport),de.copy(I.scissor),Ce=I.scissorTest,w.viewport(O),w.scissor(de),w.setScissorTest(Ce),G=-1;return}else if(je.__webglFramebuffer===void 0)ye.setupRenderTarget(I);else if(je.__hasExternalTextures)ye.rebindTextures(I,he.get(I.texture).__webglTexture,he.get(I.depthTexture).__webglTexture);else if(I.depthBuffer){const pt=I.depthTexture;if(je.__boundDepthTexture!==pt){if(pt!==null&&he.has(pt)&&(I.width!==pt.image.width||I.height!==pt.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");ye.setupDepthRenderbuffer(I)}}const Je=I.texture;(Je.isData3DTexture||Je.isDataArrayTexture||Je.isCompressedArrayTexture)&&(We=!0);const nt=he.get(I).__webglFramebuffer;I.isWebGLCubeRenderTarget?(Array.isArray(nt[q])?ae=nt[q][me]:ae=nt[q],oe=!0):I.samples>0&&ye.useMultisampledRTT(I)===!1?ae=he.get(I).__webglMultisampledFramebuffer:Array.isArray(nt)?ae=nt[me]:ae=nt,O.copy(I.viewport),de.copy(I.scissor),Ce=I.scissorTest}else O.copy(Xe).multiplyScalar(ge).floor(),de.copy(mt).multiplyScalar(ge).floor(),Ce=Gt;if(me!==0&&(ae=ne),w.bindFramebuffer($.FRAMEBUFFER,ae)&&w.drawBuffers(I,ae),w.viewport(O),w.scissor(de),w.setScissorTest(Ce),oe){const je=he.get(I.texture);$.framebufferTexture2D($.FRAMEBUFFER,$.COLOR_ATTACHMENT0,$.TEXTURE_CUBE_MAP_POSITIVE_X+q,je.__webglTexture,me)}else if(We){const je=q;for(let Je=0;Je<I.textures.length;Je++){const nt=he.get(I.textures[Je]);$.framebufferTextureLayer($.FRAMEBUFFER,$.COLOR_ATTACHMENT0+Je,nt.__webglTexture,me,je)}}else if(I!==null&&me!==0){const je=he.get(I.texture);$.framebufferTexture2D($.FRAMEBUFFER,$.COLOR_ATTACHMENT0,$.TEXTURE_2D,je.__webglTexture,me)}G=-1};function Ur(I){const q=he.get(I);return(q.__readFormat!==I.format||q.__readType!==I.type)&&(q.__readFormat=I.format,q.__readType=I.type,q.__formatReadable=k.textureFormatReadable(I.format),q.__typeReadable=k.textureTypeReadable(I.type)),q}this.readRenderTargetPixels=function(I,q,me,ae,oe,We,ze,je=0){if(!(I&&I.isWebGLRenderTarget)){zt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Je=he.get(I).__webglFramebuffer;if(I.isWebGLCubeRenderTarget&&ze!==void 0&&(Je=Je[ze]),Je){w.bindFramebuffer($.FRAMEBUFFER,Je);try{const nt=I.textures[je],pt=nt.format,Me=nt.type;I.textures.length>1&&$.readBuffer($.COLOR_ATTACHMENT0+je);const Ae=Ur(nt);if(Ae.__formatReadable===!1){zt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Ae.__typeReadable===!1){zt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}q>=0&&q<=I.width-ae&&me>=0&&me<=I.height-oe&&$.readPixels(q,me,ae,oe,Ve.convert(pt),Ve.convert(Me),We)}finally{const nt=te!==null?he.get(te).__webglFramebuffer:null;w.bindFramebuffer($.FRAMEBUFFER,nt)}}},this.readRenderTargetPixelsAsync=async function(I,q,me,ae,oe,We,ze,je=0){if(!(I&&I.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Je=he.get(I).__webglFramebuffer;if(I.isWebGLCubeRenderTarget&&ze!==void 0&&(Je=Je[ze]),Je)if(q>=0&&q<=I.width-ae&&me>=0&&me<=I.height-oe){w.bindFramebuffer($.FRAMEBUFFER,Je);const nt=I.textures[je],pt=nt.format,Me=nt.type;I.textures.length>1&&$.readBuffer($.COLOR_ATTACHMENT0+je);const Ae=Ur(nt);if(Ae.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Ae.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const He=$.createBuffer();$.bindBuffer($.PIXEL_PACK_BUFFER,He),$.bufferData($.PIXEL_PACK_BUFFER,We.byteLength,$.STREAM_READ),$.readPixels(q,me,ae,oe,Ve.convert(pt),Ve.convert(Me),0),$.bindBuffer($.PIXEL_PACK_BUFFER,null);const at=te!==null?he.get(te).__webglFramebuffer:null;w.bindFramebuffer($.FRAMEBUFFER,at);const ft=$.fenceSync($.SYNC_GPU_COMMANDS_COMPLETE,0);return $.flush(),await $_($,ft,4),$.bindBuffer($.PIXEL_PACK_BUFFER,He),$.getBufferSubData($.PIXEL_PACK_BUFFER,0,We),$.bindBuffer($.PIXEL_PACK_BUFFER,null),$.deleteBuffer(He),$.deleteSync(ft),We}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(I,q=null,me=0){const ae=Math.pow(2,-me),oe=Math.floor(I.image.width*ae),We=Math.floor(I.image.height*ae),ze=q!==null?q.x:0,je=q!==null?q.y:0;ye.setTexture2D(I,0),$.copyTexSubImage2D($.TEXTURE_2D,me,0,0,ze,je,oe,We),w.unbindTexture()},this.copyTextureToTexture=function(I,q,me=null,ae=null,oe=0,We=0){let ze,je,Je,nt,pt,Me,Ae,He,at;const ft=I.isCompressedTexture?I.mipmaps[We]:I.image;if(me!==null)ze=me.max.x-me.min.x,je=me.max.y-me.min.y,Je=me.isBox3?me.max.z-me.min.z:1,nt=me.min.x,pt=me.min.y,Me=me.isBox3?me.min.z:0;else{const Vt=Math.pow(2,-oe);ze=Math.floor(ft.width*Vt),je=Math.floor(ft.height*Vt),I.isDataArrayTexture?Je=ft.depth:I.isData3DTexture?Je=Math.floor(ft.depth*Vt):Je=1,nt=0,pt=0,Me=0}ae!==null?(Ae=ae.x,He=ae.y,at=ae.z):(Ae=0,He=0,at=0);const et=Ve.convert(q.format),St=Ve.convert(q.type);let qe;q.isData3DTexture?(ye.setTexture3D(q,0),qe=$.TEXTURE_3D):q.isDataArrayTexture||q.isCompressedArrayTexture?(ye.setTexture2DArray(q,0),qe=$.TEXTURE_2D_ARRAY):(ye.setTexture2D(q,0),qe=$.TEXTURE_2D),w.activeTexture($.TEXTURE0),w.pixelStorei($.UNPACK_FLIP_Y_WEBGL,q.flipY),w.pixelStorei($.UNPACK_PREMULTIPLY_ALPHA_WEBGL,q.premultiplyAlpha),w.pixelStorei($.UNPACK_ALIGNMENT,q.unpackAlignment);const Qt=w.getParameter($.UNPACK_ROW_LENGTH),Tt=w.getParameter($.UNPACK_IMAGE_HEIGHT),ln=w.getParameter($.UNPACK_SKIP_PIXELS),Mt=w.getParameter($.UNPACK_SKIP_ROWS),en=w.getParameter($.UNPACK_SKIP_IMAGES);w.pixelStorei($.UNPACK_ROW_LENGTH,ft.width),w.pixelStorei($.UNPACK_IMAGE_HEIGHT,ft.height),w.pixelStorei($.UNPACK_SKIP_PIXELS,nt),w.pixelStorei($.UNPACK_SKIP_ROWS,pt),w.pixelStorei($.UNPACK_SKIP_IMAGES,Me);const Tn=I.isDataArrayTexture||I.isData3DTexture,Rt=q.isDataArrayTexture||q.isData3DTexture;if(I.isDepthTexture){const Vt=he.get(I),vn=he.get(q),Ft=he.get(Vt.__renderTarget),cn=he.get(vn.__renderTarget);w.bindFramebuffer($.READ_FRAMEBUFFER,Ft.__webglFramebuffer),w.bindFramebuffer($.DRAW_FRAMEBUFFER,cn.__webglFramebuffer);for(let On=0;On<Je;On++)Tn&&($.framebufferTextureLayer($.READ_FRAMEBUFFER,$.COLOR_ATTACHMENT0,he.get(I).__webglTexture,oe,Me+On),$.framebufferTextureLayer($.DRAW_FRAMEBUFFER,$.COLOR_ATTACHMENT0,he.get(q).__webglTexture,We,at+On)),$.blitFramebuffer(nt,pt,ze,je,Ae,He,ze,je,$.DEPTH_BUFFER_BIT,$.NEAREST);w.bindFramebuffer($.READ_FRAMEBUFFER,null),w.bindFramebuffer($.DRAW_FRAMEBUFFER,null)}else if(oe!==0||I.isRenderTargetTexture||he.has(I)){const Vt=he.get(I),vn=he.get(q);w.bindFramebuffer($.READ_FRAMEBUFFER,H),w.bindFramebuffer($.DRAW_FRAMEBUFFER,W);for(let Ft=0;Ft<Je;Ft++)Tn?$.framebufferTextureLayer($.READ_FRAMEBUFFER,$.COLOR_ATTACHMENT0,Vt.__webglTexture,oe,Me+Ft):$.framebufferTexture2D($.READ_FRAMEBUFFER,$.COLOR_ATTACHMENT0,$.TEXTURE_2D,Vt.__webglTexture,oe),Rt?$.framebufferTextureLayer($.DRAW_FRAMEBUFFER,$.COLOR_ATTACHMENT0,vn.__webglTexture,We,at+Ft):$.framebufferTexture2D($.DRAW_FRAMEBUFFER,$.COLOR_ATTACHMENT0,$.TEXTURE_2D,vn.__webglTexture,We),oe!==0?$.blitFramebuffer(nt,pt,ze,je,Ae,He,ze,je,$.COLOR_BUFFER_BIT,$.NEAREST):Rt?$.copyTexSubImage3D(qe,We,Ae,He,at+Ft,nt,pt,ze,je):$.copyTexSubImage2D(qe,We,Ae,He,nt,pt,ze,je);w.bindFramebuffer($.READ_FRAMEBUFFER,null),w.bindFramebuffer($.DRAW_FRAMEBUFFER,null)}else Rt?I.isDataTexture||I.isData3DTexture?$.texSubImage3D(qe,We,Ae,He,at,ze,je,Je,et,St,ft.data):q.isCompressedArrayTexture?$.compressedTexSubImage3D(qe,We,Ae,He,at,ze,je,Je,et,ft.data):$.texSubImage3D(qe,We,Ae,He,at,ze,je,Je,et,St,ft):I.isDataTexture?$.texSubImage2D($.TEXTURE_2D,We,Ae,He,ze,je,et,St,ft.data):I.isCompressedTexture?$.compressedTexSubImage2D($.TEXTURE_2D,We,Ae,He,ft.width,ft.height,et,ft.data):$.texSubImage2D($.TEXTURE_2D,We,Ae,He,ze,je,et,St,ft);w.pixelStorei($.UNPACK_ROW_LENGTH,Qt),w.pixelStorei($.UNPACK_IMAGE_HEIGHT,Tt),w.pixelStorei($.UNPACK_SKIP_PIXELS,ln),w.pixelStorei($.UNPACK_SKIP_ROWS,Mt),w.pixelStorei($.UNPACK_SKIP_IMAGES,en),We===0&&q.generateMipmaps&&$.generateMipmap(qe),w.unbindTexture()},this.initRenderTarget=function(I){he.get(I).__webglFramebuffer===void 0&&ye.setupRenderTarget(I)},this.initTexture=function(I){I.isCubeTexture?ye.setTextureCube(I,0):I.isData3DTexture?ye.setTexture3D(I,0):I.isDataArrayTexture||I.isCompressedArrayTexture?ye.setTexture2DArray(I,0):ye.setTexture2D(I,0),w.unbindTexture()},this.resetState=function(){ue=0,Q=0,te=null,w.reset(),Ge.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ir}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=Dt._getDrawingBufferColorSpace(e),t.unpackColorSpace=Dt._getUnpackColorSpace()}}const D0={type:"change"},kh={type:"start"},zv={type:"end"},Tc=new Ka,U0=new Tr,WT=Math.cos(70*Q_.DEG2RAD),_n=new Z,ci=2*Math.PI,Kt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},gf=1e-6;class jT extends j1{constructor(e,t=null){super(e,t),this.state=Kt.NONE,this.target=new Z,this.cursor=new Z,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Do.ROTATE,MIDDLE:Do.DOLLY,RIGHT:Do.PAN},this.touches={ONE:Ro.ROTATE,TWO:Ro.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new Z,this._lastQuaternion=new ls,this._lastTargetPosition=new Z,this._quat=new ls().setFromUnitVectors(e.up,new Z(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new c0,this._sphericalDelta=new c0,this._scale=1,this._panOffset=new Z,this._rotateStart=new dt,this._rotateEnd=new dt,this._rotateDelta=new dt,this._panStart=new dt,this._panEnd=new dt,this._panDelta=new dt,this._dollyStart=new dt,this._dollyEnd=new dt,this._dollyDelta=new dt,this._dollyDirection=new Z,this._mouse=new dt,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=YT.bind(this),this._onPointerDown=XT.bind(this),this._onPointerUp=qT.bind(this),this._onContextMenu=tA.bind(this),this._onMouseWheel=ZT.bind(this),this._onKeyDown=JT.bind(this),this._onTouchStart=QT.bind(this),this._onTouchMove=eA.bind(this),this._onMouseDown=KT.bind(this),this._onMouseMove=$T.bind(this),this._interceptControlDown=nA.bind(this),this._interceptControlUp=iA.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.state=Kt.NONE,this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents();const e=this.domElement.getRootNode();e.removeEventListener("keydown",this._interceptControlDown,{capture:!0}),e.removeEventListener("keyup",this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction="",this.domElement.style.cursor="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(D0),this.update(),this.state=Kt.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){const t=this.object.position;_n.copy(t).sub(this.target),_n.applyQuaternion(this._quat),this._spherical.setFromVector3(_n),this.autoRotate&&this.state===Kt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let r=this.minAzimuthAngle,o=this.maxAzimuthAngle;isFinite(r)&&isFinite(o)&&(r<-Math.PI?r+=ci:r>Math.PI&&(r-=ci),o<-Math.PI?o+=ci:o>Math.PI&&(o-=ci),r<=o?this._spherical.theta=Math.max(r,Math.min(o,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(r+o)/2?Math.max(r,this._spherical.theta):Math.min(o,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let l=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const u=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),l=u!=this._spherical.radius}if(_n.setFromSpherical(this._spherical),_n.applyQuaternion(this._quatInverse),t.copy(this.target).add(_n),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let u=null;if(this.object.isPerspectiveCamera){const d=_n.length();u=this._clampDistance(d*this._scale);const f=d-u;this.object.position.addScaledVector(this._dollyDirection,f),this.object.updateMatrixWorld(),l=!!f}else if(this.object.isOrthographicCamera){const d=new Z(this._mouse.x,this._mouse.y,0);d.unproject(this.object);const f=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),l=f!==this.object.zoom;const p=new Z(this._mouse.x,this._mouse.y,0);p.unproject(this.object),this.object.position.sub(p).add(d),this.object.updateMatrixWorld(),u=_n.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;u!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(u).add(this.object.position):(Tc.origin.copy(this.object.position),Tc.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Tc.direction))<WT?this.object.lookAt(this.target):(U0.setFromNormalAndCoplanarPoint(this.object.up,this.target),Tc.intersectPlane(U0,this.target))))}else if(this.object.isOrthographicCamera){const u=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),u!==this.object.zoom&&(this.object.updateProjectionMatrix(),l=!0)}return this._scale=1,this._performCursorZoom=!1,l||this._lastPosition.distanceToSquared(this.object.position)>gf||8*(1-this._lastQuaternion.dot(this.object.quaternion))>gf||this._lastTargetPosition.distanceToSquared(this.target)>gf?(this.dispatchEvent(D0),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?ci/60*this.autoRotateSpeed*e:ci/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){_n.setFromMatrixColumn(t,0),_n.multiplyScalar(-e),this._panOffset.add(_n)}_panUp(e,t){this.screenSpacePanning===!0?_n.setFromMatrixColumn(t,1):(_n.setFromMatrixColumn(t,0),_n.crossVectors(this.object.up,_n)),_n.multiplyScalar(e),this._panOffset.add(_n)}_pan(e,t){const r=this.domElement;if(this.object.isPerspectiveCamera){const o=this.object.position;_n.copy(o).sub(this.target);let l=_n.length();l*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*l/r.clientHeight,this.object.matrix),this._panUp(2*t*l/r.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/r.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/r.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const r=this.domElement.getBoundingClientRect(),o=e-r.left,l=t-r.top,u=r.width,d=r.height;this._mouse.x=o/u*2-1,this._mouse.y=-(l/d)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(ci*this._rotateDelta.x/t.clientHeight),this._rotateUp(ci*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),o=.5*(e.pageY+t.y);this._rotateStart.set(r,o)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),o=.5*(e.pageY+t.y);this._panStart.set(r,o)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),r=e.pageX-t.x,o=e.pageY-t.y,l=Math.sqrt(r*r+o*o);this._dollyStart.set(0,l)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const r=this._getSecondPointerPosition(e),o=.5*(e.pageX+r.x),l=.5*(e.pageY+r.y);this._rotateEnd.set(o,l)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(ci*this._rotateDelta.x/t.clientHeight),this._rotateUp(ci*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),r=.5*(e.pageX+t.x),o=.5*(e.pageY+t.y);this._panEnd.set(r,o)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),r=e.pageX-t.x,o=e.pageY-t.y,l=Math.sqrt(r*r+o*o);this._dollyEnd.set(0,l),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const u=(e.pageX+t.x)*.5,d=(e.pageY+t.y)*.5;this._updateZoomParameters(u,d)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new dt,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,r={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:r.deltaY*=16;break;case 2:r.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(r.deltaY*=10),r}}function XT(s){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(s.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(s)&&(this._addPointer(s),s.pointerType==="touch"?this._onTouchStart(s):this._onMouseDown(s),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function YT(s){this.enabled!==!1&&(s.pointerType==="touch"?this._onTouchMove(s):this._onMouseMove(s))}function qT(s){switch(this._removePointer(s),this._pointers.length){case 0:this.domElement.releasePointerCapture(s.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(zv),this.state=Kt.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function KT(s){let e;switch(s.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Do.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(s),this.state=Kt.DOLLY;break;case Do.ROTATE:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=Kt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=Kt.ROTATE}break;case Do.PAN:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=Kt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=Kt.PAN}break;default:this.state=Kt.NONE}this.state!==Kt.NONE&&this.dispatchEvent(kh)}function $T(s){switch(this.state){case Kt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(s);break;case Kt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(s);break;case Kt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(s);break}}function ZT(s){this.enabled===!1||this.enableZoom===!1||this.state!==Kt.NONE||(s.preventDefault(),this.dispatchEvent(kh),this._handleMouseWheel(this._customWheelEvent(s)),this.dispatchEvent(zv))}function JT(s){this.enabled!==!1&&this._handleKeyDown(s)}function QT(s){switch(this._trackPointer(s),this._pointers.length){case 1:switch(this.touches.ONE){case Ro.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(s),this.state=Kt.TOUCH_ROTATE;break;case Ro.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(s),this.state=Kt.TOUCH_PAN;break;default:this.state=Kt.NONE}break;case 2:switch(this.touches.TWO){case Ro.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(s),this.state=Kt.TOUCH_DOLLY_PAN;break;case Ro.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(s),this.state=Kt.TOUCH_DOLLY_ROTATE;break;default:this.state=Kt.NONE}break;default:this.state=Kt.NONE}this.state!==Kt.NONE&&this.dispatchEvent(kh)}function eA(s){switch(this._trackPointer(s),this.state){case Kt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(s),this.update();break;case Kt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(s),this.update();break;case Kt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(s),this.update();break;case Kt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(s),this.update();break;default:this.state=Kt.NONE}}function tA(s){this.enabled!==!1&&s.preventDefault()}function nA(s){s.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function iA(s){s.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const pn=1.38;function wr(s,e,t=pn){const r=(90-s)*(Math.PI/180),o=(e+180)*(Math.PI/180),l=-(t*Math.sin(r)*Math.cos(o)),u=t*Math.sin(r)*Math.sin(o),d=t*Math.cos(r);return new Z(l,d,u)}function rA(s,e){return s>15&&s<72&&e>-165&&e<-52?!(s<25&&e<-110):s>=7&&s<=22&&e>=-95&&e<=-60?!0:s>-55&&s<12&&e>-82&&e<-34?!(s<-35&&e<-76):s>35&&s<71&&e>-10&&e<45?!0:s>-35&&s<37&&e>-18&&e<51?!(s<4&&e<8):s>8&&s<74&&e>=45&&e<145||s>-11&&s<=18&&e>=95&&e<=141||s>-44&&s<-11&&e>113&&e<154||s>-47&&s<-34&&e>166&&e<179||s>60&&s<83&&e>-73&&e<-18||s>30&&s<45&&e>129&&e<146||s>50&&s<59&&e>-11&&e<2}function sA({vpnStatus:s,locations:e=[],selectedLocationObj:t,realIpInfo:r,cameraMode:o="globe",theme:l="dark",onSelectLocation:u,onRequestConnection:d}){const f=Be.useRef(null),[p,y]=Be.useState(null),S=Be.useRef({vpnState:(s==null?void 0:s.state)||"Disconnected",selectedLocationObj:t,realIpInfo:r,cameraMode:o,theme:l,locations:e,onSelectLocation:u,onRequestConnection:d});Be.useEffect(()=>{S.current={vpnState:(s==null?void 0:s.state)||"Disconnected",selectedLocationObj:t,realIpInfo:r,cameraMode:o,theme:l,locations:e,onSelectLocation:u,onRequestConnection:d}},[s==null?void 0:s.state,t,r,o,l,e,u,d]);const v=Be.useRef({globeGroup:null,coreMaterial:null,atmosphereMaterial:null,shieldCageMaterial:null,shieldRingMaterials:[],tunnelLine:null,tunnelGlowLine:null,tunnelPacketsGeo:null,tunnelPacketsMat:null,tunnelCurve:null,targetBeaconGroup:null,targetRingMat:null,targetPillarMat:null,originBeaconGroup:null,originRingMat:null,targetRotationY:0,targetRotationX:.25,userInteracting:!1});return Be.useEffect(()=>{var W,ue,Q,te;const _=v.current;if(!_.globeGroup)return;const M=((W=r==null?void 0:r.coordinates)==null?void 0:W.lat)??23.8103,A=((ue=r==null?void 0:r.coordinates)==null?void 0:ue.lng)??90.4125,m=((Q=t==null?void 0:t.coordinates)==null?void 0:Q.lat)??40.7128,x=((te=t==null?void 0:t.coordinates)==null?void 0:te.lng)??-74.006,P=wr(M,A,pn+.012),U=wr(m,x,pn+.012);_.originBeaconGroup&&(_.originBeaconGroup.position.copy(P),_.originBeaconGroup.lookAt(P.clone().multiplyScalar(2))),_.targetBeaconGroup&&(_.targetBeaconGroup.position.copy(U),_.targetBeaconGroup.lookAt(U.clone().multiplyScalar(2)));const b=P.distanceTo(U),R=P.clone().add(U).multiplyScalar(.5);R.length()<.001?R.set(0,1,0):R.normalize();const F=pn+.22+b*.36,E=R.multiplyScalar(F),L=P.clone().lerp(E,.55).normalize().multiplyScalar(pn+.14+b*.24),B=U.clone().lerp(E,.55).normalize().multiplyScalar(pn+.14+b*.24),X=new e0(P,L,B,U);_.tunnelCurve=X;const j=X.getPoints(72);_.tunnelLine&&_.tunnelLine.geometry.setFromPoints(j),_.tunnelGlowLine&&_.tunnelGlowLine.geometry.setFromPoints(j);const ne=(x+180)*(Math.PI/180),H=m*(Math.PI/180);_.targetRotationY=-ne+Math.PI*.5,_.targetRotationX=Math.max(-.55,Math.min(.65,H*.55))},[t,r]),Be.useEffect(()=>{var nt,pt;const _=f.current;if(!_)return;const M={geometries:[],materials:[],textures:[]},A=Me=>(M.geometries.push(Me),Me),m=Me=>(M.materials.push(Me),Me),x=new h1;x.fog=new Ih(396056,.065);const P=_.clientWidth||800,U=_.clientHeight||600,b=new Ai(48,P/U,.1,100);b.position.set(0,.45,4.15),b.lookAt(0,0,0);const R=new GT({antialias:!0,alpha:!0,powerPreference:"high-performance"});R.setPixelRatio(Math.min(window.devicePixelRatio||1,2)),R.setSize(P,U),Dt.enabled=!0,R.outputColorSpace=gi,R.toneMapping=yh,R.toneMappingExposure=1.12,R.setClearColor(0,0),R.domElement.setAttribute("role","img"),R.domElement.setAttribute("aria-label","Interactive 3D Lucifer Tunnel Global Network Globe and Cyber Shield. Drag to rotate, scroll to zoom, or click a country node to connect."),R.domElement.style.display="block",R.domElement.style.width="100%",R.domElement.style.height="100%";const N=!!(typeof window<"u"&&(window.LuciferAndroidBridge||window.LuciferVpnBridge||window.location&&window.location.hostname==="appassets.lucifertunnel.local"||window.navigator&&window.navigator.userAgent&&window.navigator.userAgent.includes("LuciferTunnelAndroid")));N&&(R.domElement.style.pointerEvents="none",R.domElement.style.touchAction="none",_.style.pointerEvents="none",_.style.touchAction="none"),_.innerHTML="",_.appendChild(R.domElement);const F=new jT(b,R.domElement);F.enableDamping=!0,F.dampingFactor=.06,F.enablePan=!1,F.minDistance=2.45,F.maxDistance=6.2,F.rotateSpeed=.65,F.zoomSpeed=.85,F.touches={ONE:null,TWO:null},N&&(F.enabled=!1,F.enableRotate=!1,F.enableZoom=!1);const E=()=>{N||(v.current.userInteracting=!0)},L=()=>{N||setTimeout(()=>{v.current.userInteracting=!1},2200)};F.addEventListener("start",E),F.addEventListener("end",L);const B=new V1(9684477,.75);x.add(B);const X=new o0(14742270,1.65);X.position.set(5,6,6),x.add(X);const j=new o0(3003583,1.15);j.position.set(-6,-3,-4),x.add(j);const ne=950,H=A(new dn),W=new Float32Array(ne*3),ue=new Float32Array(ne*3);for(let Me=0;Me<ne;Me++){const Ae=7+Math.random()*14,He=Math.random()*Math.PI*2,at=Math.acos(2*Math.random()-1);W[Me*3]=Ae*Math.sin(at)*Math.cos(He),W[Me*3+1]=Ae*Math.sin(at)*Math.sin(He),W[Me*3+2]=Ae*Math.cos(at);const ft=Math.random();ue[Me*3]=ft>.5?.35:.25,ue[Me*3+1]=ft>.5?.65:.85,ue[Me*3+2]=.98}H.setAttribute("position",new jn(W,3)),H.setAttribute("color",new jn(ue,3));const Q=m(new Nc({size:.036,vertexColors:!0,transparent:!0,opacity:.55,depthWrite:!1})),te=new af(H,Q);x.add(te);const G=new as;x.add(G),v.current.globeGroup=G;const ee=A(new Po(pn*.986,48,48)),O=m(new F1({color:463398,emissive:597050,emissiveIntensity:.45,roughness:.62,metalness:.28})),de=new Sn(ee,O);G.add(de),v.current.coreMaterial=O;const Ce=A(new Po(pn*1.075,36,36)),Te=m(new tr({color:3900150,transparent:!0,opacity:.11,side:Jn,blending:Ps,depthWrite:!1})),De=new Sn(Ce,Te);G.add(De),v.current.atmosphereMaterial=Te;const Ye=[];for(let Me=-60;Me<=60;Me+=30)for(let He=0;He<64;He++){const at=He/64*360-180,ft=(He+1)/64*360-180,et=wr(Me,at,pn*.994),St=wr(Me,ft,pn*.994);Ye.push(et.x,et.y,et.z,St.x,St.y,St.z)}for(let Me=-180;Me<180;Me+=30)for(let He=0;He<48;He++){const at=He/48*180-90,ft=(He+1)/48*180-90,et=wr(at,Me,pn*.994),St=wr(ft,Me,pn*.994);Ye.push(et.x,et.y,et.z,St.x,St.y,St.z)}const le=A(new dn);le.setAttribute("position",new jn(new Float32Array(Ye),3));const ge=m(new Lc({color:3718648,transparent:!0,opacity:.11})),Ne=new w1(le,ge);G.add(Ne);const tt=2500,Xe=[],mt=[],Gt=(1+Math.sqrt(5))/2;for(let Me=0;Me<tt;Me++){const Ae=1-Me/(tt-1)*2,He=Math.sqrt(1-Ae*Ae),at=2*Math.PI*Me/Gt,ft=Math.cos(at)*He,et=Math.sin(at)*He,St=Math.asin(Ae)*(180/Math.PI),Qt=(Math.atan2(et,-ft)*(180/Math.PI)-180+540)%360-180,Tt=rA(St,Qt);if(Tt||Me%5===0){const ln=pn*(Tt?1.002:.996);Xe.push(ft*ln,Ae*ln,et*ln),Tt?mt.push(.32,.72,.98):mt.push(.12,.26,.48)}}const lt=A(new dn);lt.setAttribute("position",new jn(new Float32Array(Xe),3)),lt.setAttribute("color",new jn(new Float32Array(mt),3));const Et=m(new Nc({size:.024,vertexColors:!0,transparent:!0,opacity:.85,depthWrite:!1})),Ot=new af(lt,Et);G.add(Ot);const xt=S.current.locations||[],At=Math.max(1,xt.length),Xt=A(new Po(.024,10,10)),Wt=m(new tr({color:6333946,transparent:!0,opacity:.92})),_t=new M1(Xt,Wt,At),Nt=new Yt,$=new vt;xt.forEach((Me,Ae)=>{var et,St;const He=((et=Me.coordinates)==null?void 0:et.lat)??0,at=((St=Me.coordinates)==null?void 0:St.lng)??0,ft=wr(He,at,pn+.014);Nt.makeTranslation(ft.x,ft.y,ft.z),_t.setMatrixAt(Ae,Nt),$.setHex(Me.hasStreaming?3718648:8490232),_t.setColorAt(Ae,$)}),_t.instanceMatrix.needsUpdate=!0,_t.instanceColor&&(_t.instanceColor.needsUpdate=!0),G.add(_t);const It=new as,wt=A(new jc(.032,.062,24)),k=m(new tr({color:16007006,side:zi,transparent:!0,opacity:.9})),w=new Sn(wt,k);It.add(w);const re=A(new Po(.028,12,12)),he=m(new tr({color:16622767})),ye=new Sn(re,he);It.add(ye),G.add(It),v.current.originBeaconGroup=It,v.current.originRingMat=k;const Pe=new as,fe=A(new jc(.04,.088,28)),ie=m(new tr({color:3900150,side:zi,transparent:!0,opacity:.95})),se=new Sn(fe,ie);Pe.add(se);const be=A(new Nh(.008,.022,.24,12));be.rotateX(Math.PI/2),be.translate(0,0,.12);const Fe=m(new tr({color:3462041,transparent:!0,opacity:.85})),ve=new Sn(be,Fe);Pe.add(ve),G.add(Pe),v.current.targetBeaconGroup=Pe,v.current.targetRingMat=ie,v.current.targetPillarMat=Fe;const Ee=A(new dn),K=m(new Lc({color:3718648,transparent:!0,opacity:.95})),Ue=new lh(Ee,K);G.add(Ue),v.current.tunnelLine=Ue;const _e=A(new dn),V=m(new Lc({color:1096065,transparent:!0,opacity:.45,blending:Ps})),Oe=new lh(_e,V);Oe.scale.setScalar(1.006),G.add(Oe),v.current.tunnelGlowLine=Oe;const Se=28,Ve=new Float32Array(Se*3),Ge=A(new dn);Ge.setAttribute("position",new jn(Ve,3));const we=m(new Nc({color:7268279,size:.055,transparent:!0,opacity:.95,blending:Ps,depthWrite:!1})),rt=new af(Ge,we);G.add(rt),v.current.tunnelPacketsGeo=Ge,v.current.tunnelPacketsMat=we;const $e=new as;x.add($e);const Ut=A(new Uh(pn*1.24,2)),bt=m(new tr({color:3900150,wireframe:!0,transparent:!0,opacity:.08,blending:Ps})),fn=new Sn(Ut,bt);$e.add(fn),v.current.shieldCageMaterial=bt;const ei=[{radius:pn*1.32,tube:.006,rx:1.15,ry:.3,color:3900150},{radius:pn*1.44,tube:.005,rx:-.85,ry:.75,color:3003583},{radius:pn*1.56,tube:.004,rx:.42,ry:-1.1,color:6333946}],xi=[],ji=[];ei.forEach(Me=>{const Ae=A(new Fh(Me.radius,Me.tube,12,96)),He=m(new tr({color:Me.color,transparent:!0,opacity:.28,blending:Ps})),at=new Sn(Ae,He);at.rotation.set(Me.rx,Me.ry,0),$e.add(at),xi.push(at),ji.push(He)}),v.current.shieldRingMaterials=ji;const Xi=((nt=S.current.realIpInfo)==null?void 0:nt.coordinates)||{lat:23.8103,lng:90.4125},bi=((pt=S.current.selectedLocationObj)==null?void 0:pt.coordinates)||{lat:40.7128,lng:-74.006},lr=wr(Xi.lat,Xi.lng,pn+.012),Yi=wr(bi.lat,bi.lng,pn+.012);It.position.copy(lr),It.lookAt(lr.clone().multiplyScalar(2)),Pe.position.copy(Yi),Pe.lookAt(Yi.clone().multiplyScalar(2));const Vs=lr.distanceTo(Yi),wn=lr.clone().add(Yi).multiplyScalar(.5).normalize().multiplyScalar(pn+.22+Vs*.36),cr=new e0(lr,wn,wn,Yi);v.current.tunnelCurve=cr;const Lr=cr.getPoints(72);Ue.geometry.setFromPoints(Lr),Oe.geometry.setFromPoints(Lr);const Hs=(bi.lng+180)*(Math.PI/180);G.rotation.y=-Hs+Math.PI*.5,v.current.targetRotationY=G.rotation.y;const qi=Me=>{const Ae=Me<=900,He=Ae?.58:0,at=Ae?.82:1;G.position.y=He,$e.position.y=He,G.scale.setScalar(at),$e.scale.setScalar(at)};qi(_.clientWidth||P);const Nr=new W1,Fn=new dt(-999,-999);let ur={x:0,y:0},ti=-1;const Go=(Me,Ae)=>{const He=R.domElement.getBoundingClientRect();!He.width||!He.height||(Fn.x=(Me-He.left)/He.width*2-1,Fn.y=-((Ae-He.top)/He.height)*2+1)},$t=Me=>{N||Me.pointerType==="touch"||Go(Me.clientX,Me.clientY)},Gs=()=>{Fn.set(-999,-999),ti=-1,y(null),N||(R.domElement.style.cursor="grab")},Dr=Me=>{N||Me.pointerType==="touch"||(ur={x:Me.clientX,y:Me.clientY})},Ur=Me=>{var at,ft,et;if(N||Me.pointerType==="touch")return;const Ae=Math.abs(Me.clientX-ur.x),He=Math.abs(Me.clientY-ur.y);if(Ae<6&&He<6&&ti>=0){const St=(at=S.current.locations)==null?void 0:at[ti];St&&((et=(ft=S.current).onSelectLocation)==null||et.call(ft,St.iso))}},I=()=>{var Me,Ae,He,at,ft;if(!N&&ti>=0){const et=(Me=S.current.locations)==null?void 0:Me[ti];et&&((He=(Ae=S.current).onSelectLocation)==null||He.call(Ae,et.iso),(ft=(at=S.current).onRequestConnection)==null||ft.call(at,et.iso))}};N||(R.domElement.addEventListener("pointermove",$t),R.domElement.addEventListener("pointerleave",Gs),R.domElement.addEventListener("pointerdown",Dr),R.domElement.addEventListener("pointerup",Ur),R.domElement.addEventListener("dblclick",I));const q=window.matchMedia("(prefers-reduced-motion: reduce)");let me=q.matches;const ae=Me=>{me=Me.matches};q.addEventListener("change",ae);const oe=new ResizeObserver(Me=>{for(const Ae of Me){const{width:He,height:at}=Ae.contentRect;He>0&&at>0&&(b.aspect=He/at,b.updateProjectionMatrix(),R.setSize(He,at),qi(He))}});oe.observe(_);let We=performance.now(),ze=0;function je(){var Mt;const Me=performance.now(),Ae=Math.min(.1,Math.max(.001,(Me-We)/1e3));We=Me,ze+=Ae;const{vpnState:He,cameraMode:at,theme:ft}=S.current,et=He==="Connected",St=He==="Connecting"||He==="Reconnecting",qe=at==="shield",Qt=at==="orbit",Tt=et?1096065:St?3718648:3900150;Te.color.lerp(new vt(Tt),.06),Te.opacity=et?.16:.11,ft==="light"?(O.color.lerp(new vt(992583),.08),O.emissive.lerp(new vt(1521512),.08)):(O.color.lerp(new vt(397346),.08),O.emissive.lerp(new vt(662586),.08)),K.color.lerp(new vt(et?3462041:3718648),.08),ie.color.lerp(new vt(et?1096065:3900150),.08),Fe.color.lerp(new vt(et?3462041:6333946),.08),bt.color.lerp(new vt(Tt),.06);const ln=qe?.24:et?.12:.05;if(bt.opacity+=(ln-bt.opacity)*.08,ji.forEach((en,Tn)=>{const Rt=et?Tn%2===0?1096065:3462041:Tn%2===0?3900150:3718648;en.color.lerp(new vt(Rt),.06);const Vt=qe?.58:et?.34:.18;en.opacity+=(Vt-en.opacity)*.08}),!me){const en=St?2.4:et?.45:.22;fn.rotation.y+=Ae*en*.45,fn.rotation.x+=Ae*en*.2,xi[0].rotation.z+=Ae*en*.9,xi[1].rotation.x-=Ae*en*.7,xi[2].rotation.y+=Ae*en*.55,te.rotation.y+=Ae*.018;const Tn=1+Math.sin(ze*(St?8:3.5))*.24;se.scale.setScalar(Tn),w.scale.setScalar(1+Math.cos(ze*3)*.18);const Rt=v.current.tunnelCurve;if(Rt){const Vt=Ge.attributes.position,vn=Vt.array,Ft=et?.42:St?.75:.18;for(let cn=0;cn<Se;cn++){const On=(ze*Ft+cn/Se)%1,qn=Rt.getPointAt(On);vn[cn*3]=qn.x,vn[cn*3+1]=qn.y,vn[cn*3+2]=qn.z}Vt.needsUpdate=!0,we.color.setHex(et?7268279:St?16638023:6333946),we.size=et?.062:.048}if(!v.current.userInteracting)if(Qt||St)G.rotation.y+=Ae*(St?.85:.28),v.current.targetRotationY=G.rotation.y,(vn=>{const Ft=vn<=900,cn=Ft?.58:0,On=Ft?.82:1;G.position.y=cn,$e.position.y=cn,G.scale.setScalar(On),$e.scale.setScalar(On)})(_.clientWidth||P);else{const Vt=v.current.targetRotationY-G.rotation.y;G.rotation.y+=Vt*Math.min(1,Ae*3.2);const vn=v.current.targetRotationX-G.rotation.x;G.rotation.x+=vn*Math.min(1,Ae*3.2)}}if(Fn.x>=-1&&Fn.x<=1&&Fn.y>=-1&&Fn.y<=1){Nr.setFromCamera(Fn,b);const en=Nr.intersectObject(_t,!1);if(en.length>0&&en[0].instanceId!==void 0){const Tn=en[0].instanceId;if(ti!==Tn){ti=Tn;const Rt=(Mt=S.current.locations)==null?void 0:Mt[Tn];y(Rt||null)}R.domElement.style.cursor="pointer"}else ti!==-1&&(ti=-1,y(null)),R.domElement.style.cursor="grab"}F.update(),R.render(x,b)}R.setAnimationLoop(je);const Je=()=>{document.hidden?R.setAnimationLoop(null):(We=performance.now(),R.setAnimationLoop(je))};return document.addEventListener("visibilitychange",Je),()=>{R.setAnimationLoop(null),document.removeEventListener("visibilitychange",Je),q.removeEventListener("change",ae),oe.disconnect(),F.removeEventListener("start",E),F.removeEventListener("end",L),F.dispose(),R.domElement.removeEventListener("pointermove",$t),R.domElement.removeEventListener("pointerleave",Gs),R.domElement.removeEventListener("pointerdown",Dr),R.domElement.removeEventListener("pointerup",Ur),R.domElement.removeEventListener("dblclick",I),M.geometries.forEach(Me=>Me.dispose()),M.materials.forEach(Me=>Me.dispose()),M.textures.forEach(Me=>Me.dispose()),R.dispose()}},[]),T.jsxs("div",{style:{position:"absolute",inset:0,width:"100%",height:"100%",overflow:"hidden"},children:[T.jsx("div",{ref:f,style:{width:"100%",height:"100%",position:"relative"}}),p&&T.jsxs("div",{style:{position:"absolute",top:86,left:"50%",transform:"translateX(-50%)",pointerEvents:"none",display:"flex",alignItems:"center",gap:10,padding:"7px 14px",borderRadius:999,background:l==="light"?"rgba(255, 255, 255, 0.92)":"rgba(15, 23, 42, 0.88)",backdropFilter:"blur(12px)",border:l==="light"?"1px solid rgba(37, 99, 235, 0.25)":"1px solid rgba(56, 189, 248, 0.35)",boxShadow:"0 8px 24px rgba(0, 0, 0, 0.25)",color:l==="light"?"#0F172A":"#F8FAFC",fontSize:12,fontWeight:600,zIndex:15},children:[T.jsx("img",{src:No(p.iso),alt:p.name,style:{width:18,height:18,borderRadius:"50%",objectFit:"cover"}}),T.jsxs("span",{children:[p.name," (",p.city,")"]}),T.jsxs("span",{style:{fontSize:11,color:p.basePingMs<75?"#10B981":"#38BDF8",fontVariantNumeric:"tabular-nums"},children:[p.basePingMs," ms"]}),T.jsx("span",{style:{fontSize:10,opacity:.7},children:"• Click to select, double-click to connect"})]})]})}function F0(s){return!s||s<=0?"0.0 KB":s<1024*1024?`${(s/1024).toFixed(1)} KB`:`${(s/(1024*1024)).toFixed(2)} MB`}function oA({vpnStatus:s,realIpInfo:e,locations:t,allLocations:r,showExtendedCatalog:o,onToggleExtendedCatalog:l,selectedLocationIso:u,onSelectLocation:d,onRequestConnection:f,onConnectButtonClick:p,isStreamingMode:y,onSetStreamingMode:S,connectionElapsedFormatted:v,lookingForBestServer:_,onRefreshLocations:M,serviceBridgeConnected:A,rxBytes:m=0,txBytes:x=0,onVerifyIp:P,ipVerificationResult:U,isVerifyingIp:b,cameraMode:R="globe",onChangeCameraMode:N,theme:F="dark"}){const[E,L]=Be.useState(""),[B,X]=Be.useState("ALL"),[j,ne]=Be.useState(!1),[H,W]=Be.useState(!1),ue=o?r:t,Q=Be.useMemo(()=>r.find(Te=>Te.iso===u)||t.find(Te=>Te.iso==="US")||t[0],[r,t,u]),te=Be.useMemo(()=>{const Te=E.trim().toLowerCase();return ue.filter(De=>y&&!De.hasStreaming||B!=="ALL"&&De.region!==B?!1:Te?De.name.toLowerCase().includes(Te)||De.iso.toLowerCase().includes(Te)||De.city&&De.city.toLowerCase().includes(Te)||De.region&&De.region.toLowerCase().includes(Te):!0)},[ue,E,y,B]),G=s.state==="Connected",ee=s.state==="Connecting"||s.state==="Disconnecting"||s.state==="Reconnecting",O=Be.useMemo(()=>{switch(s.state){case"Connected":return"Connected";case"Connecting":return _?"Looking for the best server...":"Connecting...";case"Disconnecting":return"Disconnecting...";case"Reconnecting":return"Reconnecting...";case"Disconnected":default:return s.error&&s.error!=="None"?"Please retry to connect":"Not connected"}},[s.state,s.error,_]),de=Be.useMemo(()=>ee?"/resources/Screens/S4_MainLayout/Main/assets/connect-button-busy.svg":G?j?"/resources/Screens/S4_MainLayout/Main/assets/connect-button-stop-hover.svg":"/resources/Screens/S4_MainLayout/Main/assets/connect-button-stop-rest.svg":s.error&&s.error!=="None"?j?"/resources/Screens/S4_MainLayout/Main/assets/connect-button-retry-hover.svg":"/resources/Screens/S4_MainLayout/Main/assets/connect-button-retry-rest.svg":j?"/resources/Screens/S4_MainLayout/Main/assets/connect-button-start-hover.svg":"/resources/Screens/S4_MainLayout/Main/assets/connect-button-start-rest.svg",[ee,G,s.error,j]),Ce=Be.useMemo(()=>ue.filter(Te=>Te.hasStreaming).length,[ue]);return T.jsxs("div",{className:"u-vpn-main-split",children:[T.jsxs("div",{className:"u-vpn-stage-pane",style:{flex:1,position:"relative",display:"flex",flexDirection:"column",justifyContent:"flex-end",overflow:"hidden",padding:"18px 22px 20px 22px"},children:[T.jsx(sA,{vpnStatus:s,locations:t,selectedLocationObj:Q,realIpInfo:e,cameraMode:R,theme:F,onSelectLocation:d,onRequestConnection:f}),T.jsx("div",{style:{position:"relative",zIndex:10,display:"flex",flexDirection:"column",alignItems:"center",margin:"0 auto",width:"100%",maxWidth:460},children:T.jsxs("div",{className:"u-glass-card u-connect-console-card",style:{width:"100%",borderRadius:24,padding:"20px 24px 18px 24px",display:"flex",flexDirection:"column",alignItems:"center",position:"relative"},children:[T.jsxs("div",{style:{position:"relative",width:128,height:128,display:"flex",alignItems:"center",justifyContent:"center"},children:[T.jsx("img",{src:"/resources/Screens/S4_MainLayout/Main/assets/connect-button-bg.svg",alt:"","aria-hidden":"true",className:`u-connect-btn-ring ${ee?"uv-spin-fast":"uv-pulse-halo"}`,style:{position:"absolute",width:128,height:128,pointerEvents:"none",filter:G?"drop-shadow(0 6px 22px rgba(16, 185, 129, 0.55)) hue-rotate(310deg)":"drop-shadow(0 6px 20px rgba(59, 130, 246, 0.45))"}}),T.jsx("button",{onClick:p,onMouseEnter:()=>ne(!0),onMouseLeave:()=>ne(!1),className:"u-connect-btn-core","aria-label":G?"Disconnect VPN tunnel":`Connect VPN to ${(Q==null?void 0:Q.name)||"selected country"}`,style:{width:78,height:78,borderRadius:"50%",backgroundColor:"#FFFFFF",border:G?"2px solid rgba(16, 185, 129, 0.55)":"2px solid rgba(59, 130, 246, 0.35)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",position:"relative",zIndex:4,boxShadow:j?G?"0 0 28px rgba(16, 185, 129, 0.65)":"0 0 28px rgba(59, 130, 246, 0.6)":"0 6px 16px rgba(0, 0, 0, 0.28)",transition:"box-shadow 150ms ease, border-color 150ms ease"},children:T.jsx("img",{src:de,alt:"","aria-hidden":"true",className:`u-connect-btn-icon ${ee?"uv-spin-slow":""}`,style:{width:ee?34:30,height:ee?34:30}})})]}),T.jsxs("div",{style:{marginTop:10,display:"flex",alignItems:"center",justifyContent:"center",gap:9},children:[!ee&&T.jsx("span",{"aria-hidden":"true",style:{width:11,height:11,borderRadius:"50%",backgroundColor:G?"#10B981":"#F43F5E",boxShadow:G?"0 0 12px rgba(16, 185, 129, 0.85)":"0 0 10px rgba(244, 63, 94, 0.65)",display:"inline-block"}}),T.jsx("span",{style:{fontSize:_?18:21,fontWeight:700,color:"var(--uv-text-heading)",letterSpacing:"-0.3px"},children:O}),T.jsx("span",{style:{fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:999,backgroundColor:G?"rgba(16, 185, 129, 0.18)":"rgba(244, 63, 94, 0.16)",color:G?"#34D399":"#FB7185",border:G?"1px solid rgba(16, 185, 129, 0.35)":"1px solid rgba(244, 63, 94, 0.3)"},children:G?"TUNNEL PROTECTED":"UNPROTECTED"})]}),T.jsxs("div",{style:{marginTop:8,display:"flex",alignItems:"center",justifyContent:"center",gap:16,fontSize:13,color:"var(--uv-text-secondary)",fontVariantNumeric:"tabular-nums"},children:[T.jsx("span",{style:{fontSize:16,fontWeight:700,color:G?"#34D399":"var(--uv-text-muted)",letterSpacing:"0.8px"},children:v}),T.jsx("span",{children:"•"}),T.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:4},title:"Encrypted Download Traffic",children:[T.jsx(Xy,{size:13,color:"#38BDF8","aria-hidden":"true"}),T.jsx("span",{children:F0(m)})]}),T.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:4},title:"Encrypted Upload Traffic",children:[T.jsx(qy,{size:13,color:"#10B981","aria-hidden":"true"}),T.jsx("span",{children:F0(x)})]})]}),Q&&T.jsxs("button",{onClick:p,"aria-label":`Target location ${Q.name}, ${Q.city}. Click to ${G?"disconnect":"connect"}`,style:{marginTop:14,width:"100%",height:56,padding:"0 18px",borderRadius:16,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border-strong)",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,cursor:"pointer",color:"var(--uv-text-heading)",transition:"border-color 150ms ease, background-color 150ms ease"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12,minWidth:0},children:[T.jsx("img",{src:No(Q.iso),alt:Q.name,className:"u-connect-country-flag",style:{width:34,height:34,borderRadius:"50%",objectFit:"cover",border:"1px solid var(--uv-border-strong)",flexShrink:0},onError:Te=>{Te.currentTarget.src="/resources/icons/flags/ic_flag_unknown.webp"}}),T.jsxs("div",{style:{display:"flex",flexDirection:"column",textAlign:"left",minWidth:0},children:[T.jsx("span",{style:{fontSize:15,fontWeight:700,color:"var(--uv-text-heading)",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"},children:Q.name}),T.jsx("span",{style:{fontSize:11,color:"var(--uv-text-secondary)"},children:G?`${s.statusCity||s.statusCountryName||""} • ${s.statusIp}`:Q.city}),G&&s.geoMismatch&&T.jsxs("span",{style:{fontSize:10,color:"#F59E0B",marginTop:2},children:["Live exit IP geolocates to ",s.geoCountryName||s.statusCountryName]})]})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8,flexShrink:0},children:[Q.hasStreaming&&T.jsxs("span",{style:{fontSize:10,fontWeight:700,padding:"3px 7px",borderRadius:6,backgroundColor:"rgba(59, 130, 246, 0.18)",color:"#60A5FA",display:"inline-flex",alignItems:"center",gap:4},children:[T.jsx(Eg,{size:11,"aria-hidden":"true"}),T.jsx("span",{children:"4K"})]}),T.jsxs("span",{style:{fontSize:12,fontWeight:700,color:Q.basePingMs<75?"#10B981":"#38BDF8",fontVariantNumeric:"tabular-nums"},children:[Q.basePingMs," ms"]})]})]}),T.jsxs("div",{className:"u-console-footer-row",style:{marginTop:10,display:"flex",alignItems:"center",justifyContent:"space-between",width:"100%",fontSize:11,color:"var(--uv-text-secondary)",padding:"0 4px",gap:8,flexWrap:"wrap"},children:[T.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:6},children:[T.jsx("span",{"aria-hidden":"true",style:{width:7,height:7,borderRadius:"50%",backgroundColor:A?"#10B981":"#F59E0B"}}),T.jsx("span",{children:s.tunnelMode&&s.tunnelMode!=="Disconnected"?`Tunnel: ${s.tunnelMode}`:"Lucifer Tunnel Engine Ready"})]}),T.jsxs("span",{children:["Protocol:"," ",T.jsx("strong",{style:{color:"var(--uv-text-body)"},children:y?"OpenVPN TCP (Streaming)":s.effectiveProtocolLabel||"Lucifer LinkX"})]})]})]})})]}),T.jsxs("aside",{className:"u-vpn-servers-aside",style:{display:"flex",flexDirection:"column",backgroundColor:"var(--uv-surface-panel)",borderLeft:"1px solid var(--uv-border)",flexShrink:0,zIndex:20},children:[T.jsxs("div",{style:{padding:"20px 18px 12px 18px",borderBottom:"1px solid var(--uv-divider)"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12},children:[T.jsxs("div",{children:[T.jsx("h2",{style:{fontSize:16,fontWeight:700,color:"var(--uv-text-heading)"},children:"All Free & Premium Servers"}),T.jsx("span",{style:{fontSize:11,color:"var(--uv-text-secondary)"},children:"Click any country to switch your IP & rotate the 3D tunnel"})]}),T.jsx("button",{onClick:l,title:"Toggle between the 82 official VPN server countries and all 250 ISO flag countries",style:{fontSize:11,fontWeight:600,padding:"5px 10px",borderRadius:10,border:"1px solid var(--uv-border-strong)",backgroundColor:o?"var(--uv-primary)":"var(--uv-surface-card)",color:o?"#FFFFFF":"var(--uv-text-body)",cursor:"pointer"},children:o?`All ${r.length} ISO`:`${t.length} Official`})]}),T.jsxs("div",{style:{height:38,display:"flex",alignItems:"center",gap:8,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border-strong)",borderRadius:10,padding:"0 12px"},children:[T.jsx(Mg,{size:15,color:"var(--uv-text-secondary)","aria-hidden":"true"}),T.jsx("input",{type:"text",value:E,onChange:Te=>L(Te.target.value),placeholder:"Search country, city, or ISO code...","aria-label":"Search VPN server countries",style:{flex:1,border:"none",background:"transparent",outline:"none",fontSize:13,color:"var(--uv-text-heading)"}}),E&&T.jsx("button",{onClick:()=>L(""),"aria-label":"Clear search query",style:{background:"transparent",border:"none",color:"var(--uv-text-secondary)",cursor:"pointer",display:"flex",alignItems:"center"},children:T.jsx(_f,{size:14})})]}),T.jsxs("div",{style:{marginTop:10,display:"flex",backgroundColor:"var(--uv-surface-card)",borderRadius:10,padding:3,border:"1px solid var(--uv-border)",gap:4},children:[T.jsxs("button",{onClick:()=>S(!1),style:{flex:1,height:32,borderRadius:7,border:"none",backgroundColor:y?"transparent":"var(--uv-primary)",color:y?"var(--uv-text-secondary)":"#FFFFFF",fontWeight:600,fontSize:12,display:"flex",alignItems:"center",justifyContent:"center",gap:6,cursor:"pointer"},children:[T.jsx(ev,{size:13,"aria-hidden":"true"}),T.jsxs("span",{children:["All Servers (",ue.length,")"]})]}),T.jsxs("button",{onClick:()=>S(!0),style:{flex:1,height:32,borderRadius:7,border:"none",backgroundColor:y?"var(--uv-primary)":"transparent",color:y?"#FFFFFF":"var(--uv-text-secondary)",fontWeight:600,fontSize:12,display:"flex",alignItems:"center",justifyContent:"center",gap:6,cursor:"pointer"},children:[T.jsx(Eg,{size:13,"aria-hidden":"true"}),T.jsxs("span",{children:["Streaming & 4K (",Ce,")"]})]})]}),T.jsx("div",{style:{display:"flex",gap:6,marginTop:10,flexWrap:"wrap"},children:[{id:"ALL",label:"All Regions"},{id:"America",label:"Americas"},{id:"Europe, Middle East & Africa",label:"Europe & MEA"},{id:"Asia & Oceania",label:"Asia & Oceania"}].map(Te=>{const De=B===Te.id;return T.jsx("button",{onClick:()=>X(Te.id),style:{fontSize:11,fontWeight:De?600:500,padding:"4px 10px",borderRadius:999,border:"1px solid",borderColor:De?"var(--uv-primary)":"var(--uv-border)",backgroundColor:De?"rgba(59, 130, 246, 0.2)":"var(--uv-surface-card)",color:De?"#60A5FA":"var(--uv-text-secondary)",cursor:"pointer"},children:Te.label},Te.id)})})]}),T.jsx("div",{className:"uv-scrollbar",style:{flex:1,overflowY:"auto",padding:"8px 12px 18px 12px"},children:te.length===0?T.jsxs("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"0 24px"},children:[T.jsx(Mg,{size:42,color:"var(--uv-text-muted)",style:{marginBottom:12}}),T.jsx("div",{style:{fontSize:16,fontWeight:700,color:"var(--uv-text-heading)",marginBottom:4},children:"No matching servers"}),T.jsxs("div",{style:{fontSize:12,color:"var(--uv-text-secondary)",lineHeight:1.45,marginBottom:14},children:['No countries matched "',E,'". Try searching another country name, city, or ISO code.']}),T.jsx("button",{className:"u-btn u-btn-secondary",style:{height:32,fontSize:12},onClick:()=>{L(""),X("ALL"),M==null||M()},children:"Reset Filters"})]}):te.map(Te=>{const De=Te.iso===u,Ye=G&&s.uiLockedLocation===Te.iso;return T.jsxs("div",{className:`u-location-row ${Ye?"connected":De?"selected":""}`,onClick:()=>{d(Te.iso),f(Te.iso)},children:[T.jsx("div",{style:{width:34,height:34,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",marginRight:11,flexShrink:0},children:T.jsx("img",{src:No(Te.iso),alt:Te.name,loading:"lazy",style:{width:28,height:28,borderRadius:"50%",objectFit:"cover",border:"1px solid var(--uv-border-strong)"},onError:le=>{le.currentTarget.src="/resources/icons/flags/ic_flag_unknown.webp"}})}),T.jsxs("div",{style:{flex:1,minWidth:0},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6},children:[T.jsx("span",{style:{fontSize:14,fontWeight:De?700:600,color:"var(--uv-text-heading)",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"},children:Te.name}),T.jsx("span",{style:{fontSize:9,fontWeight:700,padding:"1px 6px",borderRadius:4,backgroundColor:Te.hasStreaming?"rgba(59, 130, 246, 0.2)":"rgba(148, 163, 184, 0.14)",color:Te.hasStreaming?"#60A5FA":"var(--uv-text-secondary)"},children:Te.hasStreaming?"PREMIUM • 4K":"FREE"})]}),T.jsxs("div",{style:{fontSize:11,color:"var(--uv-text-secondary)",display:"flex",alignItems:"center",gap:6,marginTop:2,fontVariantNumeric:"tabular-nums"},children:[T.jsx("span",{children:Te.city}),T.jsx("span",{children:"•"}),T.jsxs("span",{children:[Te.serverCount," nodes"]}),T.jsx("span",{children:"•"}),T.jsxs("span",{style:{color:Te.basePingMs<75?"#10B981":"#38BDF8",fontWeight:600},children:[Te.basePingMs," ms"]})]})]}),De?T.jsxs("div",{style:{padding:"0 10px",height:26,borderRadius:999,backgroundColor:Ye?"rgba(16, 185, 129, 0.22)":"rgba(59, 130, 246, 0.22)",color:Ye?"#34D399":"#60A5FA",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,flexShrink:0,gap:4},children:[T.jsx(q0,{size:12,"aria-hidden":"true"}),T.jsx("span",{children:Ye?"Connected":"Selected"})]}):T.jsx("span",{style:{fontSize:11,fontWeight:600,color:"#60A5FA",padding:"4px 8px",borderRadius:6,backgroundColor:"rgba(59, 130, 246, 0.1)"},children:"Connect"})]},Te.iso)})})]})]})}const Os="2.4.3",os="V2.4.3",Xa="2.4.2",Vv="V2.4.2",aA=[50,21,28,31,5,71,171,164,224,248,215,137,201,220,200,171,191,179,173,172,131,159,151,148,108,125,117,121,106,11,79,92,87,110,9,54,55,51,73,59,19,12,236,170,188,165,172,146,133,253,205,220,175,171,177,169,207,189,133,153,144,96,96,62,74,84,74,67,95,94,105,25,55,53,5,6,29,16,83,238,235,248,246,176,208,200,198,200,171,166,190,249,180,150,131,157],lA=[50,21,28,31,5,71,171,164,224,248,215,137,201,220,200,171,191,179,173,172,131,159,151,148,108,125,117,121,106,11,79,92,87,110,9,54,55,51,73,59,19,12,236,170,188,165,172,146,133,253,205,220,175,171,177,169,207,189,133,153,144,96,96,62,74,84,74,67,95,94,105,25,55,53,5,6,29,16,83,238,235,248,246,176,234,216,215,210,164,172,162,250,138,144,130,157,159,109,37,74,110,105,65,69,65,80,47,41,96,47,53,19],cA=[50,21,28,31,5,71,171,164,224,248,215,137,201,220,200,171,191,179,173,172,131,159,151,148,108,125,117,121,106,11,79,92,87,110,9,54,55,51,73,59,19,12,236,170,188,165,172,146,133,253,205,220,175,171,177,169,207,189,133,153,144,96,96,62,74,84,74,67,95,94,105,25,55,53,5,6,29,16,83,238,235,248,246,176,234,216,215,210,164,172,162,250,138,144,130,157,159,109,38,110,102,118];function Bh(s){let e="";for(let t=0;t<s.length;t++)e+=String.fromCharCode(s[t]^90+t*7&255);return e}function uA(){return Bh(aA)}function Hv(){return Bh(lA)}function dA(){return Bh(cA)}function Gv(s,e){const t=String(s||"").replace(/^[vV]/,"").trim(),r=String(e||"").replace(/^[vV]/,"").trim();if(!t||!r||r==="0.0.0")return!1;const o=t.split(".").map(u=>parseInt(u,10)||0),l=r.split(".").map(u=>parseInt(u,10)||0);for(let u=0;u<Math.max(o.length,l.length);u++){const d=o[u]||0,f=l[u]||0;if(d<f)return!0;if(d>f)return!1}return!1}function fA(s,e="app",t=""){if(!s||typeof s!="object")return{restricted:!1,minRequiredVersion:"0.0.0",latestVersion:String(t||"").replace(/^[vV]/,"").trim(),currentVersion:String(t||"").replace(/^[vV]/,"").trim(),lockTitle:"Mandatory Update Required",lockMessage:""};const r=s.accessControl&&typeof s.accessControl=="object"?s.accessControl:{},o=e==="app",l=String(t||(o?Os:Xa)).replace(/^[vV]/,"").trim(),u=String((o?s.appVersion:s.extensionVersion)||s.version||l).replace(/^[vV]/,"").trim(),d=!!(r.forceUpdateEnabled||s.forceUpdateEnabled||(o?r.forceAppUpdate||s.forceAppUpdate:r.forceExtensionUpdate||s.forceExtensionUpdate)),f=o?r.minAppVersion&&r.minAppVersion!=="0.0.0"?r.minAppVersion:s.minAppVersion&&s.minAppVersion!=="0.0.0"?s.minAppVersion:r.minVersion&&r.minVersion!=="0.0.0"?r.minVersion:s.minVersion&&s.minVersion!=="0.0.0"?s.minVersion:d?u:"0.0.0":r.minExtensionVersion&&r.minExtensionVersion!=="0.0.0"?r.minExtensionVersion:s.minExtensionVersion&&s.minExtensionVersion!=="0.0.0"?s.minExtensionVersion:r.minVersion&&r.minVersion!=="0.0.0"?r.minVersion:s.minVersion&&s.minVersion!=="0.0.0"?s.minVersion:d?u:"0.0.0",p=String(f||"0.0.0").replace(/^[vV]/,"").trim();return{restricted:!!(d&&Gv(l,p)),minRequiredVersion:p,latestVersion:u||p,currentVersion:l,lockTitle:r.lockTitle||s.lockTitle||"Mandatory Update Required",lockMessage:r.lockMessage||s.lockMessage||"This version (V"+l+") is no longer supported. Please update to V"+(u||p)+" to continue using Lucifer Tunnel."}}const Fa="URBAN_VPN_BROWSER_EXTENSION",hh="https://api-pro.urban-vpn.com",hA="https://stats.urban-vpn.com",Wv="luciferTunnelAndroidState_v3",jv="luciferTunnelAndroidCache_v3",O0={Auto:"Lucifer LinkX (Auto)",WireGuard:"Lucifer LinkX (WireGuard)",OpenVPN_UDP:"OpenVPN DCO (UDP)",OpenVPN_TCP:"OpenVPN DCO (TCP)"},eu={NO:new Set(["83.143.82.62","83.143.82.58"]),RU:new Set(["146.70.52.54","146.70.52.62","146.70.52.94"]),KR:new Set(["79.110.55.34"])},zh={NO:["185.181.61.141"],RU:["146.70.231.130"],KR:["108.181.50.35","61.255.174.11"],RS:["83.143.82.62","83.143.82.58"]},pA={RS:{sourceIso:"NO",allowedHosts:new Set(["83.143.82.62","83.143.82.58"])}},D={vpnState:"Disconnected",selectedIso:"US",iso:"",uiLockedLocation:"",countryName:"",city:"",isp:"",asn:"",statusIp:"",geoVerifiedIp:"",geoCountryIso2:"",geoCountryName:"",geoMismatch:!1,vpnProtocol:"Auto",protocol:"Lucifer LinkX (WireGuard)",isStreamingMode:!1,showExtendedCatalog:!1,theme:"dark",cameraMode:"globe",autoConnectOnStartup:!1,bypassLan:!0,dynamicIpRotation:!0,autoCutoffOnTabClose:!1,connectedAt:null,activeProxies:[],proxyUsername:"",proxyPassword:"1",updateAvailable:!1,latestRemoteVersion:Os,lastUpdateCheckAt:"",versionRestricted:!1,minRequiredVersion:"0.0.0",restrictionTitle:"Mandatory Update Required",restrictionMessage:"",realIpInfo:{ip:"165.101.79.231",country:"BD",countryIso2:"BD",countryName:"Bangladesh",city:"Dhaka",isp:"Direct Mobile ISP",asn:"AS64072 Mobile Broadband",coordinates:{lat:23.8103,lng:90.4125}},serviceLogs:[`[${new Date().toISOString().slice(11,19)}] [AndroidVpnEngine] Lucifer Tunnel Android VpnService Engine initialized (${os})`]},Xv="cW9NiiSbuwbqZDHwUFlef1LQhwXlwQGu",Bt={anonToken:"",accsToken:"",accsExpiresAt:0,countries:[],countriesFetchedAt:0},Oo=new Map,Oa=new Map,zo=new Map,ph=new Map,ka=new Map;let Lo=0,k0=!1;function Dn(){try{return!!(typeof window<"u"&&(window.LuciferAndroidBridge||window.__LUCIFER_ANDROID_APP__))}catch{return!1}}typeof window<"u"&&(window.__onLuciferNativeCallback=(s,e)=>{const t=ka.get(s);if(t){clearTimeout(t.timer),ka.delete(s);try{const r=typeof e=="string"?JSON.parse(e):e;t.resolve(r)}catch(r){t.resolve({ok:!1,error:(r==null?void 0:r.message)||"Invalid JSON from native bridge"})}}},window.__onLuciferNativeVpnDisconnected=()=>{Lo++,D.vpnState="Disconnected",D.iso="",D.uiLockedLocation="",D.countryName="",D.city="",D.isp="",D.asn="",D.statusIp=D.realIpInfo.ip,D.geoVerifiedIp="",D.geoCountryIso2="",D.geoCountryName="",D.geoMismatch=!1,D.connectedAt=null,D.activeProxies=[],D.proxyUsername="",ki()});function Ba(s,e=1e4){return new Promise(t=>{const r="andro_cb_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,8),o=setTimeout(()=>{ka.delete(r),t({ok:!1,error:"Native operation timed out"})},e);ka.set(r,{resolve:t,timer:o});try{s(r)}catch(l){clearTimeout(o),ka.delete(r),t({ok:!1,error:(l==null?void 0:l.message)||"Native invocation error"})}})}function B0(s){var e;try{if((e=window.LuciferAndroidBridge)!=null&&e.getStorageItem){const r=window.LuciferAndroidBridge.getStorageItem(s);if(r)return JSON.parse(r)}const t=window.localStorage.getItem(s);return t?JSON.parse(t):null}catch{return null}}function Yv(s,e){var t;try{const r=JSON.stringify(e);(t=window.LuciferAndroidBridge)!=null&&t.setStorageItem&&window.LuciferAndroidBridge.setStorageItem(s,r),window.localStorage.setItem(s,r)}catch{}}function Ns(s,e){const t=String(s||"").toUpperCase(),r=String(e||"").trim();if(!t||!r||!/^\d+\.\d+\.\d+\.\d+$/.test(r))return;const l=(zo.get(t)||[]).filter(u=>u!==r);l.push(r),l.length>32&&l.splice(0,l.length-32),zo.set(t,l)}function mA(s,e=18e4){const t=String(s||"").trim();t&&ph.set(t,Date.now()+e)}function qv(s){const e=String(s||"").trim();if(!e)return!1;const t=ph.get(e);return t?Date.now()>=t?(ph.delete(e),!1):!0:!1}function gA(s){const e=[...s];for(let t=e.length-1;t>0;t--){const r=Math.floor(Math.random()*(t+1)),o=e[t];e[t]=e[r],e[r]=o}return e}function vA(){const s=[34,35,45,52,54,64,66,74,82,89,91,104,138,142,148,151,185,193],e=s[Math.floor(Math.random()*s.length)],t=1+Math.floor(Math.random()*250),r=1+Math.floor(Math.random()*250),o=1+Math.floor(Math.random()*250);return`${e}.${t}.${r}.${o}`}function Xc(s={}){const e=vA();return{Accept:"application/json","X-Client-App":Fa,"X-Forwarded-For":e,"X-Real-IP":e,"CF-Connecting-IP":e,"True-Client-IP":e,...s}}function Ar(s,e){const t=`[${new Date().toISOString().slice(11,19)}] [${s}] ${e}`;D.serviceLogs.unshift(t),D.serviceLogs.length>60&&(D.serviceLogs.length=60)}function ki(){Yv(Wv,{vpnState:D.vpnState,selectedIso:D.selectedIso,iso:D.iso,uiLockedLocation:D.uiLockedLocation,countryName:D.countryName,city:D.city,isp:D.isp,asn:D.asn,statusIp:D.statusIp,geoVerifiedIp:D.geoVerifiedIp,geoCountryIso2:D.geoCountryIso2,geoCountryName:D.geoCountryName,geoMismatch:D.geoMismatch,vpnProtocol:D.vpnProtocol,protocol:D.protocol,isStreamingMode:D.isStreamingMode,showExtendedCatalog:D.showExtendedCatalog,theme:D.theme,cameraMode:D.cameraMode,autoConnectOnStartup:D.autoConnectOnStartup,bypassLan:!0,dynamicIpRotation:D.dynamicIpRotation,autoCutoffOnTabClose:D.autoCutoffOnTabClose,connectedAt:D.connectedAt,activeProxies:D.activeProxies,proxyUsername:D.proxyUsername,proxyPassword:D.proxyPassword,versionRestricted:D.versionRestricted,minRequiredVersion:D.minRequiredVersion,restrictionTitle:D.restrictionTitle,restrictionMessage:D.restrictionMessage,realIpInfo:D.realIpInfo})}function us(){const s={};for(const[r,o]of Oo.entries())s[r]=o;const e={};for(const[r,o]of zo.entries())e[r]=o;const t={};for(const[r,o]of Oa.entries())t[r]=o;Yv(jv,{anonToken:Bt.anonToken,accsToken:Bt.accsToken,accsExpiresAt:Bt.accsExpiresAt,countries:Bt.countries,countriesFetchedAt:Bt.countriesFetchedAt,gatewayByIso:s,recentHostsByIso:e,verifiedGeoByIp:t})}function Kv(){var t;if(k0)return;k0=!0;const s=B0(jv);if(s&&typeof s=="object"){if(s.anonToken&&s.anonToken!==Xv&&(Bt.anonToken=s.anonToken,s.accsToken&&(Bt.accsToken=s.accsToken),typeof s.accsExpiresAt=="number"&&(Bt.accsExpiresAt=s.accsExpiresAt),Array.isArray(s.countries)&&s.countries.length>0&&(Bt.countries=s.countries),typeof s.countriesFetchedAt=="number"&&(Bt.countriesFetchedAt=s.countriesFetchedAt)),s.verifiedGeoByIp&&typeof s.verifiedGeoByIp=="object")for(const[r,o]of Object.entries(s.verifiedGeoByIp))r&&typeof o=="string"&&Oa.set(r,o.toUpperCase());if(s.recentHostsByIso&&typeof s.recentHostsByIso=="object")for(const[r,o]of Object.entries(s.recentHostsByIso))Array.isArray(o)&&o.length>0&&zo.set(r.toUpperCase(),o.filter(Boolean));if(s.gatewayByIso&&typeof s.gatewayByIso=="object")for(const[r,o]of Object.entries(s.gatewayByIso)){const l=r.toUpperCase();o!=null&&o.primaryHost&&Ns(l,o.primaryHost),o!=null&&o.proxyUsername&&Array.isArray(o==null?void 0:o.proxies)&&o.proxies.length>0&&Oo.set(l,o)}}const e=B0(Wv);if(e&&typeof e=="object"){const r=["vpnState","selectedIso","iso","uiLockedLocation","countryName","city","isp","asn","statusIp","geoVerifiedIp","geoCountryIso2","geoCountryName","geoMismatch","vpnProtocol","protocol","isStreamingMode","showExtendedCatalog","theme","cameraMode","autoConnectOnStartup","dynamicIpRotation","autoCutoffOnTabClose","connectedAt","proxyUsername","proxyPassword"];for(const l of r)e[l]!==void 0&&(D[l]=e[l]);D.bypassLan=!0;const o=Dn()?Os:Xa;e.versionRestricted&&e.minRequiredVersion&&(Gv(o,e.minRequiredVersion)?(D.versionRestricted=!0,D.minRequiredVersion=e.minRequiredVersion,D.restrictionTitle=e.restrictionTitle||"Mandatory Update Required",D.restrictionMessage=e.restrictionMessage||""):(D.versionRestricted=!1,D.minRequiredVersion="0.0.0",D.restrictionMessage="")),Array.isArray(e.activeProxies)&&(D.activeProxies=e.activeProxies),e.realIpInfo&&typeof e.realIpInfo=="object"&&(D.realIpInfo={...D.realIpInfo,...e.realIpInfo});try{(t=window.LuciferAndroidBridge)!=null&&t.isVpnServiceActive&&!window.LuciferAndroidBridge.isVpnServiceActive()&&D.vpnState==="Connected"&&(D.vpnState="Disconnected",D.statusIp=D.realIpInfo.ip)}catch{}}D.vpnState==="Disconnected"&&mh()}async function Ir(s,e={},t=8e3,r=!1){var p;const o=(e.method||"GET").toUpperCase(),l=e.headers||{},u=typeof e.body=="string"?e.body:"";if((p=window.LuciferAndroidBridge)!=null&&p.httpFetchAsync){const y=await Ba(S=>window.LuciferAndroidBridge.httpFetchAsync(S,s,o,JSON.stringify(l),u,!!r,t),t+2e3);return{ok:!!(y&&y.status>=200&&y.status<300),status:(y==null?void 0:y.status)||0,text:async()=>(y==null?void 0:y.body)||"",json:async()=>JSON.parse((y==null?void 0:y.body)||"{}")}}const d=new AbortController,f=setTimeout(()=>d.abort(),t);try{return await fetch(s,{...e,cache:"no-store",signal:d.signal})}finally{clearTimeout(f)}}function $v(s,e=""){var p,y,S,v,_,M,A;if(!s||!s.ip)return null;const t=String(s.code||s.country_code||s.countryCode||s.country||e||"").toUpperCase(),r=(s.code&&s.country?s.country:"")||s.country_name||(typeof s.country=="string"&&s.country.length>2?s.country:"")||c_(t)||t,o=s.city||((p=Xn(t))==null?void 0:p.city)||"Gateway",l=((y=s.asn)==null?void 0:y.name)||((S=s.connection)==null?void 0:S.isp)||((v=s.connection)==null?void 0:v.org)||s.isp||s.org||"Lucifer Encrypted Relay",u=(_=s.asn)!=null&&_.id?`AS${s.asn.id} ${s.asn.name||""}`.trim():(M=s.connection)!=null&&M.asn?`AS${s.connection.asn} ${s.connection.org||""}`.trim():typeof s.asn=="string"?s.asn:"AS209854 Lucifer Network",d=typeof s.latitude=="number"?s.latitude:typeof s.lat=="number"||typeof s.lat=="string"&&s.lat?Number(s.lat):NaN,f=typeof s.longitude=="number"?s.longitude:typeof s.lon=="number"||typeof s.lon=="string"&&s.lon?Number(s.lon):NaN;return{ip:s.ip,countryIso2:t,countryName:r,city:o,isp:l,asn:u,coordinates:Number.isFinite(d)&&Number.isFinite(f)?{lat:d,lng:f}:(A=Xn(t))==null?void 0:A.coordinates}}async function mh(){if(D.vpnState!=="Disconnected")return D.realIpInfo;const s=["https://api.2ip.io/","https://ipwho.is/","https://geo.geosurf.io/"];for(const e of s)try{const t=await Ir(e,{method:"GET"},4500,!1);if(t.ok){const r=await t.json(),o=$v(r,"BD");if(o&&o.ip)return D.realIpInfo={ip:o.ip,country:o.countryIso2,countryIso2:o.countryIso2,countryName:o.countryName,city:o.city,isp:o.isp,asn:o.asn,coordinates:o.coordinates||{lat:23.8103,lng:90.4125}},D.vpnState==="Disconnected"&&(D.statusIp=D.realIpInfo.ip,ki()),Ar("OriginProbe",`Detected real mobile ISP IP ${o.ip} (${o.countryIso2})`),D.realIpInfo}}catch{}return D.realIpInfo}let bo=null,Rs=null;async function Vh(s=!1,e=!1){const t=Date.now();if(!s&&!e&&Bt.anonToken&&Bt.accsToken&&t<Bt.accsExpiresAt-6e4)return{anonToken:Bt.anonToken,accsToken:Bt.accsToken};if(bo&&!e)return bo;const o=(async()=>{if(Bt.countries=[],Bt.countriesFetchedAt=0,e&&(Bt.anonToken=""),!Bt.anonToken){try{const d=await Ir(hh+"/rest/v1/registrations/clientApps/"+Fa+"/users/anonymous",{method:"POST",headers:Xc({"Content-Type":"application/json"}),body:JSON.stringify({clientApp:{name:Fa}})},8e3,!1);if(d.ok){const f=await d.json();f!=null&&f.value&&(Bt.anonToken=f.value,us())}}catch{}Bt.anonToken||(Bt.anonToken=Xv)}const l=await Ir(hh+"/rest/v1/security/tokens/accs",{method:"POST",headers:Xc({Authorization:"Bearer "+Bt.anonToken,"Content-Type":"application/json"}),body:JSON.stringify({clientApp:{name:Fa},type:"accs"})},8e3,!1);if(!l.ok){if(!e)return bo=null,Vh(!0,!0);throw new Error("Gateway access token exchange failed ("+l.status+")")}const u=await l.json();if(!(u!=null&&u.value))throw new Error("Gateway access token missing value");return Bt.accsToken=u.value,Bt.accsExpiresAt=u.expirationTime||Date.now()+720*1e3,us(),{anonToken:Bt.anonToken,accsToken:Bt.accsToken}})().finally(()=>{bo===o&&(bo=null)});return bo=o,o}async function gh(s=!1,e=!1){const t=Date.now();if(!s&&!e&&Array.isArray(Bt.countries)&&Bt.countries.length>0&&t-Bt.countriesFetchedAt<360*1e3)return Bt.countries;if(Rs&&!s&&!e)return Rs;const o=(async()=>{var p;const{accsToken:l}=await Vh(s,e),u=await Ir(hA+"/api/rest/v2/entrypoints/countries",{method:"GET",headers:Xc({Authorization:"Bearer "+l})},8e3,!1);if(!u.ok){if(!s)return Rs=null,gh(!0,!1);if(!e)return Rs=null,gh(!0,!0);throw new Error("Failed to fetch gateway countries ("+u.status+")")}const d=await u.json(),f=((p=d==null?void 0:d.countries)==null?void 0:p.elements)||[];if(!Array.isArray(f)||f.length===0)throw new Error("Gateway countries list is empty");return Bt.countries=f,Bt.countriesFetchedAt=Date.now(),us(),f})().finally(()=>{Rs===o&&(Rs=null)});return Rs=o,o}async function z0(s,e){const t=await Ir(hh+"/rest/v1/security/tokens/accs-proxy",{method:"POST",headers:Xc({Authorization:"Bearer "+e,"Content-Type":"application/json"}),body:JSON.stringify({clientApp:{name:Fa},type:"accs-proxy",signature:s})},7500,!1);if(!t.ok)throw new Error("Proxy credential exchange HTTP "+t.status);const r=await t.json();if(!(r!=null&&r.value))throw new Error("Empty proxy credential token");return r.value}async function xA(s,e){var o,l;const t=String(e||"").toUpperCase();if(!s||!t||(o=zh[t])!=null&&o.includes(s))return!0;if((l=eu[t])!=null&&l.has(s))return!1;const r=Oa.get(s);if(r)return r===t;try{const u=await Ir("https://api.2ip.io/"+s,{},2600,!1);if(u.ok){const d=await u.json(),f=String((d==null?void 0:d.code)||"").toUpperCase();if(f)return Oa.set(s,f),us(),f===t}}catch{}try{const u=await Ir("https://ipwho.is/"+s,{},2600,!1);if(u.ok){const d=await u.json(),f=String((d==null?void 0:d.country_code)||"").toUpperCase();if(f)return Oa.set(s,f),us(),f===t}}catch{}return!0}function yA(s,e,t=null){var _,M;const r=String(e||"US").toUpperCase(),o=pA[r],l=o?o.sourceIso:r;let u=s.find(A=>{var m;return String(((m=A==null?void 0:A.code)==null?void 0:m.iso2)||"").toUpperCase()===l});u||(u=s.find(A=>{var m;return String(((m=A==null?void 0:A.code)==null?void 0:m.iso2)||"").toUpperCase()==="US"})||s[0]);const d=((_=u==null?void 0:u.servers)==null?void 0:_.elements)||[];let f=d.filter(A=>{var m,x,P,U;return((x=(m=A==null?void 0:A.address)==null?void 0:m.primary)==null?void 0:x.host)&&((U=(P=A==null?void 0:A.address)==null?void 0:P.primary)==null?void 0:U.port)&&(A==null?void 0:A.signature)&&(!A.accessType||A.accessType==="ACCESSIBLE")});const p=new Map;for(const A of f){const m=A.address.primary.host,x=p.get(m);(!x||(Number(A.weight)||1)>(Number(x.weight)||1))&&p.set(m,A)}if(f=Array.from(p.values()),o!=null&&o.allowedHosts){const A=f.filter(m=>o.allowedHosts.has(m.address.primary.host));A.length>0&&(f=A)}const y=eu[r];if(y){const A=f.filter(m=>!y.has(m.address.primary.host));A.length>0&&(f=A)}const S=zh[r];if(Array.isArray(S)&&S.length>0){const A=new Set(S),m=f.filter(x=>A.has(x.address.primary.host));m.length>0&&(f=m)}const v=f.filter(A=>{const m=A.address.primary.host;return!(t&&t.has(m)||qv(m))});if(v.length>0&&(f=v),f.length>1)if(D.dynamicIpRotation!==!1){const A=new Set(f.map(R=>R.address.primary.host));let x=(zo.get(r)||[]).filter(R=>A.has(R));if(x.length>=f.length){const R=x[x.length-1];x=R?[R]:[],zo.set(r,[...x])}const P=new Set(x),U=gA(f.filter(R=>!P.has(R.address.primary.host))),b=f.filter(R=>P.has(R.address.primary.host)).sort((R,N)=>x.indexOf(R.address.primary.host)-x.indexOf(N.address.primary.host));f=[...U,...b]}else{const A=(M=Oo.get(r))==null?void 0:M.primaryHost;if(A){const m=f.filter(P=>P.address.primary.host===A),x=f.filter(P=>P.address.primary.host!==A);f=[...m,...x]}}return{countryEntry:u,servers:f.length>0?f:d}}async function _A(s,e=null){var d,f,p;const t=String(s||"US").toUpperCase(),r=Oo.get(t),o=eu[t],l=o&&((d=r==null?void 0:r.proxies)==null?void 0:d.some(y=>o.has(y==null?void 0:y.host)));if(D.dynamicIpRotation===!1&&r&&!l&&r.proxyUsername&&((f=r.proxies)!=null&&f.length)&&(!e||!e.has(r.primaryHost))&&!qv(r.primaryHost)&&Date.now()-(r.cachedAt||0)<600*1e3)return r;let u=null;for(let y=0;y<3;y++)try{const S=y>=1,v=y>=2,_=await gh(S,v),{servers:M}=yA(_,t,e);if(!M||M.length===0)throw new Error("No servers listed for "+t);const{accsToken:A}=await Vh(!1,!1),m=[];let x=0;for(const P of M){if(x>=6)break;const U=P.address.primary.host;if(M.length>1&&!await xA(U,t)){m.push(P);continue}x++;try{const b=await z0(P.signature,A),R=M.filter(L=>L.signature===P.signature&&L.address.primary.host!==U&&(!o||!o.has(L.address.primary.host))),F=[P,...R].slice(0,3).map(L=>({scheme:"PROXY",host:L.address.primary.host,port:Number(L.address.primary.port)}));Ns(t,U);const E={proxies:F,primaryHost:U,proxyUsername:b,cachedAt:Date.now()};return Oo.set(t,E),us(),E}catch(b){u=b}}for(const P of m.slice(0,2))try{const U=P.address.primary.host,b=await z0(P.signature,A),R=[{scheme:"PROXY",host:U,port:Number(P.address.primary.port)}];Ns(t,U);const N={proxies:R,primaryHost:U,proxyUsername:b,cachedAt:Date.now()};return Oo.set(t,N),us(),N}catch(U){u=U}}catch(S){u=S}if(r&&!l&&r.proxyUsername&&((p=r.proxies)!=null&&p.length))return r;throw u||new Error("Failed to authenticate gateway for "+t)}async function V0(s="",e=""){var o;const t=s&&/^\d+\.\d+\.\d+\.\d+$/.test(s),r=[{url:"https://api.2ip.io/",useProxy:!0},{url:"https://ipwho.is/",useProxy:!0},{url:"https://geo.geosurf.io/",useProxy:!0},...t?[{url:"https://api.2ip.io/"+s,useProxy:!1},{url:"https://ipwho.is/"+s,useProxy:!1}]:[]];for(const l of r)try{const u=await Ir(l.url,{method:"GET"},3600,l.useProxy);if(u.ok){const d=await u.json(),f=$v(d,e||D.iso);if(f&&f.ip){if(t&&((o=D.realIpInfo)!=null&&o.ip)&&f.ip===D.realIpInfo.ip&&s!==D.realIpInfo.ip)continue;return f}}}catch{}return null}function Nn(){const s=D.vpnState==="Connected";return{state:D.vpnState,vpnState:D.vpnState,statusReady:!0,statusIp:s?D.statusIp:D.realIpInfo.ip,statusCountryIso2:s?D.geoCountryIso2||D.iso:D.realIpInfo.countryIso2,statusCountryName:s?D.geoCountryName||D.countryName:D.realIpInfo.countryName,statusCity:s?D.city:D.realIpInfo.city,statusIsp:s?D.isp:D.realIpInfo.isp,statusAsn:s?D.asn:D.realIpInfo.asn,geoVerifiedIp:D.geoVerifiedIp,geoCountryIso2:D.geoCountryIso2,geoCountryName:D.geoCountryName,geoMismatch:D.geoMismatch,uiLockedLocation:s?D.uiLockedLocation||D.iso:"",selectedIso:D.selectedIso||"US",connectionStartedTimestamp:D.connectedAt,connectedAt:D.connectedAt,vpnProtocol:D.vpnProtocol,effectiveProtocol:D.vpnProtocol==="Auto"?"WireGuard":D.vpnProtocol,effectiveProtocolLabel:D.protocol,protocol:D.protocol,isStreamingMode:D.isStreamingMode,showExtendedCatalog:D.showExtendedCatalog,theme:D.theme,cameraMode:D.cameraMode,autoConnectOnStartup:D.autoConnectOnStartup,bypassLan:!0,dynamicIpRotation:D.dynamicIpRotation,autoCutoffOnTabClose:D.autoCutoffOnTabClose,tunnelInternalIp:"10.7.1.134/32",tunnelMode:s?"Lucifer Android System VPN Tunnel":"Disconnected",realTunnelActive:s,extensionActive:!0,updateAvailable:D.updateAvailable,latestRemoteVersion:D.latestRemoteVersion,lastUpdateCheckAt:D.lastUpdateCheckAt,versionRestricted:!!D.versionRestricted,minRequiredVersion:D.minRequiredVersion||"0.0.0",restrictionTitle:D.restrictionTitle||"Mandatory Update Required",restrictionMessage:D.restrictionMessage||"",realIpInfo:D.realIpInfo,serviceLogs:D.serviceLogs.slice(0,25)}}const Zv=3600*1e3;let Uc=0;async function Ya(s=!1){var o;Kv();const e=Date.now(),t=Dn()?Os:Xa;if(!s&&Uc>0&&e-Uc<Zv)return{ok:!0,currentVersion:t,latestVersion:D.latestRemoteVersion||t,updateAvailable:!!D.updateAvailable,versionRestricted:!!D.versionRestricted,minRequiredVersion:D.minRequiredVersion||"0.0.0",restrictionTitle:D.restrictionTitle||"Mandatory Update Required",restrictionMessage:D.restrictionMessage||"",checkedAt:D.lastUpdateCheckAt};const r=(l,u)=>{const d=String(l||"").replace(/^[vV]/,"").trim(),f=String(u).replace(/^[vV]/,"").trim();if(!d||!f)return!1;const p=d.split(".").map(S=>parseInt(S,10)||0),y=f.split(".").map(S=>parseInt(S,10)||0);for(let S=0;S<Math.max(p.length,y.length);S++){const v=p[S]||0,_=y[S]||0;if(v>_)return!0;if(v<_)return!1}return!1};try{Uc=e;const l=`${uA()}?t=${e}`;let u=null;if(Dn())try{const d=await Ir(l,{method:"GET"},8e3,!1);d&&d.ok&&(u=await d.json())}catch{u=null}if(!u){const d=await fetch(l,{cache:"no-store"});d.ok&&(u=await d.json())}if(u&&typeof u=="object"){if(u.otaGatewayOverrides&&typeof u.otaGatewayOverrides=="object"){const _=u.otaGatewayOverrides;if(_.preferredHosts&&typeof _.preferredHosts=="object")for(const[M,A]of Object.entries(_.preferredHosts))Array.isArray(A)&&A.length>0&&(zh[M.toUpperCase()]=A);if(_.excludedHosts&&typeof _.excludedHosts=="object")for(const[M,A]of Object.entries(_.excludedHosts))Array.isArray(A)&&A.length>0&&(eu[M.toUpperCase()]=new Set(A))}const d=Dn()?"app":"extension",f=Dn()?Os:Xa,p=Dn()?u.appVersion||u.version||f:u.extensionVersion||u.version||f,y=String(p).replace(/^[vV]/,"").trim(),S=r(y,f),v=fA(u,d,f);D.latestRemoteVersion=y||f,D.updateAvailable=S||v.restricted,D.versionRestricted=!!v.restricted,D.minRequiredVersion=v.minRequiredVersion||"0.0.0",D.restrictionTitle=v.lockTitle||"Mandatory Update Required",D.restrictionMessage=v.lockMessage||"",D.lastUpdateCheckAt=new Date().toISOString().slice(11,19),D.versionRestricted&&D.vpnState!=="Disconnected"&&(Lo++,(o=window.LuciferAndroidBridge)!=null&&o.stopVpnTunnelAsync&&await Ba(_=>window.LuciferAndroidBridge.stopVpnTunnelAsync(_),4e3),D.vpnState="Disconnected",D.iso="",D.uiLockedLocation="",D.connectedAt=null,D.activeProxies=[],D.proxyUsername="",D.statusIp=D.realIpInfo.ip,Ar("Security",`Version V${f} restricted (minimum required: V${D.minRequiredVersion}). Tunnel stopped.`)),ki(),S?Ar("AutoUpdate",`Update V${y} available (installed: V${f})`):s&&Ar("AutoUpdate",`App V${f} is up to date & OTA synced`)}}catch{D.lastUpdateCheckAt=new Date().toISOString().slice(11,19)}return{ok:!0,currentVersion:t,latestVersion:D.latestRemoteVersion||t,updateAvailable:!!D.updateAvailable,versionRestricted:!!D.versionRestricted,minRequiredVersion:D.minRequiredVersion||"0.0.0",restrictionTitle:D.restrictionTitle||"Mandatory Update Required",restrictionMessage:D.restrictionMessage||"",checkedAt:D.lastUpdateCheckAt}}async function za(s=""){var e;try{if(Dn()&&((e=window.LuciferAndroidBridge)!=null&&e.downloadUpdateApk))return window.LuciferAndroidBridge.downloadUpdateApk(dA(),s||D.latestRemoteVersion),!0;const t=await fetch(`${Hv()}?t=${Date.now()}`,{cache:"no-store"});if(t.ok){const r=await t.blob(),o=URL.createObjectURL(r),l=document.createElement("a");return l.href=o,l.download="Lucifer-Tunnel-Extension.zip",document.body.appendChild(l),l.click(),l.remove(),setTimeout(()=>URL.revokeObjectURL(o),4e3),!0}}catch{}return!1}async function SA(s,e={}){var t,r,o,l,u,d,f,p,y,S,v,_;if(Kv(),s==="PING")return{ok:!0,extensionActive:!0,version:Os,state:Nn()};if(s==="GET_STATUS"||s==="HEARTBEAT"){if(D.vpnState==="Connected"&&((t=window.LuciferAndroidBridge)!=null&&t.isVpnServiceActive))try{window.LuciferAndroidBridge.isVpnServiceActive()||(r=window.__onLuciferNativeVpnDisconnected)==null||r.call(window)}catch{}return{ok:!0,extensionActive:!0,terminated:!1,isOwner:!0,realIpInfo:D.realIpInfo,status:Nn(),state:Nn()}}if(s==="CONNECT_VPN"){if((!D.lastUpdateCheckAt||Date.now()-Uc>=Zv||D.versionRestricted)&&await Ya(!1),D.versionRestricted)return(o=window.LuciferAndroidBridge)!=null&&o.stopVpnTunnelAsync&&await Ba(E=>window.LuciferAndroidBridge.stopVpnTunnelAsync(E),4e3),D.vpnState="Disconnected",ki(),{ok:!1,versionRestricted:!0,minRequiredVersion:D.minRequiredVersion,latestVersion:D.latestRemoteVersion,restrictionTitle:D.restrictionTitle,restrictionMessage:D.restrictionMessage,error:D.restrictionMessage||`Update Required: Please update Lucifer Tunnel to V${D.latestRemoteVersion||D.minRequiredVersion} to continue.`,status:Nn(),state:Nn()};const M=++Lo;D.vpnState==="Disconnected"&&await mh();const A=String(D.iso||D.uiLockedLocation||"").toUpperCase();A&&((u=(l=D.activeProxies)==null?void 0:l[0])!=null&&u.host&&Ns(A,D.activeProxies[0].host),D.statusIp&&D.statusIp!==((d=D.realIpInfo)==null?void 0:d.ip)&&Ns(A,D.statusIp));const m=String((e==null?void 0:e.iso)||D.selectedIso||"US").toUpperCase(),x=Xn(m)||Xn("US");e!=null&&e.protocol&&(D.vpnProtocol=e.protocol),(e==null?void 0:e.isStreamingMode)!==void 0&&(D.isStreamingMode=!!e.isStreamingMode);const P=D.isStreamingMode?"OpenVPN TCP (Streaming)":(e==null?void 0:e.protocolLabel)||O0[D.vpnProtocol]||"Lucifer LinkX (WireGuard)";D.vpnState="Connecting",D.selectedIso=m,D.iso=m,D.uiLockedLocation=m,D.countryName=(e==null?void 0:e.countryName)||(x==null?void 0:x.name)||m,D.city=(e==null?void 0:e.city)||(x==null?void 0:x.city)||"Gateway",D.isp=(e==null?void 0:e.isp)||(x==null?void 0:x.isp)||"Lucifer Encrypted Relay",D.asn=(e==null?void 0:e.asn)||(x==null?void 0:x.asn)||"AS209854 Lucifer Network",D.protocol=P;const U=new Set;let b=[],R="",N="",F=null;for(let E=0;E<2;E++){let L=[],B="",X="";try{const j=await _A(m,U);j&&(L=j.proxies,B=j.primaryHost,X=j.proxyUsername)}catch(j){Ar("Handshake",`Cloud handshake notice (${m}): ${j==null?void 0:j.message}`)}if(M!==Lo)return{ok:!0,superseded:!0,extensionActive:!0,realIpInfo:D.realIpInfo,status:Nn(),state:Nn()};if(!X||L.length===0){if(E===0)return D.vpnState="Disconnected",D.activeProxies=[],D.proxyUsername="",D.statusIp=D.realIpInfo.ip,ki(),{ok:!1,error:`Could not connect to ${D.countryName} (${m}). Please try again.`};break}if(b=L,R=B,N=X,D.proxyUsername=N,D.proxyPassword="1",D.activeProxies=b,ki(),(f=window.LuciferAndroidBridge)!=null&&f.startVpnTunnelAsync){const j=Number((p=b[0])==null?void 0:p.port)||443,ne=await Ba(H=>window.LuciferAndroidBridge.startVpnTunnelAsync(H,R,j,JSON.stringify(b),N,"1",m,D.countryName),15e3);if(!ne||!ne.ok)return D.vpnState="Disconnected",D.activeProxies=[],D.proxyUsername="",D.statusIp=D.realIpInfo.ip,ki(),{ok:!1,error:(ne==null?void 0:ne.error)||"Android VPN permission was denied or tunnel failed to start."}}if(D.vpnState="Connected",D.connectedAt=Date.now(),D.statusIp=R,F=await V0(R,m),M!==Lo)return{ok:!0,superseded:!0,extensionActive:!0,realIpInfo:D.realIpInfo,status:Nn(),state:Nn()};if(F&&F.ip){Ns(m,R),Ns(m,F.ip),us();break}R&&(U.add(R),mA(R,18e4))}F&&F.ip?(D.statusIp=F.ip,D.geoVerifiedIp=F.ip,D.geoCountryIso2=F.countryIso2||m,D.geoCountryName=F.countryName||D.countryName,D.city=F.city||D.city,D.isp=F.isp||D.isp,D.asn=F.asn||D.asn,D.geoMismatch=!!(m&&F.countryIso2&&m!==F.countryIso2.toUpperCase())):(D.geoVerifiedIp=R,D.geoCountryIso2=m,D.geoCountryName=D.countryName,D.geoMismatch=!1);try{(y=window.LuciferAndroidBridge)!=null&&y.updateVpnNotificationMetadata&&window.LuciferAndroidBridge.updateVpnNotificationMetadata(D.statusIp||R,D.geoCountryIso2||m,D.geoCountryName||D.countryName)}catch{}return Ar("Connected",`Tunnel active -> Exit IP ${D.statusIp} (${D.city}, ${D.geoCountryName})`),ki(),{ok:!0,extensionActive:!0,realIpInfo:D.realIpInfo,status:Nn(),state:Nn()}}if(s==="DISCONNECT_VPN")return Lo++,(S=window.LuciferAndroidBridge)!=null&&S.stopVpnTunnelAsync&&await Ba(M=>window.LuciferAndroidBridge.stopVpnTunnelAsync(M),5e3),D.vpnState="Disconnected",D.iso="",D.uiLockedLocation="",D.countryName="",D.city="",D.isp="",D.asn="",D.statusIp=D.realIpInfo.ip,D.geoVerifiedIp="",D.geoCountryIso2="",D.geoCountryName="",D.geoMismatch=!1,D.connectedAt=null,D.activeProxies=[],D.proxyUsername="",Ar("Disconnected",`Android VPN tunnel disconnected. Restored direct ISP (${D.realIpInfo.ip})`),ki(),{ok:!0,extensionActive:!0,realIpInfo:D.realIpInfo,status:Nn(),state:Nn()};if(s==="VERIFY_EXIT_IP"||s==="VERIFY_IP"){const M=D.vpnState==="Connected",A=((_=(v=D.activeProxies)==null?void 0:v[0])==null?void 0:_.host)||D.statusIp||"",m=M?await V0(A,D.iso):await mh();M&&m&&m.ip&&(D.statusIp=m.ip,D.geoVerifiedIp=m.ip,D.geoCountryIso2=m.countryIso2||D.iso,D.geoCountryName=m.countryName||D.countryName,D.city=m.city||D.city,D.isp=m.isp||D.isp,D.asn=m.asn||D.asn,ki());const x=(m==null?void 0:m.ip)||(M?D.statusIp:D.realIpInfo.ip),P=(m==null?void 0:m.city)||(M?D.city:D.realIpInfo.city),U=(m==null?void 0:m.countryName)||(M?D.geoCountryName||D.countryName:D.realIpInfo.countryName);return Ar("VerifyIP",`Verified active IP: ${x} (${P}, ${U})`),{ok:!0,ip:x,country:(m==null?void 0:m.countryIso2)||(M?D.geoCountryIso2||D.iso:D.realIpInfo.countryIso2),countryName:U,city:P,isp:(m==null?void 0:m.isp)||(M?D.isp:D.realIpInfo.isp),asn:(m==null?void 0:m.asn)||(M?D.asn:D.realIpInfo.asn),isVpnActive:M,realTunnelActive:M,tunnelProtocol:M?D.protocol:"Direct",tunnelInternalIp:M?"10.7.1.134/32":null,verifiedAt:new Date().toISOString()}}if(s==="CLEAR_LOGS")return D.serviceLogs=[`[${new Date().toISOString().slice(11,19)}] [System] Activity logs cleared by user`],{ok:!0,serviceLogs:D.serviceLogs};if(s==="UPDATE_SETTINGS"){const M=["selectedIso","vpnProtocol","isStreamingMode","showExtendedCatalog","theme","cameraMode","autoConnectOnStartup","dynamicIpRotation","autoCutoffOnTabClose"];for(const A of M)e&&e[A]!==void 0&&(D[A]=e[A]);return D.bypassLan=!0,D.protocol=D.isStreamingMode?"OpenVPN TCP (Streaming)":O0[D.vpnProtocol]||"Lucifer LinkX (WireGuard)",Ar("Settings",`Updated preferences (protocol=${D.vpnProtocol}, dynamicIp=${D.dynamicIpRotation!==!1?"ACTIVE":"DEACTIVE"})`),ki(),{ok:!0,status:Nn(),state:Nn()}}if(s==="GENERATE_CONFIG"){const M=String((e==null?void 0:e.iso)||D.iso||D.selectedIso||"US").toUpperCase(),A=Xn(M)||Xn("US"),m=D.vpnState==="Connected"&&D.statusIp?D.statusIp:A.gatewayIp,x=f_({...A,gatewayIp:m}),P=D.isStreamingMode?"OpenVPN_TCP":D.vpnProtocol.startsWith("OpenVPN")?D.vpnProtocol:"OpenVPN_UDP",U=h_({...A,gatewayIp:m},P);return{ok:!0,iso:M,gatewayIp:m,wgConfig:x,ovpnConfig:U}}return{ok:!0,status:Nn(),state:Nn()}}const MA="lucifer_tunnel_updater_db",Vo="dir_handles",Jv="unpacked_extension_dir";function Qv(){return new Promise((s,e)=>{const t=indexedDB.open(MA,1);t.onupgradeneeded=()=>{const r=t.result;r.objectStoreNames.contains(Vo)||r.createObjectStore(Vo)},t.onsuccess=()=>s(t.result),t.onerror=()=>e(t.error)})}async function EA(){try{const s=await Qv();return await new Promise(e=>{const r=s.transaction(Vo,"readonly").objectStore(Vo).get(Jv);r.onsuccess=()=>e(r.result||null),r.onerror=()=>e(null)})}catch{return null}}async function wA(s){try{const e=await Qv();await new Promise((t,r)=>{const o=e.transaction(Vo,"readwrite");o.objectStore(Vo).put(s,Jv),o.oncomplete=()=>t(),o.onerror=()=>r(o.error)})}catch{}}async function H0(s){try{return await s.getFileHandle("manifest.json",{create:!1}),s}catch{try{const e=await s.getDirectoryHandle("extension",{create:!1});return await e.getFileHandle("manifest.json",{create:!1}),e}catch{return s}}}async function TA(s){const e=new DecompressionStream("deflate-raw"),t=e.writable.getWriter();t.write(s),t.close();const o=await new Response(e.readable).arrayBuffer();return new Uint8Array(o)}function AA(s){const e=new DataView(s),t=new Uint8Array(s),r=new TextDecoder("utf-8");let o=-1;const l=Math.max(0,t.length-65557);for(let p=t.length-22;p>=l;p--)if(e.getUint32(p,!0)===101010256){o=p;break}if(o===-1)throw new Error("Invalid update package (EOCD signature not found)");const u=e.getUint16(o+10,!0);let d=e.getUint32(o+16,!0);const f=[];for(let p=0;p<u;p++){if(e.getUint32(d,!0)!==33639248)throw new Error("Corrupt ZIP Central Directory header");const y=e.getUint16(d+10,!0),S=e.getUint32(d+20,!0),v=e.getUint32(d+24,!0),_=e.getUint16(d+28,!0),M=e.getUint16(d+30,!0),A=e.getUint16(d+32,!0),m=e.getUint32(d+42,!0),x=t.subarray(d+46,d+46+_),P=r.decode(x).replace(/\\/g,"/");if(e.getUint32(m,!0)!==67324752)throw new Error(`Invalid local file header for ${P}`);const U=e.getUint16(m+26,!0),b=e.getUint16(m+28,!0),R=m+30+U+b,N=t.subarray(R,R+S);P.endsWith("/")||f.push({name:P,method:y,compressedData:N,uncompressedSize:v}),d+=46+_+M+A}return f}async function bA(s,e,t){const r=e.split("/").filter(Boolean);if(r.length===0)return;let o=s;for(let f=0;f<r.length-1;f++)o=await o.getDirectoryHandle(r[f],{create:!0});const l=r[r.length-1],d=await(await o.getFileHandle(l,{create:!0})).createWritable();await d.write(t),await d.close()}async function CA({onProgress:s=()=>{},allowPicker:e=!0}={}){let t=await EA();if(t)try{let f=await t.queryPermission({mode:"readwrite"});f!=="granted"&&(f=await t.requestPermission({mode:"readwrite"})),f!=="granted"&&(t=null)}catch{t=null}if(t)t=await H0(t);else{if(!e||typeof window.showDirectoryPicker!="function")return{ok:!1,needsFullTabPicker:!0,error:"Folder selection required in full tab"};s("Select your unpacked Lucifer Tunnel extension folder...");const f=await window.showDirectoryPicker({id:"lucifer_tunnel_ext_dir",mode:"readwrite",startIn:"documents"});t=await H0(f),await wA(t)}s("Downloading update package...");const r=await fetch(`${Hv()}?t=${Date.now()}`,{cache:"no-store"});if(!r.ok)throw new Error(`Download failed (HTTP ${r.status})`);const o=await r.arrayBuffer(),l=AA(o),u=[...l.filter(f=>f.name!=="manifest.json"),...l.filter(f=>f.name==="manifest.json")],d=u.length;for(let f=0;f<d;f++){const p=u[f];if(f%25===0||f===d-1){const S=Math.round((f+1)/d*100);s(`Installing update files... ${S}% (${f+1}/${d})`)}let y;if(p.method===0)y=p.compressedData;else if(p.method===8)y=await TA(p.compressedData);else throw new Error(`Unsupported ZIP compression method ${p.method}`);await bA(t,p.name,y)}return s("Update installed! Reloading extension..."),setTimeout(()=>{try{typeof chrome<"u"&&chrome.runtime&&typeof chrome.runtime.reload=="function"&&chrome.runtime.reload()}catch{}},350),{ok:!0,filesUpdated:d}}const RA=[{label:"Auto (Recommended)",value:"Auto"},{label:"WireGuard (LinkX)",value:"WireGuard"},{label:"OpenVPN (UDP)",value:"OpenVPN_UDP"},{label:"OpenVPN (TCP)",value:"OpenVPN_TCP"}];function PA({vpnProtocol:s,onChangeProtocol:e,isStreamingMode:t,appAutoStart:r,onToggleAppAutoStart:o,autoCutoffOnTabClose:l=!1,onToggleAutoCutoff:u=()=>{},dynamicIpRotation:d=!0,onToggleDynamicIp:f=()=>{},theme:p,onToggleTheme:y,cameraMode:S,onChangeCameraMode:v,serviceBridgeConnected:_}){const M=Dn(),A=M?Os:Xa,m=M?os:Vv,[x,P]=Be.useState(null),[U,b]=Be.useState({checking:!1,updateAvailable:!1,latestVersion:A,statusText:`OTA Sync Active • Up to date (${m})`});Be.useEffect(()=>{let E=!0;return Ya(!1).then(L=>{!E||!L||b({checking:!1,updateAvailable:!!L.updateAvailable,latestVersion:L.latestVersion||A,statusText:L.updateAvailable?`New V${L.latestVersion} available`:`OTA Sync Active • Up to date (${m})`})}),()=>{E=!1}},[A,m]);const R=typeof window<"u"&&window.location&&String(window.location.search||"").includes("autoUpdate=1"),N=async E=>{try{b(B=>({...B,checking:!0,statusText:"Select your unpacked extension folder to auto-install..."}));const L=await CA({allowPicker:!0,onProgress:B=>{b(X=>({...X,checking:!0,statusText:B}))}});if(L&&L.ok){b(B=>({...B,checking:!1,updateAvailable:!1,statusText:`Installed ${L.filesUpdated} files! Reloading extension...`}));return}}catch{}await za(E),b(L=>({...L,checking:!1,statusText:`Downloaded V${E} .zip — extract & reload extension`}))},F=async()=>{if(U.updateAvailable){M?(await za(U.latestVersion),b(L=>({...L,statusText:`Downloading V${L.latestVersion} APK — tap notification when complete to install`}))):await N(U.latestVersion);return}b(L=>({...L,checking:!0,statusText:"Checking for updates..."}));const E=await Ya(!0);E&&E.updateAvailable?M?(await za(E.latestVersion),b({checking:!1,updateAvailable:!0,latestVersion:E.latestVersion,statusText:`Downloading V${E.latestVersion} APK — tap notification when complete to install`})):(b({checking:!1,updateAvailable:!0,latestVersion:E.latestVersion,statusText:`New V${E.latestVersion} available`}),await N(E.latestVersion)):b(L=>({...L,checking:!1,updateAvailable:!1,statusText:`Up to date (${m})`}))};return T.jsxs("section",{"aria-label":M?"App Settings":"Extension Settings",style:{flex:1,height:"100%",overflowY:"auto",padding:M?"18px 14px 36px 14px":"24px 20px 44px 20px",display:"flex",flexDirection:"column",alignItems:"center"},children:[T.jsxs("div",{style:{width:"100%",maxWidth:560},children:[!M&&(R||U.updateAvailable)&&T.jsxs("div",{className:"u-glass-card",style:{borderRadius:14,padding:"14px 16px",marginBottom:16,border:"1px solid rgba(59, 130, 246, 0.5)",background:"rgba(37, 99, 235, 0.14)",display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,flexWrap:"wrap"},children:[T.jsxs("div",{style:{minWidth:0,flex:1},children:[T.jsx("div",{style:{fontSize:13.5,fontWeight:800,color:"var(--uv-text-heading)"},children:"1-Click Automatic Extension Folder Updater"}),T.jsx("div",{style:{fontSize:11.5,color:"var(--uv-text-secondary)",marginTop:3},children:U.statusText||"Select your unpacked extension folder once — all files will be extracted and reloaded automatically."})]}),T.jsx("button",{onClick:()=>N(U.latestVersion),disabled:U.checking,className:"u-btn u-btn-primary",style:{height:34,padding:"0 14px",fontSize:12,fontWeight:700,whiteSpace:"nowrap"},children:U.checking?"Installing...":"Select Folder & Auto-Update"})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14,gap:10},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx("h1",{style:{fontSize:20,fontWeight:800,color:"var(--uv-text-heading)",letterSpacing:"-0.02em"},children:M?"Settings":"Extension Settings"}),T.jsx("span",{style:{fontSize:10.5,fontWeight:800,padding:"2px 8px",borderRadius:999,backgroundColor:"rgba(59, 130, 246, 0.18)",border:"1px solid rgba(59, 130, 246, 0.42)",color:"#60A5FA",whiteSpace:"nowrap"},children:m})]}),T.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:6,fontSize:10.5,fontWeight:700,padding:"4px 10px",borderRadius:999,backgroundColor:"rgba(16, 185, 129, 0.16)",color:"#34D399",border:"1px solid rgba(16, 185, 129, 0.36)",whiteSpace:"nowrap"},children:[M?T.jsx(i_,{size:12,color:"#34D399","aria-hidden":"true"}):T.jsx(Z0,{size:12,color:"#34D399","aria-hidden":"true"}),T.jsx("span",{children:M?"System VPN Ready":_?"Extension Active":"Standalone Mode"})]})]}),T.jsx("div",{style:{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.06em",color:"var(--uv-text-secondary)",marginBottom:8,paddingLeft:4},children:M?"Tunnel & Connection":"Extension Tunnel & Startup"}),T.jsxs("div",{className:"u-glass-card",style:{borderRadius:14,padding:"4px 16px",marginBottom:18},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0",borderBottom:"1px solid var(--uv-divider)",gap:12},children:[T.jsxs("div",{style:{minWidth:0},children:[T.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--uv-text-heading)"},children:"VPN Protocol"}),T.jsx("div",{style:{fontSize:11.5,color:"var(--uv-text-secondary)",marginTop:2},children:t?"Locked for 4K Streaming":"LinkX WireGuard or OpenVPN"})]}),T.jsx("select",{"aria-label":"Select VPN Protocol",value:t?"OpenVPN_TCP":s,disabled:t,onChange:E=>e(E.target.value),style:{width:170,height:34,padding:"0 10px",borderRadius:9,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border-strong)",color:"var(--uv-text-heading)",fontSize:12,fontWeight:600,cursor:t?"not-allowed":"pointer",opacity:t?.65:1,outline:"none",flexShrink:0},children:RA.map(E=>T.jsx("option",{value:E.value,style:{backgroundColor:"#0F172A",color:"#F8FAFC"},children:E.label},E.value))})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0",borderBottom:"1px solid var(--uv-divider)",gap:12},children:[T.jsxs("div",{style:{minWidth:0},children:[T.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--uv-text-heading)"},children:M?"Auto-Connect on Launch":"Auto-Connect on Startup"}),T.jsx("div",{style:{fontSize:11.5,color:"var(--uv-text-secondary)",marginTop:2},children:M?"Connect when app opens":"Connect when browser launches"})]}),T.jsx("button",{role:"switch","aria-checked":r,"aria-label":"Auto-Connect",onClick:o,className:`u-switch ${r?"u-switch-checked":""}`,style:{flexShrink:0},children:T.jsx("span",{className:"u-switch-thumb"})})]}),!M&&T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0",borderBottom:"1px solid var(--uv-divider)",gap:12},children:[T.jsxs("div",{style:{minWidth:0},children:[T.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--uv-text-heading)"},children:"Auto-Cutoff on Tab Close"}),T.jsx("div",{style:{fontSize:11.5,color:"var(--uv-text-secondary)",marginTop:2},children:"Off keeps VPN active across all tabs"})]}),T.jsx("button",{role:"switch","aria-checked":l,"aria-label":"Auto-Cutoff on Tab Close",onClick:u,className:`u-switch ${l?"u-switch-checked":""}`,style:{flexShrink:0},children:T.jsx("span",{className:"u-switch-thumb"})})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0",gap:12},children:[T.jsxs("div",{style:{minWidth:0},children:[T.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--uv-text-heading)"},children:"Dynamic IP Rotation"}),T.jsx("div",{style:{fontSize:11.5,color:"var(--uv-text-secondary)",marginTop:2},children:d?"New exit IP on every connect":"Single static IP per country"})]}),T.jsx("button",{type:"button",onClick:f,"aria-pressed":d,title:"Click to toggle Dynamic IP Rotation (Active / Deactive)",style:{fontSize:10.5,fontWeight:800,padding:"4px 11px",borderRadius:999,backgroundColor:d?"rgba(16, 185, 129, 0.18)":"rgba(244, 63, 94, 0.18)",color:d?"#34D399":"#FB7185",border:d?"1px solid rgba(16, 185, 129, 0.38)":"1px solid rgba(244, 63, 94, 0.38)",whiteSpace:"nowrap",flexShrink:0,cursor:"pointer",userSelect:"none",transition:"all 150ms ease"},children:d?"ACTIVE":"DEACTIVE"})]})]}),T.jsx("div",{style:{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.06em",color:"var(--uv-text-secondary)",marginBottom:8,paddingLeft:4},children:"Appearance & 3D View"}),T.jsxs("div",{className:"u-glass-card",style:{borderRadius:14,padding:"4px 16px",marginBottom:18},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0",borderBottom:"1px solid var(--uv-divider)",gap:12},children:[T.jsxs("div",{style:{minWidth:0},children:[T.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--uv-text-heading)"},children:"Interface Theme"}),T.jsx("div",{style:{fontSize:11.5,color:"var(--uv-text-secondary)",marginTop:2},children:p==="dark"?"Dark Cyber Glass":"Clean Light Mode"})]}),T.jsx("button",{onClick:y,className:"u-btn u-btn-secondary",style:{height:34,padding:"0 14px",fontSize:12.5,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6},children:p==="dark"?T.jsxs(T.Fragment,{children:[T.jsx(Q0,{size:14,color:"#FBBF24","aria-hidden":"true"}),T.jsx("span",{children:"Dark Mode"})]}):T.jsxs(T.Fragment,{children:[T.jsx($0,{size:14,color:"#3B82F6","aria-hidden":"true"}),T.jsx("span",{children:"Light Mode"})]})})]}),T.jsxs("div",{style:{padding:"13px 0",display:"flex",flexDirection:"column",gap:10},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[T.jsx("div",{style:{fontSize:14,fontWeight:600,color:"var(--uv-text-heading)"},children:"3D Camera View"}),T.jsx("span",{style:{fontSize:11.5,color:"var(--uv-text-secondary)"},children:"Default globe mode"})]}),T.jsx("div",{style:{display:"grid",gridTemplateColumns:"repeat(3, 1fr)",gap:6,backgroundColor:"var(--uv-surface-card)",padding:4,borderRadius:10,border:"1px solid var(--uv-border)"},children:[{id:"globe",label:"3D Globe"},{id:"shield",label:"3D Shield"},{id:"orbit",label:"Auto-Orbit"}].map(E=>{const L=S===E.id;return T.jsx("button",{onClick:()=>v(E.id),style:{height:32,padding:"0 8px",borderRadius:7,border:L?"1px solid var(--uv-primary)":"1px solid transparent",backgroundColor:L?"var(--uv-primary)":"transparent",color:L?"#FFFFFF":"var(--uv-text-body)",fontSize:12,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap",textAlign:"center",transition:"background-color 150ms ease, color 150ms ease"},children:E.label},E.id)})})]})]}),T.jsx("div",{style:{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.06em",color:"var(--uv-text-secondary)",marginBottom:8,paddingLeft:4},children:"About"}),T.jsxs("div",{className:"u-glass-card",style:{borderRadius:14,padding:"16px"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,marginBottom:12},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,minWidth:0},children:[T.jsx("img",{src:"/icons/icon-192.png",alt:"",style:{width:32,height:32,borderRadius:"50%",flexShrink:0}}),T.jsxs("div",{style:{minWidth:0},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:7,flexWrap:"wrap"},children:[T.jsx("span",{style:{fontSize:15,fontWeight:800,color:"var(--uv-text-heading)",whiteSpace:"nowrap"},children:"Lucifer Tunnel"}),T.jsx("span",{style:{fontSize:10,fontWeight:800,padding:"2px 7px",borderRadius:999,backgroundColor:"rgba(16, 185, 129, 0.18)",border:"1px solid rgba(16, 185, 129, 0.4)",color:"#34D399",whiteSpace:"nowrap"},children:m})]}),T.jsxs("div",{style:{fontSize:11,color:"var(--uv-text-secondary)",marginTop:1},children:[M?"Android Mobile VPN":"Browser VPN Extension"," • By Ayan Paul"]})]})]}),T.jsxs("a",{href:"https://ayanpaul.me",target:"_blank",rel:"noreferrer",className:"u-btn u-btn-secondary",style:{height:30,padding:"0 10px",fontSize:11,textDecoration:"none",color:"#38BDF8",borderColor:"rgba(56, 189, 248, 0.35)",whiteSpace:"nowrap",flexShrink:0},children:[T.jsx("span",{children:"ayanpaul.me"}),T.jsx($y,{size:11,"aria-hidden":"true"})]})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,padding:"12px 0",borderTop:"1px solid var(--uv-divider)"},children:[T.jsxs("div",{style:{minWidth:0},children:[T.jsx("div",{style:{fontSize:13.5,fontWeight:600,color:"var(--uv-text-heading)"},children:M?"App Auto-Update":"Extension Auto-Update"}),T.jsx("div",{style:{fontSize:11,color:U.updateAvailable?"#FBBF24":"var(--uv-text-secondary)",marginTop:2},children:U.statusText})]}),T.jsx("button",{onClick:F,disabled:U.checking,className:U.updateAvailable?"u-btn u-btn-primary":"u-btn u-btn-secondary",style:{height:32,padding:"0 12px",fontSize:12,fontWeight:700,whiteSpace:"nowrap",flexShrink:0},children:U.checking?"Checking...":U.updateAvailable?`Update to V${U.latestVersion}`:"Check Update"})]}),T.jsxs("div",{style:{display:"flex",flexDirection:"column",borderTop:"1px solid var(--uv-divider)"},children:[T.jsxs("button",{onClick:()=>P("terms"),style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 0",background:"transparent",border:"none",borderBottom:"1px solid var(--uv-divider)",color:"var(--uv-text-body)",fontSize:13.5,fontWeight:600,cursor:"pointer",textAlign:"left"},children:[T.jsxs("span",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx(Sg,{size:14,color:"#60A5FA","aria-hidden":"true"}),T.jsx("span",{children:"Terms of Service"})]}),T.jsx(yg,{size:15,color:"var(--uv-text-secondary)","aria-hidden":"true"})]}),T.jsxs("button",{onClick:()=>P("privacy"),style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 0 2px 0",background:"transparent",border:"none",color:"var(--uv-text-body)",fontSize:13.5,fontWeight:600,cursor:"pointer",textAlign:"left"},children:[T.jsxs("span",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx(vf,{size:14,color:"#34D399","aria-hidden":"true"}),T.jsx("span",{children:"Privacy Policy"})]}),T.jsx(yg,{size:15,color:"var(--uv-text-secondary)","aria-hidden":"true"})]})]})]})]}),x==="terms"&&T.jsx("div",{role:"dialog","aria-modal":"true","aria-labelledby":"terms-modal-title",className:"u-modal-backdrop",onClick:()=>P(null),children:T.jsxs("div",{className:"u-dialog-card",style:{width:"92%",maxWidth:480,textAlign:"left"},onClick:E=>E.stopPropagation(),children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx(Sg,{size:18,color:"#60A5FA","aria-hidden":"true"}),T.jsxs("h2",{id:"terms-modal-title",style:{fontSize:16,fontWeight:700,color:"var(--uv-text-heading)"},children:["Terms of Service — ",os]})]}),T.jsx("button",{onClick:()=>P(null),"aria-label":"Close Terms of Service",style:{width:28,height:28,borderRadius:7,border:"1px solid var(--uv-border)",backgroundColor:"var(--uv-surface-card)",color:"var(--uv-text-secondary)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"},children:T.jsx(_f,{size:15,"aria-hidden":"true"})})]}),T.jsxs("div",{style:{maxHeight:280,overflowY:"auto",paddingRight:4,fontSize:12.5,lineHeight:1.55,color:"var(--uv-text-body)",display:"flex",flexDirection:"column",gap:10,marginBottom:16},children:[T.jsxs("p",{children:[T.jsx("strong",{children:"1. Service Architecture:"})," ",M?`Lucifer Tunnel (${os}) routes traffic through 82 official global gateways using Android VpnService and dynamic per-connection IP rotation.`:`Lucifer Tunnel (${os}) routes browser traffic through 82 official global gateways with dynamic per-connection IP rotation.`]}),T.jsxs("p",{children:[T.jsx("strong",{children:"2. Acceptable Use:"})," Use Lucifer Tunnel solely for lawful privacy, security, and network protection purposes."]}),T.jsxs("p",{children:[T.jsx("strong",{children:"3. Attribution:"})," Developed and maintained by Ayan Paul (ayanpaul.me)."]})]}),T.jsx("div",{style:{display:"flex",justifyContent:"flex-end"},children:T.jsx("button",{onClick:()=>P(null),className:"u-btn u-btn-primary",children:"Close"})})]})}),x==="privacy"&&T.jsx("div",{role:"dialog","aria-modal":"true","aria-labelledby":"privacy-modal-title",className:"u-modal-backdrop",onClick:()=>P(null),children:T.jsxs("div",{className:"u-dialog-card",style:{width:"92%",maxWidth:480,textAlign:"left"},onClick:E=>E.stopPropagation(),children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx(vf,{size:18,color:"#34D399","aria-hidden":"true"}),T.jsxs("h2",{id:"privacy-modal-title",style:{fontSize:16,fontWeight:700,color:"var(--uv-text-heading)"},children:["Privacy Policy — ",os]})]}),T.jsx("button",{onClick:()=>P(null),"aria-label":"Close Privacy Policy",style:{width:28,height:28,borderRadius:7,border:"1px solid var(--uv-border)",backgroundColor:"var(--uv-surface-card)",color:"var(--uv-text-secondary)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"},children:T.jsx(_f,{size:15,"aria-hidden":"true"})})]}),T.jsxs("div",{style:{maxHeight:280,overflowY:"auto",paddingRight:4,fontSize:12.5,lineHeight:1.55,color:"var(--uv-text-body)",display:"flex",flexDirection:"column",gap:10,marginBottom:16},children:[T.jsxs("p",{children:[T.jsx("strong",{children:"1. Strict Zero-Logs Policy:"})," Lucifer Tunnel does not record, log, or store your browsing history, traffic destination, or DNS queries."]}),T.jsxs("p",{children:[T.jsx("strong",{children:"2. Ephemeral Session State:"})," Active tunnel credentials and routing state are held strictly in memory and cleared when disconnected."]}),T.jsxs("p",{children:[T.jsx("strong",{children:"3. Minimal Permissions:"})," Only standard network and VPN tunnel permissions are used."]})]}),T.jsx("div",{style:{display:"flex",justifyContent:"flex-end"},children:T.jsx("button",{onClick:()=>P(null),className:"u-btn u-btn-primary",children:"Close"})})]})})]})}const Yc=new Map,qc=new Set;let G0=!1;function Bi(){var s;if(Dn())return!0;try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&typeof chrome.runtime.sendMessage=="function"&&typeof window<"u"&&((s=window.location)==null?void 0:s.protocol)==="chrome-extension:")}catch{return!1}}function ex(){if(!(G0||typeof window>"u")){if(G0=!0,!Dn()&&Bi())try{chrome.runtime.onMessage.addListener(s=>{if(!(!s||s.source!=="LUCIFER_BACKGROUND"))for(const e of qc)try{e({source:"LUCIFER_TUNNEL_EXTENSION",type:s.type||"EXTENSION_EVENT",payload:s.payload||{}})}catch{}})}catch{}window.addEventListener("message",s=>{if(s.source!==window)return;const e=s.data;if(!(!e||e.source!=="LUCIFER_TUNNEL_EXTENSION")){if(e.type==="EXTENSION_RESPONSE"&&e.requestId){const t=Yc.get(e.requestId);t&&(clearTimeout(t.timer),Yc.delete(e.requestId),t.resolve(e.response||{ok:!1}));return}for(const t of qc)try{t(e)}catch{}}})}}function Oi(){return Dn()||Bi()?!0:typeof document>"u"?!1:!!document.documentElement.getAttribute("data-lucifer-extension")}function Wn(s,e={},t=4500){return ex(),typeof window>"u"?Promise.resolve({ok:!1,notInstalled:!0}):Dn()?SA(s,e):Bi()?new Promise(r=>{const o=setTimeout(()=>{r({ok:!1,timeout:!0})},t);try{chrome.runtime.sendMessage({source:"LUCIFER_EXTENSION_DASHBOARD",action:s,payload:e},l=>{clearTimeout(o);const u=chrome.runtime.lastError;r(u?{ok:!1,error:u.message}:l||{ok:!1})})}catch(l){clearTimeout(o),r({ok:!1,error:(l==null?void 0:l.message)||"Extension runtime error"})}}):new Promise(r=>{var d;const o="lucifer_req_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,8),l=setTimeout(()=>{Yc.delete(o),r({ok:!1,timeout:!0,notInstalled:!Oi()})},t);Yc.set(o,{resolve:r,timer:l});const u=typeof window<"u"&&((d=window.location)!=null&&d.origin)&&window.location.origin!=="null"?window.location.origin:"*";window.postMessage({source:"LUCIFER_TUNNEL_WEB",requestId:o,action:s,payload:e},u)})}function IA(s){return ex(),qc.add(s),()=>{qc.delete(s)}}function LA(s){if(!s||typeof s.lat!="number"||typeof s.lng!="number")return"—";const e=s.lat>=0?"N":"S",t=s.lng>=0?"E":"W";return`${Math.abs(s.lat).toFixed(2)}° ${e}, ${Math.abs(s.lng).toFixed(2)}° ${t}`}function NA(s,e){const t=String(s||"").trim(),r=t.match(/^\[([^\]]+)\]\s*\[([^\]]+)\]\s*(.*)$/);let o="",l="System",u=t;r&&(o=r[1].trim(),l=r[2].trim(),u=r[3].trim());const d=d_(o,e),f=l.toUpperCase();if(f.includes("CONNECTED")&&!f.includes("DISCONNECTED"))return{time:d,label:"CONNECTED",group:"TUNNEL",color:"#34D399",bg:"rgba(16, 185, 129, 0.14)",border:"rgba(16, 185, 129, 0.38)",Icon:xf,message:u};if(f.includes("DISCONNECTED"))return{time:d,label:"DISCONNECTED",group:"TUNNEL",color:"#FB7185",bg:"rgba(244, 63, 94, 0.14)",border:"rgba(244, 63, 94, 0.38)",Icon:t_,message:u};if(f.includes("TUNNEL")||f.includes("HANDSHAKE")){const p=f.includes("HANDSHAKE");return{time:d,label:p?"HANDSHAKE":"TUNNEL",group:"TUNNEL",color:p?"#FBBF24":"#60A5FA",bg:p?"rgba(245, 158, 11, 0.14)":"rgba(59, 130, 246, 0.14)",border:p?"rgba(245, 158, 11, 0.38)":"rgba(59, 130, 246, 0.38)",Icon:ev,message:u}}return f.includes("VERIFY")||f.includes("ORIGIN")?{time:d,label:f.includes("ORIGIN")?"ISP PROBE":"IP VERIFY",group:"VERIFY",color:"#38BDF8",bg:"rgba(56, 189, 248, 0.14)",border:"rgba(56, 189, 248, 0.38)",Icon:K0,message:u}:f.includes("SETTING")?{time:d,label:"CONFIG",group:"SYSTEM",color:"#C084FC",bg:"rgba(168, 85, 247, 0.14)",border:"rgba(168, 85, 247, 0.38)",Icon:J0,message:u}:{time:d,label:"ENGINE",group:"SYSTEM",color:"#60A5FA",bg:"rgba(59, 130, 246, 0.14)",border:"rgba(59, 130, 246, 0.35)",Icon:yf,message:u}}function DA(s){return String(s||"").split(/\b(\d{1,3}(?:\.\d{1,3}){3})\b/g).map((r,o)=>/^\d{1,3}(?:\.\d{1,3}){3}$/.test(r)?T.jsx("span",{style:{display:"inline-block",padding:"1px 7px",margin:"0 2px",borderRadius:6,fontSize:11,fontWeight:700,fontVariantNumeric:"tabular-nums",backgroundColor:"rgba(56, 189, 248, 0.15)",border:"1px solid rgba(56, 189, 248, 0.35)",color:"#38BDF8"},children:r},o):T.jsx(j0.Fragment,{children:r},o))}function UA({vpnStatus:s,realIpInfo:e,selectedLocationIso:t,onVerifyIp:r,ipVerificationResult:o,isVerifyingIp:l}){const[u,d]=Be.useState("telemetry"),[f,p]=Be.useState("ALL"),[y,S]=Be.useState([]),[v,_]=Be.useState(!1),[M,A]=Be.useState(()=>new Date),m=(s==null?void 0:s.state)==="Connected",x=Be.useMemo(()=>Xn(t||"US")||Xn("US"),[t]),P=m?(s==null?void 0:s.statusCountryIso2)||(x==null?void 0:x.iso)||"US":(e==null?void 0:e.country)||"BD",U=m?(s==null?void 0:s.statusIp)||(x==null?void 0:x.gatewayIp)||"—":(e==null?void 0:e.ip)||"—",b=m?(s==null?void 0:s.statusCity)||(x==null?void 0:x.city)||"Gateway":(e==null?void 0:e.city)||"Dhaka",R=m?(s==null?void 0:s.statusCountryName)||(x==null?void 0:x.name)||P:(e==null?void 0:e.countryName)||"Bangladesh",N=m?(s==null?void 0:s.statusIsp)||(x==null?void 0:x.isp)||"Lucifer Encrypted Relay":(e==null?void 0:e.isp)||"Direct Client ISP",F=m?(s==null?void 0:s.statusAsn)||(x==null?void 0:x.asn)||"AS209854 Lucifer Network":(e==null?void 0:e.asn)||"AS64072 Local Broadband",E=Be.useMemo(()=>o!=null&&o.coordinates?o.coordinates:m?(x==null?void 0:x.coordinates)||{lat:40.7128,lng:-74.006}:(e==null?void 0:e.coordinates)||{lat:23.8103,lng:90.4125},[o,m,x,e]);Be.useEffect(()=>{const W=setInterval(()=>{A(new Date)},1e3);return()=>clearInterval(W)},[]),Be.useEffect(()=>{let W=!1;async function ue(){const te=await Wn("GET_STATUS",{},1800);if(W||!te||!te.ok)return;const G=te.state||te.status||{};Array.isArray(G.serviceLogs)&&S(G.serviceLogs)}ue();const Q=setInterval(ue,2e3);return()=>{W=!0,clearInterval(Q)}},[s==null?void 0:s.state,o]);const L=Be.useMemo(()=>Da(P,M,{showCountryTag:!0,hour12:!0}),[P,M]),B=Be.useMemo(()=>o!=null&&o.verifiedAt?Da(P,o.verifiedAt,{showCountryTag:!0,hour12:!0}):"",[o,P]),X=Be.useMemo(()=>(Array.isArray(y)&&y.length>0?y:[`[${new Date().toISOString()}] [LuciferEngine] Tunnel telemetry & security monitor active.`]).map(ue=>NA(ue,P)),[y,P]),j=Be.useMemo(()=>f==="ALL"?X:X.filter(W=>W.group===f),[X,f]),ne=()=>{var W;if(U!=="—")try{(W=navigator.clipboard)==null||W.writeText(U),_(!0),setTimeout(()=>_(!1),1800)}catch{}},H=async()=>{const W=await Wn("CLEAR_LOGS",{},1500);W&&Array.isArray(W.serviceLogs)?S(W.serviceLogs):S([`[${new Date().toISOString()}] [System] Activity logs cleared by user`])};return T.jsx("div",{className:"uv-scrollbar u-settings-scroll",style:{flex:1,height:"100vh",overflowY:"auto",padding:"28px 36px 40px 36px",background:"transparent"},children:T.jsxs("div",{style:{maxWidth:880,margin:"0 auto",display:"flex",flexDirection:"column",gap:18},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:12},children:[T.jsx("div",{children:T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10},children:[T.jsx("div",{style:{width:36,height:36,borderRadius:10,background:m?"linear-gradient(135deg, rgba(16, 185, 129, 0.22), rgba(56, 189, 248, 0.16))":"linear-gradient(135deg, rgba(59, 130, 246, 0.22), rgba(244, 63, 94, 0.16))",border:m?"1px solid rgba(16, 185, 129, 0.45)":"1px solid rgba(59, 130, 246, 0.4)",display:"flex",alignItems:"center",justifyContent:"center"},children:T.jsx(Y0,{size:18,color:m?"#34D399":"#60A5FA"})}),T.jsxs("div",{children:[T.jsx("h1",{style:{fontSize:22,fontWeight:800,color:"var(--uv-text-heading)",letterSpacing:"-0.3px"},children:"IP & Logs"}),T.jsx("p",{style:{fontSize:12.5,color:"var(--uv-text-secondary)",marginTop:1},children:"Real-time exit-node geolocation, leak audit & engine activity logs"})]})]})}),T.jsxs("div",{style:{display:"inline-flex",alignItems:"center",gap:8,padding:"7px 13px",borderRadius:999,background:"var(--uv-surface-card)",border:"1px solid var(--uv-border-strong)",fontSize:12,fontWeight:700,color:"var(--uv-text-heading)",fontVariantNumeric:"tabular-nums"},title:"Live clock synchronized to the active country's timezone",children:[T.jsx(_g,{size:14,color:"#38BDF8"}),T.jsx("span",{children:L})]})]}),T.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,padding:5,borderRadius:14,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsxs("button",{type:"button",onClick:()=>d("telemetry"),style:{height:38,borderRadius:10,border:u==="telemetry"?"1px solid rgba(59, 130, 246, 0.45)":"1px solid transparent",background:u==="telemetry"?"linear-gradient(135deg, rgba(59, 130, 246, 0.25), rgba(37, 99, 235, 0.14))":"transparent",color:u==="telemetry"?"var(--uv-text-heading)":"var(--uv-text-secondary)",fontSize:13,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:8,cursor:"pointer",transition:"all 150ms ease"},children:[T.jsx(xf,{size:16,color:u==="telemetry"?"#38BDF8":"currentColor"}),T.jsx("span",{children:"Live IP & Security"})]}),T.jsxs("button",{type:"button",onClick:()=>d("logs"),style:{height:38,borderRadius:10,border:u==="logs"?"1px solid rgba(59, 130, 246, 0.45)":"1px solid transparent",background:u==="logs"?"linear-gradient(135deg, rgba(59, 130, 246, 0.25), rgba(37, 99, 235, 0.14))":"transparent",color:u==="logs"?"var(--uv-text-heading)":"var(--uv-text-secondary)",fontSize:13,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:8,cursor:"pointer",transition:"all 150ms ease"},children:[T.jsx(yf,{size:16,color:u==="logs"?"#38BDF8":"currentColor"}),T.jsx("span",{children:"Activity Logs"}),T.jsx("span",{style:{padding:"1px 7px",borderRadius:999,fontSize:10.5,fontWeight:800,backgroundColor:"rgba(59, 130, 246, 0.2)",color:"#60A5FA"},children:X.length})]})]}),u==="telemetry"?T.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:16},children:[T.jsxs("div",{className:"u-glass-card",style:{borderRadius:18,padding:"22px",position:"relative",overflow:"hidden",background:m?"radial-gradient(circle at 92% 12%, rgba(16, 185, 129, 0.14), transparent 55%), var(--uv-surface-glass)":"radial-gradient(circle at 92% 12%, rgba(244, 63, 94, 0.12), transparent 55%), var(--uv-surface-glass)",border:m?"1px solid rgba(16, 185, 129, 0.32)":"1px solid var(--uv-border-strong)"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,marginBottom:16,flexWrap:"wrap"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:7},children:[T.jsx(K0,{size:14,color:m?"#34D399":"#38BDF8"}),T.jsx("span",{style:{fontSize:11,fontWeight:800,textTransform:"uppercase",letterSpacing:"0.7px",color:"var(--uv-text-secondary)"},children:"Active Public Exit IP"})]}),T.jsx("span",{style:{fontSize:10.5,fontWeight:800,padding:"4px 11px",borderRadius:999,letterSpacing:"0.5px",backgroundColor:m?"rgba(16, 185, 129, 0.18)":"rgba(244, 63, 94, 0.16)",color:m?"#34D399":"#FB7185",border:m?"1px solid rgba(16, 185, 129, 0.42)":"1px solid rgba(244, 63, 94, 0.35)"},children:m?`TUNNEL PROTECTED • ${P}`:"DIRECT ISP"})]}),T.jsx("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:14,flexWrap:"wrap",marginBottom:18},children:T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:14},children:[T.jsxs("div",{style:{position:"relative",flexShrink:0},children:[T.jsx("img",{src:No(P),alt:R,style:{width:50,height:50,borderRadius:"50%",objectFit:"cover",border:m?"2px solid #10B981":"2px solid var(--uv-border-strong)",boxShadow:m?"0 0 18px rgba(16, 185, 129, 0.4)":"0 4px 12px rgba(0, 0, 0, 0.25)"},onError:W=>{W.currentTarget.src="/resources/icons/flags/ic_flag_unknown.webp"}}),T.jsx("span",{style:{position:"absolute",bottom:1,right:1,width:13,height:13,borderRadius:"50%",backgroundColor:m?"#10B981":"#F43F5E",border:"2px solid #0B1223"}})]}),T.jsxs("div",{children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"},children:[T.jsx("span",{style:{fontSize:24,fontWeight:800,color:"var(--uv-text-heading)",fontVariantNumeric:"tabular-nums",letterSpacing:"-0.4px"},children:U}),T.jsxs("button",{type:"button",onClick:ne,title:"Copy Public IP",style:{height:26,padding:"0 9px",borderRadius:7,border:"1px solid var(--uv-border-strong)",backgroundColor:"var(--uv-surface-card)",color:v?"#34D399":"var(--uv-text-secondary)",fontSize:11,fontWeight:700,display:"inline-flex",alignItems:"center",gap:5,cursor:"pointer"},children:[v?T.jsx(q0,{size:12,color:"#34D399"}):T.jsx(Ky,{size:12}),T.jsx("span",{children:v?"Copied":"Copy"})]})]}),T.jsxs("div",{style:{fontSize:13,color:"var(--uv-text-secondary)",marginTop:3,display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"},children:[T.jsx(Zy,{size:13,color:"#38BDF8"}),T.jsxs("span",{children:[b,", ",R," (",P,")"]})]})]})]})}),T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,padding:"11px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)",marginBottom:14,flexWrap:"wrap"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx("img",{src:No((e==null?void 0:e.country)||"BD"),alt:"Origin",style:{width:20,height:20,borderRadius:"50%",objectFit:"cover"},onError:W=>{W.currentTarget.src="/resources/icons/flags/ic_flag_unknown.webp"}}),T.jsxs("div",{children:[T.jsxs("div",{style:{fontSize:10,fontWeight:700,color:"var(--uv-text-secondary)",textTransform:"uppercase"},children:["Origin ISP (",(e==null?void 0:e.country)||"BD",")"]}),T.jsx("div",{style:{fontSize:12.5,fontWeight:700,color:"var(--uv-text-body)",fontVariantNumeric:"tabular-nums"},children:(e==null?void 0:e.ip)||"—"})]})]}),T.jsxs("div",{style:{display:"inline-flex",alignItems:"center",gap:6,padding:"3px 10px",borderRadius:999,fontSize:10.5,fontWeight:700,backgroundColor:m?"rgba(16, 185, 129, 0.14)":"rgba(148, 163, 184, 0.12)",color:m?"#34D399":"var(--uv-text-secondary)"},children:[T.jsx("span",{children:m?"Encrypted Tunnel":"Direct Route"}),T.jsx(Yy,{size:13})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx("img",{src:No(P),alt:"Exit",style:{width:20,height:20,borderRadius:"50%",objectFit:"cover"},onError:W=>{W.currentTarget.src="/resources/icons/flags/ic_flag_unknown.webp"}}),T.jsxs("div",{children:[T.jsx("div",{style:{fontSize:10,fontWeight:700,color:m?"#34D399":"#FB7185",textTransform:"uppercase"},children:m?`Exit Node (${P})`:"Unprotected IP"}),T.jsx("div",{style:{fontSize:12.5,fontWeight:700,color:"var(--uv-text-heading)",fontVariantNumeric:"tabular-nums"},children:U})]})]})]}),T.jsxs("div",{className:"u-settings-top-grid",style:{gap:10},children:[T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6,fontSize:11,fontWeight:600,color:"var(--uv-text-secondary)",marginBottom:4},children:[T.jsx(e_,{size:13,color:"#60A5FA"}),T.jsx("span",{children:"ISP / Carrier"})]}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:"var(--uv-text-heading)"},children:N})]}),T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6,fontSize:11,fontWeight:600,color:"var(--uv-text-secondary)",marginBottom:4},children:[T.jsx(Jy,{size:13,color:"#38BDF8"}),T.jsx("span",{children:"ASN Network"})]}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:"var(--uv-text-heading)"},children:F})]}),T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6,fontSize:11,fontWeight:600,color:"var(--uv-text-secondary)",marginBottom:4},children:[T.jsx(vf,{size:13,color:"#34D399"}),T.jsx("span",{children:"DNS Resolvers"})]}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:"var(--uv-text-heading)",fontVariantNumeric:"tabular-nums"},children:m?"1.1.1.1, 1.0.0.1 (Protected)":"8.8.8.8 (ISP Default)"})]}),T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6,fontSize:11,fontWeight:600,color:"var(--uv-text-secondary)",marginBottom:4},children:[T.jsx(_g,{size:13,color:"#FBBF24"}),T.jsxs("span",{children:["Country Local Time (",P,")"]})]}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:"#38BDF8",fontVariantNumeric:"tabular-nums"},children:L})]})]})]}),T.jsxs("div",{className:"u-glass-card",style:{borderRadius:18,padding:"22px"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,marginBottom:16,flexWrap:"wrap"},children:[T.jsxs("div",{children:[T.jsx("div",{style:{fontSize:15,fontWeight:800,color:"var(--uv-text-heading)"},children:"Live Tunnel & Route Verification"}),T.jsxs("div",{style:{fontSize:12,color:"var(--uv-text-secondary)",marginTop:2},children:["Encrypted exit-node & leak protection audit (",R," Time)"]})]}),T.jsxs("button",{type:"button",onClick:r,disabled:l,className:"u-btn u-btn-primary",style:{height:38,padding:"0 16px",borderRadius:10,fontSize:12.5,fontWeight:700},children:[T.jsx(Qy,{size:14,className:l?"uv-spin-fast":"","aria-hidden":"true"}),T.jsx("span",{children:l?"Verifying...":"Verify IP Now"})]})]}),T.jsxs("div",{className:"u-settings-top-grid",style:{gap:10,marginBottom:14},children:[T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsx("div",{style:{fontSize:11,color:"var(--uv-text-secondary)",marginBottom:4},children:"Tunnel Route Status"}),T.jsx("div",{style:{fontSize:13.5,fontWeight:800,color:m?"#34D399":"#FB7185"},children:m?`Protected (${P})`:"Direct ISP Route"})]}),T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsx("div",{style:{fontSize:11,color:"var(--uv-text-secondary)",marginBottom:4},children:"Transport Cipher"}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:"var(--uv-text-heading)"},children:m?"TLS 1.3 • AES-256-GCM":"Unencrypted Direct"})]}),T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsx("div",{style:{fontSize:11,color:"var(--uv-text-secondary)",marginBottom:4},children:"DNS & WebRTC Shield"}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:m?"#38BDF8":"var(--uv-text-heading)"},children:m?"Zero-Leak Shielded":"Standard ISP DNS"})]}),T.jsxs("div",{style:{padding:"12px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)"},children:[T.jsx("div",{style:{fontSize:11,color:"var(--uv-text-secondary)",marginBottom:4},children:"Exit Geo Coordinates"}),T.jsx("div",{style:{fontSize:13.5,fontWeight:700,color:"var(--uv-text-heading)",fontVariantNumeric:"tabular-nums"},children:LA(E)})]})]}),T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",borderRadius:12,backgroundColor:o||m?"rgba(16, 185, 129, 0.14)":"var(--uv-surface-card)",border:o||m?"1px solid rgba(16, 185, 129, 0.38)":"1px solid var(--uv-border)",color:o||m?"#34D399":"var(--uv-text-secondary)",fontSize:12.5,fontWeight:600,lineHeight:1.45},children:[T.jsx(xf,{size:17,style:{flexShrink:0}}),T.jsx("span",{children:o?`Verified active IP ${o.ip||U} (${o.city||b}, ${o.countryName||R}) • ${B}`:m?`Encrypted tunnel active via ${b}, ${R} (${U}) • ${L}`:`Click "Verify IP Now" to audit live exit-node routing and leak protection (${L}).`})]})]})]}):T.jsxs("div",{className:"u-glass-card",style:{borderRadius:18,padding:"22px",display:"flex",flexDirection:"column",gap:14},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,flexWrap:"wrap"},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[T.jsx(yf,{size:16,color:"#38BDF8"}),T.jsx("span",{style:{fontSize:14,fontWeight:800,color:"var(--uv-text-heading)",textTransform:"uppercase",letterSpacing:"0.5px"},children:"Engine Activity Logs"}),T.jsxs("span",{style:{padding:"2px 9px",borderRadius:999,fontSize:11,fontWeight:700,backgroundColor:"rgba(59, 130, 246, 0.16)",border:"1px solid rgba(59, 130, 246, 0.35)",color:"#60A5FA"},children:[j.length," ",j.length===1?"Event":"Events"]})]}),T.jsxs("button",{type:"button",onClick:H,className:"u-btn u-btn-secondary",style:{height:30,padding:"0 11px",fontSize:11.5,borderRadius:8},children:[T.jsx(r_,{size:13}),T.jsx("span",{children:"Clear"})]})]}),T.jsx("div",{style:{display:"flex",gap:6,flexWrap:"wrap"},children:[{id:"ALL",label:"All Events"},{id:"TUNNEL",label:"Tunnel"},{id:"VERIFY",label:"IP Verify"},{id:"SYSTEM",label:"System"}].map(W=>{const ue=f===W.id;return T.jsx("button",{type:"button",onClick:()=>p(W.id),style:{height:30,padding:"0 12px",borderRadius:999,border:ue?"1px solid rgba(59, 130, 246, 0.5)":"1px solid var(--uv-border)",backgroundColor:ue?"rgba(59, 130, 246, 0.2)":"var(--uv-surface-card)",color:ue?"#60A5FA":"var(--uv-text-secondary)",fontSize:11.5,fontWeight:700,cursor:"pointer"},children:W.label},W.id)})}),T.jsx("div",{className:"uv-scrollbar",style:{display:"flex",flexDirection:"column",gap:8,maxHeight:460,overflowY:"auto",paddingRight:4},children:j.length===0?T.jsx("div",{style:{textAlign:"center",padding:"36px 16px",color:"var(--uv-text-secondary)",fontSize:12.5},children:"No activity logs in this category."}):j.map((W,ue)=>{const Q=W.Icon;return T.jsxs("div",{style:{padding:"11px 14px",borderRadius:12,backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)",borderLeft:`3px solid ${W.color}`,display:"flex",flexDirection:"column",gap:6},children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,flexWrap:"wrap"},children:[T.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:5,padding:"2px 8px",borderRadius:6,fontSize:10,fontWeight:800,backgroundColor:W.bg,border:`1px solid ${W.border}`,color:W.color,letterSpacing:"0.4px"},children:[T.jsx(Q,{size:11}),T.jsx("span",{children:W.label})]}),T.jsx("span",{style:{fontSize:11,fontWeight:600,color:"var(--uv-text-secondary)",fontVariantNumeric:"tabular-nums"},children:W.time})]}),T.jsx("div",{style:{fontSize:12.5,color:"var(--uv-text-body)",lineHeight:1.45},children:DA(W.message)})]},ue)})})]})]})})}const FA={Auto:"Lucifer LinkX (Auto)",WireGuard:"Lucifer LinkX (WireGuard)",OpenVPN_UDP:"OpenVPN DCO (UDP)",OpenVPN_TCP:"OpenVPN DCO (TCP)"};function OA(s){const e=Math.floor(s/3600),t=Math.floor(s%3600/60),r=s%60;return[e,t,r].map(o=>String(o).padStart(2,"0")).join(":")}function kA(){const s=Be.useRef(null);if(!s.current){let fe=null;try{fe=window.sessionStorage.getItem("uv_tab_id")}catch{fe=null}if(!fe){fe="uvtab_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,9);try{window.sessionStorage.setItem("uv_tab_id",fe)}catch{}}s.current=fe}const[e,t]=Be.useState(!1),r=Be.useRef(!1),[o,l]=Be.useState(""),[u,d]=Be.useState(()=>typeof window<"u"&&window.location&&String(window.location.search||"").includes("autoUpdate=1")?"settings":"vpn"),[f,p]=Be.useState("dark"),[y,S]=Be.useState("globe"),[v,_]=Be.useState("Auto"),[M,A]=Be.useState(!1),[m,x]=Be.useState(!1),[P,U]=Be.useState(!0),[b,R]=Be.useState(!1),[N,F]=Be.useState(!1),[E,L]=Be.useState(!0),[B,X]=Be.useState({ip:"165.101.79.231",country:"BD",countryName:"Bangladesh",city:"Dhaka",isp:"Direct Host ISP (Unprotected)",asn:"AS64072 Local Broadband",coordinates:{lat:23.8103,lng:90.4125}}),[j,ne]=Be.useState("US"),[H,W]=Be.useState({state:"Disconnected",error:!1,statusReady:!0,statusIp:"165.101.79.231",statusCountryIso2:"BD",statusCountryName:"Bangladesh",statusCity:"Dhaka",statusIsp:"Direct Host ISP (Unprotected)",statusAsn:"AS64072 Local Broadband",uiLockedLocation:"",connectionStartedTimestamp:null,effectiveProtocol:"WireGuard",effectiveProtocolLabel:"Lucifer LinkX (Auto)",tunnelInternalIp:"10.7.1.134/32",tunnelMode:"Disconnected",realTunnelActive:!1}),[ue,Q]=Be.useState(0),[te,G]=Be.useState(!1),[ee,O]=Be.useState(0),[de,Ce]=Be.useState(0),[Te,De]=Be.useState(null),[Ye,le]=Be.useState(!1),[ge,Ne]=Be.useState(null),[tt,Xe]=Be.useState(()=>{try{return Bi()||window.matchMedia("(display-mode: standalone)").matches||!!window.navigator.standalone}catch{return!1}}),[mt,Gt]=Be.useState(!1),[lt,Et]=Be.useState(()=>Oi()),[Ot,xt]=Be.useState(!1),[At,Xt]=Be.useState({restricted:!1,minRequiredVersion:"",latestVersion:"",title:"Mandatory Update Required",message:"This version of Lucifer Tunnel is no longer supported. Please update to the latest version to continue using the VPN.",downloading:!1}),[Wt,_t]=Be.useState({visible:!1,latestVersion:"",popupKey:0}),Nt=Be.useRef(null),$=Be.useRef(0),It=Be.useRef(null),wt=Be.useRef(!1);Be.useEffect(()=>{let fe=!0;const ie=Ee=>{!fe||!Dn()||!Ee||(Nt.current&&clearTimeout(Nt.current),_t(K=>({visible:!0,latestVersion:Ee,popupKey:K.popupKey+1})),Nt.current=setTimeout(()=>{fe&&_t(K=>({...K,visible:!1}))},3e3))},se=async(Ee=!1,K=!1)=>{try{const Ue=await Ya(Ee);if(!fe||!Ue)return;Ue.versionRestricted?(Nt.current&&clearTimeout(Nt.current),_t(_e=>_e.visible?{..._e,visible:!1}:_e),Xt(_e=>({..._e,restricted:!0,minRequiredVersion:Ue.minRequiredVersion||Ue.latestVersion||_e.minRequiredVersion,latestVersion:Ue.latestVersion||Ue.minRequiredVersion||_e.latestVersion,title:Ue.restrictionTitle||_e.title,message:Ue.restrictionMessage||_e.message}))):(Ue.versionRestricted===!1&&Xt(_e=>_e.restricted?{..._e,restricted:!1}:_e),K&&Dn()&&Ue.updateAvailable&&Ue.latestVersion&&ie(Ue.latestVersion))}catch{}},be=()=>{const Ee=Date.now();Ee-$.current<1500||($.current=Ee,se(!0,!0))},Fe=()=>{document.visibilityState==="visible"&&be()};be();const ve=setInterval(()=>se(!0,!0),3600*1e3);return document.addEventListener("visibilitychange",Fe),typeof window<"u"&&(window.__onLuciferAppEntered=be),()=>{fe=!1,clearInterval(ve),Nt.current&&clearTimeout(Nt.current),document.removeEventListener("visibilitychange",Fe),typeof window<"u"&&window.__onLuciferAppEntered===be&&delete window.__onLuciferAppEntered}},[]),Be.useEffect(()=>(Oi()&&Et(!0),Wn("PING",{},1500).then(ie=>{ie&&ie.ok&&Et(!0)}),IA(ie=>{ie.type==="EXTENSION_READY"?Et(!0):ie.type==="SESSION_SUPERSEDED"&&(r.current=!0,t(!0))})),[]),Be.useEffect(()=>{document.documentElement.setAttribute("data-theme",f)},[f]),Be.useEffect(()=>{const fe=se=>{se.preventDefault(),Ne(se)},ie=()=>{Xe(!0),Ne(null),Gt(!1)};return window.addEventListener("beforeinstallprompt",fe),window.addEventListener("appinstalled",ie),()=>{window.removeEventListener("beforeinstallprompt",fe),window.removeEventListener("appinstalled",ie)}},[]),Be.useCallback(async()=>{if(ge)try{ge.prompt();const fe=await ge.userChoice;fe&&fe.outcome==="accepted"&&Xe(!0),Ne(null);return}catch{}Gt(!0)},[ge]),Be.useEffect(()=>{const fe=s.current,ie=Bi(),se=()=>{r.current||(Oi()&&Wn("HEARTBEAT",{tabId:fe},1500).then(ve=>{ve&&ve.terminated&&(r.current=!0,t(!0))}),ie||fetch("/api/vpn/heartbeat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tabId:fe}),keepalive:!0}).then(ve=>ve.json()).then(ve=>{ve&&ve.terminated&&(r.current=!0,t(!0))}).catch(()=>{}))};ie||fetch("/api/vpn/tab-open",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tabId:fe}),keepalive:!0}).catch(()=>{});const be=setInterval(se,2500),Fe=()=>{if(!r.current&&(Oi()&&!ie&&Wn("TAB_CLOSED",{tabId:fe,reason:"tab_dismissed"},800),!ie))try{const ve=new Blob([JSON.stringify({tabId:fe,reason:"tab_dismissed"})],{type:"application/json"});navigator.sendBeacon("/api/vpn/tab-closed",ve)}catch{fetch("/api/vpn/tab-closed",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tabId:fe,reason:"tab_dismissed"}),keepalive:!0}).catch(()=>{})}};return window.addEventListener("pagehide",Fe),window.addEventListener("beforeunload",Fe),()=>{clearInterval(be),window.removeEventListener("pagehide",Fe),window.removeEventListener("beforeunload",Fe)}},[]),Be.useEffect(()=>{let fe=!1;async function ie(){const Fe=await Wn("GET_STATUS",{},2e3);if(fe||wt.current||!Fe||!Fe.ok)return!1;const ve=Fe.state||Fe.status;if(!ve)return!1;if(ve.vpnProtocol&&_(ve.vpnProtocol),ve.autoConnectOnStartup!==void 0&&x(!!ve.autoConnectOnStartup),ve.dynamicIpRotation!==void 0&&U(!!ve.dynamicIpRotation),ve.autoCutoffOnTabClose!==void 0&&R(!!ve.autoCutoffOnTabClose),ve.versionRestricted!==void 0&&Xt(K=>({...K,restricted:!!ve.versionRestricted,minRequiredVersion:ve.minRequiredVersion||ve.latestVersion||K.minRequiredVersion,latestVersion:ve.latestVersion||ve.minRequiredVersion||K.latestVersion,title:ve.restrictionTitle||K.title,message:ve.restrictionMessage||K.message})),Fe.realIpInfo||ve.realIpInfo){const K=Fe.realIpInfo||ve.realIpInfo,Ue=Xn(K.country||K.countryIso2);X(_e=>({..._e,...K,country:K.country||K.countryIso2||_e.country,coordinates:K.coordinates||(Ue==null?void 0:Ue.coordinates)||_e.coordinates||{lat:23.8103,lng:90.4125}}))}const Ee=ve.vpnState||ve.state||"Disconnected";if(Ee==="Connected"){const K=ve.geoCountryIso2||ve.statusCountryIso2||ve.iso||"US",Ue=ve.uiLockedLocation||ve.iso||K;W(_e=>({..._e,state:"Connected",statusReady:!0,statusIp:ve.statusIp||_e.statusIp,statusCountryIso2:K,statusCountryName:ve.geoCountryName||ve.statusCountryName||ve.countryName||_e.statusCountryName,statusCity:ve.statusCity||ve.city||_e.statusCity,statusIsp:ve.statusIsp||ve.isp||_e.statusIsp,statusAsn:ve.statusAsn||ve.asn||_e.statusAsn,geoMismatch:!!ve.geoMismatch,geoCountryName:ve.geoCountryName||"",geoVerified:!!(ve.geoVerifiedIp||ve.statusIp),uiLockedLocation:Ue,connectionStartedTimestamp:ve.connectedAt||ve.connectionStartedTimestamp||_e.connectionStartedTimestamp||Date.now(),effectiveProtocolLabel:ve.protocol||_e.effectiveProtocolLabel,tunnelMode:ve.tunnelMode||"Lucifer Standalone Extension Tunnel",realTunnelActive:!0})),ne(Ue)}else if(Ee==="Disconnected"){const K=Fe.realIpInfo||ve.realIpInfo||B;W(Ue=>({...Ue,state:"Disconnected",statusReady:!0,statusIp:K.ip||Ue.statusIp,statusCountryIso2:K.country||K.countryIso2||Ue.statusCountryIso2,statusCountryName:K.countryName||Ue.statusCountryName,statusCity:K.city||Ue.statusCity,statusIsp:K.isp||Ue.statusIsp,statusAsn:K.asn||Ue.statusAsn,uiLockedLocation:"",connectionStartedTimestamp:null,tunnelMode:"Disconnected",realTunnelActive:!1}))}return!0}async function se(){var Fe,ve;if(Bi()){await ie();return}try{const Ee=await fetch("/api/vpn/status");if(!Ee.ok){Oi()&&await ie();return}const K=await Ee.json();if(fe)return;if(L(!!(((Fe=K.status)==null?void 0:Fe.qtServiceConnected)??!0)),(((ve=K.status)==null?void 0:ve.terminatedTabIds)||[]).includes(s.current)){r.current||(r.current=!0,t(!0));return}if(K.realIpInfo){const _e=Xn(K.realIpInfo.country);X(V=>({...V,...K.realIpInfo,coordinates:K.realIpInfo.coordinates||(_e==null?void 0:_e.coordinates)||V.coordinates||{lat:23.8103,lng:90.4125}}))}if(K.status&&!wt.current){const _e=!!K.status.qtServiceConnected;if(!_e&&Oi()&&await ie())return;if(!_e&&K.status.state==="Disconnected"){W(V=>V.state==="Connected"?V:{...V,state:"Disconnected",statusReady:!0,statusIp:K.status.statusIp||V.statusIp,statusCountryIso2:K.status.statusCountryIso2||V.statusCountryIso2,statusCountryName:K.status.statusCountryName||V.statusCountryName,statusCity:K.status.statusCity??V.statusCity,statusIsp:K.status.statusIsp??V.statusIsp,statusAsn:K.status.statusAsn??V.statusAsn});return}W(V=>({...V,state:K.status.state||V.state,statusReady:!!(K.status.statusReady??!0),statusIp:K.status.statusIp||V.statusIp,statusCountryIso2:K.status.statusCountryIso2||V.statusCountryIso2,statusCountryName:K.status.statusCountryName||V.statusCountryName,statusCity:K.status.statusCity??V.statusCity,statusIsp:K.status.statusIsp??V.statusIsp,statusAsn:K.status.statusAsn??V.statusAsn,geoMismatch:!!K.status.geoMismatch,geoCountryName:K.status.geoCountryName||"",geoVerified:!!K.status.geoVerifiedIp,uiLockedLocation:K.status.uiLockedLocation!==void 0?K.status.uiLockedLocation:V.uiLockedLocation,connectionStartedTimestamp:K.status.connectionStartedTimestamp||V.connectionStartedTimestamp,effectiveProtocol:K.status.effectiveProtocol||V.effectiveProtocol,effectiveProtocolLabel:K.status.effectiveProtocolLabel||V.effectiveProtocolLabel,tunnelInternalIp:K.status.tunnelInternalIp||V.tunnelInternalIp,tunnelMode:K.status.tunnelMode||V.tunnelMode,realTunnelActive:!!K.status.realTunnelActive})),K.status.uiLockedLocation&&K.status.state==="Connected"&&ne(K.status.uiLockedLocation)}}catch{Oi()&&await ie()}}se();const be=setInterval(se,2e3);return()=>{fe=!0,clearInterval(be)}},[B]),Be.useEffect(()=>{if(H.state!=="Connected"||!H.connectionStartedTimestamp){Q(0);return}const fe=setInterval(()=>{const ie=Math.max(0,Math.floor((Date.now()-H.connectionStartedTimestamp)/1e3));Q(ie),O(se=>se+Math.floor(16400+Math.random()*44e3)),Ce(se=>se+Math.floor(5800+Math.random()*18200))},1e3);return()=>clearInterval(fe)},[H.state,H.connectionStartedTimestamp]);const k=Be.useCallback(fe=>{ne(fe);const ie=Xn(fe);H.state==="Disconnected"&&ie&&!Bi()&&fetch("/api/vpn/prefetch",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({iso:fe})}).catch(()=>{})},[H.state]),w=Be.useCallback(async fe=>{const ie=fe||j||"US",se=Xn(ie);if(!se)return;ne(ie),r.current=!1,t(!1),l(""),It.current&&clearTimeout(It.current),wt.current=!0;const be=M?"OpenVPN_TCP":v==="Auto"?"WireGuard":v,Fe=M?"OpenVPN TCP (Streaming)":FA[v]||"Lucifer LinkX (WireGuard)";G(!1),W(ve=>({...ve,state:"Connecting",error:!1,uiLockedLocation:ie,effectiveProtocol:be,effectiveProtocolLabel:Fe})),It.current=setTimeout(()=>{G(!0)},450);try{if(Bi()){const Ee=await Wn("CONNECT_VPN",{iso:se.iso,countryName:se.name,city:se.city,isp:se.isp,asn:se.asn,protocol:v,protocolLabel:Fe,isStreamingMode:M,tabId:s.current,standalone:!0},14e3);if(It.current&&clearTimeout(It.current),G(!1),Ee&&Ee.ok&&Ee.status){const K=Ee.status;W(Ue=>({...Ue,state:"Connected",error:!1,statusReady:!0,statusIp:K.statusIp||se.gatewayIp,statusCountryIso2:K.statusCountryIso2||se.iso,statusCountryName:K.statusCountryName||se.name,statusCity:K.statusCity||K.city||se.city,statusIsp:K.statusIsp||K.isp||se.isp,statusAsn:K.statusAsn||K.asn||se.asn,geoMismatch:!!K.geoMismatch,geoCountryName:K.geoCountryName||"",geoVerified:!!(K.geoVerifiedIp||K.statusIp),uiLockedLocation:se.iso,connectionStartedTimestamp:K.connectionStartedTimestamp||Date.now(),effectiveProtocol:be,effectiveProtocolLabel:Fe,tunnelMode:K.tunnelMode||"Lucifer Standalone Extension Tunnel",realTunnelActive:!0})),O(24576),Ce(8192)}else l((Ee==null?void 0:Ee.error)||"Could not establish the VPN tunnel."),W(K=>({...K,state:"Disconnected",error:"Failed",uiLockedLocation:"",connectionStartedTimestamp:null,tunnelMode:"Disconnected",realTunnelActive:!1}));return}const ve=await fetch("/api/vpn/connect",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({iso:se.iso,protocol:v,isStreamingMode:M,tabId:s.current})});if(It.current&&clearTimeout(It.current),G(!1),ve.ok){const Ee=await ve.json();if(!Ee.ok){if(Ee.superseded)r.current=!0,t(!0);else{l(Ee.error||"Could not establish the VPN tunnel.");const V=Ee.status;W(Oe=>({...Oe,state:"Disconnected",error:"Failed",uiLockedLocation:"",connectionStartedTimestamp:null,tunnelMode:"Disconnected",realTunnelActive:!1,statusIp:(V==null?void 0:V.statusIp)||Oe.statusIp}))}return}l("");const K=Ee.status,Ue=(K==null?void 0:K.connectionStartedTimestamp)||Date.now();let _e=null;if(lt||Oi()){const V=await Wn("CONNECT_VPN",{iso:se.iso,countryName:se.name,city:(K==null?void 0:K.statusCity)||se.city,isp:(K==null?void 0:K.statusIsp)||se.isp,asn:(K==null?void 0:K.statusAsn)||se.asn,protocolLabel:Fe,proxyCandidates:Ee.proxyCandidates||[],proxyAuth:Ee.proxyAuth||null,gatewayIp:(K==null?void 0:K.statusIp)||Ee.gatewayIp,tabId:s.current,origin:window.location.origin},12e3);if(V&&V.ok&&V.status)_e=V.status,Et(!0);else if(!(K!=null&&K.qtServiceConnected)&&V&&V.error){l(V.error),W(Oe=>({...Oe,state:"Disconnected",error:"Failed",uiLockedLocation:"",connectionStartedTimestamp:null,tunnelMode:"Disconnected",realTunnelActive:!1}));return}}W(V=>({...V,state:"Connected",error:!1,statusReady:!0,statusIp:(_e==null?void 0:_e.statusIp)||(K==null?void 0:K.statusIp)||V.statusIp,statusCountryIso2:(_e==null?void 0:_e.statusCountryIso2)||(K==null?void 0:K.statusCountryIso2)||se.iso,statusCountryName:(_e==null?void 0:_e.statusCountryName)||(K==null?void 0:K.statusCountryName)||se.name,statusCity:(_e==null?void 0:_e.statusCity)||(_e==null?void 0:_e.city)||(K?K.statusCity:se.city),statusIsp:(_e==null?void 0:_e.statusIsp)||(_e==null?void 0:_e.isp)||(K?K.statusIsp:se.isp),statusAsn:(_e==null?void 0:_e.statusAsn)||(_e==null?void 0:_e.asn)||(K?K.statusAsn:se.asn),geoMismatch:!!((_e==null?void 0:_e.geoMismatch)??(K==null?void 0:K.geoMismatch)),geoCountryName:(_e==null?void 0:_e.geoCountryName)||(K==null?void 0:K.geoCountryName)||"",geoVerified:!!(_e!=null&&_e.geoVerifiedIp||K!=null&&K.geoVerifiedIp||_e),uiLockedLocation:se.iso,connectionStartedTimestamp:Ue,effectiveProtocol:be,effectiveProtocolLabel:Fe,tunnelInternalIp:(K==null?void 0:K.tunnelInternalIp)||"10.7.1.134/32",tunnelMode:(_e==null?void 0:_e.tunnelMode)||(K==null?void 0:K.tunnelMode)||"Lucifer Kernel Tunnel (Active)",realTunnelActive:!!((_e==null?void 0:_e.realTunnelActive)??(K==null?void 0:K.realTunnelActive)??!0)})),O(24576),Ce(8192)}}catch{It.current&&clearTimeout(It.current),G(!1)}finally{wt.current=!1}},[j,M,v,lt]),re=Be.useCallback(async()=>{It.current&&clearTimeout(It.current),wt.current=!0,G(!1),W(fe=>({...fe,state:"Disconnecting"}));try{if((lt||Oi())&&await Wn("DISCONNECT_VPN",{tabId:s.current,force:Bi()},2500),!Bi()){const fe=await fetch("/api/vpn/disconnect",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tabId:s.current})}),ie=fe.ok?await fe.json():null;if(ie&&ie.ok===!1){wt.current=!1;return}}W(fe=>({...fe,state:"Disconnected",error:!1,statusReady:!0,statusIp:B.ip,statusCountryIso2:B.country,statusCountryName:B.countryName,statusCity:B.city,statusIsp:B.isp,statusAsn:B.asn,uiLockedLocation:"",connectionStartedTimestamp:null,tunnelMode:"Disconnected",realTunnelActive:!1}))}catch{W(fe=>({...fe,state:"Disconnected",uiLockedLocation:"",connectionStartedTimestamp:null,tunnelMode:"Disconnected",realTunnelActive:!1}))}finally{wt.current=!1,O(0),Ce(0),De(null)}},[B,lt]),he=Be.useCallback(()=>{H.state==="Connected"||H.state==="Connecting"||H.state==="Reconnecting"?re():H.state==="Disconnected"&&w(j)},[H.state,j,w,re]),ye=Be.useCallback(async()=>{le(!0);try{if(Bi()||(lt||Oi())&&!E){const se=await Wn("VERIFY_IP",{},5e3);if(se&&se.ok&&se.ip){De(se),W(be=>({...be,statusIp:se.ip,statusCity:se.city||be.statusCity,statusIsp:se.isp||be.statusIsp,statusAsn:se.asn||be.statusAsn})),le(!1);return}}const ie=await fetch("/api/vpn/verify-ip");if(ie.ok){const se=await ie.json();De(se),se.ip&&W(be=>({...be,statusIp:se.ip,statusCity:se.city||be.statusCity,statusIsp:se.isp||be.statusIsp,statusAsn:se.asn||be.statusAsn})),le(!1);return}}catch{}const fe=Xn(H.statusCountryIso2);De({ip:H.statusIp,country:H.statusCountryIso2,countryName:H.statusCountryName,city:H.statusCity,isp:H.statusIsp,asn:H.statusAsn,coordinates:(fe==null?void 0:fe.coordinates)||{lat:23.8103,lng:90.4125},dnsServers:H.state==="Connected"?["1.1.1.1","1.0.0.1"]:["8.8.8.8"],isVpnActive:H.state==="Connected",tunnelProtocol:H.state==="Connected"?H.effectiveProtocolLabel:"Direct",verifiedAt:new Date().toISOString()}),le(!1)},[H,lt,E]),Pe=H.state==="Connected";return T.jsxs("div",{className:"u-app-fullscreen",children:[T.jsxs("nav",{"aria-label":"Primary Navigation",className:"u-nav-rail",children:[T.jsxs("button",{onClick:()=>d("vpn"),className:"u-nav-brand-btn",title:"Lucifer Tunnel 3D Dashboard","aria-label":"Lucifer Tunnel Home",children:[T.jsx("img",{src:"/icons/icon-192.png",alt:"Lucifer Tunnel",className:"u-nav-brand-logo",style:{borderRadius:"50%",filter:Pe?"drop-shadow(0 0 10px rgba(16, 185, 129, 0.55))":"drop-shadow(0 0 8px rgba(244, 63, 94, 0.55))"}}),T.jsx("span",{className:"u-nav-brand-title",children:"Lucifer Tunnel"})]}),T.jsxs("div",{className:"u-nav-center",children:[T.jsxs("button",{onClick:()=>d("vpn"),"aria-current":u==="vpn"?"page":void 0,className:"u-nav-tab-btn",style:{border:u==="vpn"?"1px solid rgba(59, 130, 246, 0.45)":"1px solid var(--uv-border)",backgroundColor:u==="vpn"?"rgba(59, 130, 246, 0.18)":"var(--uv-surface-card)",color:u==="vpn"?"var(--uv-text-heading)":"var(--uv-text-secondary)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",position:"relative",transition:"background-color 150ms ease, color 150ms ease"},children:[T.jsx(n_,{size:17,color:Pe?"#10B981":u==="vpn"?"#60A5FA":"currentColor","aria-hidden":"true"}),T.jsx("span",{style:{fontSize:11,fontWeight:700},children:"VPN"}),T.jsx("span",{"aria-hidden":"true",className:"u-nav-status-dot",style:{width:6,height:6,borderRadius:"50%",backgroundColor:Pe?"#10B981":"#F43F5E"}})]}),T.jsx("button",{onClick:()=>d("settings"),"aria-current":u==="settings"?"page":void 0,title:"Settings","aria-label":"Settings",className:"u-nav-icon-btn",style:{border:u==="settings"?"1px solid rgba(59, 130, 246, 0.5)":"1px solid var(--uv-border)",backgroundColor:u==="settings"?"rgba(59, 130, 246, 0.2)":"var(--uv-surface-card)",color:u==="settings"?"#60A5FA":"var(--uv-text-secondary)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"background-color 150ms ease, color 150ms ease, border-color 150ms ease"},children:T.jsx(J0,{size:17,color:u==="settings"?"#60A5FA":"currentColor","aria-hidden":"true"})}),T.jsxs("button",{onClick:()=>d("ip_logs"),"aria-current":u==="ip_logs"?"page":void 0,title:"IP & Logs","aria-label":"IP & Logs",className:"u-nav-tab-btn",style:{border:u==="ip_logs"?"1px solid rgba(59, 130, 246, 0.5)":"1px solid var(--uv-border)",backgroundColor:u==="ip_logs"?"rgba(59, 130, 246, 0.2)":"var(--uv-surface-card)",color:u==="ip_logs"?"#38BDF8":"var(--uv-text-secondary)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"background-color 150ms ease, color 150ms ease, border-color 150ms ease"},children:[T.jsx(Y0,{size:16,color:u==="ip_logs"?"#38BDF8":"currentColor","aria-hidden":"true"}),T.jsx("span",{style:{fontSize:9.5,fontWeight:700,whiteSpace:"nowrap"},children:"IP & Logs"})]})]}),T.jsx("div",{className:"u-nav-bottom",children:T.jsx("button",{onClick:()=>p(fe=>fe==="dark"?"light":"dark"),className:"u-nav-icon-btn",title:f==="dark"?"Switch to Light Mode":"Switch to Dark Cyber Mode","aria-label":f==="dark"?"Switch to Light Mode":"Switch to Dark Mode",style:{border:"1px solid var(--uv-border)",backgroundColor:"var(--uv-surface-card)",color:"var(--uv-text-body)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"},children:f==="dark"?T.jsx(Q0,{size:16,color:"#FBBF24","aria-hidden":"true"}):T.jsx($0,{size:16,color:"#3B82F6","aria-hidden":"true"})})})]}),u==="vpn"?T.jsx(oA,{vpnStatus:H,realIpInfo:B,locations:Oc,allLocations:Oc,showExtendedCatalog:!1,onToggleExtendedCatalog:()=>F(!1),selectedLocationIso:j,onSelectLocation:k,onRequestConnection:w,onConnectButtonClick:he,isStreamingMode:M,onSetStreamingMode:A,connectionElapsedFormatted:OA(ue),lookingForBestServer:te,onRefreshLocations:()=>{},serviceBridgeConnected:E,rxBytes:ee,txBytes:de,onVerifyIp:ye,ipVerificationResult:Te,isVerifyingIp:Ye,cameraMode:y,onChangeCameraMode:S,theme:f}):u==="ip_logs"?T.jsx(UA,{vpnStatus:H,realIpInfo:B,selectedLocationIso:j,onVerifyIp:ye,ipVerificationResult:Te,isVerifyingIp:Ye}):T.jsx(PA,{vpnProtocol:v,onChangeProtocol:fe=>{_(fe),Wn("UPDATE_SETTINGS",{vpnProtocol:fe})},isStreamingMode:M,appAutoStart:m,onToggleAppAutoStart:()=>{x(fe=>{const ie=!fe;return Wn("UPDATE_SETTINGS",{autoConnectOnStartup:ie}),ie})},dynamicIpRotation:P,onToggleDynamicIp:()=>{U(fe=>{const ie=!fe;return Wn("UPDATE_SETTINGS",{dynamicIpRotation:ie}),ie})},autoCutoffOnTabClose:b,onToggleAutoCutoff:()=>{R(fe=>{const ie=!fe;return Wn("UPDATE_SETTINGS",{autoCutoffOnTabClose:ie}),ie})},onSendReport:()=>{},theme:f,onToggleTheme:()=>p(fe=>{const ie=fe==="dark"?"light":"dark";return Wn("UPDATE_SETTINGS",{theme:ie}),ie}),cameraMode:y,onChangeCameraMode:fe=>{S(fe),Wn("UPDATE_SETTINGS",{cameraMode:fe})},serviceBridgeConnected:E}),Ot&&T.jsx("div",{className:"u-modal-backdrop",onClick:()=>xt(!1),children:T.jsxs("div",{className:"u-dialog-card",style:{width:"92%",maxWidth:480},onClick:fe=>fe.stopPropagation(),children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12,marginBottom:12},children:[T.jsx("div",{style:{width:40,height:40,borderRadius:11,background:"rgba(16, 185, 129, 0.16)",border:"1px solid rgba(16, 185, 129, 0.4)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0},children:T.jsx(Z0,{size:20,color:"#34D399","aria-hidden":"true"})}),T.jsxs("div",{children:[T.jsx("h3",{style:{fontSize:17,fontWeight:700,color:"var(--uv-text-heading)"},children:"Lucifer Tunnel Standalone Extension"}),T.jsx("span",{style:{fontSize:12,color:"var(--uv-text-secondary)"},children:"100% Standalone Browser VPN with Segmented Controls & Obfuscated Build"})]})]}),T.jsx("p",{style:{fontSize:13,color:"var(--uv-text-body)",lineHeight:1.55,marginBottom:14},children:lt?"The Lucifer Tunnel Browser Extension is active! You can control all 82+ countries, 3D Globe, IP verification, WireGuard/OpenVPN configs, and Settings directly from the extension icon in your browser toolbar.":"Install the standalone Manifest V3 browser extension to connect/disconnect countries directly from your browser toolbar:"}),T.jsxs("div",{style:{backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)",borderRadius:10,padding:"12px 14px",fontSize:12,color:"var(--uv-text-body)",lineHeight:1.65,marginBottom:16},children:[T.jsxs("div",{style:{marginBottom:6},children:[T.jsx("strong",{style:{color:"#60A5FA"},children:"Step 1:"})," Click"," ",T.jsx("strong",{children:"Download Extension (.zip)"})," below and extract the folder on your computer."]}),T.jsxs("div",{style:{marginBottom:6},children:[T.jsx("strong",{style:{color:"#60A5FA"},children:"Step 2:"})," Open"," ",T.jsx("code",{children:"chrome://extensions"})," (or ",T.jsx("code",{children:"edge://extensions"})," /"," ",T.jsx("code",{children:"brave://extensions"}),") and enable ",T.jsx("strong",{children:"Developer mode"})," in the top-right corner."]}),T.jsxs("div",{children:[T.jsx("strong",{style:{color:"#34D399"},children:"Step 3:"})," Click"," ",T.jsx("strong",{children:"Load unpacked"})," and select the extracted"," ",T.jsx("code",{children:"extension"})," folder."]})]}),T.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap"},children:[T.jsxs("a",{href:"/lucifer-tunnel-extension.zip",download:"lucifer-tunnel-extension.zip",className:"u-btn u-btn-primary",style:{textDecoration:"none",height:36,padding:"0 16px",fontSize:12},children:[T.jsx(Zl,{size:14,"aria-hidden":"true"}),T.jsx("span",{children:"Download Extension (.zip)"})]}),T.jsx("button",{className:"u-btn u-btn-secondary",onClick:()=>xt(!1),children:"Close"})]})]})}),mt&&T.jsx("div",{className:"u-modal-backdrop",onClick:()=>Gt(!1),children:T.jsxs("div",{className:"u-dialog-card",style:{width:"92%",maxWidth:440},onClick:fe=>fe.stopPropagation(),children:[T.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12,marginBottom:12},children:[T.jsx("img",{src:"/icons/icon-192.png",alt:"Lucifer Tunnel",style:{width:40,height:40,borderRadius:"50%"}}),T.jsxs("div",{children:[T.jsx("h3",{style:{fontSize:17,fontWeight:700,color:"var(--uv-text-heading)"},children:"Install Lucifer Tunnel App"}),T.jsx("span",{style:{fontSize:12,color:"var(--uv-text-secondary)"},children:"Standalone Desktop & Mobile Progressive Web App"})]})]}),T.jsx("p",{style:{fontSize:13,color:"var(--uv-text-body)",lineHeight:1.55,marginBottom:14},children:tt?"Lucifer Tunnel is already installed on your device! You can launch it directly from your desktop or home screen.":"You can install Lucifer Tunnel as a standalone application for instant one-click access:"}),!tt&&T.jsxs("div",{style:{backgroundColor:"var(--uv-surface-card)",border:"1px solid var(--uv-border)",borderRadius:10,padding:"12px 14px",fontSize:12,color:"var(--uv-text-body)",lineHeight:1.6,marginBottom:18},children:[T.jsxs("div",{style:{marginBottom:6},children:[T.jsx("strong",{style:{color:"#60A5FA"},children:"Desktop (Chrome / Edge / Brave):"})," Click the ",T.jsx("strong",{children:"Install Lucifer Tunnel"})," icon in the right side of your browser address bar, or open the browser menu (⋮) → ",T.jsx("strong",{children:"Install Lucifer Tunnel"}),"."]}),T.jsxs("div",{children:[T.jsx("strong",{style:{color:"#34D399"},children:"Mobile (Android / iOS):"})," Tap the browser menu or Share button and select ",T.jsx("strong",{children:"Add to Home Screen / Install App"}),"."]})]}),T.jsxs("div",{style:{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap"},children:[T.jsxs("a",{href:"/lucifer-tunnel.apk",download:"Lucifer-Tunnel.apk",className:"u-btn u-btn-primary",style:{textDecoration:"none",height:36,padding:"0 16px",fontSize:12},children:[T.jsx(Zl,{size:14,"aria-hidden":"true"}),T.jsx("span",{children:"Download Android APK (.apk)"})]}),T.jsx("button",{className:"u-btn u-btn-secondary",onClick:()=>Gt(!1),children:"Got it"})]})]})}),o&&!e&&T.jsxs("div",{role:"alert",className:"u-glass-card",style:{position:"fixed",top:16,left:"50%",transform:"translateX(-50%)",zIndex:90,padding:"10px 16px",borderRadius:12,border:"1px solid rgba(244, 63, 94, 0.5)",color:"var(--uv-text-heading)",fontSize:13,display:"flex",alignItems:"center",gap:12},children:[T.jsx("span",{children:o}),T.jsx("button",{className:"u-btn u-btn-secondary",onClick:()=>l(""),children:"Dismiss"})]}),e&&T.jsx("div",{className:"u-modal-backdrop",role:"alertdialog","aria-modal":"true",children:T.jsxs("div",{className:"u-dialog-card",style:{maxWidth:420,textAlign:"center"},children:[T.jsx("h2",{style:{fontSize:18,marginBottom:8},children:"VPN session ended"}),T.jsx("p",{style:{fontSize:13,color:"var(--uv-text-secondary)",marginBottom:18},children:"The VPN was connected from another window or browser. Only one session can be active at a time, so this session was disconnected."}),T.jsx("div",{style:{display:"flex",gap:10,justifyContent:"center"},children:T.jsx("button",{className:"u-btn u-btn-primary",onClick:()=>w(j),children:"Use VPN in this window"})})]})}),Dn()&&Wt.visible&&!At.restricted&&T.jsx("div",{role:"dialog","aria-live":"polite","aria-label":`New Update V${Wt.latestVersion} Available`,style:{position:"fixed",inset:0,zIndex:9990,backgroundColor:"rgba(6, 10, 22, 0.72)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center",padding:18},children:T.jsxs("div",{className:"u-dialog-card",style:{width:"92%",maxWidth:360,textAlign:"center",padding:"22px 20px 18px 20px",border:"1px solid rgba(59, 130, 246, 0.52)",boxShadow:"0 22px 54px rgba(0, 0, 0, 0.8), 0 0 32px rgba(59, 130, 246, 0.25)",position:"relative",overflow:"hidden"},children:[T.jsx("img",{src:"/icons/icon-192.png",alt:"Lucifer Tunnel",style:{width:56,height:56,borderRadius:"50%",margin:"0 auto 10px auto",display:"block",boxShadow:"0 0 20px rgba(244, 63, 94, 0.5)"}}),T.jsxs("span",{style:{display:"inline-block",padding:"3px 11px",borderRadius:999,fontSize:10.5,fontWeight:800,letterSpacing:"0.05em",textTransform:"uppercase",backgroundColor:"rgba(59, 130, 246, 0.18)",border:"1px solid rgba(59, 130, 246, 0.48)",color:"#60A5FA",marginBottom:8},children:["New Version V",Wt.latestVersion," Available"]}),T.jsxs("h3",{style:{fontSize:17,fontWeight:800,color:"#F8FAFC",marginBottom:6},children:["Update Available (V",Wt.latestVersion,")"]}),T.jsxs("p",{style:{fontSize:12.5,color:"var(--uv-text-secondary)",lineHeight:1.5,marginBottom:14},children:["A new Lucifer Tunnel update (",T.jsxs("strong",{children:["V",Wt.latestVersion]}),") is ready! Current version: ",os,"."]}),T.jsxs("button",{type:"button",className:"u-btn u-btn-primary",style:{width:"100%",height:36,fontSize:12.5,fontWeight:800},onClick:async()=>{Nt.current&&clearTimeout(Nt.current),_t(fe=>({...fe,visible:!1})),await za(Wt.latestVersion)},children:[T.jsx(Zl,{size:14,"aria-hidden":"true"}),T.jsxs("span",{children:["Update Now to V",Wt.latestVersion]})]})]})},`mobile-update-popup-${Wt.popupKey}`),At.restricted&&T.jsx("div",{className:"u-modal-backdrop",role:"alertdialog","aria-modal":"true",style:{zIndex:99999,backgroundColor:"rgba(5, 8, 18, 0.96)",backdropFilter:"blur(18px)"},children:T.jsxs("div",{className:"u-dialog-card",style:{width:"92%",maxWidth:420,textAlign:"center",padding:"28px 22px",border:"1px solid rgba(244, 63, 94, 0.45)",boxShadow:"0 24px 64px rgba(0, 0, 0, 0.85), 0 0 40px rgba(244, 63, 94, 0.2)"},children:[T.jsx("img",{src:"/icons/icon-192.png",alt:"Lucifer Tunnel",style:{width:68,height:68,borderRadius:"50%",margin:"0 auto 14px auto",display:"block",boxShadow:"0 0 24px rgba(244, 63, 94, 0.55)"}}),T.jsxs("span",{style:{display:"inline-block",padding:"4px 12px",borderRadius:999,fontSize:10.5,fontWeight:800,letterSpacing:"0.06em",textTransform:"uppercase",backgroundColor:"rgba(244, 63, 94, 0.18)",border:"1px solid rgba(244, 63, 94, 0.48)",color:"#FB7185",marginBottom:10},children:["Update Required • Minimum V",At.minRequiredVersion||At.latestVersion]}),T.jsx("h2",{style:{fontSize:19,fontWeight:800,color:"#F8FAFC",marginBottom:8},children:At.title||"Mandatory Update Required"}),T.jsx("p",{style:{fontSize:13,color:"var(--uv-text-secondary)",lineHeight:1.55,marginBottom:20},children:At.message||"This version of Lucifer Tunnel is no longer supported. Please update to the latest version to continue using the VPN."}),T.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:10},children:[T.jsxs("button",{className:"u-btn u-btn-primary",style:{width:"100%",height:42,fontSize:13.5,fontWeight:800,background:"linear-gradient(135deg, #E11D48, #BE123C)",borderColor:"rgba(251, 113, 133, 0.5)"},onClick:async()=>{Xt(fe=>({...fe,downloading:!0})),await za(At.latestVersion||At.minRequiredVersion)},children:[T.jsx(Zl,{size:15,"aria-hidden":"true"}),T.jsx("span",{children:At.downloading?Dn()?"Downloading APK — Check Notifications...":"Downloading Update Package...":`Update Now to V${At.latestVersion||At.minRequiredVersion}`})]}),T.jsxs("button",{className:"u-btn u-btn-secondary",style:{width:"100%",height:36,fontSize:12},onClick:async()=>{const fe=await Ya(!0);fe&&fe.versionRestricted===!1&&Xt(ie=>({...ie,restricted:!1}))},children:["Re-check Version Status (",Dn()?os:Vv,")"]})]})]})})]})}Hy.createRoot(document.getElementById("root")).render(T.jsx(j0.StrictMode,{children:T.jsx(kA,{})}));"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").catch(()=>{})});
